/* 型態雷達 PWA — ⓪ 方向入口 → ① 型態選單 →（② 類股雷達、③ 個股下鑽：後續項目）
 * ② 類股雷達（RuleCard + RadarSweep + SectorTable）→ ③ 個股下鑽（StockRow + FundamentalChips）→ 個股詳情（K 線 + PatternOverlay）。
 * Static app: reads summary_latest.json / scan_latest.json produced by the box-side batch.
 * State lives in location.hash (#/long, #/short/w_bottom) so rotation / Split View never loses it (§18.2). */
(function () {
  "use strict";
  const $app = document.getElementById("app");
  const $banner = document.getElementById("banner");
  const DIR = { long: { label: "做多", arrow: "↑", cls: "long" }, short: { label: "做空", arrow: "↓", cls: "short" } };
  const STATE_ZH = { CONFIRMED: "確認突破", FORMING: "成形中", FAILED: "型態失敗", TARGET_HIT: "達滿足點", ENTRY: "進場",
                     HOLD: "續抱（參考）", EXIT_WARNING: "出場警示", EXIT: "出場訊號", WATCH: "觀望" };
  // 示意線形（卡面縮圖），x 0–100, y 0–40（y 往下）
  const SKETCH = {
    w_bottom: "0,5 20,32 40,14 60,31 80,12 100,2", bottom_reversal: "0,8 30,22 45,36 55,20 75,14 100,3",
    bottom_reversal_w: "0,5 20,28 40,12 60,36 75,18 100,2", bull_flag: "0,36 25,6 35,12 45,10 55,16 65,14 75,19 100,1",
    bear_flag: "0,4 25,34 35,28 45,30 55,24 65,26 75,21 100,39", m_top: "0,35 20,8 40,26 60,9 80,28 100,38",
    false_breakout: "0,30 25,14 45,22 60,6 72,20 100,36", hs_top: "0,36 15,16 30,24 50,4 70,24 85,16 100,38",
    hs_top_fake: "0,36 15,16 30,24 45,10 50,2 58,12 70,24 85,16 100,38", hs_bottom: "0,4 15,24 30,16 50,36 70,16 85,24 100,2",
    tri_top: "0,30 12,4 28,30 44,10 60,26 74,14 86,22 100,38", tri_bottom: "0,10 12,36 28,10 44,30 60,14 74,26 86,18 100,2",
    cis_base: "0,30 30,22 45,26 55,18 100,8", cis_exp: "0,26 30,24 50,22 60,16 100,6",
  };
  let SUMMARY = null, SCAN = null, FUND = null, OFFLINE = false;
  const CACHED_AT = {};
  const S = window.RadarStore || null;

  // ---------------------------------------------------------------- data（§14.5／§18.4：網路優先，失敗才回退 IndexedDB 快取；離線唯讀）
  async function getJSON(name) {
    try {
      const r = await fetch(name + "?t=" + Date.now(), { cache: "no-store" });
      if (!r.ok) throw new Error(r.status);
      const j = await r.json();
      if (r.headers.get("X-Radar-SW-Cache")) { OFFLINE = true; return j; }   // sw.js 離線回退（上次快取）→ 照樣標示離線唯讀
      if (S) S.cachePut(name, j);  // 記錄 cached_at；data_as_of 在 JSON 內
      return j;
    } catch (e) {
      OFFLINE = true;
      const rec = S && (await S.cacheGet(name));
      if (rec) { CACHED_AT[name] = rec.cached_at; return rec.json; }
      const c = self.caches && (await caches.open("radar-data").catch(() => null)); // P1 舊版快取（相容）
      const hit = c && (await c.match(name));
      if (hit) return hit.json();
      throw e;
    }
  }
  const tpe = (iso) => (iso ? new Date(new Date(iso).getTime() + 8 * 3600e3).toISOString().slice(0, 16).replace("T", " ") : "—");
  function staleBanner() {
    if (!SUMMARY) return;
    const msgs = [];
    if (OFFLINE) msgs.push(`離線模式，資料截至 ${SUMMARY.data_as_of}（台北時間）${CACHED_AT["summary_latest.json"] ? `・快取於 ${tpe(CACHED_AT["summary_latest.json"])}` : ""}`);
    const today = new Date(Date.now() + 8 * 3600e3).toISOString().slice(0, 10);
    if (OFFLINE && SUMMARY.data_as_of < today) msgs.push("可能已過期");
    if (OFFLINE) msgs.push("唯讀：不可掃描、回測、改規則、備份還原或寄信");
    $banner.hidden = !msgs.length; $banner.textContent = msgs.join("｜");
  }
  // 離線時擋下寫入類動作（§14.5）
  function guard() { if (OFFLINE || navigator.onLine === false) { alert("目前離線，無法執行"); return false; } return true; }

  // ---------------------------------------------------------------- helpers
  const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const fmt = (x, d = 2) => (x == null || isNaN(x) ? "—" : Number(x).toFixed(d));
  const stat = (pid, dir) => (SUMMARY.by_pattern[`${pid}|${dir}`] || {});
  const patternsFor = (dir) => SUMMARY.patterns.filter((p) => p.directions.includes(dir));
  function asofLine() {
    const f = SUMMARY.finished_at ? SUMMARY.finished_at.replace("T", " ").slice(0, 16) : "—"; // stored in Asia/Taipei
    return `資料日 ${SUMMARY.data_as_of}｜掃描完成 ${f}（台北時間）｜掃描 ${SUMMARY.universe} 檔`;
  }
  function go(hash) { if (location.hash !== hash) location.hash = hash; else render(); }

  // ---------------------------------------------------------------- ⓪ DirectionGate
  function renderGate() {
    const t = SUMMARY.totals;
    const btn = (d) => {
      const s = t[d] || {}, D = DIR[d];
      return `<button type="button" class="dir ${D.cls}" data-dir="${d}" aria-label="${D.label}，今日新命中 ${s.new_symbols ?? s.new ?? 0} 檔">
        <span class="arrow" aria-hidden="true">${D.arrow}</span>
        <span class="label">${D.label}</span>
        <span class="cnt">今日新命中<b class="num">${s.new_symbols ?? s.new ?? 0}</b>檔</span>
        <span class="sub">${s.new || 0} 個新訊號・成形中 ${s.forming || 0}・${patternsFor(d).length} 種型態</span>
      </button>`;
    };
    $app.innerHTML = `
      <div class="gate-head"><h1>型態<span>雷達</span></h1><div class="asof">${esc(asofLine())}</div></div>
      <div class="gate">${btn("long")}${btn("short")}</div>
      <p class="note">先選方向，再選型態。做多：W底、破底翻、破底翻（W底）、下飄旗形、頭肩底、收斂三角形底部、CIS 基準線／實驗組。
      做空：上飄旗形、M頭、假突破、頭肩頂、假突破（頭肩頂）、收斂三角形頭部、CIS 實驗組。</p>
      <nav class="tools-nav" aria-label="工具">
        <a class="btn" href="#/lab">📊 回測實驗室</a><a class="btn" href="#/watch">⭐ 觀察清單</a><a class="btn" href="#/markets">🌍 全球指數</a><a class="btn" href="#/etf/00631L">📈 00631L</a><a class="btn" href="#/alerts">✉️ 盤後警示</a>
        <a class="btn" href="#/editor">🧩 型態編輯器</a><a class="btn" href="#/backup">🔐 備份與還原</a><a class="btn" href="#/health">🩺 資料狀態</a><a class="btn" href="#/prefs">⚙️ 設定</a><a class="btn" href="#/appendix">📖 附錄</a></nav>`;
    if (window.RadarPages) RadarPages.gateFx(t);
    $app.querySelectorAll(".dir").forEach((b) => b.addEventListener("click", () => {
      const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
      b.classList.add("go");
      setTimeout(() => go(`#/${b.dataset.dir}`), reduce ? 0 : 220);
    }));
  }

  // ---------------------------------------------------------------- ① PatternMenu
  function sketch(pid, dir) {
    const col = dir === "long" ? "var(--long)" : "var(--short)";
    return `<svg viewBox="0 0 100 40" preserveAspectRatio="none" aria-hidden="true"><polyline points="${SKETCH[pid] || ""}"
      fill="none" stroke="${col}" stroke-width="2.2" vector-effect="non-scaling-stroke" stroke-linejoin="round"/></svg>`;
  }
  function renderMenu(dir) {
    const D = DIR[dir];
    const cards = patternsFor(dir).map((p) => {
      const s = stat(p.id, dir);
      const tag = p.role === "baseline" ? `<span class="tag base">基準線</span>` : p.role === "experiment" ? `<span class="tag exp">實驗組</span>` :
        `<span class="tag assume">補定義・待確認</span>`;
      const isCis = p.id.startsWith("cis");
      const extra = isCis ? `<span class="f">持有者參考：續抱 <b class="num">${s.hold || 0}</b> 警示 <b class="num">${s.exit_warning || 0}</b> 出場 <b class="num">${s.exit || 0}</b></span>`
        : `<span class="f">成形中 <b class="num">${s.forming || 0}</b></span><span class="f">近 10 日已確認 <b class="num">${s.active || 0}</b></span>`;
      return `<button type="button" class="card ${D.cls}" data-pid="${p.id}">
        <span class="t">${esc(p.name)}${isCis && dir === "short" ? "（空）" : isCis ? "（多）" : ""} ${tag}</span>
        ${sketch(p.id, dir)}
        <span class="stats"><span>今日 <b class="num">${s.new || 0}</b>檔</span>${extra}</span>
      </button>`;
    }).join("");
    $app.innerHTML = `
      <div class="bar">
        <button type="button" class="btn" id="home" aria-label="回方向入口">← 方向</button>
        <h2>${D.label}型態</h2>
        <span class="switch" role="group" aria-label="切換方向">
          <button type="button" class="long" aria-pressed="${dir === "long"}" data-dir="long">↑ 做多</button>
          <button type="button" class="short" aria-pressed="${dir === "short"}" data-dir="short">↓ 做空</button>
        </span>
      </div>
      <div class="asof">${esc(asofLine())}</div>
      ${dir === "short" ? `<p class="note short">做空：融券／借券費用假設 0，未計入；實際可否融券依交易所與券商公告。</p>` : ""}
      <div class="grid" style="margin-top:12px">${cards}</div>
      <p class="note">「今日」= 今日收盤確認的新訊號（蔡森招式：CONFIRMED；CIS：ENTRY）。蔡森十二招全部為補定義，參數待 Jay 確認；CIS 規則為二手摘錄、SMA 為工作假設。</p>`;
    $app.querySelector("#home").addEventListener("click", () => go("#/"));
    $app.querySelectorAll(".switch button").forEach((b) => b.addEventListener("click", () => go(`#/${b.dataset.dir}`)));
    $app.querySelectorAll(".card").forEach((c) => c.addEventListener("click", () => go(`#/${dir}/${c.dataset.pid}`)));
  }

  // ---------------------------------------------------------------- shared loaders
  async function needScan() { if (!SCAN) SCAN = await getJSON("scan_latest.json"); return SCAN; }
  async function needFund() { if (!FUND) { try { FUND = await getJSON("fundamentals_latest.json"); } catch (e) { FUND = { data: {}, notes: ["基本面資料無法載入"], failed: true }; } } return FUND; }
  const HIT = (s) => s.state === "ENTRY" || s.state === "CONFIRMED";
  const patternName = (pid) => (SUMMARY.patterns.find((x) => x.id === pid) || {}).name || pid;
  const stLabel = (h) => (h.state === "CONFIRMED" && !h.fresh ? `已確認（${h.confirmed_on}）` : STATE_ZH[h.state] || h.state);
  const lots = (x) => (x == null ? null : Math.round(x / 1000));
  const sectorName = (sc) => (sc === "ALL" ? "全部類股" : (SCAN.sector_names || {})[sc] || sc);

  // ---------------------------------------------------------------- 基本面規則（§8：必要／加分／關閉，預設全部關閉；門檻由 Jay 設定）
  const FFIELDS = [
    ["rev_yoy", "rev", "yoy", "月營收 YoY", "%", ">="], ["rev_mom", "rev", "mom", "月營收 MoM", "%", ">="], ["rev_cum_yoy", "rev", "cum_yoy", "累計營收 YoY", "%", ">="],
    ["eps_ytd", "fin", "eps_ytd", "EPS（本年累計）", "元", ">="], ["gross_margin", "fin", "gross_margin", "毛利率", "%", ">="],
    ["op_margin", "fin", "op_margin", "營益率", "%", ">="], ["net_margin", "fin", "net_margin", "淨利率", "%", ">="],
    ["roe_ann", "fin", "roe_ann", "ROE（本年累計年化）", "%", ">="], ["pe", "val", "pe", "本益比", "倍", "<="],
    ["pb", "val", "pb", "股價淨值比", "倍", "<="], ["dividend_yield", "val", "dividend_yield", "殖利率", "%", ">="],
  ];
  function loadRules() { try { return JSON.parse(localStorage.getItem("radar.fundRules") || "[]"); } catch (e) { return []; } }
  function saveRules(r) { localStorage.setItem("radar.fundRules", JSON.stringify(r)); if (S) S.save("fundamental_rules", { id: "default", name: "預設", rules_json: JSON.stringify(r) }).catch(() => {}); }
  const activeRules = () => loadRules().filter((r) => r.mode && r.mode !== "off" && r.value !== "" && r.value != null && !isNaN(r.value));
  function applyRules(snap, rules) { // mirrors pipeline/radar/fundamentals.apply_rules (tested in Python)
    let status = "pass", bonus = 0; const detail = [];
    for (const r of rules) {
      const F = FFIELDS.find((f) => f[0] === r.key); if (!F) continue;
      const v = ((snap || {})[F[1]] || {})[F[2]];
      if (v == null) { detail.push([r.key, "pending"]); if (r.mode === "required" && status === "pass") status = "pending"; continue; }
      const ok = (r.op || F[5]) === ">=" ? v >= +r.value : v <= +r.value;
      detail.push([r.key, ok ? "pass" : "fail"]);
      if (r.mode === "required" && !ok) status = "fail";
      if (r.mode === "bonus" && ok) bonus++;
    }
    return { status, bonus, detail };
  }
  const CHIP = { pass: ["通過", "ok"], fail: ["未通過", "bad"], pending: ["待補", "pend"] };
  function chip(res, rules) {
    if (!rules.length) return `<span class="chip off" title="未設定基本面條件（預設全部關閉）">未設條件</span>`;
    const [t, c] = CHIP[res.status];
    return `<span class="chip ${c}">${t}${res.bonus ? `＋${res.bonus}` : ""}</span>`;
  }

  // ---------------------------------------------------------------- ② 型態掃描（RuleCard + RadarSweep）＋ 類股雷達（SectorTable）
  const PARAM_ZH = { neckline_tol: "頸線容差", breakout_pct: "突破幅度", vol_mult: "量能倍數", min_span: "最短天數", max_span: "最長天數",
    breakout_window: "突破搜尋窗", confirm_window: "確認窗", track_days: "追蹤天數", zigzag_pct: "ZigZag 轉折幅度" };
  function ruleCard(pid, doc) {
    const p = doc.params || {}, own = p[pid] || {}, cm = p.common || {};
    const kv = (o) => Object.entries(o).filter(([, v]) => typeof v !== "object").map(([k, v]) => `<span class="kv"><i>${esc(PARAM_ZH[k] || k)}</i><b class="num">${esc(v)}</b></span>`).join("");
    const role = (SUMMARY.patterns.find((x) => x.id === pid) || {}).role;
    return `<details class="rule"><summary>規則定義與參數 <span class="tag ${role === "baseline" ? "base" : role === "experiment" ? "exp" : "assume"}">${role === "baseline" ? "基準線（二手摘錄）" : role === "experiment" ? "實驗組" : "補定義・待 Jay 確認"}</span></summary>
      <div class="kvs">${kv(own)}</div><div class="kvs muted">${kv(cm)}${pid.startsWith("cis") ? kv(p.cis_common || {}) : ""}</div>
      <p class="note">參數為工程化預設（SPEC 待 Jay 確認／補定義），不是市場統計結果。</p></details>`;
  }
  function radarSVG(rows, dir) {
    const n = rows.length || 1, R = 140, cx = 160, cy = 160, maxS = Math.max(1, ...rows.map((r) => r.score));
    const col = dir === "long" ? "0,240,255" : "255,43,214";
    const wedges = rows.map((r, i) => {
      const a0 = (i / n) * 2 * Math.PI - Math.PI / 2, a1 = ((i + 1) / n) * 2 * Math.PI - Math.PI / 2;
      const p = (a, rr) => `${(cx + rr * Math.cos(a)).toFixed(1)},${(cy + rr * Math.sin(a)).toFixed(1)}`;
      const op = r.hits || r.forming ? 0.12 + 0.78 * (r.score / maxS) : 0.04;
      const dot = r.is_hit ? `<circle class="blip" data-i="${i}" cx="${p((a0 + a1) / 2, R * 0.72).split(",")[0]}" cy="${p((a0 + a1) / 2, R * 0.72).split(",")[1]}" r="4" />` : "";
      return `<path data-i="${i}" class="wedge${r.is_hit ? " hit" : ""}" d="M${cx},${cy} L${p(a0, R)} A${R},${R} 0 0 1 ${p(a1, R)} Z" fill="rgba(${col},${op.toFixed(2)})"><title>${esc(r.sector_name)}：${r.hits}/${r.n_members}，綜合分 ${fmt(r.score, 1)}</title></path>${dot}`;
    }).join("");
    return `<svg class="radar ${dir}" viewBox="0 0 320 320" role="img" aria-label="類股雷達圓盤">
      <defs><linearGradient id="sw" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="rgba(${col},0)"/><stop offset="1" stop-color="rgba(${col},.55)"/></linearGradient></defs>
      ${wedges}
      ${[0.33, 0.66, 1].map((k) => `<circle cx="${cx}" cy="${cy}" r="${R * k}" class="ring"/>`).join("")}
      <g class="sweep"><path d="M${cx},${cy} L${cx + R},${cy} A${R},${R} 0 0 0 ${(cx + R * Math.cos(-0.6)).toFixed(1)},${(cy + R * Math.sin(-0.6)).toFixed(1)} Z" fill="url(#sw)"/></g>
      <circle class="prog-bg" cx="${cx}" cy="${cy}" r="152"/><circle class="prog" cx="${cx}" cy="${cy}" r="152" pathLength="100" stroke-dasharray="0 100" transform="rotate(-90 ${cx} ${cy})"/>
    </svg>`;
  }
  async function renderSectors(dir, pid) {
    const p = SUMMARY.patterns.find((x) => x.id === pid);
    if (!p || !p.directions.includes(dir)) return go(`#/${dir}`);
    $app.innerHTML = `<p class="loading">載入掃描結果…</p>`;
    try { await needScan(); } catch (e) { $app.innerHTML = `<p class="loading">掃描結果無法載入（離線且無快取）。</p>`; return; }
    const D = DIR[dir], isCis = pid.startsWith("cis");
    const all = SCAN.hits.filter((h) => h.patternId === pid && h.direction === dir);
    const cnt = (f) => all.filter(f).length;
    const members = SCAN.sector_members || {};
    const got = Object.fromEntries((SCAN.sectors || []).filter((r) => r.pattern_id === pid && r.direction === dir).map((r) => [r.sector_code, r]));
    const rows = Object.entries(members).map(([sc, n]) => got[sc] || { sector_code: sc, sector_name: sectorName(sc), n_members: n, hits: 0, hits_fresh: 0, forming: 0, hit_ratio: 0, avg_strength: 0, inst_ratio: 0, score: 0, small: n < SCAN.params.sector.min_members, is_hit: false });
    const ring = rows.slice().sort((a, b) => a.sector_code.localeCompare(b.sector_code));
    const ranked = rows.filter((r) => !r.small && (r.hits || r.forming)).sort((a, b) => b.score - a.score);
    const small = rows.filter((r) => r.small && (r.hits || r.forming)).sort((a, b) => b.score - a.score);
    const zero = rows.filter((r) => !r.hits && !r.forming).length;
    const sp = SCAN.params.sector;
    const tr = (r) => `<tr class="row${r.is_hit ? " is-hit" : ""}" data-sc="${esc(r.sector_code)}" tabindex="0">
      <td>${esc(r.sector_name)}${r.is_hit ? ` <span class="chip ok">命中</span>` : ""}</td><td class="r num">${r.hits}<span class="muted">/${r.n_members}</span>${r.hits_fresh ? `<br><span class="fresh">今日 ${r.hits_fresh}</span>` : ""}</td>
      <td class="r num">${fmt(r.hit_ratio * 100, 1)}%</td><td class="r num">${fmt(r.avg_strength, 0)}</td><td class="r num">${r.forming}</td>
      <td class="r num">${r.hits ? fmt(r.inst_ratio * 100, 0) + "%" : "—"}</td><td class="r num score">${fmt(r.score, 1)}</td></tr>`;
    const head = `<thead><tr><th>類股</th><th class="r">命中/成員</th><th class="r">命中比例</th><th class="r">平均強度</th><th class="r">成形中</th><th class="r">法人同向</th><th class="r">綜合分</th></tr></thead>`;
    $app.innerHTML = `
      <div class="bar"><button type="button" class="btn" id="back">← ${D.label}型態</button><h2>${esc(p.name)}・${D.label}</h2>
        <button type="button" class="btn" disabled title="掃描在盤後批次（box）執行；GitHub Pages 靜態版無法即時重掃">立即重掃（批次執行）</button></div>
      <div class="asof">${esc(asofLine())}</div>
      ${dir === "short" ? `<p class="note short">融券／借券費用假設 0，未計入。${isCis ? "cis_exp 空方已排除不可融券標的。" : "不可融券的個股仍列出並標註。"}</p>` : ""}
      ${ruleCard(pid, SCAN)}
      <div class="chips-row" role="group" aria-label="狀態統計">
        <span class="stchip st-CONFIRMED">${isCis ? "進場" : "今日確認"} <b class="num">${cnt((h) => h.state === "ENTRY" || (h.state === "CONFIRMED" && h.fresh))}</b></span>
        ${isCis ? `<span class="stchip">續抱 <b class="num">${cnt((h) => h.state === "HOLD")}</b></span><span class="stchip st-EXIT_WARNING">出場警示 <b class="num">${cnt((h) => h.state === "EXIT_WARNING")}</b></span><span class="stchip st-EXIT">出場 <b class="num">${cnt((h) => h.state === "EXIT")}</b></span>`
          : `<span class="stchip">近 10 日已確認 <b class="num">${cnt((h) => h.state === "CONFIRMED" && !h.fresh)}</b></span><span class="stchip st-FORMING">成形中 <b class="num">${cnt((h) => h.state === "FORMING")}</b></span>
          <span class="stchip st-TARGET_HIT">達滿足點 <b class="num">${cnt((h) => h.state === "TARGET_HIT")}</b></span><span class="stchip st-FAILED">型態失敗 <b class="num">${cnt((h) => h.state === "FAILED")}</b></span>`}
        <button type="button" class="btn sm" id="allstocks">全部個股 →</button>
      </div>
      <div class="radar-wrap">
        <div class="radar-box">${radarSVG(ring, dir)}<div class="prog-txt num" id="progtxt">0 / ${ring.length} 類股</div></div>
        <div class="sector-tbl">
          <div class="scroll"><table class="sectors">${head}<tbody>${ranked.map(tr).join("") || `<tr><td colspan="7" class="asof">今日沒有類股命中。</td></tr>`}</tbody></table></div>
          ${small.length ? `<h3 class="sub-h">小類股（成員 &lt; ${sp.min_members} 檔，不列入排名）</h3><div class="scroll"><table class="sectors">${head}<tbody>${small.map(tr).join("")}</tbody></table></div>` : ""}
          <p class="note">其餘 ${zero} 個類股今日 0 命中。綜合分 = ${sp.w1}×命中比例 + ${sp.w2}×平均強度 + ${sp.w3}×成形中比例 + ${sp.w4}×法人同向比例（×100；權重為補定義預設）。
          「命中」= 命中 ≥ ${sp.min_hits} 檔且比例 ≥ ${sp.min_ratio * 100}%。命中含今日確認與近 ${SCAN.params.common.track_days || 10} 日內確認仍有效者。</p>
        </div>
      </div>`;
    $app.querySelector("#back").addEventListener("click", () => go(`#/${dir}`));
    $app.querySelector("#allstocks").addEventListener("click", () => go(`#/${dir}/${pid}/ALL`));
    $app.querySelectorAll("tr.row").forEach((r) => { const f = () => go(`#/${dir}/${pid}/${r.dataset.sc}`); r.addEventListener("click", f); r.addEventListener("keydown", (e) => e.key === "Enter" && f()); });
    $app.querySelectorAll(".wedge").forEach((w) => w.addEventListener("click", () => { const r = ring[+w.dataset.i]; if (r.hits || r.forming) go(`#/${dir}/${pid}/${r.sector_code}`); }));
    // RadarSweep progress: 已掃類股數 / 總數（批次已完成，這裡重播進度；減少動態時直接顯示結果）
    const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
    const prog = $app.querySelector(".prog"), txt = $app.querySelector("#progtxt"), svg = $app.querySelector(".radar");
    const N = ring.length, t0 = performance.now(), dur = 1400;
    const step = (now) => {
      const k = reduce ? 1 : Math.min(1, (now - t0) / dur), done = Math.round(k * N);
      prog.setAttribute("stroke-dasharray", `${(k * 100).toFixed(1)} 100`); txt.textContent = `${done} / ${N} 類股`;
      svg.querySelectorAll(".wedge,.blip").forEach((el) => el.classList.toggle("seen", +el.dataset.i < done));
      if (k < 1) requestAnimationFrame(step); else { svg.classList.add("done"); if (window.RadarPages) RadarPages.hitFx(svg, dir); txt.textContent = `已掃 ${N} / ${N} 類股・${ranked.filter((r) => r.is_hit).length} 個命中`; }
    };
    requestAnimationFrame(step);
  }

  // ---------------------------------------------------------------- ③ 個股下鑽（StockRow + FundamentalChips）
  async function renderStocks(dir, pid, sc) {
    $app.innerHTML = `<p class="loading">載入個股…</p>`;
    try { await needScan(); } catch (e) { $app.innerHTML = `<p class="loading">掃描結果無法載入。</p>`; return; }
    await needFund();
    const D = DIR[dir], rules = activeRules();
    const sort = sessionStorage.getItem("radar.sort") || "strength", onlyPass = sessionStorage.getItem("radar.onlyPass") === "1";
    const order = { ENTRY: 0, CONFIRMED: 0, FORMING: 1, TARGET_HIT: 2, FAILED: 3, EXIT: 4, EXIT_WARNING: 5, HOLD: 6 };
    let rows = SCAN.hits.filter((h) => h.patternId === pid && h.direction === dir && (sc === "ALL" || h.sector_code === sc))
      .map((h) => ({ h, f: applyRules(FUND.data[h.symbol], rules) }));
    const nAll = rows.length;
    if (onlyPass && rules.length) rows = rows.filter((r) => r.f.status === "pass");
    const fRank = { pass: 0, pending: 1, fail: 2 };
    const inst = (h) => (h.instNet == null ? -Infinity : dir === "long" ? h.instNet : -h.instNet);
    const key = { strength: (r) => -(r.h.strength || 0), vol: (r) => -(r.h.volRatio || 0), inst: (r) => -inst(r.h), fund: (r) => fRank[r.f.status] * 100 - r.f.bonus };
    rows.sort((a, b) => (order[a.h.state] - order[b.h.state]) || ((b.h.fresh ? 1 : 0) - (a.h.fresh ? 1 : 0)) || (key[sort](a) - key[sort](b)));
    const item = ({ h, f }) => {
      const lv = h.levels || {};
      const noShort = dir === "short" && h.shortable === false ? `<span class="chip bad">不可融券</span>` : dir === "short" && h.shortable == null ? `<span class="chip pend">融券未知</span>` : "";
      return `<button type="button" class="srow" data-sym="${esc(h.symbol)}" data-sc="${esc(h.sector_code)}">
        <span class="s-id"><b class="num">${esc(h.symbol)}</b> ${esc(h.name)}<br><span class="muted">${esc(h.sector_name || "")}・${esc(h.market)}</span></span>
        <span class="s-st st-${h.state}">${esc(stLabel(h))}</span>
        <span class="s-m"><i>強度</i><b class="num">${fmt(h.strength, 0)}</b></span>
        <span class="s-m"><i>量比</i><b class="num">${fmt(h.volRatio, 2)}</b></span>
        <span class="s-m"><i>法人(張)</i><b class="num ${h.instNet > 0 ? "up" : h.instNet < 0 ? "down" : ""}">${h.instNet == null ? "—" : lots(h.instNet).toLocaleString()}</b></span>
        <span class="s-m"><i>收盤</i><b class="num">${fmt(h.close)}</b></span>
        <span class="s-m"><i>${pid.startsWith("cis") ? "MA25" : "頸線"}</i><b class="num">${fmt(lv.neckline ?? lv.ma25)}</b></span>
        <span class="s-c">${chip(f, rules)}${noShort}</span></button>`;
    };
    const sb = (k, t) => `<button type="button" class="seg" aria-pressed="${sort === k}" data-sort="${k}">${t}</button>`;
    $app.innerHTML = `
      <div class="bar"><button type="button" class="btn" id="back">← 類股雷達</button><h2>${esc(sectorName(sc))}・${esc(patternName(pid))}・${D.label}</h2>
        <button type="button" class="btn" id="fset">基本面條件${rules.length ? `（${rules.length}）` : ""}</button></div>
      <div class="asof">${esc(asofLine())}｜${rows.length}${rows.length !== nAll ? ` / ${nAll}` : ""} 檔</div>
      <div class="tools">
        <span class="segs" role="group" aria-label="排序">${sb("strength", "強度")}${sb("vol", "量比")}${sb("inst", "法人")}${sb("fund", "基本面")}</span>
        <label class="toggle"><input type="checkbox" id="onlyPass" ${onlyPass ? "checked" : ""} ${rules.length ? "" : "disabled"}> 只看通過基本面</label>
      </div>
      ${rules.length ? "" : `<p class="note">尚未設定任何基本面條件（§8 預設全部關閉）。按「基本面條件」設定門檻後，才會顯示 通過／未通過／待補。</p>`}
      ${dir === "short" ? `<p class="note short">融券／借券費用假設 0，未計入。</p>` : ""}
      <div class="slist">${rows.map(item).join("") || `<p class="asof">沒有符合的個股。</p>`}</div>`;
    $app.querySelector("#back").addEventListener("click", () => go(`#/${dir}/${pid}`));
    $app.querySelector("#fset").addEventListener("click", () => go(`#/settings/fund?back=${encodeURIComponent(location.hash)}`));
    $app.querySelector("#onlyPass").addEventListener("change", (e) => { sessionStorage.setItem("radar.onlyPass", e.target.checked ? "1" : "0"); render(); });
    $app.querySelectorAll(".seg").forEach((b) => b.addEventListener("click", () => { sessionStorage.setItem("radar.sort", b.dataset.sort); render(); }));
    $app.querySelectorAll(".srow").forEach((b) => b.addEventListener("click", () => go(`#/${dir}/${pid}/${sc}/${b.dataset.sym}`)));
  }

  // ---------------------------------------------------------------- 基本面條件設定
  async function renderFundSettings(back) {
    await needFund();
    const cur = Object.fromEntries(loadRules().map((r) => [r.key, r]));
    const row = ([k, , , label, unit, op]) => {
      const r = cur[k] || { mode: "off", op, value: "" };
      return `<div class="frule" data-key="${k}"><span class="fl">${esc(label)}</span>
        <span class="segs" role="group" aria-label="${esc(label)} 模式">${["off", "required", "bonus"].map((m) => `<button type="button" class="seg" data-mode="${m}" aria-pressed="${r.mode === m}">${{ off: "關閉", required: "必要", bonus: "加分" }[m]}</button>`).join("")}</span>
        <select class="fop" aria-label="比較"><option ${(r.op || op) === ">=" ? "selected" : ""}>&gt;=</option><option ${(r.op || op) === "<=" ? "selected" : ""}>&lt;=</option></select>
        <input class="fval num" inputmode="decimal" placeholder="門檻" value="${esc(r.value)}" aria-label="${esc(label)} 門檻"><span class="muted">${unit}</span></div>`;
    };
    $app.innerHTML = `
      <div class="bar"><button type="button" class="btn" id="back">← 返回</button><h2>基本面條件</h2><button type="button" class="btn" id="clear">全部關閉</button></div>
      <p class="note">每個條件可設「必要」「加分」或「關閉」，<b>預設全部關閉</b>；門檻由你自己設定（本 App 不給預設值）。缺資料標「待補」，不直接淘汰。設定只存在這台裝置（localStorage）。</p>
      <div class="frules">${FFIELDS.map(row).join("")}
        <div class="frule"><span class="fl">財測</span><span class="muted">無免費官方來源</span></div>
        <div class="frule"><span class="fl">EPS／ROE 近四季</span><span class="muted">資料待補（需 MOPS 歷史季報；目前用本年累計）</span></div></div>
      <p class="note">資料：TWSE／TPEx OpenAPI（轉載 MOPS），只用資料日當天（含）以前已公告者。${(FUND.notes || []).map(esc).join(" ")}</p>`;
    const persist = () => !OFFLINE && saveRules([...$app.querySelectorAll(".frule[data-key]")].map((el) => ({ key: el.dataset.key,
      mode: el.querySelector(".seg[aria-pressed=true]").dataset.mode, op: el.querySelector(".fop").value, value: el.querySelector(".fval").value === "" ? "" : +el.querySelector(".fval").value })));
    $app.querySelectorAll(".frule .seg").forEach((b) => b.addEventListener("click", () => { b.parentNode.querySelectorAll(".seg").forEach((x) => x.setAttribute("aria-pressed", x === b)); persist(); }));
    $app.querySelectorAll(".fop,.fval").forEach((el) => el.addEventListener("change", persist));
    $app.querySelector("#clear").addEventListener("click", () => { if (!guard()) return; saveRules([]); render(); });
    if (OFFLINE) $app.querySelectorAll(".frule .seg,.fop,.fval").forEach((el) => { el.disabled = true; el.title = "目前離線，無法執行"; });
    $app.querySelector("#back").addEventListener("click", () => { persist(); go(back || "#/"); });
  }

  // ---------------------------------------------------------------- 個股詳情（GradientCandleChart + PatternOverlay + InstitutionBar + 基本面卡 + BacktestMiniCard）
  let CHART = null;
  function loadLW() {
    if (window.LightweightCharts) return Promise.resolve(window.LightweightCharts);
    return new Promise((ok, no) => { const s = document.createElement("script"); s.src = "lightweight-charts.js"; s.onload = () => ok(window.LightweightCharts); s.onerror = no; document.head.appendChild(s); });
  }
  const BARS = {};
  async function needBars(sc) { if (!BARS[sc]) BARS[sc] = await getJSON(`bars_${sc}.json`); return BARS[sc]; }
  const isoD = (t) => `${t.slice(0, 4)}-${t.slice(4, 6)}-${t.slice(6, 8)}`;
  const GEO_ZH = { LS: "左肩", RS: "右肩", Head: "頭", T1: "頸1", T2: "頸2", L1: "左腳", L2: "右腳", H1: "左峰", H2: "右峰", B: "破底", S: "支撐", reclaim: "翻回",
    pole_base: "旗桿起", pole_top: "旗桿頂", R: "壓力", U: "假突破", fail: "跌回", Lmin: "最低", Hmax: "最高" };
  async function renderStock(dir, pid, sc, sym) {
    $app.innerHTML = `<p class="loading">載入個股…</p>`;
    try { await needScan(); } catch (e) { $app.innerHTML = `<p class="loading">掃描結果無法載入。</p>`; return; }
    await needFund();
    const sigs = SCAN.hits.filter((h) => h.symbol === sym);
    const main = sigs.find((h) => h.patternId === pid && h.direction === dir) || sigs[0];
    if (!main) { $app.innerHTML = `<p class="loading">今日掃描沒有 ${esc(sym)} 的訊號。</p>`; return; }
    const D = DIR[dir], f = FUND.data[sym] || {}, rules = activeRules(), fr = applyRules(f, rules);
    let B = null; try { B = (await needBars(main.sector_code || "NA")).series[sym]; } catch (e) { B = null; }
    const lv = main.levels || {};
    const fv = (g, k, d = 2, u = "") => { const v = (f[g] || {})[k]; return v == null ? `<span class="pend-t">待補</span>` : `${fmt(v, d)}${u}`; };
    const others = sigs.filter((h) => h !== main).map((h) => `<a class="chip ${h.direction}" href="#/${h.direction}/${h.patternId}/${sc}/${sym}">${esc(patternName(h.patternId))}・${DIR[h.direction].label}・${esc(stLabel(h))}</a>`).join("");
    const tvx = main.market === "TPEx" ? "TPEX" : "TWSE";
    const strip = [["收盤", fmt(main.close)], lv.neckline != null && ["頸線", fmt(lv.neckline)], lv.ma25 != null && ["MA25", fmt(lv.ma25)], lv.breakout != null && ["突破", fmt(lv.breakout)],
      lv.target != null && ["滿足點", fmt(lv.target)], lv.stopRef != null && ["停損參考", fmt(lv.stopRef)], ["強度", fmt(main.strength, 0)]].filter(Boolean);
    $app.innerHTML = `
      <div class="bar stock-bar"><button type="button" class="btn" id="back">← 個股列表</button>
        <h2><span class="num">${esc(sym)}</span> ${esc(main.name)} <span class="muted s">${esc(main.sector_name || "")}・${esc(main.market)}</span></h2>
        <span id="watchbtn"></span>
        <button type="button" class="btn sm" id="sidebtn" aria-controls="side" aria-expanded="true">資訊欄</button>
        <a class="btn sm" href="https://www.tradingview.com/chart/?symbol=${tvx}:${encodeURIComponent(sym)}" target="_blank" rel="noopener">TradingView ↗</a></div>
      <div class="asof">${esc(asofLine())}</div>
      <div class="sumstrip ${dir}"><b>${esc(patternName(main.patternId))}・${DIR[main.direction].label}</b> <span class="st-${main.state}">${esc(stLabel(main))}</span>
        ${strip.map(([k, v]) => `<span class="kv1"><i>${k}</i><b class="num">${v}</b></span>`).join("")}</div>
      <div class="stock" id="stockwrap">
        <div class="main-col"><section class="chart-card"><div class="legend num" id="legend"></div><div id="chart" class="chart" aria-label="K 線圖"></div>
          <p class="note">K 線為還原權息後序列（最新一根 = 原始收盤價），紅漲綠跌（漸層實體，量越大外光越亮）；虛線：頸線／突破／滿足點／停損參考。${B ? "" : OFFLINE ? "<b>離線無圖</b>（本機沒有這個類股的日 K 快取；命中摘要、關鍵價與理由照常顯示）。" : "<b>此檔 K 線資料檔未載入。</b>"}</p></section></div>
        <div class="side-scrim" id="sidescrim"></div>
        <aside class="side" id="side" aria-label="詳細資訊">
          <div class="side-head"><b>詳細資訊</b><button type="button" class="btn sm" id="sideclose">收起 ✕</button></div>
          <section class="pcard ${dir}"><h3>${esc(patternName(main.patternId))}・${DIR[main.direction].label} <span class="st-${main.state}">${esc(stLabel(main))}</span></h3>
            <div class="kvs">
              <span class="kv"><i>強度</i><b class="num">${fmt(main.strength, 0)}</b></span><span class="kv"><i>收盤</i><b class="num">${fmt(main.close)}</b></span>
              ${lv.neckline != null ? `<span class="kv"><i>頸線</i><b class="num">${fmt(lv.neckline)}</b></span>` : ""}${lv.ma25 != null ? `<span class="kv"><i>MA25</i><b class="num">${fmt(lv.ma25)}</b></span>` : ""}
              ${lv.breakout != null ? `<span class="kv"><i>突破價</i><b class="num">${fmt(lv.breakout)}</b></span>` : ""}${lv.target != null ? `<span class="kv"><i>滿足點</i><b class="num">${fmt(lv.target)}</b></span>` : ""}
              ${lv.stopRef != null ? `<span class="kv"><i>停損參考</i><b class="num">${fmt(lv.stopRef)}</b></span>` : ""}<span class="kv"><i>量比</i><b class="num">${fmt(main.volRatio)}</b></span></div>
            <ul class="reasons">${(main.reasons || []).map((r) => `<li>${esc(r)}</li>`).join("")}</ul>
            ${dir === "short" ? `<p class="note short">融券／借券費用假設 0，未計入。${main.shortable === false ? "<b>此檔目前不可融券（依交易所公告）。</b>" : main.shortable == null ? "可否融券：資料未知。" : ""}</p>` : ""}
            ${others ? `<div class="others"><span class="muted">同檔其他命中：</span>${others}</div>` : ""}</section>
          <section class="pcard"><h3>三大法人買賣超（近 20 日，張）</h3>${!B && OFFLINE ? `<p class="muted">離線：本機沒有這個類股的快取。</p>` : instBar(B ? B.inst : [])}</section>
          <section class="pcard"><h3>基本面 ${chip(fr, rules)}</h3>
            <div class="kvs">
              <span class="kv"><i>月營收 YoY${f.rev ? `（${esc(f.rev.ym)}）` : ""}</i><b class="num">${fv("rev", "yoy", 1, "%")}</b></span><span class="kv"><i>MoM</i><b class="num">${fv("rev", "mom", 1, "%")}</b></span>
              <span class="kv"><i>累計 YoY</i><b class="num">${fv("rev", "cum_yoy", 1, "%")}</b></span>
              <span class="kv"><i>EPS 本年累計${f.fin ? `（${esc(f.fin.yq)}）` : ""}</i><b class="num">${fv("fin", "eps_ytd")}</b></span>
              <span class="kv"><i>毛利率</i><b class="num">${fv("fin", "gross_margin", 1, "%")}</b></span><span class="kv"><i>營益率</i><b class="num">${fv("fin", "op_margin", 1, "%")}</b></span>
              <span class="kv"><i>淨利率</i><b class="num">${fv("fin", "net_margin", 1, "%")}</b></span><span class="kv"><i>ROE 年化</i><b class="num">${fv("fin", "roe_ann", 1, "%")}</b></span>
              <span class="kv"><i>本益比</i><b class="num">${fv("val", "pe")}</b></span><span class="kv"><i>淨值比</i><b class="num">${fv("val", "pb")}</b></span>
              <span class="kv"><i>殖利率</i><b class="num">${fv("val", "dividend_yield", 2, "%")}</b></span><span class="kv"><i>財測</i><b class="muted">無免費官方來源</b></span></div>
            <p class="note">${f.rev ? `營收公告 ${esc(f.rev.as_of)}；` : ""}${f.fin ? `財報公告 ${esc(f.fin.as_of)}；` : ""}EPS／ROE 為本年累計（ROE 年化），近四季資料待補。${Object.keys(f).length ? "" : "<b>基本面資料待補（ETF 或來源無此檔）。</b>"}</p></section>
          <section class="pcard" id="btmini"><h3>歷史回測</h3><p class="muted">載入回測結果…</p></section>
        </aside>
      </div>`;
    sidePanel();
    $app.querySelector("#back").addEventListener("click", () => go(`#/${dir}/${pid}/${sc}`));
    if (window.RadarPages) { RadarPages.miniCard(document.getElementById("btmini"), dir, pid, sym, main.sector_code); RadarPages.watchButton(document.getElementById("watchbtn"), sym, main.name); }
    if (!B) document.getElementById("chart").innerHTML = `<p class="loading">${OFFLINE ? "離線無圖" : "K 線資料未載入"}</p>`;
    if (B) drawChart(B, main, sigs).catch((e) => { document.getElementById("chart").innerHTML = `<p class="loading">圖表載入失敗：${esc(e.message || e)}</p>`; });
  }
  // 右側資訊欄：寬螢幕＝可收合的窄欄（預設展開）；窄螢幕／直向＝抽屜（預設收起）。狀態分別記在 localStorage。
  const NARROW = () => matchMedia("(max-width:900px), (orientation:portrait)").matches;
  function sidePanel() {
    const wrap = document.getElementById("stockwrap"), btn = document.getElementById("sidebtn"); if (!wrap || !btn) return;
    const key = () => `radar.side.${NARROW() ? "narrow" : "wide"}`;
    const isOpen = () => { const v = localStorage.getItem(key()); return v ? v === "open" : !NARROW(); };
    const apply = (open) => { wrap.classList.toggle("side-open", open); wrap.classList.toggle("side-closed", !open);
      btn.setAttribute("aria-expanded", open); btn.textContent = open ? (NARROW() ? "資訊欄 ✕" : "收起資訊欄 ▸") : (NARROW() ? "☰ 資訊欄" : "◂ 顯示資訊欄"); };
    const set = (open) => { localStorage.setItem(key(), open ? "open" : "closed"); apply(open); };
    apply(isOpen());
    btn.addEventListener("click", () => set(!wrap.classList.contains("side-open")));
    const c = document.getElementById("sideclose"); if (c) c.addEventListener("click", () => set(false));
    const sc = document.getElementById("sidescrim"); if (sc) sc.addEventListener("click", () => set(false));
    const mq = matchMedia("(max-width:900px), (orientation:portrait)"); const re = () => { if (document.body.contains(wrap)) apply(isOpen()); };
    mq.addEventListener ? mq.addEventListener("change", re) : mq.addListener(re);
  }

  function instBar(inst) {
    if (!inst || !inst.length) return `<p class="muted">資料抓不到或此檔無三大法人資料。</p>`;
    const W = 300, H = 90, n = inst.length, bw = W / n, mx = Math.max(1, ...inst.map((x) => Math.abs(x[1])));
    const bars = inst.map(([d, v], i) => { const h = (Math.abs(v) / mx) * (H / 2 - 4); return `<rect x="${(i * bw + 1).toFixed(1)}" y="${v >= 0 ? H / 2 - h : H / 2}" width="${(bw - 2).toFixed(1)}" height="${Math.max(0.5, h).toFixed(1)}" class="${v >= 0 ? "up" : "down"}"><title>${isoD(d)}：${v.toLocaleString()} 張</title></rect>`; }).join("");
    const sum = inst.reduce((a, x) => a + x[1], 0);
    return `<svg class="inst" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="三大法人近 ${n} 日買賣超">${bars}<line x1="0" x2="${W}" y1="${H / 2}" y2="${H / 2}" class="axis"/></svg>
      <div class="asof num">${isoD(inst[0][0])} ～ ${isoD(inst[n - 1][0])}｜合計 <b class="${sum >= 0 ? "up" : "down"}">${sum.toLocaleString()}</b> 張｜最新 ${inst[n - 1][1].toLocaleString()} 張</div>`;
  }
  // ---------------------------------------------------------------- 量測漲跌幅（1×／2× 型態高度）；批次已算好就用 sig.move，舊資料由幾何現算（同 radar/engine.py measured_move）
  const MOVE_SPECS = { m_top: ["drop", "M頭", ["H1", "H2"], "高點"], hs_top: ["drop", "頭肩頂", ["Head"], "頭部"], hs_top_fake: ["drop", "頭肩頂（假突破）", ["Head"], "頭部"],
    w_bottom: ["rise", "W底", ["L1", "L2"], "低點"], bottom_reversal_w: ["rise", "破底翻（W底）", ["L2"], "低點"], hs_bottom: ["rise", "頭肩底", ["Head"], "頭部"] };
  function measuredMove(sig, time, closeNow) {
    if (!sig) return null;
    if (sig.move) return sig.move;
    const spec = MOVE_SPECS[sig.patternId], lv = sig.levels || {}, geo = sig.geometry || {};
    if (!spec || lv.neckline == null) return null;
    const [kind, basis, keys, exLabel] = spec;
    const pts = keys.filter((k) => geo[k] && geo[k].price != null).map((k) => ({ key: k, price: geo[k].price, date: geo[k].date }));
    if (!pts.length) return null;
    const ext = pts.reduce((a, q) => (kind === "drop" ? (q.price > a.price ? q : a) : (q.price < a.price ? q : a)));
    let neckRef = lv.neckline; const nk = geo.neckline;
    if (nk && nk.p0 && nk.p1 && time) { const i0 = time.indexOf(nk.p0.date), i1 = time.indexOf(nk.p1.date), ie = time.indexOf(ext.date);
      if (i0 >= 0 && i1 > i0 && ie >= 0) neckRef = nk.p0.price + (nk.p1.price - nk.p0.price) * (ie - i0) / (i1 - i0); }
    const h = kind === "drop" ? ext.price - neckRef : neckRef - ext.price; if (!(h > 0)) return null;
    const base = lv.neckline, sg = kind === "drop" ? -1 : 1, r2 = (x) => Math.round(x * 100) / 100, pc = (x, ref) => (ref ? r2((x / ref - 1) * 100) : null);
    const t1 = base + sg * h, t2 = base + sg * 2 * h;
    const m = { kind, basis, pattern: sig.patternId, extreme: r2(ext.price), extreme_label: exLabel, extreme_date: ext.date, peaks: pts.map((q) => ({ key: q.key, price: r2(q.price), date: q.date })),
      neck_ref: r2(neckRef), neckline: r2(base), height: r2(h), height_pct: r2((h / neckRef) * 100), t1: r2(t1), t2: r2(t2), t1_pct: pc(t1, base), t2_pct: pc(t2, base) };
    if (closeNow) Object.assign(m, { close: r2(closeNow), t1_from_close_pct: pc(t1, closeNow), t2_from_close_pct: pc(t2, closeNow) });
    return m;
  }
  const PEAK_ZH = { H1: "左峰", H2: "右峰", L1: "左腳", L2: "右腳", Head: "頭" };
  function moveBox(m) {
    if (!m) return "";
    const drop = m.kind === "drop", w = drop ? "跌" : "漲", n2 = (x) => (x == null ? "—" : Number(x).toLocaleString("zh-TW", { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
    const p = (x) => (x == null ? "—" : `${x >= 0 ? "+" : ""}${fmt(x)}%`);
    const many = (m.peaks || []).length > 1;
    const peaks = (m.peaks || []).map((q) => `${many ? (PEAK_ZH[q.key] || q.key) + " " : ""}${n2(q.price)}${q.date ? `（${esc(q.date)}）` : ""}`).join("、");
    return `<div class="movebox ${drop ? "drop" : "rise"}" role="note"><div class="mv-h"><b>📐 ${esc(m.basis)}・量測${w}幅</b><span class="muted">高度 = ${drop ? `${esc(m.extreme_label)} − 頸線` : `頸線 − ${esc(m.extreme_label)}`}</span></div>
      <div class="mv-g"><span><i>${many ? "兩個" + esc(m.extreme_label) : esc(m.extreme_label)}</i><b class="num">${peaks}</b></span>
        <span><i>頸線</i><b class="num">${n2(m.neckline)}</b>${Math.abs(m.neck_ref - m.neckline) > 0.005 ? `<em class="muted">（${esc(m.extreme_label)}當日 ${n2(m.neck_ref)}，斜頸線）</em>` : ""}</span>
        <span><i>型態高度</i><b class="num">${n2(m.height)} 點（${fmt(m.height_pct)}%）</b></span></div>
      <div class="scroll"><table class="cmp mv-t"><thead><tr><th></th><th class="r">目標點位</th><th class="r">${w}幅（點）</th><th class="r">距頸線</th>${m.close != null ? `<th class="r">距收盤 ${n2(m.close)}</th>` : ""}</tr></thead><tbody>
        <tr><td>1 倍</td><td class="r num"><b>${n2(m.t1)}</b></td><td class="r num">${n2(m.height)}</td><td class="r num">${p(m.t1_pct)}</td>${m.close != null ? `<td class="r num">${p(m.t1_from_close_pct)}</td>` : ""}</tr>
        <tr><td>2 倍</td><td class="r num"><b>${n2(m.t2)}</b></td><td class="r num">${n2(m.height * 2)}</td><td class="r num">${p(m.t2_pct)}</td>${m.close != null ? `<td class="r num">${p(m.t2_from_close_pct)}</td>` : ""}</tr></tbody></table></div>
      <p class="note">目標 = 頸線 ${drop ? "−" : "＋"} 1 倍／2 倍型態高度。型態量測只是參考，不保證會到，不構成投資建議。</p></div>`;
  }

  async function drawChart(B, main, sigs) {
    const L = await loadLW(); const el = document.getElementById("chart");
    if (CHART) { try { CHART.remove(); } catch (e) {} CHART = null; }
    const UP = "#FF3B5C", DOWN = "#1ED97A";
    const chart = L.createChart(el, { autoSize: true, layout: { background: { type: L.ColorType.Solid, color: "#070A14" }, textColor: "#8A94B2", fontFamily: "ui-monospace,Menlo,monospace", panes: { separatorColor: "#232c45" } },
      grid: { vertLines: { color: "rgba(35,44,69,.5)" }, horzLines: { color: "rgba(35,44,69,.5)" } }, rightPriceScale: { borderColor: "#232c45" },
      timeScale: { borderColor: "#232c45", rightOffset: 6 }, crosshair: { mode: 0 }, localization: { locale: "zh-TW" },
      handleScale: { pinch: true, mouseWheel: true, axisPressedMouseMove: true }, handleScroll: { horzTouchDrag: true, vertTouchDrag: false, mouseWheel: true, pressedMouseMove: true }, kineticScroll: { touch: true } });
    CHART = chart;
    const time = B.t.map(isoD);
    const grad = window.RadarPages && RadarPages.pref("gradient") !== false && typeof chart.addCustomSeries === "function";
    const T0 = "rgba(0,0,0,0)";  // 漸層模式：標準 K 線只負責標註／價位線／自動縮放，外觀由 GradientCandles 繪製
    const candles = chart.addSeries(L.CandlestickSeries, grad ? { upColor: T0, downColor: T0, borderVisible: false, wickVisible: false, priceLineVisible: false }
      : { upColor: UP, downColor: DOWN, borderUpColor: UP, borderDownColor: DOWN, wickUpColor: UP, wickDownColor: DOWN, priceLineVisible: false }, 0);
    candles.setData(time.map((t, i) => ({ time: t, open: B.o[i], high: B.h[i], low: B.l[i], close: B.c[i] })));
    if (grad) { try { RadarPages.gradientCandles(chart, time, B); } catch (e) { candles.applyOptions({ upColor: UP, downColor: DOWN, wickVisible: true, borderVisible: true, wickUpColor: UP, wickDownColor: DOWN }); } }
    const ma = (k) => B.c.map((_, i) => (i < k - 1 ? null : { time: time[i], value: B.c.slice(i - k + 1, i + 1).reduce((a, b) => a + b, 0) / k })).filter(Boolean);
    const m5 = chart.addSeries(L.LineSeries, { color: "#FFD166", lineWidth: 1, priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false }, 0); m5.setData(ma(5));
    const m25 = chart.addSeries(L.LineSeries, { color: "#B388FF", lineWidth: 1.5, priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false }, 0); m25.setData(ma(25));
    if (!B.novol) {   // 指數沒有成交量時（B.novol）不畫量能窗格
      const vol = chart.addSeries(L.HistogramSeries, { priceFormat: { type: "volume" }, priceScaleId: "volume", lastValueVisible: false, priceLineVisible: false }, 1);
      vol.setData(time.map((t, i) => ({ time: t, value: B.v[i], color: B.c[i] >= B.o[i] ? "rgba(255,59,92,.55)" : "rgba(30,217,122,.55)" })));
    }
    try { const ps = chart.panes(); ps[0].setStretchFactor(4); ps[1] && ps[1].setStretchFactor(1); } catch (e) {}
    // PatternOverlay: price lines + trend lines (p0→p1) + pivot markers
    const lv = main.levels || {}, isLong = main.direction === "long", acc = isLong ? "#00F0FF" : "#FF2BD6";
    const pl = (price, title, color, style) => price != null && candles.createPriceLine({ price, color, lineWidth: 1, lineStyle: style, axisLabelVisible: true, title });
    const mv = measuredMove(main, time, B.c[B.c.length - 1]);
    pl(lv.neckline, "頸線", acc, 2); pl(lv.breakout, "突破", "#B6FF3B", 1); pl(lv.stopRef, "停損參考", "#FF8A00", 2);
    if (mv) {   // 讓價格軸自動縮放也包含 1 倍／2 倍目標，線才看得到
      const lo = Math.min(mv.t1, mv.t2), hi = Math.max(mv.t1, mv.t2);
      candles.applyOptions({ autoscaleInfoProvider: (orig) => { const r = orig(); if (r && r.priceRange) { r.priceRange.minValue = Math.min(r.priceRange.minValue, lo); r.priceRange.maxValue = Math.max(r.priceRange.maxValue, hi); } return r; } });
      pl(mv.t1, `1倍${mv.kind === "drop" ? "跌" : "漲"}幅`, "#B6FF3B", 2); pl(mv.t2, `2倍${mv.kind === "drop" ? "跌" : "漲"}幅`, "#FFD166", 2); }
    else pl(lv.target, "滿足點", "#B6FF3B", 2);
    const tset = new Set(time), marks = [];
    const geo = main.geometry || {};
    // 型態輪廓：把轉折點依日期連成折線（M頭＝左峰→頸→右峰；頭肩＝左肩→頸1→頭→頸2→右肩）
    const OUT = ["H1", "L1", "H2", "LS", "T1", "Head", "T2", "RS", "L2"];
    const outline = OUT.map((k) => geo[k]).filter((g) => g && g.date && g.price != null && tset.has(g.date)).sort((a, b) => (a.date < b.date ? -1 : 1))
      .filter((g, i, arr) => !i || g.date !== arr[i - 1].date);
    if (mv && outline.length >= 3) {
      const ol = chart.addSeries(L.LineSeries, { color: acc, lineWidth: 1, lineStyle: 0, priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false, pointMarkersVisible: true }, 0);
      ol.setData(outline.map((g) => ({ time: g.date, value: g.price })));
    }
    for (const [k, g] of Object.entries(geo)) {
      if (g && g.p0 && g.p1 && tset.has(g.p0.date) && tset.has(g.p1.date)) {
        const s = chart.addSeries(L.LineSeries, { color: acc, lineWidth: 2, lineStyle: k === "neckline" ? 2 : 0, priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false }, 0);
        s.setData(g.p0.date === g.p1.date ? [{ time: g.p0.date, value: g.p0.price }] : [{ time: g.p0.date, value: g.p0.price }, { time: g.p1.date, value: g.p1.price }]);
      } else if (g && g.date && g.price != null && tset.has(g.date)) {
        const i = time.indexOf(g.date), high = Math.abs(g.price - B.h[i]) < Math.abs(g.price - B.l[i]);
        marks.push({ time: g.date, position: high ? "aboveBar" : "belowBar", color: acc, shape: high ? "arrowDown" : "arrowUp", text: GEO_ZH[k] || k });
      }
    }
    if (main.confirmed_on && tset.has(main.confirmed_on)) marks.push({ time: main.confirmed_on, position: isLong ? "belowBar" : "aboveBar", color: "#B6FF3B", shape: "circle", text: "確認" });
    if (main.state === "ENTRY" || main.state === "CONFIRMED") marks.push({ time: time[time.length - 1], position: isLong ? "belowBar" : "aboveBar", color: "#B6FF3B", shape: isLong ? "arrowUp" : "arrowDown", text: STATE_ZH[main.state] });
    marks.sort((a, b) => (a.time < b.time ? -1 : a.time > b.time ? 1 : 0));
    try { L.createSeriesMarkers(candles, marks); } catch (e) {}
    const card = el.closest(".chart-card"); if (card) { let box = card.querySelector(".movebox-wrap");
      if (!box) { box = document.createElement("div"); box.className = "movebox-wrap"; el.insertAdjacentElement("afterend", box); }
      box.innerHTML = moveBox(mv); }
    const firstGeo = Object.values(geo).map((g) => (g && (g.date || (g.p0 && g.p0.date)))).filter((d) => d && tset.has(d)).sort()[0];
    const from = Math.max(0, Math.min(time.length - 90, firstGeo ? time.indexOf(firstGeo) - 15 : time.length - 120));
    chart.timeScale().setVisibleLogicalRange({ from, to: time.length + 5 });
    const $lg = document.getElementById("legend");
    const legend = (i) => { if (i < 0 || i >= time.length) i = time.length - 1; const ch = i ? (B.c[i] / B.c[i - 1] - 1) * 100 : 0;
      $lg.innerHTML = `${time[i]}　開 ${fmt(B.o[i])} 高 ${fmt(B.h[i])} 低 ${fmt(B.l[i])} 收 <b class="${ch >= 0 ? "up" : "down"}">${fmt(B.c[i])} (${ch >= 0 ? "+" : ""}${fmt(ch)}%)</b> ${B.novol ? "" : `量 ${(B.v[i] || 0).toLocaleString()}${B.vu == null ? " 張" : B.vu}`}　<span style="color:#FFD166">MA5</span> <span style="color:#B388FF">MA25</span>`; };
    legend(time.length - 1);
    chart.subscribeCrosshairMove((p) => legend(p && p.time ? time.indexOf(p.time) : -1));
    // 兩指縮放只作用在圖上；不封鎖整頁縮放（§18.2）
    el.addEventListener("touchmove", (e) => { if (e.touches.length > 1) e.preventDefault(); }, { passive: false });
  }

  // ---------------------------------------------------------------- router
  function render() {
    staleBanner();
    if (CHART && !/^#\/((long|short)\/[^/]+\/[^/]+\/[^/]+|etf\/|markets\/)/.test(location.hash)) { try { CHART.remove(); } catch (e) {} CHART = null; }
    const h = (location.hash || "#/").replace(/^#/, "");
    if (h.startsWith("/settings/fund")) return renderFundSettings(decodeURIComponent((h.split("back=")[1] || "")));
    if (h.startsWith("/etf/")) return window.RadarEtf ? RadarEtf.render(decodeURIComponent(h.split("/")[2] || "00631L")) : renderGate();
    if (window.RadarPages && RadarPages.route(h)) return;
    const [, dir, pid, sc, sym] = h.split("/").map(decodeURIComponent);
    if (!dir || !DIR[dir]) return renderGate();
    if (!pid) return renderMenu(dir);
    if (!sc) return renderSectors(dir, pid);
    if (!sym) return renderStocks(dir, pid, sc);
    return renderStock(dir, pid, sc, sym);
  }
  window.addEventListener("hashchange", render);
  window.RadarApp = { DIR, STATE_ZH, esc, fmt, go, render, getJSON, guard, tpe, loadLW, needBars, isoD, needScan, needFund, patternName, sectorName: (sc) => sectorName(sc),
    loadRules, saveRules, FFIELDS, drawChart, measuredMove, moveBox, sidePanel, instBar, stLabel, get SUMMARY() { return SUMMARY; }, get SCAN() { return SCAN; }, get OFFLINE() { return OFFLINE; }, CACHED_AT, asofLine: () => asofLine() };
  // 恢復連線：重新拉資料，陳舊標示消失（§18.4 驗收）
  window.addEventListener("online", () => { OFFLINE = false; SCAN = null; FUND = null; getJSON("summary_latest.json").then((j) => { SUMMARY = j; render(); }).catch(() => {}); });
  window.addEventListener("offline", () => { OFFLINE = true; staleBanner(); });
  if (S) S.migrate().catch(() => {});
  getJSON("summary_latest.json").then((j) => { SUMMARY = j; render(); if (window.RadarPages) RadarPages.autoBackup(); })
    .catch(() => { $app.innerHTML = `<p class="loading">掃描結果無法載入（離線且尚無快取）。請連線後重新開啟。</p>`; });
  if ("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(() => {});
})();
