/* 型態雷達 自訂型態 DSL（§16）— 瀏覽器端直譯器，語意與 pipeline/radar/dsl.py 相同（node parity 測試）。
 * 只用白名單函式；沒有屬性存取、索引、字串或任意程式碼。限制：運算式 ≤500 字、≤200 節點、回溯 ≤250 根。 */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.RadarDSL = factory();
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";
  const MAX_EXPR = 500, MAX_NODES = 200, MAX_WIN = 250, MAX_SERIES = 40, MAX_STATES = 24;
  const BASE = ["close", "open", "high", "low", "volume"];
  const STATES = ["ENTRY", "HOLD", "EXIT_WARNING", "EXIT", "WATCH", "FORMING", "CONFIRMED", "FAILED", "TARGET_HIT"];
  const POS = ["NONE", "LONG", "SHORT", "ANY"], RESERVED = ["pivots", "trendline"];
  class DSLError extends Error {}
  function tokenize(s) {
    s = String(s); if (s.length > MAX_EXPR) throw new DSLError(`運算式過長（> ${MAX_EXPR} 字）`);
    const re = /\s*(?:(\d+\.\d*|\.\d+|\d+)|([A-Za-z_][A-Za-z0-9_]*)|(>=|<=|==|!=|[-+*/()<>,]))/y; const out = []; let i = 0;
    while (i < s.length) {
      if (!s.slice(i).trim()) break;
      re.lastIndex = i; const m = re.exec(s);
      if (!m || re.lastIndex === i) throw new DSLError(`無法辨識的字元：${JSON.stringify(s.slice(i, i + 10))}`);
      out.push(m[1] ? ["num", parseFloat(m[1])] : m[2] ? ["id", m[2]] : ["op", m[3]]); i = re.lastIndex;
    }
    return out;
  }
  function parse(src) {
    const t = tokenize(src); let i = 0, nodes = 0;
    const peek = () => t[i] || [null, null], is = (k, v) => peek()[0] === k && peek()[1] === v;
    const node = (...n) => { if (++nodes > MAX_NODES) throw new DSLError(`運算式過於複雜（> ${MAX_NODES} 節點）`); return n; };
    const eat = (k, v) => { const [pk, pv] = peek(); if (pk === null || (k && pk !== k) || (v != null && pv !== v)) throw new DSLError(`語法錯誤：預期 ${v || k}，得到 ${JSON.stringify(pv)}`); i++; return pv; };
    function or_() { let a = and_(); while (is("id", "or")) { i++; a = node("or", a, and_()); } return a; }
    function and_() { let a = not_(); while (is("id", "and")) { i++; a = node("and", a, not_()); } return a; }
    function not_() { if (is("id", "not")) { i++; return node("not", not_()); } return cmp(); }
    function cmp() { const a = sum(); const [k, v] = peek(); if (k === "op" && [">", ">=", "<", "<=", "==", "!="].includes(v)) { i++; return node("cmp", v, a, sum()); } return a; }
    function sum() { let a = prod(); while (peek()[0] === "op" && "+-".includes(peek()[1])) { const op = eat(); a = node("bin", op, a, prod()); } return a; }
    function prod() { let a = unary(); while (peek()[0] === "op" && "*/".includes(peek()[1])) { const op = eat(); a = node("bin", op, a, unary()); } return a; }
    function unary() { if (is("op", "-")) { i++; return node("neg", unary()); } return atom(); }
    function atom() {
      const [k, v] = peek();
      if (k === "num") { i++; return node("num", v); }
      if (k === "op" && v === "(") { i++; const e = or_(); eat("op", ")"); return e; }
      if (k === "id") {
        i++;
        if (["and", "or", "not"].includes(v)) throw new DSLError(`語法錯誤：${v} 位置不對`);
        if (v === "true" || v === "false") return node("num", v === "true" ? 1 : 0);
        if (is("op", "(")) { i++; const args = []; if (!is("op", ")")) { args.push(or_()); while (is("op", ",")) { i++; args.push(or_()); } } eat("op", ")"); return node("call", v, args); }
        return node("var", v);
      }
      throw new DSLError(`語法錯誤：意外的 ${JSON.stringify(v)}`);
    }
    const e = or_(); if (i !== t.length) throw new DSLError(`語法錯誤：多餘的 ${JSON.stringify(peek()[1])}`); return e;
  }
  // ---- vector helpers (Float64Array, NaN-aware)
  const full = (n, v) => new Float64Array(n).fill(v);
  const map2 = (a, b, f) => { const o = new Float64Array(a.length); for (let k = 0; k < a.length; k++) o[k] = f(a[k], b[k]); return o; };
  const B = (x) => x.map((v) => (isNaN(v) ? 0 : v !== 0 ? 1 : 0));
  const shift = (x, k) => { k = k | 0; const o = full(x.length, NaN); for (let j = k; j < x.length; j++) o[j] = x[j - k]; return o; };
  function sma(x, n) { const o = full(x.length, NaN); let s = 0; for (let j = 0; j < x.length; j++) { s += x[j]; if (j >= n) s -= x[j - n]; if (j >= n - 1) o[j] = s / n; } return o; }
  function smaExact(x, n) { // windowed exact sum (avoids drift; matches numpy cumsum within 1e-9)
    const o = full(x.length, NaN); for (let j = n - 1; j < x.length; j++) { let s = 0; for (let q = j - n + 1; q <= j; q++) s += x[q]; o[j] = s / n; } return o; }
  function ema(x, n) { const o = full(x.length, NaN); if (!x.length) return o; const a = 2 / (n + 1); o[0] = x[0]; for (let j = 1; j < x.length; j++) o[j] = a * x[j] + (1 - a) * o[j - 1]; for (let j = 0; j < n - 1 && j < x.length; j++) o[j] = NaN; return o; }
  const avgPrev = (x, n) => shift(smaExact(x, n), 1);
  function roll(x, n, f) { const o = full(x.length, NaN); for (let j = n - 1; j < x.length; j++) { const w = x.slice(j - n + 1, j + 1); o[j] = w.some(isNaN) ? NaN : f(w); } return o; }
  function cmpv(op, a, b) { return map2(a, b, (p, q) => (isNaN(p) || isNaN(q) ? 0 : (op === ">" ? p > q : op === ">=" ? p >= q : op === "<" ? p < q : op === "<=" ? p <= q : op === "==" ? p === q : p !== q) ? 1 : 0)); }
  const FUNCS = {
    sma: [[2], [1], (E, x, n) => smaExact(x, n | 0)], ema: [[2], [1], (E, x, n) => ema(x, n | 0)],
    avg_vol: [[1, 2], [0, 1], (E, n, ex = 1) => (ex ? avgPrev(E.volume, n | 0) : smaExact(E.volume, n | 0))],
    slope_pct: [[2], [1], (E, x, k) => map2(x, shift(x, k), (p, q) => p / q - 1)], ref: [[2], [1], (E, x, k) => shift(x, k)],
    cross_up: [[2], [], (E, a, b) => map2(B(cmpv("<=", shift(a, 1), shift(b, 1))), B(cmpv(">", a, b)), (p, q) => p * q)],
    cross_down: [[2], [], (E, a, b) => map2(B(cmpv(">=", shift(a, 1), shift(b, 1))), B(cmpv("<", a, b)), (p, q) => p * q)],
    highest: [[2], [1], (E, x, n) => roll(x, n | 0, (w) => Math.max(...w))], lowest: [[2], [1], (E, x, n) => roll(x, n | 0, (w) => Math.min(...w))],
    count: [[2], [1], (E, c, n) => roll(B(c), n | 0, (w) => w.reduce((s, v) => s + v, 0))],
    min: [[2], [], (E, a, b) => map2(a, b, (p, q) => (isNaN(p) || isNaN(q) ? NaN : Math.min(p, q)))],
    max: [[2], [], (E, a, b) => map2(a, b, (p, q) => (isNaN(p) || isNaN(q) ? NaN : Math.max(p, q)))],
    abs: [[1], [], (E, x) => x.map(Math.abs)],
  };
  const konst = (n) => (n[0] === "num" ? n[1] : n[0] === "neg" && n[1][0] === "num" ? -n[1][1] : null);
  function check(node, names, where = "") {
    const errs = [];
    (function walk(n) {
      const k = n[0];
      if (k === "var") { if (!(n[1] in names)) errs.push(`${where}未知名稱 '${n[1]}'`); }
      else if (k === "call") {
        const [, f, args] = n;
        if (RESERVED.includes(f)) { errs.push(`${where}${f}() 為內建型態專用的幾何函式，DSL v1 未開放`); return; }
        if (!(f in FUNCS)) { errs.push(`${where}不允許的函式 ${f}()（白名單：${Object.keys(FUNCS).sort().join(", ")}）`); return; }
        const [ar, wins] = FUNCS[f];
        if (!ar.includes(args.length)) { errs.push(`${where}${f}() 參數數量應為 ${ar.join("/")}`); return; }
        for (const i of wins) { if (i >= args.length) continue; const a = args[i];
          if (a[0] === "var" && names[a[1]] === "param") continue;
          const c = konst(a);
          if (c === null) errs.push(`${where}${f}() 第 ${i + 1} 個參數必須是常數或參數`);
          else if (!(c >= 0 && c <= MAX_WIN) || c !== Math.floor(c)) errs.push(`${where}${f}() 回溯長度需為 0–${MAX_WIN} 的整數`); }
        args.forEach(walk);
      } else if (k === "bin" || k === "cmp") { walk(n[2]); walk(n[3]); }
      else if (k === "and" || k === "or") { walk(n[1]); walk(n[2]); }
      else if (k === "not" || k === "neg") walk(n[1]);
    })(node);
    return errs;
  }
  function tryCheck(expr, names, where, E) { try { E.push(...check(parse(expr), names, where)); } catch (e) { E.push(where + e.message); } }
  function validate(d) {
    const E = [];
    if (!d || typeof d !== "object" || Array.isArray(d)) return ["定義必須是 JSON 物件"];
    for (const k of ["code", "name", "version", "directions", "params", "series", "states"]) if (!(k in d)) E.push(`缺少必要欄位 ${k}`);
    if (E.length) return E;
    if (typeof d.code !== "string" || !/^[a-z0-9_]+$/.test(d.code)) E.push("code 只能用小寫英數與底線");
    if (!Number.isInteger(d.version) || d.version < 1) E.push("version 必須是 ≥1 的整數");
    if (!Array.isArray(d.directions) || !d.directions.length || d.directions.some((x) => x !== "long" && x !== "short")) E.push("directions 只能含 long／short");
    if (!["baseline", "experiment", "standard"].includes(d.role || "standard")) E.push("role 不合法");
    if (!["X2", "X3"].includes(d.native_exit || "X3")) E.push("native_exit 只能是 X2 或 X3");
    if (!d.params || typeof d.params !== "object") { E.push("params 必須是物件"); return E; }
    const names = Object.fromEntries(BASE.map((b) => [b, "base"]));
    for (const [p, spec] of Object.entries(d.params)) {
      if (!/^[a-z_][a-z0-9_]*$/.test(p)) E.push(`參數名 '${p}' 不合法`);
      if (!spec || typeof spec !== "object" || !("default" in spec)) { E.push(`參數 ${p} 缺 default`); continue; }
      if (typeof spec.default !== "number") E.push(`參數 ${p} 的 default 必須是數字`);
      names[p] = "param";
    }
    if (!d.series || typeof d.series !== "object" || Object.keys(d.series).length > MAX_SERIES) { E.push(`series 必須是物件且 ≤ ${MAX_SERIES} 個`); return E; }
    for (const [s, expr] of Object.entries(d.series)) {
      if (s in names || s in FUNCS || RESERVED.includes(s) || !/^[a-z_][a-z0-9_]*$/.test(s)) { E.push(`series 名稱 '${s}' 重複或不合法`); continue; }
      tryCheck(expr, names, `series.${s}：`, E); names[s] = "series";
    }
    for (const [f, expr] of Object.entries(d.strong_flags || {})) { tryCheck(expr, names, `strong_flags.${f}：`, E); names[f] = "flag"; }
    if (!Array.isArray(d.states) || !d.states.length || d.states.length > MAX_STATES) { E.push(`states 必須是 1–${MAX_STATES} 筆的陣列`); return E; }
    d.states.forEach((st, i) => {
      const w = `states[${i}]：`;
      if (!st || typeof st !== "object" || !("state" in st) || !("when" in st)) { E.push(w + "需要 state 與 when"); return; }
      if (!STATES.includes(st.state)) E.push(w + `state '${st.state}' 不合法`);
      if (![undefined, null, "long", "short"].includes(st.direction)) E.push(w + "direction 只能 long／short／null");
      if (st.direction && !d.directions.includes(st.direction)) E.push(w + `direction ${st.direction} 不在 directions 內`);
      if (!POS.includes(st.requires_position || "ANY")) E.push(w + "requires_position 不合法");
      for (const fld of ["when", "strength"]) if (fld in st) tryCheck(st[fld], names, w + `${fld}：`, E);
      for (const [lk, le] of Object.entries(st.levels || {})) tryCheck(le, names, w + `levels.${lk}：`, E);
    });
    return E;
  }
  function compile(d, override = {}) {
    const errs = validate(d); if (errs.length) throw new DSLError(errs.join("；"));
    const params = Object.fromEntries(Object.entries(d.params).map(([k, v]) => [k, +(k in override ? override[k] : v.default)]));
    const series = Object.entries(d.series).map(([k, v]) => [k, parse(v)]);
    const flags = Object.entries(d.strong_flags || {}).map(([k, v]) => [k, parse(v)]);
    const states = d.states.map((st) => ({ ...st, _w: parse(st.when), _s: st.strength ? parse(st.strength) : null, _lv: Object.entries(st.levels || {}).map(([k, v]) => [k, parse(v)]) }));
    function ev(n, E) {
      const k = n[0], N = E.close.length;
      if (k === "num") return full(N, n[1]);
      if (k === "var") return E[n[1]];
      if (k === "neg") return ev(n[1], E).map((v) => -v);
      if (k === "not") return B(ev(n[1], E)).map((v) => 1 - v);
      if (k === "and") return map2(B(ev(n[1], E)), B(ev(n[2], E)), (p, q) => p * q);
      if (k === "or") return map2(B(ev(n[1], E)), B(ev(n[2], E)), (p, q) => Math.max(p, q));
      if (k === "cmp") return cmpv(n[1], ev(n[2], E), ev(n[3], E));
      if (k === "bin") { const a = ev(n[2], E), b = ev(n[3], E), op = n[1];
        return map2(a, b, (p, q) => { if (op === "+") return p + q; if (op === "-") return p - q; if (op === "*") return p * q; const r = p / q; return isFinite(r) ? r : NaN; }); }
      if (k === "call") { const [ar, wins, fn] = FUNCS[n[1]];
        const vals = n[2].map((a, i) => (wins.includes(i) ? (konst(a) !== null ? konst(a) : E[a[1]][0]) : ev(a, E)));
        return fn(E, ...vals); }
      throw new DSLError("未知節點 " + k);
    }
    function env(o, h, l, c, v) {
      const E = { close: Float64Array.from(c), open: Float64Array.from(o), high: Float64Array.from(h), low: Float64Array.from(l), volume: Float64Array.from(v) };
      for (const [k, p] of Object.entries(params)) E[k] = full(c.length, p);
      for (const [k, node] of series) E[k] = ev(node, E);
      for (const [k, node] of flags) E[k] = B(ev(node, E));
      E._cache = {}; return E;
    }
    const cached = (E, key, node) => (E._cache[key] || (E._cache[key] = ev(node, E)));
    function stateAt(E, t, position = "NONE", shortable = null) {
      if (t < (d.min_bars || 60) - 1) return { state: "NO_DATA", direction: null, strength: null, levels: {}, strong: false };
      for (let i = 0; i < states.length; i++) {
        const st = states[i], rp = st.requires_position || "ANY";
        if (rp !== "ANY" && rp !== position) continue;
        if (!cached(E, "w" + i, st._w)[t]) continue;
        const dir = st.direction ?? null;
        if (st.state === "ENTRY" && dir === "short" && shortable === false) continue;
        let strength = null; if (st._s) { const sv = cached(E, "s" + i, st._s)[t]; strength = isNaN(sv) ? null : sv; }
        const levels = Object.fromEntries(st._lv.map(([k, node]) => [k, cached(E, "l" + i + k, node)[t]]));
        return { state: st.state, direction: dir, strength, levels, strong: flags.some(([k]) => E[k][t]), note: st.note || null };
      }
      return { state: "WATCH", direction: null, strength: null, levels: {}, strong: false };
    }
    return { def: d, params, env, stateAt };
  }
  return { DSLError, tokenize, parse, check, validate, compile, FUNCS: Object.keys(FUNCS), BASE, STATES, POS, MAX_WIN };
});
