/* 型態雷達 本機資料庫（§14.1）— IndexedDB「pattern-radar」
 * 使用者資料表（皆帶同步欄位 id / updated_at / updated_by_device / deleted / version；欄位名稱與 box 端 SQLite 相同，
 * 所以加密備份檔可直接用 pipeline/run_backup.py 匯入 box，供盤後批次使用）：
 *   patterns, pattern_versions, watchlist, alert_settings, fundamental_rules, settings, backtest_runs
 * 另有：cache（掃描結果 JSON 快取，含 cached_at；離線時唯讀）、blobs（最近 K 份加密備份）、meta（device_id 等本機值，不備份）。 */
(function (root) {
  "use strict";
  const DB_NAME = "pattern-radar", DB_VER = 1, K_BLOBS = 7;
  const USER = ["patterns", "pattern_versions", "watchlist", "alert_settings", "fundamental_rules", "settings", "backtest_runs"];
  let dbp = null;
  function open() {
    if (dbp) return dbp;
    dbp = new Promise((ok, no) => {
      if (!root.indexedDB) return no(new Error("此瀏覽器不支援 IndexedDB"));
      const r = indexedDB.open(DB_NAME, DB_VER);
      r.onupgradeneeded = () => {
        const db = r.result;
        for (const t of USER) if (!db.objectStoreNames.contains(t)) db.createObjectStore(t, { keyPath: "id" });
        if (!db.objectStoreNames.contains("cache")) db.createObjectStore("cache", { keyPath: "name" });
        if (!db.objectStoreNames.contains("blobs")) db.createObjectStore("blobs", { keyPath: "id" });
        if (!db.objectStoreNames.contains("meta")) db.createObjectStore("meta", { keyPath: "k" });
      };
      r.onsuccess = () => ok(r.result); r.onerror = () => no(r.error);
    });
    return dbp;
  }
  const req = (r) => new Promise((ok, no) => { r.onsuccess = () => ok(r.result); r.onerror = () => no(r.error); });
  async function tx(store, mode, fn) {
    const db = await open(); const t = db.transaction(store, mode); const s = t.objectStore(store);
    const out = await fn(s); await new Promise((ok, no) => { t.oncomplete = ok; t.onerror = () => no(t.error); t.onabort = () => no(t.error); });
    return out;
  }
  const all = (store) => tx(store, "readonly", (s) => req(s.getAll()));
  const get = (store, key) => tx(store, "readonly", (s) => req(s.get(key)));
  const put = (store, v) => tx(store, "readwrite", (s) => req(s.put(v)));
  const del = (store, key) => tx(store, "readwrite", (s) => req(s.delete(key)));
  const nowISO = () => new Date().toISOString();
  async function meta(k, v) { if (v === undefined) { const r = await get("meta", k); return r ? r.v : undefined; } await put("meta", { k, v }); return v; }
  async function deviceId() {
    let d = await meta("device_id");
    if (!d) d = await meta("device_id", (root.RadarBackup ? RadarBackup.uuid7() : String(Date.now())) );
    return d;
  }
  // --- user rows (sync fields maintained here; deletes are tombstones)
  async function save(table, row) {
    const cur = row.id ? await get(table, row.id) : null;
    const r = Object.assign({}, cur || {}, row, { id: row.id || RadarBackup.uuid7(), updated_at: nowISO(), updated_by_device: await deviceId(),
      deleted: 0, version: ((cur && cur.version) || 0) + 1 });
    await put(table, r); return r;
  }
  async function remove(table, id) {
    const cur = await get(table, id); if (!cur) return;
    await put(table, Object.assign({}, cur, { deleted: 1, updated_at: nowISO(), updated_by_device: await deviceId(), version: (cur.version || 1) + 1 }));
  }
  const live = async (table) => (await all(table)).filter((r) => !r.deleted);
  async function setting(key, value) { // settings table (key = id), value stored as value_json like SQLite
    if (value === undefined) { const r = await get("settings", key); return r && !r.deleted ? JSON.parse(r.value_json) : undefined; }
    return save("settings", { id: key, key, value_json: JSON.stringify(value) });
  }
  async function exportTables() { const o = {}; for (const t of USER) o[t] = await all(t); return o; }
  async function importTables(tables) { // after merge: replace each table with merged rows
    for (const t of USER) { if (!tables[t]) continue;
      await tx(t, "readwrite", async (s) => { await req(s.clear()); for (const r of tables[t]) s.put(r); }); }
  }
  // --- data cache (scan JSON), read-only fallback offline (§18.4)
  async function cachePut(name, json) { try { await put("cache", { name, json, cached_at: nowISO() }); } catch (e) {} }
  async function cacheGet(name) { try { return await get("cache", name); } catch (e) { return null; } }
  async function cacheList() { try { return (await all("cache")).map((r) => ({ name: r.name, cached_at: r.cached_at, as_of: r.json && (r.json.data_as_of || r.json.trade_date || (r.json.config && r.json.config.end)) })); } catch (e) { return []; } }
  // --- encrypted backup blobs (keep last K)
  async function blobAdd(b) {
    await put("blobs", b);
    const xs = (await all("blobs")).sort((a, c) => (a.created_at < c.created_at ? 1 : -1));
    for (const x of xs.slice(K_BLOBS)) await del("blobs", x.id);
  }
  const blobs = async () => (await all("blobs")).sort((a, c) => (a.created_at < c.created_at ? 1 : -1));
  // --- migrate P1 localStorage fundamentals rules → fundamental_rules table (once)
  async function migrate() {
    if (await meta("migrated_v1")) return;
    try {
      const ls = JSON.parse(localStorage.getItem("radar.fundRules") || "null");
      if (ls && ls.length) await save("fundamental_rules", { id: "default", name: "預設", rules_json: JSON.stringify(ls) });
    } catch (e) {}
    await meta("migrated_v1", nowISO());
  }
  root.RadarStore = { USER, K_BLOBS, open, all, get, put, del, save, remove, live, setting, meta, deviceId, exportTables, importTables,
    cachePut, cacheGet, cacheList, blobAdd, blobs, migrate, nowISO };
})(self);
