/* 型態雷達 備份核心（§3.3、§14.3、§15）— 瀏覽器與 node 共用（node 用於測試；Python 版在 pipeline/radar/backup.py，格式相同）
 * 復原碼 → PBKDF2-SHA256(210000, salt "pattern-radar/v1") → 64 bytes：前 32 = AES-256-GCM 金鑰，後 32 → vault_id = SHA-256 hex 前 32 字
 * 檔案格式：ASCII "PRB1" + 12-byte IV + AES-GCM(gzip(UTF-8 JSON))；JSON = { schema_version, exported_at, device_id, vault_id, tables:{…} }
 * 合併（§14.3）：同 id 取 updated_at 新者；相同比 version；再相同比 updated_by_device 字典序大者 → 結果固定。tombstone（deleted=1）照同規則。 */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory(globalThis.crypto, globalThis);
  else root.RadarBackup = factory(root.crypto, root);
})(typeof self !== "undefined" ? self : this, function (crypto, G) {
  "use strict";
  const SCHEMA_VERSION = 1, ITER = 210000, SALT = "pattern-radar/v1", MAGIC = "PRB1";
  const ALPH = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"; // 無 0/O/1/I/L
  const enc = new TextEncoder(), dec = new TextDecoder();
  const USER_TABLES = ["patterns", "pattern_versions", "watchlist", "alert_settings", "fundamental_rules", "settings", "backtest_runs"];
  const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
  function newRecoveryCode() {
    const r = crypto.getRandomValues(new Uint8Array(24));
    const s = [...r].map((x) => ALPH[x % ALPH.length]).join("");
    return s.match(/.{4}/g).join("-");
  }
  const normCode = (c) => String(c || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  async function derive(code) {
    const base = await crypto.subtle.importKey("raw", enc.encode(normCode(code)), "PBKDF2", false, ["deriveBits"]);
    const bits = new Uint8Array(await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: enc.encode(SALT), iterations: ITER }, base, 512));
    const key = await crypto.subtle.importKey("raw", bits.slice(0, 32), "AES-GCM", false, ["encrypt", "decrypt"]);
    const vault_id = hex(await crypto.subtle.digest("SHA-256", bits.slice(32))).slice(0, 32);
    return { key, vault_id };
  }
  async function gzip(bytes) {
    const cs = new G.CompressionStream("gzip"); const w = cs.writable.getWriter(); w.write(bytes); w.close();
    return new Uint8Array(await new G.Response(cs.readable).arrayBuffer());
  }
  async function gunzip(bytes) {
    const ds = new G.DecompressionStream("gzip"); const w = ds.writable.getWriter(); w.write(bytes); w.close();
    return new Uint8Array(await new G.Response(ds.readable).arrayBuffer());
  }
  // canonical JSON (sorted keys) → checksum stable across devices / Python
  function canon(v) {
    if (Array.isArray(v)) return "[" + v.map(canon).join(",") + "]";
    if (v && typeof v === "object") return "{" + Object.keys(v).sort().map((k) => JSON.stringify(k) + ":" + canon(v[k])).join(",") + "}";
    return JSON.stringify(v === undefined ? null : v);
  }
  async function checksum(tables) {
    const sorted = {};
    for (const t of Object.keys(tables).sort()) sorted[t] = [...tables[t]].sort((a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
    return hex(await crypto.subtle.digest("SHA-256", enc.encode(canon(sorted))));
  }
  async function encryptBackup(doc, code) {
    const { key, vault_id } = await derive(code);
    doc = Object.assign({ schema_version: SCHEMA_VERSION }, doc, { vault_id });
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, await gzip(enc.encode(JSON.stringify(doc)))));
    const out = new Uint8Array(4 + 12 + ct.length); out.set(enc.encode(MAGIC), 0); out.set(iv, 4); out.set(ct, 16);
    return { bytes: out, vault_id, checksum: await checksum(doc.tables || {}) };
  }
  async function decryptBackup(bytes, code) {
    bytes = new Uint8Array(bytes);
    if (dec.decode(bytes.slice(0, 4)) !== MAGIC) throw new Error("不是型態雷達備份檔（檔頭不符）");
    const { key, vault_id } = await derive(code);
    let pt;
    try { pt = await crypto.subtle.decrypt({ name: "AES-GCM", iv: bytes.slice(4, 16) }, key, bytes.slice(16)); }
    catch (e) { throw new Error("復原碼不正確，或檔案已損壞（AES-GCM 驗證失敗）"); }
    const doc = JSON.parse(dec.decode(await gunzip(new Uint8Array(pt))));
    if (doc.schema_version > SCHEMA_VERSION) throw new Error(`備份 schema_version ${doc.schema_version} 比本 App 新，請先更新 App`);
    if (doc.vault_id && doc.vault_id !== vault_id) throw new Error("vault_id 不符");
    return { doc, vault_id, checksum: await checksum(doc.tables || {}) };
  }
  function newer(a, b) { // true if a should win over b
    if (a.updated_at !== b.updated_at) return a.updated_at > b.updated_at;
    if ((a.version || 1) !== (b.version || 1)) return (a.version || 1) > (b.version || 1);
    return String(a.updated_by_device || "") > String(b.updated_by_device || "");
  }
  function mergeTables(local, remote) {
    const out = {}, stats = {};
    for (const t of new Set([...Object.keys(local || {}), ...Object.keys(remote || {})])) {
      const m = new Map(); let taken = 0, kept = 0, added = 0;
      for (const r of (local || {})[t] || []) m.set(r.id, r);
      for (const r of (remote || {})[t] || []) {
        const cur = m.get(r.id);
        if (!cur) { m.set(r.id, r); added++; } else if (newer(r, cur)) { m.set(r.id, r); taken++; } else kept++;
      }
      out[t] = [...m.values()]; stats[t] = { added, taken, kept, total: out[t].length, live: out[t].filter((r) => !r.deleted).length };
    }
    return { tables: out, stats };
  }
  // UUID v7（§14.3：可依時間排序）
  function uuid7() {
    const b = crypto.getRandomValues(new Uint8Array(16)); let ms = Date.now();
    for (let i = 5; i >= 0; i--) { b[i] = ms % 256; ms = Math.floor(ms / 256); }
    b[6] = (b[6] & 0x0f) | 0x70; b[8] = (b[8] & 0x3f) | 0x80;
    const h = hex(b); return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
  }
  return { SCHEMA_VERSION, USER_TABLES, newRecoveryCode, normCode, derive, encryptBackup, decryptBackup, mergeTables, newer, checksum, canon, uuid7 };
});
