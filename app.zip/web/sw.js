/* App Shell: cache-first + background refresh. Data JSON: network-first (handled in app.js + here). §14.5 / §18.4 */
const CACHE = "radar-shell-v13";
const DATA_CACHE = "radar-data-v13";
const SHELL = ["./", "./index.html", "./styles.css", "./app.js", "./manifest.webmanifest", "./icon-192.png", "./icon-512.png", "./apple-touch-icon.png", "./lightweight-charts.js", "./backup-core.js", "./store.js", "./dsl.js", "./pages.js", "./etf.js"];
// 資料 JSON（每日批次產生）：網路優先，失敗才用上次快取（app.js 另有 IndexedDB 快取＋離線標示）
const DATA = ["summary_latest.json", "scan_latest.json", "fundamentals_latest.json", "backtest_latest.json", "backtest_trades.json", "health_latest.json", "indices_latest.json", "etf_00631L.json", "fx_twd.json", "margin_latest.json"];
self.addEventListener("install", (e) => e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting())));
self.addEventListener("activate", (e) => e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => (k.startsWith("radar-shell") && k !== CACHE) || (k.startsWith("radar-data-v") && k !== DATA_CACHE)).map((k) => caches.delete(k)))).then(() => self.clients.claim())));
self.addEventListener("fetch", (e) => {
  const req = e.request; if (req.method !== "GET") return;
  const url = new URL(req.url); if (url.origin !== location.origin) return;
  if (url.pathname.endsWith(".json")) {
    const name = url.pathname.split("/").pop();
    if (!DATA.includes(name)) return; // bars_*.json 等：交給 app.js（IndexedDB 快取）
    e.respondWith(fetch(req).then((res) => { if (res.ok) { const copy = res.clone(); caches.open(DATA_CACHE).then((c) => c.put(name, copy)); } return res; })
      .catch(() => caches.open(DATA_CACHE).then((c) => c.match(name)).then((hit) => hit ? hit.blob().then((b) => new Response(b, { status: 200, headers: { "Content-Type": "application/json", "X-Radar-SW-Cache": "1" } })) : Response.error())));
    return;
  }
  e.respondWith(caches.match(req, { ignoreSearch: true }).then((hit) => {
    const net = fetch(req).then((res) => { if (res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); } return res; }).catch(() => hit);
    return hit || net;
  }));
});
