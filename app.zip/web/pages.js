/* 型態雷達 — 其餘畫面（§13）：回測實驗室、BacktestMiniCard、自選／持有、警示設定、備份與還原、型態編輯器、資料狀態、設定；
 * 以及遊戲感效果：GradientCandleChart（Lightweight Charts 自訂 series）、命中粒子、Web Audio 短音效（預設關閉）。
 * 依賴 app.js 暴露的 window.RadarApp、store.js 的 RadarStore、backup-core.js 的 RadarBackup、dsl.js 的 RadarDSL。 */
(function () {
  "use strict";
  const A = window.RadarApp, S = window.RadarStore, $app = document.getElementById("app");
  const { esc, fmt, go } = A;
  const pct = (x, d = 1) => (x == null || isNaN(x) ? "—" : `${(x * 100).toFixed(d)}%`);
  const sgn = (x, d = 2) => (x == null || isNaN(x) ? "—" : `${x >= 0 ? "+" : ""}${(x * 100).toFixed(d)}%`);
  const reduce = () => matchMedia("(prefers-reduced-motion: reduce)").matches;
  const qs = (h) => Object.fromEntries(new URLSearchParams((h.split("?")[1] || "")));
  const off = () => A.OFFLINE || navigator.onLine === false;

  // ================================================================ 偏好（同步讀：localStorage 鏡像；寫入同時存 IndexedDB settings）
  const PREF_DEF = { sound: false, particles: true, gradient: true };
  function prefs() { try { return Object.assign({}, PREF_DEF, JSON.parse(localStorage.getItem("radar.prefs") || "{}")); } catch (e) { return Object.assign({}, PREF_DEF); } }
  const pref = (k) => prefs()[k];
  function setPref(k, v) { const p = prefs(); p[k] = v; localStorage.setItem("radar.prefs", JSON.stringify(p)); if (S) S.setting("ui_prefs", p).catch(() => {}); }

  // ================================================================ FX：粒子（canvas）＋音效（Web Audio）
  let fxCanvas = null, parts = [], fxRun = false, actx = null;
  function canvas() {
    if (fxCanvas) return fxCanvas;
    fxCanvas = document.createElement("canvas"); fxCanvas.className = "fx"; fxCanvas.setAttribute("aria-hidden", "true");
    document.body.appendChild(fxCanvas);
    const fit = () => { const r = devicePixelRatio || 1; fxCanvas.width = innerWidth * r; fxCanvas.height = innerHeight * r; };
    fit(); addEventListener("resize", fit); return fxCanvas;
  }
  function burst(x, y, color, n = 36) {
    if (!pref("particles") || reduce()) return;
    const c = canvas(), r = devicePixelRatio || 1;
    for (let i = 0; i < n; i++) { const a = Math.random() * Math.PI * 2, v = 1.5 + Math.random() * 4.5;
      parts.push({ x: x * r, y: y * r, vx: Math.cos(a) * v * r, vy: Math.sin(a) * v * r - 1.5 * r, life: 1, size: (1.5 + Math.random() * 2.5) * r, color }); }
    if (!fxRun) { fxRun = true; requestAnimationFrame(tick); }
  }
  function tick() {
    const c = fxCanvas, g = c.getContext("2d"); g.clearRect(0, 0, c.width, c.height);
    g.globalCompositeOperation = "lighter";
    parts = parts.filter((p) => p.life > 0);
    for (const p of parts) { p.x += p.vx; p.y += p.vy; p.vy += 0.08 * (devicePixelRatio || 1); p.vx *= 0.985; p.life -= 0.018;
      g.globalAlpha = Math.max(0, p.life); g.fillStyle = p.color; g.shadowColor = p.color; g.shadowBlur = 8;
      g.beginPath(); g.arc(p.x, p.y, p.size, 0, Math.PI * 2); g.fill(); }
    g.globalAlpha = 1; g.shadowBlur = 0;
    if (parts.length) requestAnimationFrame(tick); else { fxRun = false; g.clearRect(0, 0, c.width, c.height); }
  }
  function ping(dir) {  // 短音效：只在使用者開啟後、且有互動之後播放（§13）
    if (!pref("sound")) return;
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)();
      if (actx.state === "suspended") actx.resume();
      const t = actx.currentTime, f = dir === "short" ? [660, 440] : [520, 880];
      f.forEach((hz, i) => { const o = actx.createOscillator(), g = actx.createGain(); o.type = "triangle"; o.frequency.value = hz;
        g.gain.setValueAtTime(0.0001, t + i * 0.09); g.gain.exponentialRampToValueAtTime(0.18, t + i * 0.09 + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + i * 0.09 + 0.22);
        o.connect(g).connect(actx.destination); o.start(t + i * 0.09); o.stop(t + i * 0.09 + 0.25); });
    } catch (e) {}
  }
  function gateFx(totals) {  // 方向入口：今日有新命中 → 數字處粒子爆散
    setTimeout(() => document.querySelectorAll(".dir").forEach((b) => {
      const n = ((totals || {})[b.dataset.dir] || {}).new_symbols || 0; if (!n) return;
      const el = b.querySelector(".cnt b"), r = el.getBoundingClientRect();
      burst(r.left + r.width / 2, r.top + r.height / 2, b.dataset.dir === "long" ? "#00F0FF" : "#FF2BD6", 26);
      burst(r.left + r.width / 2, r.top + r.height / 2, "#B6FF3B", 14);
    }), 250);
    document.querySelectorAll(".dir").forEach((b) => b.addEventListener("click", () => ping(b.dataset.dir), { once: true }));
  }
  function hitFx(svg, dir) {  // 類股雷達：掃完時在命中扇區亮點爆散＋音效
    const blips = [...svg.querySelectorAll(".blip")]; if (!blips.length) return;
    blips.slice(0, 8).forEach((b, i) => setTimeout(() => { const r = b.getBoundingClientRect(); burst(r.left + r.width / 2, r.top + r.height / 2, "#B6FF3B", 18); }, i * 90));
    ping(dir);
  }

  // ================================================================ GradientCandleChart（§13：紅漲綠跌漸層實體，量越大外光越亮）
  function gradientCandles(chart, time, B) {
    const vr = B.v.map((v, i) => { if (i < 5) return 1; let s = 0, n = Math.min(20, i); for (let k = i - n; k < i; k++) s += B.v[k]; return s ? v / (s / n) : 1; });
    class R {
      update(d) { this.d = d; }
      draw(target, toY) {
        target.useBitmapCoordinateSpace(({ context: g, horizontalPixelRatio: hr, verticalPixelRatio: vrt }) => {
          const d = this.d; if (!d || !d.visibleRange) return;
          const bw = Math.max(1, Math.floor(d.barSpacing * hr * 0.72)), ww = Math.max(1, Math.floor(hr));
          for (let i = d.visibleRange.from; i < d.visibleRange.to; i++) {
            const b = d.bars[i]; if (!b) continue; const o = b.originalData; if (o.close == null) continue;
            const yo = toY(o.open), yc = toY(o.close), yh = toY(o.high), yl = toY(o.low); if ([yo, yc, yh, yl].some((y) => y == null)) continue;
            const up = o.close >= o.open, x = Math.round(b.x * hr);
            const top = Math.round(Math.min(yo, yc) * vrt), bot = Math.max(top + 1, Math.round(Math.max(yo, yc) * vrt));
            const c1 = up ? "#FF8098" : "#7CFFC4", c2 = up ? "#C8102E" : "#06844A", glow = up ? "rgba(255,59,92,.9)" : "rgba(30,217,122,.9)";
            g.fillStyle = up ? "#FF3B5C" : "#1ED97A";
            g.fillRect(x - Math.floor(ww / 2), Math.round(yh * vrt), ww, Math.max(1, Math.round((yl - yh) * vrt)));
            const gr = g.createLinearGradient(0, top, 0, bot); gr.addColorStop(0, c1); gr.addColorStop(1, c2);
            const k = Math.max(0, Math.min(1, (o.vr - 1) / 2)); // 量比 1→3 對應外光 0→滿
            g.save(); if (k > 0.05) { g.shadowColor = glow; g.shadowBlur = (4 + 16 * k) * hr; }
            g.fillStyle = gr; g.fillRect(x - Math.floor(bw / 2), top, bw, bot - top); g.restore();
          }
        });
      }
    }
    const r = new R();
    const view = { renderer: () => r, update: (d, opt) => r.update(d, opt), priceValueBuilder: (d) => [d.low, d.high, d.close],
      isWhitespace: (d) => d.close === undefined, defaultOptions: () => ({ priceLineVisible: false, lastValueVisible: false }), destroy() {} };
    const s = chart.addCustomSeries(view, { priceLineVisible: false, lastValueVisible: false }, 0);
    s.setData(time.map((t, i) => ({ time: t, open: B.o[i], high: B.h[i], low: B.l[i], close: B.c[i], vr: vr[i] })));
    return s;
  }

  // ================================================================ 共用
  function page(title, back, body, right = "") {
    $app.innerHTML = `<div class="bar"><button type="button" class="btn" id="pback">← ${esc(back[1])}</button><h2>${title}</h2>${right}</div>${body}`;
    $app.querySelector("#pback").addEventListener("click", () => go(back[0]));
  }
  function download(name, data, type) {
    const url = URL.createObjectURL(data instanceof Blob ? data : new Blob([data], { type }));
    const a = document.createElement("a"); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 2000);
  }
  let BT = null, TR = null;
  async function needBT() { if (!BT) BT = await A.getJSON("backtest_latest.json"); return BT; }
  async function needTR() { if (!TR) { const j = await A.getJSON("backtest_trades.json"); TR = j.rows.map((r) => Object.fromEntries(j.cols.map((c, i) => [c, r[i]]))); } return TR; }

  // ================================================================ 回測實驗室（§12、§13：BacktestForm / ExitSetCompare / EquityCurve / StatsGrid / ShortCostNote）
  const XCOL = { X1: "#B6FF3B", X2: "#00F0FF", X3: "#FF8A00" };
  const XZH = { X1: "固定停損利", X2: "型態出場", X3: "均線出場" };   // 內部代號 X1/X2/X3 不變（JSON、params、DSL），畫面只顯示中文名稱
  const XTIP = { X1: "固定停損利（主軸）：扣成本後 −7% 停損、+12% 停利、最多持有 10 個交易日；13 種型態共用（代號 X1）",
    X2: "型態出場（對照）：蔡森十二招專用，碰滿足點、收盤破停損參考價或型態失敗就出場，無天數上限（代號 X2）",
    X3: "均線出場（對照）：CIS 兩組專用，多方第一根收盤跌破 5 日與 25 日均線的黑 K 出場、空方鏡像，無天數上限（代號 X3）" };
  const XROLE = (x) => (x === "X1" ? "主軸" : "對照組");
  const GZH = { base: "基準線", exp: "實驗組", "—": "" };
  function tradeMetrics(ts) {  // 與 pipeline/radar/backtest.metrics 相同定義（期間篩選時在瀏覽器端重算）
    const n = ts.length, rets = ts.map((t) => t.net), w = rets.filter((r) => r > 0), l = rets.filter((r) => r <= 0);
    const m = { trades: n, exit_reasons: {}, open_at_end: ts.filter((t) => t.reason === "open_end").length };
    ts.forEach((t) => (m.exit_reasons[t.reason] = (m.exit_reasons[t.reason] || 0) + 1));
    if (n) { const wr = w.length / n, aw = w.length ? w.reduce((a, b) => a + b, 0) / w.length : 0, al = l.length ? l.reduce((a, b) => a + b, 0) / l.length : 0;
      Object.assign(m, { win_rate: wr, avg_net: rets.reduce((a, b) => a + b, 0) / n, avg_win: aw, avg_loss: al, payoff: al ? aw / Math.abs(al) : null, expectancy: wr * aw + (1 - wr) * al,
        hold_mean: ts.reduce((a, t) => a + t.hold_days, 0) / n });
      const hs = ts.map((t) => t.hold_days).sort((a, b) => a - b); m.hold_median = n % 2 ? hs[(n - 1) / 2] : (hs[n / 2 - 1] + hs[n / 2]) / 2; }
    return m;
  }
  function mddOf(nav) { let pk = -Infinity, m = 0; for (const v of nav) { pk = Math.max(pk, v); m = Math.min(m, v / pk - 1); } return m; }
  async function renderLab(h) {
    $app.innerHTML = `<p class="loading">載入回測結果…</p>`;
    let bt; try { bt = await needBT(); } catch (e) { $app.innerHTML = `<p class="loading">回測結果無法載入${off() ? "（離線且無快取）" : ""}。</p>`; return; }
    const q = qs(h), dir = q.d === "short" ? "short" : "long", minN = bt.config.min_trades_display;
    const pats = [...new Set(bt.combos.filter((c) => c.direction === dir).map((c) => c.pattern))];
    const pid = pats.includes(q.p) ? q.p : pats.includes("cis_base") ? "cis_base" : pats[0];
    const isCis = pid && pid.startsWith("cis"), smp = ["ALL", "IS", "OOS"].includes(q.s) ? q.s : "ALL";
    const from = q.f || bt.config.start, to = q.t || bt.config.end, custom = from !== bt.config.start || to !== bt.config.end;
    const xs = (q.x || "X1,X2,X3").split(",");
    // CIS 基準線與實驗組並排（§12.2）：選 cis_* 時兩組都列出
    const combos = bt.combos.filter((c) => c.direction === dir && (isCis ? c.pattern.startsWith("cis") : c.pattern === pid) && xs.includes(c.exit_set))
      .sort((a, b) => (a.group + a.exit_set).localeCompare(b.group + b.exit_set));
    let trades = null;
    if (custom) { try { trades = await needTR(); } catch (e) { trades = null; } }
    const iFrom = Math.max(0, bt.days.findIndex((d) => d >= from)), iTo = (() => { let k = -1; bt.days.forEach((d, i) => { if (d <= to) k = i; }); return k < 0 ? bt.days.length - 1 : k; })();
    const iSplit = bt.days.findIndex((d) => d >= bt.config.split);
    function M(c, s) {
      if (!custom) return c.metrics[s] || { trades: 0 };
      if (!trades) return { trades: 0, unavailable: true };
      const sel = trades.filter((t) => t.pattern === c.pattern && t.group === c.group && t.exit_set === c.exit_set && t.direction === c.direction &&
        t.signal_date >= from && t.signal_date <= to && (s === "ALL" || t.sample === s));
      const m = tradeMetrics(sel); m.insufficient = m.trades < minN;
      const nav = c.nav.slice(iFrom, iTo + 1); m.max_drawdown = nav.length ? mddOf(nav.map((v) => v - nav[0] + 1)) : null; m.skipped_full = null;
      return m;
    }
    const D = A.DIR[dir], col = (c) => `${XZH[c.exit_set] || c.exit_set}${isCis ? "・" + GZH[c.group] : ""}`;
    const rowsDef = [["交易數", (m) => m.trades, (v) => v], ["勝率", (m) => m.win_rate, pct, 1], ["平均淨報酬（期望值）", (m) => m.expectancy, sgn],
      ["平均獲利", (m) => m.avg_win, sgn], ["平均虧損", (m) => m.avg_loss, sgn], ["盈虧比", (m) => m.payoff, (v) => fmt(v, 2)], ["最大回撤（組合淨值）", (m) => m.max_drawdown, sgn],
      ["平均持有（交易日）", (m) => m.hold_mean, (v) => fmt(v, 1)], ["中位持有（交易日）", (m) => m.hold_median, (v) => fmt(v, 1)], ["期末未平倉", (m) => m.open_at_end, (v) => v ?? "—"], ["滿檔不進", (m) => m.skipped_full, (v) => v ?? "—"]];
    const cell = (m, f, fm, isWin) => { if (!m || !m.trades) return `<td class="r pend-t">${m && m.unavailable ? "逐筆檔未載入" : "待實測"}</td>`;
      if (isWin && m.insufficient) return `<td class="r pend-t">樣本不足</td>`;  // §12.4：不足 min_trades_display 不顯示勝率
      const v = f(m); return `<td class="r num${m.insufficient ? " insuf" : ""}">${v == null ? "—" : fm(v)}</td>`; };
    const cmp = combos.length ? `<div class="scroll"><table class="cmp"><thead><tr><th>指標（${smp === "ALL" ? "全期" : smp === "IS" ? "樣本內" : "樣本外"}）</th>${combos.map((c) => `<th class="r" style="color:${XCOL[c.exit_set]}"><span title="${esc(XTIP[c.exit_set] || "")}">${esc(col(c))}</span><br><span class="muted">${XROLE(c.exit_set)}</span></th>`).join("")}</tr></thead>
      <tbody>${rowsDef.map(([t, f, fm, w]) => `<tr><td>${t}</td>${combos.map((c) => cell(M(c, smp), f, fm, w)).join("")}</tr>`).join("")}
      <tr><td>樣本</td>${combos.map((c) => { const m = M(c, smp); return `<td class="r">${!m.trades ? "" : m.insufficient ? `<span class="chip pend">樣本不足（&lt;${minN}）</span>` : `<span class="chip ok">≥${minN} 筆</span>`}</td>`; }).join("")}</tr>
      <tr><td class="muted">訊號／跳空放棄／重複略過</td>${combos.map((c) => `<td class="r muted num">${c.signals}／${c.abandoned}／${c.skipped_dup}</td>`).join("")}</tr></tbody></table></div>` : `<p class="pend-t">此方向／型態沒有回測結果：待實測。</p>`;
    const isoos = combos.length ? `<div class="scroll"><table class="cmp"><thead><tr><th>出場</th><th class="r">樣本內 交易</th><th class="r">勝率</th><th class="r">期望值</th><th class="r">MDD</th><th class="r">樣本外 交易</th><th class="r">勝率</th><th class="r">期望值</th><th class="r">MDD</th></tr></thead><tbody>
      ${combos.map((c) => { const a = M(c, "IS"), b = M(c, "OOS"); const td = (m) => cell(m, (x) => x.trades, (v) => v) + cell(m, (x) => x.win_rate, pct, 1) + cell(m, (x) => x.expectancy, sgn) + cell(m, (x) => x.max_drawdown, sgn);
        return `<tr><td style="color:${XCOL[c.exit_set]}">${esc(col(c))}</td>${td(a)}${td(b)}</tr>`; }).join("")}</tbody></table></div>` : "";
    // EquityCurve：多條 NAV 疊圖＋樣本切分線
    const W = 900, H = 240, P = 34;
    const curves = combos.map((c) => ({ c, nav: c.nav.slice(iFrom, iTo + 1) }));
    const all = curves.flatMap((x) => x.nav); const lo = Math.min(0.9, ...all), hi = Math.max(1.1, ...all), N = iTo - iFrom + 1;
    const X = (i) => P + (i / Math.max(1, N - 1)) * (W - P - 8), Y = (v) => 8 + (1 - (v - lo) / (hi - lo)) * (H - P - 8);
    const sx = iSplit >= iFrom && iSplit <= iTo ? X(iSplit - iFrom) : null;
    const dash = (c) => (c.group === "exp" ? "6 4" : "");
    const svg = combos.length ? `<svg class="equity" viewBox="0 0 ${W} ${H}" role="img" aria-label="組合淨值曲線">
      ${[lo, 1, hi].map((v) => `<line x1="${P}" x2="${W - 8}" y1="${Y(v).toFixed(1)}" y2="${Y(v).toFixed(1)}" class="${v === 1 ? "base" : "grid"}"/><text x="2" y="${(Y(v) + 4).toFixed(1)}">${v.toFixed(2)}</text>`).join("")}
      ${sx != null ? `<line x1="${sx.toFixed(1)}" x2="${sx.toFixed(1)}" y1="6" y2="${H - P}" class="split"/><text x="${(sx + 4).toFixed(1)}" y="18" class="split-t">樣本外 ${esc(bt.config.split)} →</text>` : ""}
      ${curves.map(({ c, nav }) => `<polyline fill="none" stroke="${XCOL[c.exit_set]}" stroke-width="2" stroke-dasharray="${dash(c)}" points="${nav.map((v, i) => `${X(i).toFixed(1)},${Y(v).toFixed(1)}`).join(" ")}"><title>${esc(col(c))}</title></polyline>`).join("")}
      <text x="${P}" y="${H - 10}">${esc(bt.days[iFrom])}</text><text x="${W - 8}" y="${H - 10}" text-anchor="end">${esc(bt.days[iTo])}</text></svg>
      <div class="legend-row">${curves.map(({ c }) => `<span><i style="background:${XCOL[c.exit_set]}${c.group === "exp" ? ";opacity:.6" : ""}"></i>${esc(col(c))}${c.group === "exp" ? "（虛線）" : ""}</span>`).join("")}</div>` : "";
    // 出場原因
    const reasons = combos.map((c) => { const m = M(c, smp), er = m.exit_reasons || {}, tot = Object.values(er).reduce((a, b) => a + b, 0) || 1;
      return `<div class="rs-row"><span class="rs-l" style="color:${XCOL[c.exit_set]}">${esc(col(c))}</span><span class="rs-bar">${Object.entries(er).sort((a, b) => b[1] - a[1]).map(([k, v]) =>
        `<span class="rs-seg rs-${k}" style="width:${(v / tot) * 100}%" title="${esc(bt.reason_zh[k] || k)}：${v}"></span>`).join("")}</span>
        <span class="rs-t">${Object.entries(er).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${esc(bt.reason_zh[k] || k)} ${v}`).join("・") || "—"}</span></div>`; }).join("");
    // 分組統計（第一個組合；全期）
    const g0 = combos[0], gk = ["year", "market", "sector"].includes(q.g) ? q.g : "year";
    const grp = g0 ? Object.entries(g0.groups[gk] || {}).map(([k, v]) => `<tr><td>${esc(gk === "sector" ? sectorLabel(k) : k)}</td><td class="r num">${v.trades}</td><td class="r num">${v.insufficient ? `<span class="pend-t">樣本不足</span>` : pct(v.win_rate)}</td><td class="r num${v.insufficient ? " insuf" : ""}">${sgn(v.avg_net)}</td><td>${v.insufficient ? `<span class="chip pend">樣本不足</span>` : ""}</td></tr>`).join("") : "";
    const pname = (p) => (bt.patterns.find((x) => x.id === p) || {}).name || p;
    const exitsAvail = [...new Set(bt.combos.filter((c) => c.direction === dir && (isCis ? c.pattern.startsWith("cis") : c.pattern === pid)).map((c) => c.exit_set))];
    page(`回測實驗室・${D.label}`, ["#/", "方向"], `
      <div class="asof">最近一次回測：${esc((bt.finished_at || "").replace("T", " ").slice(0, 16))}（台北時間）｜期間 ${esc(bt.config.start)} ～ ${esc(bt.config.end)}（${bt.days.length} 個交易日）｜樣本外起 ${esc(bt.config.split)}｜每組最多 ${bt.config.max_positions} 檔等權｜成交 ${bt.config.exit_exec === "next_open" ? "訊號隔日開盤" : "當日收盤（樂觀）"}</div>
      <form class="btform" id="btf" onsubmit="return false">
        <label>型態<select id="fp" class="fop">${pats.map((p) => `<option value="${esc(p)}" ${p === pid ? "selected" : ""}>${esc(pname(p))}</option>`).join("")}</select></label>
        <label>期間<input id="ff" class="fval" type="date" value="${esc(from)}" min="${esc(bt.config.start)}" max="${esc(bt.config.end)}"> ～ <input id="ft" class="fval" type="date" value="${esc(to)}" min="${esc(bt.config.start)}" max="${esc(bt.config.end)}"></label>
        <span class="segs" role="group" aria-label="樣本">${[["ALL", "全期"], ["IS", "樣本內"], ["OOS", "樣本外"]].map(([k, t]) => `<button type="button" class="seg" data-s="${k}" aria-pressed="${smp === k}">${t}</button>`).join("")}</span>
        <span class="xs">${["X1", "X2", "X3"].map((x) => `<label class="toggle" title="${esc(XTIP[x])}"><input type="checkbox" data-x="${x}" ${xs.includes(x) ? "checked" : ""} ${exitsAvail.includes(x) ? "" : "disabled"}> ${XZH[x]}</label>`).join("")}</span>
        <button type="button" class="btn" id="run" title="回測在 box 盤後批次執行">執行回測</button>
        <button type="button" class="btn" id="csv">匯出 CSV</button>
      </form>
      ${custom ? `<p class="note">期間篩選：以全期組合（滿檔限制已套用）的逐筆成交，依訊號日在瀏覽器端重新統計；MDD 為期間內淨值（含期初已持有部位）。「滿檔不進」只在全期統計提供。</p>` : ""}
      ${dir === "short" ? `<p class="note short"><b>ShortCostNote：</b>融券／借券費用假設 0（short_extra_cost = 0），<b>假設值，未計入</b>；融券保證金利息亦未計入。歷史可否融券狀態沒有資料，未排除。</p>` : ""}
      <h3 class="sub-h">出場規則並列（ExitSetCompare）${isCis ? "・CIS 基準線與實驗組並排" : ""}</h3>${cmp}
      <h3 class="sub-h">樣本內 vs 樣本外</h3>${isoos}
      <h3 class="sub-h">組合淨值（EquityCurve，等權、不複利）</h3>${svg}
      <h3 class="sub-h">出場原因</h3><div class="reasons-box">${reasons}</div>
      ${g0 ? `<h3 class="sub-h">分組統計：${esc(col(g0))}（全期）　<span class="segs">${[["year", "年度"], ["market", "市場"], ["sector", "類股"]].map(([k, t]) => `<button type="button" class="seg" data-g="${k}" aria-pressed="${gk === k}">${t}</button>`).join("")}</span></h3>
        <div class="scroll"><table class="cmp"><thead><tr><th>${gk === "year" ? "年度" : gk === "market" ? "市場" : "類股"}</th><th class="r">交易</th><th class="r">勝率</th><th class="r">平均淨報酬</th><th></th></tr></thead><tbody>${grp}</tbody></table></div>` : ""}
      ${crossTable(bt, dir, minN)}
      <ul class="note">${bt.notes.map((n) => `<li>${esc(n)}</li>`).join("")}<li>樣本 &lt; ${minN} 筆：不顯示勝率、其餘數字以灰色顯示並標「樣本不足」，不宜當結論。「固定停損利」為主軸；「型態出場」「均線出場」為對照組。<a href="#/appendix">三種出場規則與樣本內外說明 →</a></li>
        <li>組合淨值 = 1 + Σ(每筆 1/${bt.config.max_positions} 名目 × 淨報酬)，<b>不複利</b>；累積虧損大時淨值可低於 0，因此最大回撤可能超過 −100%（代表虧損超過初始資金）。</li></ul>`);
    const nav = (o) => go("#/lab?" + new URLSearchParams(Object.assign({ d: dir, p: pid, s: smp, f: from, t: to, x: xs.join(","), g: gk }, o)).toString());
    $app.querySelector("#fp").addEventListener("change", (e) => nav({ p: e.target.value }));
    $app.querySelectorAll(".seg[data-s]").forEach((b) => b.addEventListener("click", () => nav({ s: b.dataset.s })));
    $app.querySelectorAll(".seg[data-g]").forEach((b) => b.addEventListener("click", () => nav({ g: b.dataset.g })));
    $app.querySelector("#ff").addEventListener("change", (e) => nav({ f: e.target.value || bt.config.start }));
    $app.querySelector("#ft").addEventListener("change", (e) => nav({ t: e.target.value || bt.config.end }));
    $app.querySelectorAll("input[data-x]").forEach((b) => b.addEventListener("change", () => nav({ x: [...$app.querySelectorAll("input[data-x]:checked")].map((x) => x.dataset.x).join(",") || "X1" })));
    $app.querySelector("#run").addEventListener("click", () => {
      if (!A.guard()) return;
      alert("回測在 box 盤後批次執行（python3 pipeline/run_backtest.py），GitHub Pages 靜態版不能重跑。\n這裡顯示最近一次結果；期間／樣本／出場勾選會用逐筆成交在瀏覽器端重新統計。");
    });
    $app.querySelector("#csv").addEventListener("click", async () => {
      let ts; try { ts = await needTR(); } catch (e) { alert("逐筆成交檔無法載入"); return; }
      const sel = ts.filter((t) => t.direction === dir && combos.some((c) => c.pattern === t.pattern && c.group === t.group && c.exit_set === t.exit_set) &&
        t.signal_date >= from && t.signal_date <= to && (smp === "ALL" || t.sample === smp));
      const cols0 = Object.keys(sel[0] || ts[0] || {}), xi = cols0.indexOf("exit_set");
      const cols = xi < 0 ? cols0 : [...cols0.slice(0, xi + 1), "出場規則", ...cols0.slice(xi + 1)];
      sel.forEach((t) => { t["出場規則"] = XZH[t.exit_set] || t.exit_set; });
      const csv = "\ufeff" + [cols.join(","), ...sel.map((t) => cols.map((c) => { const v = t[c] == null ? "" : String(t[c]); return /[",\n]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v; }).join(","))].join("\n");
      download(`backtest_${pid}_${dir}_${from}_${to}_${smp}.csv`, csv, "text/csv");
    });
  }
  function crossTable(bt, dir, minN) {  // §12.4 交叉表：型態 × 類股（X1 固定停損利、全期、組合層級）
    const cs = bt.combos.filter((c) => c.direction === dir && c.exit_set === "X1");
    const secs = [...new Set(cs.flatMap((c) => Object.keys(c.groups.sector || {})))].sort();
    if (!cs.length) return "";
    const head = cs.map((c) => `<th class="r">${esc(((bt.patterns.find((p) => p.id === c.pattern) || {}).name || c.pattern).replace(/（.*?）/g, ""))}${c.group !== "—" ? "・" + GZH[c.group] : ""}</th>`).join("");
    const rows = secs.map((k) => `<tr><td>${esc(sectorLabel(k))}</td>${cs.map((c) => { const v = (c.groups.sector || {})[k];
      return !v ? `<td class="r muted">—</td>` : `<td class="r num${v.insufficient ? " insuf" : ""}" title="${v.trades} 筆${v.insufficient ? "（樣本不足）" : `，勝率 ${pct(v.win_rate)}`}">${sgn(v.avg_net, 1)}<br><span class="muted">${v.trades} 筆</span></td>`; }).join("")}</tr>`).join("");
    return `<details class="rule"><summary>交叉表：型態 × 類股（固定停損利、全期、平均淨報酬）</summary><div class="scroll"><table class="cmp xt"><thead><tr><th>類股</th>${head}</tr></thead><tbody>${rows}</tbody></table></div>
      <p class="note">灰字 = 該格 &lt; ${minN} 筆（樣本不足）；滑鼠停留可看筆數與勝率（樣本足夠時）。</p></details>`;
  }
  const sectorLabel = (k) => { const n = A.SCAN && A.SCAN.sector_names; return (n && n[k]) || (k === "ETF" ? "ETF" : k === "NA" ? "未分類" : k); };

  // ================================================================ BacktestMiniCard（個股頁）
  async function miniCard(el, dir, pid, sym, sc) {
    let bt; try { bt = await needBT(); } catch (e) { el.innerHTML = `<h3>歷史回測</h3><p class="pend-t">待實測（回測結果無法載入${off() ? "：離線且無快取" : ""}）。</p>`; return; }
    const minN = bt.config.min_trades_display;
    const cs = bt.combos.filter((c) => c.pattern === pid && c.direction === dir).sort((a, b) => a.exit_set.localeCompare(b.exit_set));
    if (!cs.length) { el.innerHTML = `<h3>歷史回測</h3><p class="pend-t">待實測（此型態／方向沒有回測紀錄）。</p>`; return; }
    const tri = (v) => (!v ? `<td class="r pend-t">—</td><td></td><td></td>` : `<td class="r num${v[0] < minN ? " insuf" : ""}">${v[0]}</td><td class="r num${v[0] < minN ? " pend-t" : ""}">${v[0] < minN ? "不足" : pct(v[1], 0)}</td><td class="r num${v[0] < minN ? " insuf" : ""}">${sgn(v[2], 1)}</td>`);
    el.innerHTML = `<h3>歷史回測 <span class="tag">${esc(bt.config.start)}～${esc(bt.config.end)}</span></h3>
      <div class="scroll"><table class="mini"><thead><tr><th>出場</th><th>範圍</th><th class="r">筆數</th><th class="r">勝率</th><th class="r">平均</th></tr></thead><tbody>
      ${cs.map((c) => { const m = c.metrics.ALL, sl = c.signal_level;
        return `<tr><td rowspan="3" style="color:${XCOL[c.exit_set]}" title="${esc(XTIP[c.exit_set] || "")}">${esc(XZH[c.exit_set] || c.exit_set)}<br><span class="muted">${XROLE(c.exit_set)}</span></td><td>全市場（組合）</td>${m.trades ? tri([m.trades, m.win_rate, m.expectancy]) : tri(null)}</tr>
          <tr><td>同類股（逐訊號）</td>${tri(sl.by_sector[sc || "NA"])}</tr><tr><td>本檔（逐訊號）</td>${tri(sl.by_symbol[sym])}</tr>`; }).join("")}</tbody></table></div>
      <p class="note">樣本 &lt; ${minN} 筆：不顯示勝率（標「不足」），平均報酬以灰字顯示。逐訊號 = 不受滿檔限制、同檔同時只持有一筆。${dir === "short" ? "融券費用假設 0，未計入。" : ""}歷史統計不代表未來。<a href="#/appendix">出場規則說明</a></p>
      <a class="btn sm" href="#/lab?d=${dir}&p=${encodeURIComponent(pid)}">到回測實驗室 →</a>`;
  }

  // ================================================================ 觀察清單／持有（watchlist 表：symbol、side 做多/做空、position 持有部位、note）
  // side 是 v6 新增欄位：決定放在「做多觀察清單」或「做空觀察清單」；舊資料沒有 side → 依 position 推（SHORT→做空，其餘→做多）。
  // position 照舊：NONE＝只觀察、LONG＝持有多單、SHORT＝持有空單（盤後警示的 CIS 出場判斷用；box 端只讀 symbol/position）。
  // 數量不設上限（Jay 2026-11-22）。
  const POS_ZH = { NONE: "觀察", LONG: "持有多單", SHORT: "持有空單" };
  const sideOf = (r) => r.side || (r.position === "SHORT" ? "short" : "long");
  async function watchRow(sym) { return (await S.live("watchlist")).find((r) => r.symbol === sym); }
  const WOPT = [["", "未追蹤"], ["long:NONE", "做多觀察"], ["short:NONE", "做空觀察"], ["long:LONG", "持有多單"], ["short:SHORT", "持有空單"]];
  async function watchButton(el, sym) {
    if (!el || !S) return;
    let r; try { r = await watchRow(sym); } catch (e) { return; }
    const cur = r ? `${sideOf(r)}:${r.position || "NONE"}` : "";
    el.innerHTML = `<label class="watchsel"><span aria-hidden="true">${r ? "⭐" : "☆"}</span><select aria-label="觀察清單／持有" ${off() ? 'disabled title="目前離線，無法執行"' : ""}>
      ${WOPT.map(([k, t]) => `<option value="${k}" ${cur === k ? "selected" : ""}>${t}</option>`).join("")}</select></label>`;
    el.querySelector("select").addEventListener("change", async (e) => {
      if (!A.guard()) { watchButton(el, sym); return; }
      const v = e.target.value, row = await watchRow(sym);
      if (!v) { if (row) await S.remove("watchlist", row.id); }
      else { const [side, position] = v.split(":"); await S.save("watchlist", Object.assign({}, row || { symbol: sym, note: "" }, { side, position })); }
      watchButton(el, sym);
    });
  }
  // 可搜尋的標的：scan_latest.json 的 universe（v6 起由批次輸出：今日掃描範圍內全部個股＋ETF）；舊檔沒有就用今日命中個股；00631L 永遠可加。
  function universeOf(scan) {
    const m = new Map();
    for (const u of (scan && scan.universe) || []) m.set(u[0], { symbol: u[0], name: u[1], market: u[2], sc: u[3] });
    for (const h of (scan && scan.hits) || []) if (!m.has(h.symbol)) m.set(h.symbol, { symbol: h.symbol, name: h.name, market: h.market, sc: h.sector_code });
    if (!m.has("00631L")) m.set("00631L", { symbol: "00631L", name: "元大台灣50正2", market: "TWSE", sc: "ETF" });
    return [...m.values()];
  }
  function matchStock(U, q) {
    q = String(q || "").trim(); if (!q) return { err: "請輸入股票代號或名稱。" };
    const tok = q.split(/\s+/)[0].toUpperCase();
    let hit = U.find((u) => u.symbol.toUpperCase() === tok) || U.find((u) => u.name === q) || U.find((u) => `${u.symbol} ${u.name}` === q);
    if (hit) return { hit };
    const ql = q.toLowerCase(), cands = U.filter((u) => u.name.toLowerCase().includes(ql) || u.symbol.toLowerCase().startsWith(ql));
    if (cands.length === 1) return { hit: cands[0] };
    if (cands.length > 1) return { many: cands.slice(0, 8), n: cands.length };
    return { err: `找不到「${q}」。只能加入今日掃描範圍內的標的（共 ${U.length} 檔）；股價低於 10 元、成交量太小、處置股等會被排除。請確認代號。` };
  }
  async function renderWatch() {
    $app.innerHTML = `<p class="loading">載入觀察清單…</p>`;
    let scan = null; try { scan = await A.needScan(); } catch (e) {}
    const U = universeOf(scan), byS = new Map(U.map((u) => [u.symbol, u]));
    const rows = (await S.live("watchlist")).sort((a, b) => a.symbol.localeCompare(b.symbol));
    const lastSide = sessionStorage.getItem("radar.watchSide") || "long";
    const item = (r) => {
      const sig = scan ? scan.hits.filter((h) => h.symbol === r.symbol) : [], side = sideOf(r), held = r.position && r.position !== "NONE";
      const nm = (sig[0] && sig[0].name) || (byS.get(r.symbol) || {}).name || "";
      const link = r.symbol === "00631L" ? "#/etf/00631L" : sig[0] ? `#/${sig[0].direction}/${encodeURIComponent(sig[0].patternId)}/${encodeURIComponent(sig[0].sector_code || "NA")}/${encodeURIComponent(r.symbol)}` : "";
      return `<div class="wrow" data-id="${esc(r.id)}">
        <div class="w-id">${link ? `<a href="${link}"><b class="num">${esc(r.symbol)}</b> ${esc(nm)}</a>` : `<b class="num">${esc(r.symbol)}</b> ${esc(nm)}`}</div>
        <div class="w-sig">${sig.length ? sig.map((h) => `<a class="chip ${h.direction}" href="#/${h.direction}/${encodeURIComponent(h.patternId)}/${encodeURIComponent(h.sector_code || "NA")}/${encodeURIComponent(h.symbol)}">${esc(A.patternName(h.patternId))}・${esc(A.STATE_ZH[h.state] || h.state)}</a>`).join("") : `<span class="muted">今日無訊號</span>`}</div>
        <div class="w-act"><span class="segs sm" role="group" aria-label="部位"><button type="button" class="seg" data-p="NONE" aria-pressed="${!held}">觀察</button><button type="button" class="seg" data-p="${side === "short" ? "SHORT" : "LONG"}" aria-pressed="${held}">${side === "short" ? "持有空單" : "持有多單"}</button></span>
          <input class="fval note-in" value="${esc(r.note || "")}" placeholder="備註" aria-label="${esc(r.symbol)} 備註">
          <button type="button" class="btn sm rm" aria-label="移除 ${esc(r.symbol)}">移除</button></div></div>`;
    };
    const col = (side) => { const rs = rows.filter((r) => sideOf(r) === side), D = A.DIR[side];
      return `<section class="wcol ${side}" data-side="${side}"><h3>${D.arrow} ${D.label}觀察清單 <span class="muted">（${rs.length} 檔）</span></h3>
        <div class="wlist">${rs.map(item).join("") || `<p class="pend-t">還沒有${D.label}觀察的標的。</p>`}</div></section>`; };
    page("觀察清單／持有", ["#/", "方向"], `
      <form class="wadd" id="wadd" autocomplete="off">
        <label class="sr" for="wq">股票代號或名稱</label>
        <input id="wq" class="wq" list="wuniv" placeholder="輸入代號或名稱，例如 2330 或 台積電" enterkeyhint="done">
        <datalist id="wuniv">${U.map((u) => `<option value="${esc(u.symbol)} ${esc(u.name)}"></option>`).join("")}</datalist>
        <span class="segs" role="group" aria-label="加到哪一邊"><button type="button" class="seg long" data-side="long" aria-pressed="${lastSide === "long"}">↑ 做多</button><button type="button" class="seg short" data-side="short" aria-pressed="${lastSide === "short"}">↓ 做空</button></span>
        <button type="submit" class="btn add" id="wbtn">＋ 加入</button>
      </form>
      <p class="wmsg" id="wmsg" role="status" aria-live="polite"></p>
      <div class="wcols">${col("long")}${col("short")}</div>
      <p class="note">做多、做空各一份清單，數量不限。按「持有多單／持有空單」表示你手上有部位：盤後警示預設只寄觀察清單／持有標的的 CIS 出場與出場警示，持有部位會改用續抱／出場判斷。個股頁右上角的 ⭐ 選單也能直接加入。資料存在本機 IndexedDB，備份檔會一併帶走。</p>`);
    const $m = $app.querySelector("#wmsg"), msg = (t, cls = "") => { $m.className = `wmsg ${cls}`; $m.innerHTML = t; };
    let side = lastSide;
    $app.querySelectorAll(".wadd .seg").forEach((b) => b.addEventListener("click", () => { side = b.dataset.side; sessionStorage.setItem("radar.watchSide", side);
      $app.querySelectorAll(".wadd .seg").forEach((x) => x.setAttribute("aria-pressed", x === b)); }));
    async function add(u) {
      if (!A.guard()) return;
      const all = await S.live("watchlist"), ex = all.find((r) => r.symbol === u.symbol), D = A.DIR[side];
      if (ex && sideOf(ex) === side) { msg(`${esc(u.symbol)} ${esc(u.name)} 已經在${D.label}觀察清單裡。`, "warn"); return; }
      if (ex) { await S.save("watchlist", Object.assign({}, ex, { side, position: "NONE" })); sessionStorage.setItem("radar.wmsg", `已把 ${u.symbol} ${u.name} 從${A.DIR[sideOf(ex)].label}改到${D.label}觀察清單（部位改回「觀察」）。`); }
      else { await S.save("watchlist", { symbol: u.symbol, note: "", side, position: "NONE" }); sessionStorage.setItem("radar.wmsg", `已加入${D.label}觀察清單：${u.symbol} ${u.name}`); }
      renderWatch();
    }
    $app.querySelector("#wadd").addEventListener("submit", (e) => {
      e.preventDefault(); const q = $app.querySelector("#wq").value, r = matchStock(U, q);
      if (r.err) return msg(esc(r.err), "bad");
      if (r.many) { msg(`「${esc(q)}」符合 ${r.n} 檔，請點選一檔：${r.many.map((u) => `<button type="button" class="chip pick" data-sym="${esc(u.symbol)}">${esc(u.symbol)} ${esc(u.name)}</button>`).join("")}`, "warn");
        $m.querySelectorAll(".pick").forEach((b) => b.addEventListener("click", () => add(byS.get(b.dataset.sym)))); return; }
      add(r.hit);
    });
    const flash = sessionStorage.getItem("radar.wmsg"); if (flash) { msg(esc(flash), "ok"); sessionStorage.removeItem("radar.wmsg"); }
    $app.querySelectorAll(".wrow[data-id]").forEach((el) => {
      const id = el.dataset.id, row = rows.find((r) => r.id === id);
      el.querySelectorAll(".seg").forEach((b) => b.addEventListener("click", async () => { if (!A.guard()) return; await S.save("watchlist", Object.assign({}, row, { side: sideOf(row), position: b.dataset.p })); renderWatch(); }));
      el.querySelector(".note-in").addEventListener("change", async (e) => { if (!A.guard()) return; await S.save("watchlist", Object.assign({}, row, { note: e.target.value })); });
      el.querySelector(".rm").addEventListener("click", async () => { if (!A.guard()) return; await S.remove("watchlist", id); sessionStorage.setItem("radar.wmsg", `已移除 ${row.symbol}`); renderWatch(); });
    });
    if (off()) $app.querySelectorAll(".wadd input,.wadd button,.wrow button,.wrow input").forEach((x) => { x.disabled = true; x.title = "目前離線，無法執行"; });
  }

  // ================================================================ 🌍 指數 K 線頁（idx_<id>.json，由 run_indices.py 產生；有十二招型態就畫線，沒有只畫 K 線）
  async function loadIdx(id) {
    const name = `idx_${id}.json`;
    try {
      const r = await fetch(name + "?t=" + Date.now(), { cache: "no-store" });
      if (r.status === 404) return null;                       // 檔案不存在 ≠ 離線：直接顯示「無資料」，不切到離線模式
      if (r.ok) { const j = await r.json(); if (S) S.cachePut(name, j).catch(() => {}); return j; }
    } catch (e) { /* 網路失敗 → 下面改用快取 */ }
    try { return await A.getJSON(name); } catch (e) { return null; }
  }
  function idxMain(sigs) { return sigs.find((x) => x.state === "CONFIRMED" || x.state === "FORMING") || sigs[0] || null; }
  async function renderIndex(id) {
    $app.innerHTML = `<p class="loading">載入指數 K 線…</p>`;
    const [d, list] = await Promise.all([loadIdx(id), A.getJSON("indices_latest.json").catch(() => null)]);
    const meta = ((list && list.indices) || []).find((x) => x.id === id) || {};
    const title = esc(d && d.name || meta.name || id);
    const bars = d && d.bars;
    if (!d || !bars || !bars.t || !bars.t.length) {
      return page(`🌍 ${title}`, ["#/markets", "全球指數"], `<section class="pcard"><h3>K 線</h3><p class="pend-t">無資料</p>
        <p class="note">這個指數的日 K 資料還沒產生或本次抓取失敗（每日批次台北時間 15:00／17:30／21:30 會再試）${off() ? "；目前離線" : ""}。</p></section>`);
    }
    const sigs = (d.signals || []).filter((x) => !String(x.patternId).startsWith("cis"));
    let main = idxMain(sigs);
    const n = bars.c.length, last = bars.c[n - 1], prev = n > 1 ? bars.c[n - 2] : null, chg = prev ? (last / prev - 1) * 100 : null;
    const cls = (x) => (x == null ? "" : x >= 0 ? "up" : "down"), sg = (x) => (x == null ? "—" : `${x >= 0 ? "+" : ""}${fmt(x)}`);
    const ma = (k) => (n >= k ? bars.c.slice(-k).reduce((a, b) => a + b, 0) / k : null);
    const kv = (k, v) => `<span class="kv"><i>${k}</i><b class="num">${v}</b></span>`;
    const sigCard = (x, i) => { const lv = x.levels || {};
      return `<div class="sigc ${esc(x.direction)}"><b>${esc(A.patternName(x.patternId))}・${(A.DIR[x.direction] || {}).label || ""}</b> <span class="st-${esc(x.state)}">${esc(A.stLabel(x))}</span>
        <div class="kvs">${lv.neckline != null ? kv("頸線", fmt(lv.neckline)) : ""}${lv.breakout != null ? kv("突破", fmt(lv.breakout)) : ""}${(() => { const m = A.measuredMove(x, bars.t.map(A.isoD), last); return m ? kv("1倍目標", fmt(m.t1)) + kv("2倍目標", fmt(m.t2)) + kv("型態高度", fmt(m.height)) : (lv.target != null ? kv("滿足點", fmt(lv.target)) : ""); })()}${lv.stopRef != null ? kv("停損參考", fmt(lv.stopRef)) : ""}${kv("強度", fmt(x.strength, 0))}</div>
        <ul class="reasons">${(x.reasons || []).map((r) => `<li>${esc(r)}</li>`).join("")}</ul>
        ${sigs.length > 1 ? `<button type="button" class="btn sm ovl" data-i="${i}">在圖上顯示這個型態</button>` : ""}</div>`; };
    const strip = () => main ? `<b>${esc(A.patternName(main.patternId))}・${(A.DIR[main.direction] || {}).label || ""}</b> <span class="st-${esc(main.state)}">${esc(A.stLabel(main))}</span>` : `<b class="muted">十二招：目前沒有型態</b>`;
    $app.innerHTML = `
      <div class="bar stock-bar"><button type="button" class="btn" id="back">← 全球指數</button>
        <h2>${title} <span class="muted s">${esc(d.region || meta.region || "")}・${esc(d.symbol || "")}</span></h2>
        <button type="button" class="btn sm" id="sidebtn" aria-controls="side" aria-expanded="true">資訊欄</button></div>
      <div class="asof">資料日 ${esc(d.data_as_of)}｜更新於 ${esc(A.tpe(d.generated_at))}（台北時間）｜來源 ${esc(d.source || "—")}｜${n} 根日 K</div>
      ${d.stale || d.error ? `<p class="note short"><b>資料可能過期：</b>${esc(d.error || "本次未更新")}</p>` : ""}
      <div class="sumstrip ${main ? esc(main.direction) : ""}" id="idxstrip"><span id="idxsig">${strip()}</span>
        <span class="kv1"><i>收盤</i><b class="num">${fmt(last)}</b></span><span class="kv1"><i>漲跌</i><b class="num ${cls(chg)}">${sg(chg)}%</b></span>
        <span class="kv1"><i>MA5</i><b class="num" style="color:#FFD166">${fmt(ma(5))}</b></span><span class="kv1"><i>MA25</i><b class="num" style="color:#B388FF">${fmt(ma(25))}</b></span></div>
      <div class="stock" id="stockwrap">
        <div class="main-col"><section class="chart-card"><div class="legend num" id="legend"></div><div id="chart" class="chart" aria-label="${title} 日 K 線圖"></div>
          <p class="note">紅漲綠跌；黃線 MA5、紫線 MA25。${sigs.length ? "虛線／實線為十二招型態的頸線、突破、停損參考與趨勢線；M頭／頭肩頂等頭部型態另畫 1 倍、2 倍跌幅目標（底部型態為漲幅），數值見圖下方。" : "目前沒有十二招型態成形或確認，只顯示 K 線。"}${d.has_volume ? "" : " 此指數來源沒有成交量，不顯示量能。"}</p></section></div>
        <div class="side-scrim" id="sidescrim"></div>
        <aside class="side" id="side" aria-label="詳細資訊">
          <div class="side-head"><b>詳細資訊</b><button type="button" class="btn sm" id="sideclose">收起 ✕</button></div>
          <section class="pcard"><h3>十二招型態訊號</h3>${sigs.length ? sigs.map(sigCard).join("") : `<p class="muted">目前沒有成形中或已確認的型態。</p>`}</section>
          <section class="pcard"><h3>說明</h3><p class="note">型態偵測用最近 ${n} 根日 K，規則與參數同個股掃描（不含 CIS、不看三大法人）。${(d.notes || []).map(esc).join(" ")}
            盤中尚未收盤的 K 棒不納入。僅供參考，不構成投資建議。<a href="#/appendix">規則說明</a></p></section>
        </aside>
      </div>`;
    A.sidePanel();
    $app.querySelector("#back").addEventListener("click", () => go("#/markets"));
    const B = Object.assign({}, bars, { vu: "", novol: !d.has_volume });
    const NONE = { direction: "long", state: "WATCH", levels: {}, geometry: {} };
    const draw = () => A.drawChart(B, main || NONE, sigs).catch((e) => { document.getElementById("chart").innerHTML = `<p class="loading">圖表載入失敗：${esc(e.message || e)}</p>`; });
    draw();
    $app.querySelectorAll(".ovl").forEach((b) => b.addEventListener("click", () => {
      main = sigs[+b.dataset.i]; const st = document.getElementById("idxstrip");
      st.className = `sumstrip ${main.direction}`; document.getElementById("idxsig").innerHTML = strip();
      draw(); document.getElementById("chart").scrollIntoView({ behavior: "smooth", block: "nearest" });
    }));
  }

  // ================================================================ 🌍 全球指數（indices_latest.json，由每日批次 run_indices.py 產生）
  function spark(vals, up) {
    if (!vals || vals.length < 2) return `<svg class="spark" viewBox="0 0 120 36" aria-hidden="true"></svg>`;
    const mn = Math.min(...vals), mx = Math.max(...vals), rg = mx - mn || 1;
    const pts = vals.map((v, i) => `${((i / (vals.length - 1)) * 120).toFixed(1)},${(34 - ((v - mn) / rg) * 32).toFixed(1)}`).join(" ");
    return `<svg class="spark" viewBox="0 0 120 36" preserveAspectRatio="none" role="img" aria-label="近 ${vals.length} 個交易日走勢"><polyline points="${pts}" fill="none" stroke="${up ? "var(--up)" : "var(--down)"}" stroke-width="1.6" vector-effect="non-scaling-stroke"/></svg>`;
  }
  async function renderMarkets() {
    $app.innerHTML = `<p class="loading">載入全球指數…</p>`;
    let d; try { d = await A.getJSON("indices_latest.json"); } catch (e) {
      return page("🌍 全球指數", ["#/", "方向"], `<p class="pend-t">全球指數資料還沒產生（每日批次跑過一次後就會有）${off() ? "，且目前離線" : ""}。</p>`); }
    const card = (x) => { const up = (x.change_pct || 0) >= 0, cls = x.change_pct == null ? "" : up ? "up" : "down";
      const rng = x.spark && x.spark.length ? `近 ${x.spark.length} 日` : "";
      const pats = (x.patterns || []).map(([pid, dir, st]) => `<span class="chip ${esc(dir)}">${esc(A.patternName(pid))}・${(A.DIR[dir] || {}).label || ""}・${esc(A.STATE_ZH[st] || st)}</span>`).join("");
      return `<a class="icard${x.stale ? " stale" : ""}" data-id="${esc(x.id)}" href="#/markets/${encodeURIComponent(x.id)}" aria-label="${esc(x.name)} K 線圖">
        <div class="i-h"><b>${esc(x.name)}</b><span class="muted">${esc(x.region)}・${esc(x.symbol)}</span></div>
        <div class="i-v"><b class="num">${x.close == null ? "—" : Number(x.close).toLocaleString("zh-TW", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</b>
          <span class="num ${cls}">${x.change_pct == null ? "—" : `${up ? "▲ +" : "▼ "}${fmt(x.change_pct)}%`}</span></div>
        ${spark(x.spark, up)}
        <div class="i-f muted">資料日 <span class="num">${esc(x.date || "—")}</span>・${rng}・來源 ${esc(x.source || "—")}${x.stale ? ` <span class="tag warn">過期：${esc(x.error || "本次未更新")}</span>` : ""}</div>
        <div class="i-p">${pats || (x.chart === false ? `<span class="muted">K 線：無資料</span>` : x.chart ? `<span class="muted">十二招：無型態</span>` : "")}<span class="i-go">K 線 ›</span></div></a>`; };
    page("🌍 全球指數", ["#/", "方向"], `
      <div class="asof">更新於 ${esc(A.tpe(d.generated_at))}（台北時間）${A.CACHED_AT["indices_latest.json"] ? `・離線快取 ${esc(A.tpe(A.CACHED_AT["indices_latest.json"]))}` : ""}</div>
      <p class="note">${esc(d.note || "")} 漲跌顏色：紅漲綠跌（台股習慣）。走勢線為近 60 個交易日收盤。點任一指數可看日 K 線；符合十二招型態時會畫出頸線／突破／滿足點等線。</p>
      <div class="igrid">${(d.indices || []).map(card).join("")}</div>
      <p class="note">資料：Yahoo Finance（失敗時改用 stooq；滬深 300 等中國指數再退新浪財經）。僅供參考，不構成投資建議。</p>`);
  }

  // ================================================================ 盤後警示設定（§11、§13 AlertForm）— 只存設定；寄信由 box 批次負責，目前只做 dry-run
  const ALERT_DEF = { patterns: { long: null, short: null }, recipients: [], cooldown_days: 5, max_rows: 50, send_empty_digest: false,
    schedule_cron: "15:00／17:30／21:30 Asia/Taipei", fundamental_rules: [] };
  async function loadAlert() {
    const r = await S.get("alert_settings", "default");
    if (!r || r.deleted) return Object.assign({}, JSON.parse(JSON.stringify(ALERT_DEF)), { _src: "預設值" });
    return { patterns: JSON.parse(r.pattern_ids_json || "null") || { long: null, short: null }, recipients: JSON.parse(r.recipients_json || "[]"),
      cooldown_days: r.cooldown_days, max_rows: r.max_rows, send_empty_digest: !!r.send_empty_digest, schedule_cron: r.schedule_cron,
      fundamental_rules: JSON.parse(r.fundamental_rules_json || "[]"), _src: `本機設定（${A.tpe(r.updated_at)} 台北時間）` };
  }
  async function renderAlerts(h) {
    const q = qs(h), dir = q.d === "short" ? "short" : "long", D = A.DIR[dir];
    const st = await loadAlert(), scope = (await S.setting("cis_exit_scope")) || "watchlist";
    const pats = A.SUMMARY.patterns.filter((p) => p.directions.includes(dir));
    const sel = st.patterns[dir];  // null = 全部
    const rules = A.loadRules().filter((r) => r.mode && r.mode !== "off" && r.value !== "");
    page("盤後 Email 警示", ["#/", "方向"], `
      <div class="bar"><span class="switch" role="group" aria-label="方向分頁">
        <button type="button" class="long" aria-pressed="${dir === "long"}" data-d="long">↑ 做多</button><button type="button" class="short" aria-pressed="${dir === "short"}" data-d="short">↓ 做空</button></span>
        <span class="asof">目前設定來源：${esc(st._src)}</span></div>
      <section class="pcard ${dir}"><h3>${D.label}：啟用的型態</h3>
        <label class="toggle"><input type="checkbox" id="allp" ${sel == null ? "checked" : ""}> 全部型態（預設）</label>
        <div class="chips-row">${pats.map((p) => `<label class="toggle pchk"><input type="checkbox" data-pid="${esc(p.id)}" ${sel == null || sel.includes(p.id) ? "checked" : ""} ${sel == null ? "disabled" : ""}> ${esc(p.name)}</label>`).join("")}</div></section>
      <section class="pcard"><h3>收件與節流（兩個方向共用）</h3>
        <div class="frules">
          <div class="frule"><span class="fl">收件人</span><input id="rcp" class="fval" style="width:min(420px,100%)" value="${esc(st.recipients.join(", "))}" aria-label="收件人（逗號分隔）" placeholder="寄信收件人由 GitHub Secrets ALERT_TO 設定"></div>
          <div class="frule"><span class="fl">冷卻天數（同檔同型態同狀態）</span><input id="cool" class="fval num" type="number" min="0" max="30" value="${esc(st.cooldown_days)}"></div>
          <div class="frule"><span class="fl">每封最多列數</span><input id="maxr" class="fval num" type="number" min="5" max="500" value="${esc(st.max_rows)}"></div>
          <div class="frule"><span class="fl">沒有新訊號也寄（空摘要）</span><label class="toggle"><input type="checkbox" id="empty" ${st.send_empty_digest ? "checked" : ""}> 寄送</label></div>
          <div class="frule"><span class="fl">CIS 出場／出場警示</span><span class="segs">${[["watchlist", "只寄觀察清單／持有"], ["all", "全部標的"]].map(([k, t]) => `<button type="button" class="seg" data-scope="${k}" aria-pressed="${scope === k}">${t}</button>`).join("")}</span></div>
          <div class="frule"><span class="fl">基本面條件</span><label class="toggle"><input type="checkbox" id="frl" ${st.fundamental_rules.length ? "checked" : ""} ${rules.length ? "" : "disabled"}> 套用目前的基本面條件（${rules.length} 條${rules.length ? "" : "，尚未設定"}）</label></div>
          <div class="frule"><span class="fl">排程</span><span class="num">${esc(st.schedule_cron)}</span><span class="muted">每個交易日 15:00（台北時間）由 GitHub Actions 自動執行，17:30／21:30 補跑法人與融資融券；休市日不寄。</span></div>
        </div></section>
      <div class="tools"><button type="button" class="btn" id="save">儲存設定</button>
        <button type="button" class="btn" disabled title="靜態網頁不能寄信；信件由 GitHub Actions 寄出">測試寄送（由 GitHub Actions 執行）</button>
        <a class="btn" href="alert_preview.html" target="_blank" rel="noopener">看最近一次信件預覽 ↗</a></div>
      <ul class="note"><li>去重：同一交易日、型態、版本、個股、方向、狀態只寄一次（重跑不重寄）；只有「狀態轉換」才寄；冷卻期內不重複。</li>
        <li>這一頁的設定只存在這台裝置（IndexedDB）。GitHub 上的每日批次<b>讀不到</b>這裡的設定：寄信用預設值（全部型態、冷卻 5 日、每封 50 列、沒新訊號不寄），收件人由 repo 的 Secrets <span class="num">ALERT_TO</span> 決定。</li>
        <li><b>寄信</b>：repo 設好 Secrets（SMTP_USER、SMTP_PASS、ALERT_TO）後，每個交易日盤後由 GitHub Actions 寄出；沒設就只產生預覽，不寄。</li></ul>`);
    $app.querySelectorAll(".switch button").forEach((b) => b.addEventListener("click", () => go(`#/alerts?d=${b.dataset.d}`)));
    $app.querySelector("#allp").addEventListener("change", (e) => $app.querySelectorAll(".pchk input").forEach((x) => { x.disabled = e.target.checked; if (e.target.checked) x.checked = true; }));
    let sc = scope;
    $app.querySelectorAll(".seg[data-scope]").forEach((b) => b.addEventListener("click", () => { sc = b.dataset.scope; $app.querySelectorAll(".seg[data-scope]").forEach((x) => x.setAttribute("aria-pressed", x === b)); }));
    $app.querySelector("#save").addEventListener("click", async () => {
      if (!A.guard()) return;
      const rc = $app.querySelector("#rcp").value.split(/[,\s;]+/).filter(Boolean);
      const bad = rc.filter((x) => !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(x));
      if (!rc.length || bad.length) { alert(`收件人格式不正確：${bad.join(", ") || "（空白）"}`); return; }
      const P = Object.assign({}, st.patterns);
      P[dir] = $app.querySelector("#allp").checked ? null : [...$app.querySelectorAll(".pchk input:checked")].map((x) => x.dataset.pid);
      await S.save("alert_settings", { id: "default", pattern_ids_json: JSON.stringify(P), recipients_json: JSON.stringify(rc), schedule_cron: st.schedule_cron,
        cooldown_days: Math.max(0, Math.min(30, +$app.querySelector("#cool").value || 0)), max_rows: Math.max(5, Math.min(500, +$app.querySelector("#maxr").value || 50)),
        send_empty_digest: $app.querySelector("#empty").checked ? 1 : 0, fundamental_rules_json: JSON.stringify($app.querySelector("#frl").checked ? rules : []) });
      await S.setting("cis_exit_scope", sc);
      renderAlerts(h);
    });
  }

  // ================================================================ 備份與還原（§3.3、§14、§15 BackupPanel）
  const B = window.RadarBackup;
  async function makeBackup(code, download_ = true) {
    const tables = await S.exportTables();
    const doc = { exported_at: new Date().toISOString(), device_id: await S.deviceId(), tables };
    const r = await B.encryptBackup(doc, code);
    const ts = doc.exported_at.replace(/[-:]/g, "").slice(0, 15) + "Z";
    const rec = { id: B.uuid7(), created_at: doc.exported_at, vault_id: r.vault_id, checksum: r.checksum, size: r.bytes.length,
      rows: Object.fromEntries(Object.entries(tables).map(([t, v]) => [t, v.length])), bytes: r.bytes, name: `pattern-radar_${r.vault_id.slice(0, 8)}_${ts}.prb` };
    await S.blobAdd(rec); await S.meta("last_backup_at", doc.exported_at);
    if (download_) download(rec.name, new Blob([r.bytes], { type: "application/octet-stream" }));
    return rec;
  }
  async function autoBackup() {  // 每日自動備份到本機（最近 K 份）；需已設定復原碼、開啟自動、且在線
    try {
      if (!S || off() || !(await S.setting("auto_backup"))) return;
      const code = await S.meta("recovery_code"); if (!code) return;
      const last = await S.meta("last_backup_at");
      if (last && Date.now() - new Date(last).getTime() < 20 * 3600e3) return;
      await makeBackup(code, false);
    } catch (e) {}
  }
  async function renderBackup(h) {
    const dev = await S.deviceId(), code = await S.meta("recovery_code"), confirmed = await S.meta("recovery_confirmed");
    const show = qs(h).show === "1" && code;
    let vault = "—"; if (code) { try { vault = (await B.derive(code)).vault_id; } catch (e) {} }
    const blobs = await S.blobs(), auto = !!(await S.setting("auto_backup"));
    let persisted = null, est = null; try { persisted = navigator.storage && navigator.storage.persisted ? await navigator.storage.persisted() : null; est = navigator.storage && navigator.storage.estimate ? await navigator.storage.estimate() : null; } catch (e) {}
    const local = await S.exportTables(), localSum = await B.checksum(local);
    const counts = Object.entries(local).map(([t, v]) => `${t} ${v.filter((r) => !r.deleted).length}${v.some((r) => r.deleted) ? `（+${v.filter((r) => r.deleted).length} 刪除標記）` : ""}`).join("・");
    const codeBox = !code ? `<p>尚未設定復原碼。</p><div class="tools"><button type="button" class="btn" id="gen">產生復原碼</button>
        <input id="have" class="fval" style="width:280px" placeholder="或輸入既有復原碼（換機還原用）" autocomplete="off" spellcheck="false"><button type="button" class="btn" id="use">使用這組</button></div>`
      : !confirmed || show ? `<div class="rcode num" aria-label="復原碼">${esc(code)}</div>
        <p class="note short"><b>請立刻抄寫並妥善保存。</b>遺失復原碼 = 無法還原備份（沒有任何人能幫你找回）。${!confirmed ? "這是唯一一次自動顯示。" : ""}</p>
        ${!confirmed ? `<label class="toggle"><input type="checkbox" id="ack"> 我已抄寫並妥善保存</label> <button type="button" class="btn" id="ackb">確認</button>` : `<button type="button" class="btn" id="hide">隱藏</button>`}`
      : `<p>復原碼已設定（已隱藏）。<button type="button" class="btn sm" id="reshow">重新顯示（需在本機確認）</button></p>`;
    page("備份與還原", ["#/", "方向"], `
      <section class="pcard"><h3>裝置與復原碼</h3>
        <div class="kvs"><span class="kv"><i>device_id</i><b class="num sm">${esc(dev)}</b></span><span class="kv"><i>vault_id（由復原碼推導）</i><b class="num sm">${esc(vault)}</b></span></div>
        ${codeBox}</section>
      <section class="pcard"><h3>立即備份</h3>
        <p class="muted">本機資料：${esc(counts)}<br>checksum <span class="num sm">${esc(localSum.slice(0, 16))}…</span></p>
        <div class="tools"><button type="button" class="btn" id="bk" ${code ? "" : "disabled"}>🔐 立即備份（加密下載）</button>
          <label class="toggle"><input type="checkbox" id="auto" ${auto ? "checked" : ""} ${code ? "" : "disabled"}> 每日自動備份到本機（保留最近 ${S.K_BLOBS} 份）</label></div>
        <p class="note">檔案以 AES-256-GCM 加密（金鑰由復原碼經 PBKDF2-SHA256 210,000 次推導），只有持有復原碼的人能打開。下載的 .prb 檔請自行存到 iCloud Drive／Google Drive。</p></section>
      <section class="pcard"><h3>備份列表（本機）</h3>
        ${blobs.length ? `<div class="scroll"><table class="cmp"><thead><tr><th>時間（台北）</th><th class="r">大小</th><th>checksum</th><th></th></tr></thead><tbody>${blobs.map((b) => `<tr data-id="${esc(b.id)}"><td class="num">${esc(A.tpe(b.created_at))}</td><td class="r num">${(b.size / 1024).toFixed(1)} KB</td><td class="num sm">${esc(b.checksum.slice(0, 12))}…</td>
          <td><button type="button" class="btn sm dl">下載</button> <button type="button" class="btn sm rs">還原</button></td></tr>`).join("")}</tbody></table></div>` : `<p class="pend-t">尚無本機備份。</p>`}</section>
      <section class="pcard"><h3>從備份檔還原（新蓋舊合併）</h3>
        <div class="tools"><input type="file" id="file" accept=".prb,application/octet-stream" class="fval" style="width:auto">
          <input id="rcode" class="fval" style="width:280px" placeholder="復原碼（預設用本機這組）" autocomplete="off" spellcheck="false">
          <button type="button" class="btn" id="restore">解密並預覽合併</button></div>
        <div id="rres"></div>
        <p class="note">合併規則（§14.3）：同一筆資料取 updated_at 較新者；相同時比 version，再比 updated_by_device。刪除以 tombstone 保留並同步。還原不會刪掉本機較新的資料。</p></section>
      <section class="pcard"><h3>儲存空間</h3>
        <p>持久儲存（navigator.storage.persist）：<b>${persisted == null ? "此瀏覽器不支援" : persisted ? "已核准" : "未核准"}</b> ${persisted === false ? `<button type="button" class="btn sm" id="persist">申請</button>` : ""}
          ${est ? `｜已用 ${(est.usage / 1048576).toFixed(1)} MB／配額 ${(est.quota / 1048576).toFixed(0)} MB` : ""}</p>
        <ul class="note"><li>iPad：Safari 分頁和「加入主畫面」的 App 可能是兩份獨立儲存（兩個 device_id）。日常請從主畫面開啟；若資料不見，用復原碼＋備份檔還原即可。</li>
          <li>Safari 可能清除長期未使用網站的資料，請定期下載備份檔。</li>
          <li><b>雲端備份（Supabase）尚未設定</b>：需要 Jay 建立 Supabase 專案與金鑰（§14.2），本版不自動建立帳號。目前以「加密備份檔」匯出／匯入代替；同一個檔案也能在 box 用 <span class="num">pipeline/run_backup.py import</span> 匯入，讓盤後批次使用你的設定與自訂型態。</li></ul></section>`);
    const $ = (id) => $app.querySelector("#" + id);
    if ($("gen")) $("gen").addEventListener("click", async () => { if (!A.guard()) return; await S.meta("recovery_code", B.newRecoveryCode()); await S.meta("recovery_confirmed", false); renderBackup("#/backup"); });
    if ($("use")) $("use").addEventListener("click", async () => { const c = B.normCode($("have").value); if (c.length !== 24) { alert("復原碼應為 24 個英數字"); return; }
      await S.meta("recovery_code", c.match(/.{4}/g).join("-")); await S.meta("recovery_confirmed", true); renderBackup("#/backup"); });
    if ($("ackb")) $("ackb").addEventListener("click", async () => { if (!$("ack").checked) { alert("請先勾選「我已抄寫並妥善保存」"); return; } await S.meta("recovery_confirmed", true); go("#/backup"); });
    if ($("hide")) $("hide").addEventListener("click", () => go("#/backup"));
    if ($("reshow")) $("reshow").addEventListener("click", () => { if (confirm("要在這台裝置重新顯示復原碼嗎？請確認旁邊沒有其他人。")) go("#/backup?show=1"); });
    if ($("bk")) $("bk").addEventListener("click", async () => { if (!A.guard()) return; $("bk").disabled = true; $("bk").textContent = "加密中…";
      try { await makeBackup(code, true); } catch (e) { alert("備份失敗：" + e.message); } renderBackup("#/backup"); });
    if ($("auto")) $("auto").addEventListener("change", async (e) => { if (!A.guard()) { e.target.checked = !e.target.checked; return; } await S.setting("auto_backup", e.target.checked); if (e.target.checked) autoBackup(); });
    if ($("persist")) $("persist").addEventListener("click", async () => { try { await navigator.storage.persist(); } catch (e) {} renderBackup("#/backup"); });
    $app.querySelectorAll("tr[data-id]").forEach((tr) => {
      const b = blobs.find((x) => x.id === tr.dataset.id);
      tr.querySelector(".dl").addEventListener("click", () => download(b.name || "pattern-radar.prb", new Blob([b.bytes])));
      tr.querySelector(".rs").addEventListener("click", () => preview(b.bytes));
    });
    $("restore").addEventListener("click", async () => { const f = $("file").files[0]; if (!f) { alert("請先選擇備份檔（.prb）"); return; } preview(new Uint8Array(await f.arrayBuffer())); });
    async function preview(bytes) {
      if (!A.guard()) return;
      const out = $("rres"); out.innerHTML = `<p class="muted">解密中…</p>`;
      const c = $("rcode").value.trim() || code; if (!c) { out.innerHTML = `<p class="chip bad">請輸入復原碼</p>`; return; }
      let r; try { r = await B.decryptBackup(bytes, c); } catch (e) { out.innerHTML = `<p class="chip bad">${esc(e.message)}</p>`; return; }
      const cur = await S.exportTables(), m = B.mergeTables(cur, r.doc.tables || {});
      out.innerHTML = `<p>備份時間 ${esc(A.tpe(r.doc.exported_at))}（台北）・來源裝置 <span class="num sm">${esc(r.doc.device_id)}</span>・檔案 checksum <span class="num sm">${esc(r.checksum.slice(0, 16))}…</span></p>
        <div class="scroll"><table class="cmp"><thead><tr><th>資料表</th><th class="r">備份筆數</th><th class="r">新增</th><th class="r">採用備份（較新）</th><th class="r">保留本機（較新）</th><th class="r">合併後</th></tr></thead><tbody>
        ${Object.entries(m.stats).map(([t, x]) => `<tr><td>${esc(t)}</td><td class="r num">${((r.doc.tables || {})[t] || []).length}</td><td class="r num">${x.added}</td><td class="r num">${x.taken}</td><td class="r num">${x.kept}</td><td class="r num">${x.total}（有效 ${x.live}）</td></tr>`).join("")}</tbody></table></div>
        <button type="button" class="btn" id="apply">套用合併</button>`;
      out.querySelector("#apply").addEventListener("click", async () => {
        if (!A.guard()) return;
        await S.importTables(m.tables);
        const fr = (m.tables.fundamental_rules || []).find((x) => x.id === "default" && !x.deleted);
        if (fr) localStorage.setItem("radar.fundRules", fr.rules_json);
        const up = (m.tables.settings || []).find((x) => x.id === "ui_prefs" && !x.deleted); if (up) localStorage.setItem("radar.prefs", up.value_json);
        if (!code) { await S.meta("recovery_code", B.normCode(c).match(/.{4}/g).join("-")); await S.meta("recovery_confirmed", true); }
        const after = await B.checksum(await S.exportTables());
        out.innerHTML = `<p class="chip ok">已還原並合併</p><p>本機 checksum <span class="num sm">${esc(after.slice(0, 16))}…</span>${after === r.checksum ? `　<span class="chip ok">與備份檔一致</span>` : `　<span class="muted">（與備份檔不同：本機另有較新或額外的資料）</span>`}</p>`;
      });
    }
  }

  // ================================================================ 型態編輯器（§16、P9：RuleBlockEditor + JsonPanel + 即時預覽）
  const BLANK = { code: "my_pattern", name: "我的型態", version: 1, directions: ["long"], role: "standard", native_exit: "X3", min_bars: 60,
    params: { n_fast: { default: 5, min: 2, max: 60, desc: "快線天數" }, n_slow: { default: 25, min: 5, max: 250, desc: "慢線天數" } },
    series: { fast: "sma(close, n_fast)", slow: "sma(close, n_slow)" }, strong_flags: {},
    states: [{ state: "EXIT", direction: "long", requires_position: "LONG", when: "cross_down(close, slow)" },
      { state: "ENTRY", direction: "long", requires_position: "NONE", when: "cross_up(fast, slow) and volume > avg_vol(20) * 1.3", strength: "50 + 50 * (slope_pct(slow, 5) > 0)", levels: { stopRef: "slow" } },
      { state: "HOLD", requires_position: "LONG", when: "close > slow" }] };
  let ED = null;  // { W, row, versions }
  const builtinIds = () => new Set(A.SUMMARY.patterns.filter((p) => !p.custom).map((p) => p.id));
  async function dslBuiltin() { try { const sc = await A.needScan(); const d = sc.dsl_builtin; return (Array.isArray(d) ? d : d && d.patterns) || []; } catch (e) { return []; } }
  async function renderEditorList() {
    const mine = (await S.live("patterns")).filter((p) => !p.builtin).sort((a, b) => a.code.localeCompare(b.code));
    const tpl = await dslBuiltin();
    page("型態編輯器", ["#/", "方向"], `
      <p class="note">用 DSL（§16）組合條件：只允許白名單函式（sma、ema、avg_vol、slope_pct、ref、cross_up／down、highest、lowest、count、min、max、abs），不能執行任意程式碼。
        內建 CIS 兩組的 DSL 版與內建版結果完全一致（測試：pipeline/tests/test_dsl.py、test_dsl_js.py）。</p>
      <h3 class="sub-h">我的型態</h3>
      <div class="frules">${mine.map((p) => `<div class="frule"><span class="fl">${esc(p.name)} <span class="muted num">${esc(p.code)} v${p.current_version}</span></span>
        <span>${JSON.parse(p.directions_json || "[]").map((d) => `<span class="chip ${d}">${A.DIR[d].label}</span>`).join("")}<span class="chip ${p.enabled ? "ok" : "off"}">${p.enabled ? "啟用" : "停用"}</span></span>
        <a class="btn sm" href="#/editor/${encodeURIComponent(p.id)}">編輯</a></div>`).join("") || `<p class="pend-t">還沒有自訂型態。</p>`}</div>
      <div class="tools"><a class="btn" href="#/editor/new">＋ 新增型態</a>${tpl.map((d) => `<a class="btn" href="#/editor/new?from=${encodeURIComponent(d.code)}">從 ${esc(d.code)} 複製</a>`).join("")}</div>
      <h3 class="sub-h">內建 DSL 範本（唯讀）</h3>
      <div class="frules">${tpl.map((d) => `<div class="frule"><span class="fl">${esc(d.name)} <span class="muted num">${esc(d.code)}</span></span><span class="muted">${esc(d.description || "")}</span><a class="btn sm" href="#/editor/view?code=${encodeURIComponent(d.code)}">檢視／預覽</a></div>`).join("") || `<p class="pend-t">內建範本未載入（需最新掃描結果）。</p>`}</div>
      <p class="note">自訂型態存在本機 IndexedDB（離線可看，不能改）。要讓盤後批次掃描、回測與警示包含它：備份與還原 → 匯出備份檔 → 在 box 執行 <span class="num">python3 pipeline/run_backup.py import 檔案</span>。</p>`);
  }
  async function renderEditor(h) {
    const id = decodeURIComponent(h.split("?")[0].split("/")[2] || ""), q = qs(h), tpl = await dslBuiltin();
    let W, row = null, versions = [], readonly = false;
    if (id === "view") { W = tpl.find((d) => d.code === q.code); readonly = true; if (!W) return renderEditorList(); }
    else if (id === "new") { const src = tpl.find((d) => d.code === q.from); W = JSON.parse(JSON.stringify(src || BLANK)); if (src) { W.code = src.code + "_my"; W.name = src.name + "（我的）"; W.version = 1; } }
    else { row = await S.get("patterns", id); if (!row || row.deleted) return go("#/editor");
      versions = (await S.live("pattern_versions")).filter((v) => v.pattern_id === id).sort((a, b) => b.ver - a.ver);
      const cur = versions.find((v) => v.ver === row.current_version) || versions[0]; W = JSON.parse(cur.definition_json); }
    if (PENDING && !readonly) W = PENDING;
    ED = { W: JSON.parse(JSON.stringify(W)), row, versions, readonly };
    const ro = readonly || off();
    const opt = (xs, v) => xs.map((x) => `<option ${x === (v ?? "") ? "selected" : ""} value="${esc(x)}">${esc(x || "（無）")}</option>`).join("");
    const kvRows = (obj, cls) => Object.entries(obj || {}).map(([k, v]) => `<div class="blk-kv ${cls}"><input class="fval k" value="${esc(k)}" aria-label="名稱"> = <input class="fval v expr" value="${esc(v)}" aria-label="運算式"><button type="button" class="btn sm del">✕</button></div>`).join("");
    const stBlock = (st, i) => `<div class="blk" data-i="${i}">
        <div class="blk-h"><b>#${i + 1}</b><select class="fop s-state">${opt(RadarDSL.STATES, st.state)}</select><select class="fop s-dir">${opt(["", "long", "short"], st.direction || "")}</select>
          <label class="muted">需要部位</label><select class="fop s-pos">${opt(RadarDSL.POS, st.requires_position || "ANY")}</select>
          <span class="sp"></span><button type="button" class="btn sm up">↑</button><button type="button" class="btn sm dn">↓</button><button type="button" class="btn sm del">✕</button></div>
        <label class="blk-l">條件 when<textarea class="fval expr s-when" rows="2">${esc(st.when)}</textarea></label>
        <label class="blk-l">強度 strength（0–100，可空白）<input class="fval expr s-str" value="${esc(st.strength || "")}"></label>
        <label class="blk-l">關鍵價 levels（每行「名稱 = 運算式」）<textarea class="fval expr s-lv" rows="2">${esc(Object.entries(st.levels || {}).map(([k, v]) => `${k} = ${v}`).join("\n"))}</textarea></label>
        <label class="blk-l">說明 note<input class="fval s-note" value="${esc(st.note || "")}"></label></div>`;
    const p = ED.W;
    page(readonly ? `型態定義：${esc(p.name)}` : row ? `編輯：${esc(p.name)}` : "新增型態", ["#/editor", "型態列表"], `
      ${readonly ? `<p class="note">內建範本唯讀；要修改請「從 ${esc(p.code)} 複製」。</p>` : off() ? `<p class="note short">目前離線：可檢視，不能修改或儲存。</p>` : ""}
      <div class="ed">
        <div class="ed-main">
          <section class="pcard"><h3>基本設定</h3><div class="frules">
            <div class="frule"><span class="fl">代碼 code</span><input id="e-code" class="fval num" value="${esc(p.code)}" style="width:200px"><span class="fl">名稱</span><input id="e-name" class="fval" value="${esc(p.name)}" style="width:220px"></div>
            <div class="frule"><span class="fl">方向</span><label class="toggle"><input type="checkbox" id="e-long" ${p.directions.includes("long") ? "checked" : ""}> 做多</label><label class="toggle"><input type="checkbox" id="e-short" ${p.directions.includes("short") ? "checked" : ""}> 做空</label>
              <span class="fl">角色</span><select id="e-role" class="fop">${opt(["standard", "baseline", "experiment"], p.role || "standard")}</select>
              <span class="fl">原生出場</span><select id="e-nx" class="fop">${["X3", "X2"].map((x) => `<option ${x === (p.native_exit || "X3") ? "selected" : ""} value="${x}">${XZH[x]}</option>`).join("")}</select>
              <span class="fl">最少 K 線</span><input id="e-min" class="fval num" type="number" value="${esc(p.min_bars || 60)}" style="width:90px"></div></div></section>
          <section class="pcard"><h3>參數（params）</h3><div id="e-params">${Object.entries(p.params || {}).map(([k, v]) => `<div class="blk-kv prm"><input class="fval k" value="${esc(k)}" aria-label="參數名"> 預設 <input class="fval v num" type="number" step="any" value="${esc(v.default)}"> 範圍 <input class="fval mn num" type="number" step="any" value="${esc(v.min ?? "")}" style="width:80px">～<input class="fval mx num" type="number" step="any" value="${esc(v.max ?? "")}" style="width:80px"> <input class="fval ds" value="${esc(v.desc || "")}" placeholder="說明"><button type="button" class="btn sm del">✕</button></div>`).join("")}</div>
            <button type="button" class="btn sm add" data-add="prm">＋ 參數</button></section>
          <section class="pcard"><h3>序列（series，依序計算）</h3><div id="e-series">${kvRows(p.series, "ser")}</div><button type="button" class="btn sm add" data-add="ser">＋ 序列</button></section>
          <section class="pcard"><h3>強勢旗標（strong_flags）</h3><div id="e-flags">${kvRows(p.strong_flags, "flg")}</div><button type="button" class="btn sm add" data-add="flg">＋ 旗標</button></section>
          <section class="pcard"><h3>狀態積木（RuleBlockEditor：由上往下，第一個成立的就是當天狀態）</h3><div id="e-states">${p.states.map(stBlock).join("")}</div>
            <button type="button" class="btn sm" id="e-addst">＋ 狀態</button></section>
        </div>
        <div class="ed-side">
          <section class="pcard"><h3>檢查</h3><div id="e-val"></div></section>
          <section class="pcard"><h3>即時預覽（最新交易日）</h3>
            <div class="tools"><select id="e-sec" class="fop"></select><button type="button" class="btn sm" id="e-run">預覽</button></div><div id="e-prev" class="muted">選類股後按「預覽」。</div></section>
          <section class="pcard"><h3>JSON（JsonPanel）</h3><textarea id="e-json" class="fval json" rows="16" spellcheck="false"></textarea>
            <div class="tools"><button type="button" class="btn sm" id="e-applyjson">套用 JSON 到積木</button><button type="button" class="btn sm" id="e-dl">下載 JSON</button></div></section>
          ${readonly ? "" : `<section class="pcard"><h3>儲存</h3><input id="e-vnote" class="fval" placeholder="版本說明（可空白）" style="width:100%">
            <div class="tools"><button type="button" class="btn" id="e-save">儲存為新版本</button>${row ? `<label class="toggle"><input type="checkbox" id="e-en" ${row.enabled ? "checked" : ""}> 啟用</label><button type="button" class="btn sm" id="e-del">刪除</button>` : ""}</div>
            ${versions.length ? `<h4 class="sub-h">版本</h4>${versions.map((v) => `<div class="frule"><span class="fl">v${v.ver}${v.ver === row.current_version ? "（目前）" : ""}</span><span class="muted">${esc(A.tpe(v.updated_at))}・${esc(v.note || "")}</span>${v.ver !== row.current_version ? `<button type="button" class="btn sm setv" data-v="${v.ver}">設為目前</button>` : ""}</div>`).join("")}` : ""}</section>`}
        </div></div>`);
    const $ = (s) => $app.querySelector(s);
    if (ro) $app.querySelectorAll(".ed-main input,.ed-main select,.ed-main textarea,.ed-main button,#e-applyjson,#e-json").forEach((x) => (x.disabled = true));
    function readBlocks() {
      const W = Object.assign({}, ED.W, { code: $("#e-code").value.trim(), name: $("#e-name").value.trim(), version: ED.W.version || 1,
        directions: [$("#e-long").checked && "long", $("#e-short").checked && "short"].filter(Boolean), role: $("#e-role").value, native_exit: $("#e-nx").value, min_bars: +$("#e-min").value || 60,
        params: {}, series: {}, strong_flags: {}, states: [] });
      $app.querySelectorAll(".prm").forEach((r) => { const k = r.querySelector(".k").value.trim(); if (!k) return; const o = { default: r.querySelector(".v").value === "" ? null : +r.querySelector(".v").value };
        if (r.querySelector(".mn").value !== "") o.min = +r.querySelector(".mn").value; if (r.querySelector(".mx").value !== "") o.max = +r.querySelector(".mx").value; if (r.querySelector(".ds").value) o.desc = r.querySelector(".ds").value; W.params[k] = o; });
      $app.querySelectorAll(".ser").forEach((r) => { const k = r.querySelector(".k").value.trim(); if (k) W.series[k] = r.querySelector(".v").value; });
      $app.querySelectorAll(".flg").forEach((r) => { const k = r.querySelector(".k").value.trim(); if (k) W.strong_flags[k] = r.querySelector(".v").value; });
      if (!Object.keys(W.strong_flags).length) delete W.strong_flags;
      $app.querySelectorAll(".blk").forEach((b) => { const st = { state: b.querySelector(".s-state").value, when: b.querySelector(".s-when").value };
        const d = b.querySelector(".s-dir").value; if (d) st.direction = d; const rp = b.querySelector(".s-pos").value; if (rp && rp !== "ANY") st.requires_position = rp;
        const sv = b.querySelector(".s-str").value.trim(); if (sv) st.strength = sv;
        const lv = Object.fromEntries(b.querySelector(".s-lv").value.split("\n").map((l) => l.split("=")).filter((x) => x.length >= 2 && x[0].trim()).map(([k, ...r]) => [k.trim(), r.join("=").trim()]));
        if (Object.keys(lv).length) st.levels = lv; const nt = b.querySelector(".s-note").value.trim(); if (nt) st.note = nt; W.states.push(st); });
      return W;
    }
    function refresh(fromBlocks = true) {
      if (fromBlocks && !ro) ED.W = readBlocks();
      $("#e-json").value = JSON.stringify(ED.W, null, 2);
      const errs = RadarDSL.validate(ED.W);
      if (!readonly && !row && builtinIds().has(ED.W.code)) errs.push(`code「${ED.W.code}」與內建型態重複`);
      $("#e-val").innerHTML = errs.length ? `<p class="chip bad">${errs.length} 個問題</p><ul class="reasons">${errs.map((e) => `<li>${esc(e)}</li>`).join("")}</ul>` : `<p class="chip ok">定義合法</p>`;
      if ($("#e-save")) $("#e-save").disabled = !!errs.length;
      return errs;
    }
    $app.querySelector(".ed-main").addEventListener("input", () => refresh());
    $app.querySelector(".ed-main").addEventListener("change", () => refresh());
    $app.querySelector(".ed-main").addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b || ro) return;
      if (b.classList.contains("del")) { (b.closest(".blk") || b.closest(".blk-kv")).remove(); }
      else if (b.classList.contains("up") || b.classList.contains("dn")) { const blk = b.closest(".blk"), sib = b.classList.contains("up") ? blk.previousElementSibling : blk.nextElementSibling;
        if (sib) b.classList.contains("up") ? blk.parentNode.insertBefore(blk, sib) : blk.parentNode.insertBefore(sib, blk); }
      else if (b.dataset.add) { const host = { prm: "#e-params", ser: "#e-series", flg: "#e-flags" }[b.dataset.add];
        $(host).insertAdjacentHTML("beforeend", b.dataset.add === "prm" ? `<div class="blk-kv prm"><input class="fval k" value="p${Date.now() % 1000}"> 預設 <input class="fval v num" type="number" step="any" value="1"> 範圍 <input class="fval mn num" type="number" step="any" style="width:80px">～<input class="fval mx num" type="number" step="any" style="width:80px"> <input class="fval ds" placeholder="說明"><button type="button" class="btn sm del">✕</button></div>`
          : kvRows({ [`s${Date.now() % 1000}`]: "close" }, b.dataset.add)); }
      else if (b.id === "e-addst") { $("#e-states").insertAdjacentHTML("beforeend", stBlock({ state: "WATCH", when: "close > 0" }, $app.querySelectorAll(".blk").length)); }
      else return;
      refresh();
    });
    $("#e-applyjson") && $("#e-applyjson").addEventListener("click", () => { let j; try { j = JSON.parse($("#e-json").value); } catch (e) { alert("JSON 格式錯誤：" + e.message); return; }
      if (!j || typeof j !== "object" || !Array.isArray(j.states) || !Array.isArray(j.directions)) { alert("JSON 至少需要 directions 與 states 陣列"); return; }
      const errs = RadarDSL.validate(j); if (errs.length && !confirm(`JSON 有 ${errs.length} 個問題，仍要套用到積木嗎？`)) return;
      PENDING = j; renderEditor(location.hash.slice(1)).finally(() => { PENDING = null; }); });
    $("#e-dl").addEventListener("click", () => download(`${ED.W.code || "pattern"}.json`, JSON.stringify(ED.W, null, 2), "application/json"));
    // preview
    const sc = A.SCAN || (await A.needScan().catch(() => null));
    const secs = sc ? Object.keys(sc.sector_members || {}).sort() : [];
    $("#e-sec").innerHTML = secs.map((k) => `<option value="${esc(k)}">${esc(k)} ${esc((sc.sector_names || {})[k] || "")}</option>`).join("");
    if (secs.includes("24")) $("#e-sec").value = "24";
    $("#e-run").addEventListener("click", async () => {
      const out = $("#e-prev"), errs = refresh(); if (errs.length) { out.innerHTML = `<p class="chip bad">定義有問題，先修正再預覽。</p>`; return; }
      out.textContent = "計算中…";
      let bars; try { bars = await A.needBars($("#e-sec").value); } catch (e) { out.innerHTML = off() ? `<p class="pend-t">離線無圖：本機沒有這個類股的日 K 快取。</p>` : `<p class="chip bad">日 K 載入失敗</p>`; return; }
      let prog; try { prog = RadarDSL.compile(ED.W); } catch (e) { out.innerHTML = `<p class="chip bad">${esc(e.message)}</p>`; return; }
      const cnt = {}, hits = [], t0 = performance.now();
      const scanEntry = new Set((sc ? sc.hits : []).filter((x) => x.patternId === ED.W.code && x.state === "ENTRY").map((x) => `${x.symbol}|${x.direction}`));
      const short = Object.fromEntries((sc ? sc.hits : []).map((x) => [x.symbol, x.shortable]));
      let agree = 0, disagree = [];
      for (const [sym, b] of Object.entries(bars.series)) {
        const E = prog.env(b.o, b.h, b.l, b.c, b.v), st = prog.stateAt(E, b.c.length - 1, "NONE", short[sym] ?? null);
        cnt[st.state] = (cnt[st.state] || 0) + 1;
        if (st.state === "ENTRY" || st.state === "CONFIRMED") hits.push([sym, st]);
        if (scanEntry.size || builtinIds().has(ED.W.code)) { const k = `${sym}|${st.direction}`, mine = st.state === "ENTRY";
          const inScan = mine ? scanEntry.has(k) : [...scanEntry].some((x) => x.startsWith(sym + "|"));
          if (mine === inScan) agree++; else disagree.push(sym); }
      }
      const name = (sym) => { const x = sc && sc.hits.find((y) => y.symbol === sym); return x ? x.name : ""; };
      out.innerHTML = `<p class="num">${Object.keys(bars.series).length} 檔・${(performance.now() - t0).toFixed(0)} ms・資料日 ${esc(bars.trade_date || "")}</p>
        <div class="chips-row">${Object.entries(cnt).sort((a, b) => b[1] - a[1]).map(([k, v]) => `<span class="stchip st-${k}">${esc(A.STATE_ZH[k] || k)} <b class="num">${v}</b></span>`).join("")}</div>
        ${hits.length ? `<table class="mini"><tbody>${hits.slice(0, 40).map(([s, st]) => `<tr><td class="num">${esc(s)}</td><td>${esc(name(s))}</td><td class="${st.direction}">${st.direction ? A.DIR[st.direction].label : ""}</td><td class="r num">${fmt(st.strength, 0)}</td></tr>`).join("")}</tbody></table>` : `<p class="muted">今天沒有進場訊號。</p>`}
        ${builtinIds().has(ED.W.code) ? `<p>${!disagree.length ? `<span class="chip ok">與內建 ${esc(ED.W.code)} 今日進場結果一致（${agree} 檔）</span>` : `<span class="chip bad">與內建不一致：${disagree.map(esc).join("、")}</span>`}</p>` : ""}
        <p class="note">預覽範圍：這個類股今日有任何訊號的個股（網頁只帶這些個股的日 K）；部位假設為空手（NONE）。完整掃描在 box 盤後批次。</p>`;
    });
    // save / versions
    if ($("#e-save")) $("#e-save").addEventListener("click", async () => {
      if (!A.guard()) return; const errs = refresh(); if (errs.length) return;
      const W = ED.W, same = (await S.live("patterns")).find((x) => x.code === W.code && (!row || x.id !== row.id));
      if (same) { alert(`已有代碼 ${W.code} 的型態`); return; }
      const ver = row ? Math.max(...versions.map((v) => v.ver), 0) + 1 : 1; W.version = ver;
      const pr = await S.save("patterns", Object.assign({}, row || {}, { code: W.code, name: W.name, directions_json: JSON.stringify(W.directions), role: W.role || "standard",
        native_exit: W.native_exit || "X3", builtin: 0, current_version: ver, enabled: row ? row.enabled : 1, confirmed_by_jay: 0 }));
      await S.save("pattern_versions", { pattern_id: pr.id, ver, definition_json: JSON.stringify(W), note: $("#e-vnote").value.trim() });
      go(`#/editor/${encodeURIComponent(pr.id)}`);
    });
    if ($("#e-en")) $("#e-en").addEventListener("change", async (e) => { if (!A.guard()) { e.target.checked = !e.target.checked; return; } await S.save("patterns", Object.assign({}, row, { enabled: e.target.checked ? 1 : 0 })); });
    if ($("#e-del")) $("#e-del").addEventListener("click", async () => { if (!A.guard()) return; if (!confirm(`刪除「${row.name}」？（以刪除標記保留，備份還原時會同步刪除）`)) return;
      await S.remove("patterns", row.id); go("#/editor"); });
    $app.querySelectorAll(".setv").forEach((b) => b.addEventListener("click", async () => { if (!A.guard()) return; await S.save("patterns", Object.assign({}, row, { current_version: +b.dataset.v })); renderEditor(location.hash.slice(1)); }));
    refresh(false);
  }
  let PENDING = null;

  // ================================================================ 資料狀態（DataHealth）
  async function renderHealth() {
    $app.innerHTML = `<p class="loading">載入資料狀態…</p>`;
    let H = null; try { H = await A.getJSON("health_latest.json"); } catch (e) {}
    const cache = S ? await S.cacheList() : [];
    page("資料狀態", ["#/", "方向"], !H ? `<p class="pend-t">資料狀態檔（health_latest.json）無法載入${off() ? "（離線且無快取）" : ""}。</p>` : `
      <div class="asof">產生時間 ${esc((H.generated_at || "").replace("T", " ").slice(0, 16))}（台北時間）｜交易日曆 ${esc(H.trading_days.first)} ～ ${esc(H.trading_days.last)}（${H.trading_days.count} 日）</div>
      <h3 class="sub-h">資料源（最後成功、錯誤、節流）</h3>
      <div class="scroll"><table class="cmp"><thead><tr><th>來源</th><th class="r">成功</th><th class="r">失敗</th><th>最後成功（台北）</th><th>最後錯誤</th><th class="r">請求間隔</th></tr></thead><tbody>
      ${H.sources.map((s) => `<tr><td>${esc(s.name)}</td><td class="r num">${s.ok}</td><td class="r num ${s.fail ? "bad-t" : ""}">${s.fail}</td><td class="num">${esc((s.last_ok || "—").replace("T", " ").slice(0, 19))}</td><td class="${s.last_error ? "bad-t" : "muted"}">${esc(s.last_error || "無")}</td><td class="r num">${s.throttle_sec ?? "—"} 秒</td></tr>`).join("")}</tbody></table></div>
      <h3 class="sub-h">資料表</h3>
      <div class="scroll"><table class="cmp"><thead><tr><th>資料</th><th>最早</th><th>最新</th><th class="r">最新一期筆數</th><th class="r">總筆數</th></tr></thead><tbody>
      ${H.tables.map((t) => `<tr><td>${esc(t.name)}</td><td class="num">${esc(t.earliest || "—")}</td><td class="num">${esc(t.latest || "—")}</td><td class="r num">${t.rows_latest ?? "—"}</td><td class="r num">${(t.rows ?? 0).toLocaleString()}</td></tr>`).join("")}</tbody></table></div>
      ${H.scan ? `<h3 class="sub-h">最近一次掃描</h3><p>交易日 ${esc(H.scan.trade_date)}・完成 ${esc((H.scan.finished_at || "").replace("T", " ").slice(0, 16))}（台北）・Universe ${H.scan.universe} 檔
        ・法人 ${Object.entries(H.scan.inst_available || {}).map(([k, v]) => `${k} ${v ? "✓" : "✗"}`).join(" ")}・融券 ${Object.entries(H.scan.margin_available || {}).map(([k, v]) => `${k} ${v ? "✓" : "✗"}`).join(" ")}</p>
        <div class="chips-row">${Object.entries(H.scan.excluded || {}).map(([k, v]) => `<span class="chip">${esc(k)} ${v}</span>`).join("")}</div>
        ${(H.scan.custom_pattern_errors || []).length ? `<p class="chip bad">自訂型態錯誤：${H.scan.custom_pattern_errors.map(esc).join("；")}</p>` : ""}` : ""}
      <h3 class="sub-h">這台裝置的離線快取（IndexedDB）</h3>
      ${cache.length ? `<div class="scroll"><table class="cmp"><thead><tr><th>檔案</th><th>資料日</th><th>快取時間（台北）</th></tr></thead><tbody>${cache.sort((a, b) => a.name.localeCompare(b.name)).map((c) => `<tr><td class="num">${esc(c.name)}</td><td class="num">${esc(c.as_of || "—")}</td><td class="num">${esc(A.tpe(c.cached_at))}</td></tr>`).join("")}</tbody></table></div>` : `<p class="pend-t">尚無快取。</p>`}
      <ul class="note">${(H.notes || []).map((n) => `<li>${esc(n)}</li>`).join("")}<li>K 線只快取看過的類股；離線時沒看過的類股顯示「離線無圖」。</li></ul>`);
  }

  // ================================================================ 設定（音效預設關閉、粒子、漸層 K 線）
  function renderPrefs() {
    const p = prefs(), rm = reduce();
    const tg = (k, t, d) => `<div class="frule"><span class="fl">${t}</span><label class="toggle"><input type="checkbox" data-k="${k}" ${p[k] ? "checked" : ""}> 開啟</label><span class="muted">${d}</span></div>`;
    page("設定", ["#/", "方向"], `<div class="frules">
      ${tg("sound", "命中音效", "預設關閉；開啟後，命中時播放短音效（Web Audio）。")}
      ${tg("particles", "命中粒子", rm ? "系統已設定「減少動態效果」，粒子與雷達旋轉已自動停用。" : "命中時粒子爆散。")}
      ${tg("gradient", "漸層 K 線", "紅漲綠跌漸層實體，量越大外光越亮；關閉則用一般 K 線。")}
      <div class="frule"><span class="fl">試聽／試看</span><button type="button" class="btn sm" id="try">▶ 播放一次</button></div>
      <div class="frule"><span class="fl">減少動態效果</span><span>${rm ? "系統已開啟" : "系統未開啟"}</span><span class="muted">依 prefers-reduced-motion 自動判斷。</span></div></div>
      <p class="note">設定存在本機，備份檔會一併帶走。</p>
      <p><a class="btn sm" href="#/appendix">📖 附錄：出場規則、樣本內外、交易成本</a></p>`);
    $app.querySelectorAll("input[data-k]").forEach((x) => x.addEventListener("change", () => setPref(x.dataset.k, x.checked)));
    $app.querySelector("#try").addEventListener("click", (e) => { const r = e.target.getBoundingClientRect(); burst(r.left + r.width / 2, r.top, "#B6FF3B", 40); ping("long"); });
  }

  // ================================================================ 附錄：出場規則、樣本內外、成本
  async function renderAppendix() {
    let bt = null; try { bt = await needBT(); } catch (e) {}
    const cf = (bt && bt.config) || {}, split = cf.split || "2025-07-01", start = cf.start || "2024-01-02", end = cf.end || "最新交易日";
    const days = (bt && bt.days) || [], nIS = days.filter((d) => d < split).length, nOOS = days.length - nIS;
    const row = (x, use, rule) => `<tr><td style="color:${XCOL[x]}"><b>${XZH[x]}</b><br><span class="muted">${XROLE(x)}・代號 ${x}</span></td><td>${use}</td><td>${rule}</td></tr>`;
    page("附錄：回測怎麼算", ["#/lab", "回測實驗室"], `
      <section class="pcard"><h3>三種出場規則</h3>
        <p>每一筆進場訊號，都用適用的出場規則<b>各算一次</b>，結果並排比較。進場方式都一樣，差別只在什麼時候賣。</p>
        <div class="scroll"><table class="cmp wrap"><thead><tr><th>名稱</th><th>用在哪些型態</th><th>什麼時候出場（先碰到哪個就照哪個）</th></tr></thead><tbody>
          ${row("X1", "全部 13 種型態共用", "扣掉成本後的淨報酬<b>虧到 −7% 停損</b>、<b>賺到 +12% 停利</b>；兩個都沒碰到，<b>最多持有 10 個交易日</b>，第 10 天收盤出場（進場日算第 1 天）。這是統一的尺，用來公平比較每一招。")}
          ${row("X2", "只用於蔡森十二招", "<b>碰到滿足點</b>就出場（多方看盤中最高價、空方看最低價）；<b>收盤跌破停損參考價</b>（空方是站上）；或<b>型態失敗</b>。沒有天數上限。")}
          ${row("X3", "只用於 CIS 兩組（基準線、實驗組）", "做多：出現<b>第一根收盤同時跌破 5 日與 25 日均線的黑 K</b> 就出場。做空反過來：第一根同時站上兩條均線的紅 K。沒有天數上限。")}
        </tbody></table></div>
        <ul class="note"><li>停損、停利用盤中最高最低價判斷；同一天兩個都碰到，保守算停損。開盤就跳空越過停損價或滿足點時，以開盤價成交。</li>
          <li>型態出場、均線出場是「收盤才確認」的訊號，隔天開盤賣出。</li>
          <li>回測結束時還沒出場的部位，用最後一天的收盤價結算，標為「期末未平倉」。</li></ul></section>
      <section class="pcard"><h3>樣本內、樣本外是什麼</h3>
        <p>用來檢查回測結果是不是運氣。資料從 <b class="num">${esc(split)}</b> 切成兩段：</p>
        <ul><li><b>樣本內</b>：${esc(start)} ～ ${esc(split)} 前一天${nIS ? `（${nIS} 個交易日）` : ""}。設計和調整規則時看的那一段。</li>
          <li><b>樣本外</b>：${esc(split)} ～ ${esc(end)}${nOOS ? `（${nOOS} 個交易日）` : ""}。規則定好之後才拿來驗收的那一段。</li></ul>
        <p>好的規則應該前後兩段都賺。只有一段賺、另一段賠，比較像剛好碰上那段行情，還不能算穩定的優勢。要調參數時只能看樣本內，樣本外只用來驗證。</p>
        <p class="muted">切在 ${esc(split)}，是因為這樣前後兩段的交易日差不多一樣多。目前的參數是補定義、沒有用樣本內調過，所以兩段現在都等於沒看過的資料。</p></section>
      <section class="pcard"><h3>交易成本與進場</h3>
        <ul><li>手續費 0.1425% × 0.6（買、賣各收一次）＋ 賣出證交稅 0.3% ＋ 滑價進出各 0.15%，<b>來回約 0.77%</b>。上面的 −7%／+12% 都是扣掉這些成本後的淨報酬。</li>
          <li>訊號日收盤後才知道訊號，<b>隔天開盤進場</b>；開盤跳空超過 4% 或漲跌停就放棄這筆。</li>
          <li>每個組合最多同時持有 ${esc(cf.max_positions || 8)} 檔、等權重，名額滿了就不進（記為「滿檔不進」）。</li>
          <li>做空：融券／借券費用、保證金與利息都假設為 0，未計入，結果偏樂觀。</li>
          <li>交易少於 ${esc(cf.min_trades_display || 30)} 筆的組合顯示「樣本不足」，不顯示勝率。</li></ul></section>
      <p class="note">歷史回測結果不代表未來績效，不構成投資建議。</p>`);
  }

  // ================================================================ router
  addEventListener("hashchange", () => { parts = []; if (fxCanvas) fxCanvas.getContext("2d").clearRect(0, 0, fxCanvas.width, fxCanvas.height); });
  function route(h) {
    const p = h.split("?")[0];
    const run = (f) => { Promise.resolve(f()).catch((e) => { $app.innerHTML = `<p class="loading">畫面載入失敗：${esc(e.message || e)}</p>`; }); return true; };
    if (p === "/lab") return run(() => renderLab(h));
    if (p === "/watch") return run(renderWatch);
    if (p === "/alerts") return run(() => renderAlerts(h));
    if (p === "/backup") return run(() => renderBackup(h));
    if (p === "/health") return run(renderHealth);
    if (p === "/prefs") return run(renderPrefs);
    if (p === "/appendix") return run(renderAppendix);
    if (p === "/markets") return run(renderMarkets);
    if (p.startsWith("/markets/")) return run(() => renderIndex(decodeURIComponent(p.split("/")[2] || "")));
    if (p === "/editor") return run(renderEditorList);
    if (p.startsWith("/editor/")) return run(() => renderEditor(h));
    return false;
  }
  window.RadarPages = { route, pref, gateFx, hitFx, gradientCandles, miniCard, watchButton, autoBackup, burst, ping, _tradeMetrics: tradeMetrics };
})();
