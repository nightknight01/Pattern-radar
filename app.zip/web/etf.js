/* 型態雷達 — 📈 ETF 專頁（目前只有 00631L 元大台灣50正2）＋ 00631L 持倉紀錄。
 * 資料：etf_00631L.json（每日批次 run_etf.py：K 線、關鍵統計、CIS 狀態、十二招訊號）。
 * 持倉：存在 IndexedDB settings 表 key「etf_00631L_lots」（陣列；出場的筆數帶 exit_price / exit_date），所以加密備份／還原會一併帶走。 */
(function () {
  "use strict";
  const A = window.RadarApp, S = window.RadarStore, $app = document.getElementById("app");
  const { esc, fmt, go } = A;
  const FEE = 0.001425, TAX = 0.001;        // 手續費每邊 0.1425%；ETF 證交稅 0.1%（賣出時）
  const LOTS_KEY = (sym) => `etf_${sym}_lots`;
  const CIS_ZH = { ENTRY: "進場訊號", HOLD: "續抱", EXIT_WARNING: "出場警示", EXIT: "出場訊號", WATCH: "觀望", NO_DATA: "資料不足", FORMING: "成形中" };
  const sg = (x, d = 2) => (x == null || isNaN(x) ? "—" : `${x >= 0 ? "+" : ""}${Number(x).toFixed(d)}`);
  const cls = (x) => (x == null || isNaN(x) ? "" : x >= 0 ? "up" : "down");
  const nt = (x) => (x == null || isNaN(x) ? "—" : Math.round(x).toLocaleString("zh-TW"));
  const today = () => new Date(Date.now() + 8 * 3600e3).toISOString().slice(0, 10);

  // ---------------------------------------------------------------- 損益計算（純函式，瀏覽器測試會直接呼叫）
  function lotCalc(l, px) {
    const cost = l.price * l.shares, buyFee = cost * FEE;
    const sellPx = l.exit_price != null ? l.exit_price : px, mv = sellPx * l.shares, sellFee = mv * FEE, tax = mv * TAX;
    const gross = mv - cost, net = mv - sellFee - tax - cost - buyFee;
    return { cost, buyFee, mv, sellFee, tax, gross, grossPct: cost ? gross / cost * 100 : null, net, netPct: cost ? net / (cost + buyFee) * 100 : null };
  }
  function totals(lots, px) {
    const xs = lots.map((l) => lotCalc(l, px)), sh = lots.reduce((a, l) => a + l.shares, 0), sum = (k) => xs.reduce((a, x) => a + x[k], 0);
    const cost = sum("cost"), buyFee = sum("buyFee"), net = sum("net"), gross = sum("gross");
    return { shares: sh, avg: sh ? cost / sh : null, cost, mv: sum("mv"), gross, grossPct: cost ? gross / cost * 100 : null, net, netPct: cost ? net / (cost + buyFee) * 100 : null, fees: buyFee + sum("sellFee") + sum("tax") };
  }
  async function loadLots(sym) { return ((await S.setting(LOTS_KEY(sym))) || []).filter((l) => l && l.id); }
  async function saveLots(sym, lots) { await S.setting(LOTS_KEY(sym), lots); }
  const uid = () => (window.RadarBackup && RadarBackup.uuid7 ? RadarBackup.uuid7() : String(Date.now()) + Math.random().toString(16).slice(2));

  // ---------------------------------------------------------------- 持倉紀錄卡
  async function renderLots(el, sym, px, asof) {
    let lots = []; try { lots = await loadLots(sym); } catch (e) { el.innerHTML = `<h3>持倉紀錄</h3><p class="pend-t">本機資料庫無法使用。</p>`; return; }
    const open = lots.filter((l) => l.exit_price == null).sort((a, b) => (a.date < b.date ? -1 : 1));
    const closed = lots.filter((l) => l.exit_price != null).sort((a, b) => ((a.exit_date || "") < (b.exit_date || "") ? -1 : 1));
    const T = totals(open, px);
    let run = 0;
    const delBtn = (l) => `<button type="button" class="btn sm del" data-id="${esc(l.id)}">刪除</button>`;
    const oRow = (l) => { const c = lotCalc(l, px);
      return `<tr data-id="${esc(l.id)}"><td class="num">${esc(l.date)}</td><td class="r num">${fmt(l.price)}</td><td class="r num">${l.shares.toLocaleString()}</td><td class="r num">${nt(c.cost)}</td><td class="r num">${nt(c.mv)}</td>
        <td class="r num ${cls(c.net)}"><b>${sg(c.net, 0)}</b><br><span>${sg(c.netPct)}%</span></td><td class="r num muted ${cls(c.gross)}">${sg(c.gross, 0)}<br>${sg(c.grossPct)}%</td>
        <td class="acts"><button type="button" class="btn sm exit" data-id="${esc(l.id)}">出場</button>${delBtn(l)}</td></tr>`; };
    const cRow = (l) => { const c = lotCalc(l, px); run += c.net;
      return `<tr data-id="${esc(l.id)}"><td class="num">${esc(l.date)} → ${esc(l.exit_date || "")}</td><td class="r num">${fmt(l.price)} → ${fmt(l.exit_price)}</td><td class="r num">${l.shares.toLocaleString()}</td>
        <td class="r num ${cls(c.net)}"><b>${sg(c.net, 0)}</b><br><span>${sg(c.netPct)}%</span></td><td class="r num ${cls(run)}">${sg(run, 0)}</td><td class="acts">${delBtn(l)}</td></tr>`; };
    el.innerHTML = `<h3>📒 ${esc(sym)} 持倉紀錄 <button type="button" class="btn sm" id="lotadd">＋ 記入買進</button></h3>
      <form class="lotform" id="lotform" hidden>
        <label>買進價格<input id="lp" class="num" inputmode="decimal" value="${px != null ? px : ""}"></label>
        <label>數量<input id="lq" class="num" inputmode="numeric" value="1"></label>
        <span class="segs sm" role="group" aria-label="單位"><button type="button" class="seg" data-u="lot" aria-pressed="true">張</button><button type="button" class="seg" data-u="sh" aria-pressed="false">股</button></span>
        <label>日期<input id="ld" type="date" value="${today()}" max="${today()}"></label>
        <span class="muted" id="lhelp"></span>
        <span class="lf-btns"><button type="submit" class="btn sm add">儲存</button><button type="button" class="btn sm" id="lotcancel">取消</button></span>
      </form>
      <p class="wmsg" id="lotmsg" role="status" aria-live="polite"></p>
      <h4>未平倉（市值以 ${esc(asof || "")} 收盤 <b class="num">${fmt(px)}</b> 計）</h4>
      ${open.length ? `<div class="scroll"><table class="cmp lots" id="opentbl"><thead><tr><th>買進日</th><th class="r">買價</th><th class="r">股數</th><th class="r">成本</th><th class="r">市值</th><th class="r">未實現（淨）</th><th class="r">未實現（未扣費）</th><th></th></tr></thead>
        <tbody>${open.map(oRow).join("")}</tbody>
        <tfoot><tr><td>合計 ${open.length} 筆</td><td class="r num" title="加權平均成本">均價 ${fmt(T.avg)}</td><td class="r num">${T.shares.toLocaleString()}</td><td class="r num">${nt(T.cost)}</td><td class="r num">${nt(T.mv)}</td>
          <td class="r num ${cls(T.net)}"><b>${sg(T.net, 0)}</b><br>${sg(T.netPct)}%</td><td class="r num muted ${cls(T.gross)}">${sg(T.gross, 0)}<br>${sg(T.grossPct)}%</td><td></td></tr></tfoot></table></div>`
        : `<p class="pend-t" id="noopen">目前沒有未平倉部位。按「＋ 記入買進」新增。</p>`}
      <h4>已出場</h4>
      ${closed.length ? `<div class="scroll"><table class="cmp lots" id="closedtbl"><thead><tr><th>買進 → 出場</th><th class="r">買價 → 賣價</th><th class="r">股數</th><th class="r">已實現（淨）</th><th class="r">累計</th><th></th></tr></thead>
        <tbody>${closed.map(cRow).join("")}</tbody></table></div><p class="num">已實現合計（淨）：<b class="${cls(run)}" id="realized">${sg(run, 0)}</b> 元</p>` : `<p class="muted">尚無出場紀錄。</p>`}
      <p class="note">「淨」= 已扣買賣手續費各 0.1425%＋賣出證交稅 0.1%（ETF）；未計最低手續費 20 元、券商折扣，也未計融資利息（以全額部位計算，不是自備款報酬率）。1 張 = 1,000 股。紀錄只存在這台裝置，備份檔會一併帶走。</p>`;
    const $msg = el.querySelector("#lotmsg"), msg = (t, c = "") => { $msg.className = `wmsg ${c}`; $msg.textContent = t; };
    const form = el.querySelector("#lotform"); let unit = "lot";
    const help = () => { const q = +el.querySelector("#lq").value, p = +el.querySelector("#lp").value, sh = unit === "lot" ? q * 1000 : q;
      el.querySelector("#lhelp").textContent = q > 0 ? `= ${sh.toLocaleString()} 股${p > 0 ? `，成本約 ${nt(sh * p)} 元` : ""}` : ""; };
    el.querySelector("#lotadd").addEventListener("click", () => { if (!A.guard()) return; form.hidden = !form.hidden; help(); if (!form.hidden) el.querySelector("#lp").focus(); });
    el.querySelector("#lotcancel").addEventListener("click", () => { form.hidden = true; });
    form.querySelectorAll(".seg").forEach((b) => b.addEventListener("click", () => { unit = b.dataset.u; form.querySelectorAll(".seg").forEach((x) => x.setAttribute("aria-pressed", x === b)); help(); }));
    form.querySelectorAll("input").forEach((x) => x.addEventListener("input", help));
    form.addEventListener("submit", async (e) => {
      e.preventDefault(); if (!A.guard()) return;
      const p = +el.querySelector("#lp").value, q = +el.querySelector("#lq").value, d = el.querySelector("#ld").value, sh = Math.round(unit === "lot" ? q * 1000 : q);
      if (!(p > 0)) return msg("請輸入正確的買進價格。", "bad");
      if (!(sh > 0)) return msg("請輸入正確的數量。", "bad");
      if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) return msg("請選擇日期。", "bad");
      const all = await loadLots(sym); all.push({ id: uid(), date: d, price: p, shares: sh, created_at: new Date().toISOString() });
      await saveLots(sym, all); sessionStorage.setItem("radar.lotmsg", `已記入：${d} 買進 ${sh.toLocaleString()} 股 @ ${p}`); renderLots(el, sym, px, asof);
    });
    const flash = sessionStorage.getItem("radar.lotmsg"); if (flash) { msg(flash, "ok"); sessionStorage.removeItem("radar.lotmsg"); }
    // 出場：在該列下方展開小表單（賣價預設最新收盤、日期預設今天）
    el.querySelectorAll(".exit").forEach((b) => b.addEventListener("click", () => {
      if (!A.guard()) return;
      const tr = b.closest("tr"); if (tr.nextElementSibling && tr.nextElementSibling.classList.contains("exitrow")) { tr.nextElementSibling.remove(); return; }
      const row = document.createElement("tr"); row.className = "exitrow";
      row.innerHTML = `<td colspan="8"><form class="lotform exitform"><label>賣出價格<input class="num xp" inputmode="decimal" value="${px != null ? px : ""}"></label>
        <label>日期<input class="xd" type="date" value="${today()}" max="${today()}"></label><button type="submit" class="btn sm add">確認出場</button><button type="button" class="btn sm xc">取消</button></form></td>`;
      tr.after(row);
      row.querySelector(".xc").addEventListener("click", () => row.remove());
      row.querySelector("form").addEventListener("submit", async (e) => {
        e.preventDefault(); const xp = +row.querySelector(".xp").value, xd = row.querySelector(".xd").value;
        if (!(xp > 0)) return msg("請輸入正確的賣出價格。", "bad");
        const all = await loadLots(sym), l = all.find((x) => x.id === b.dataset.id); if (!l) return;
        if (xd && xd < l.date) return msg("出場日期不能早於買進日期。", "bad");
        Object.assign(l, { exit_price: xp, exit_date: xd || today() }); await saveLots(sym, all);
        sessionStorage.setItem("radar.lotmsg", `已出場：${l.shares.toLocaleString()} 股 @ ${xp}，已實現（淨）${sg(lotCalc(l, xp).net, 0)} 元`); renderLots(el, sym, px, asof);
      });
    }));
    // 刪除：兩段式確認（第一次按變成「確定刪除？」）
    el.querySelectorAll(".del").forEach((b) => b.addEventListener("click", async () => {
      if (!A.guard()) return;
      if (b.dataset.armed !== "1") { b.dataset.armed = "1"; b.textContent = "確定刪除？"; b.classList.add("danger");
        setTimeout(() => { if (document.body.contains(b)) { b.dataset.armed = ""; b.textContent = "刪除"; b.classList.remove("danger"); } }, 5000); return; }
      const all = (await loadLots(sym)).filter((x) => x.id !== b.dataset.id); await saveLots(sym, all);
      sessionStorage.setItem("radar.lotmsg", "已刪除這筆紀錄。"); renderLots(el, sym, px, asof);
    }));
  }

  // ---------------------------------------------------------------- 00631L × 台積電 2330 疊圖（顯示切換＋均線模式；偏好存 localStorage＋IndexedDB settings）
  const CP_KEY = "radar.etfChart", CP_DEF = { mode: "main", cis: true, lw: false };   // mode: main=只看 00631L／ov=只看 2330／both=兩者
  function chartPrefs() { try { return Object.assign({}, CP_DEF, JSON.parse(localStorage.getItem(CP_KEY) || "{}")); } catch (e) { return Object.assign({}, CP_DEF); } }
  function saveChartPrefs(p) { localStorage.setItem(CP_KEY, JSON.stringify(p)); if (S) S.setting("etf_chart_prefs", p).catch(() => {}); }
  const OV_UP = "#3B82F6", OV_DOWN = "#F97316";   // 台積電：藍漲、橘跌（與 00631L 紅漲綠跌區分）
  let DUAL = null;
  function maOf(c, k) { return c.map((_, i) => (i < k - 1 ? null : c.slice(i - k + 1, i + 1).reduce((a, b) => a + b, 0) / k)); }
  async function drawDual(d, P) {
    const L = await A.loadLW(), el = document.getElementById("chart"); if (!el) return;
    A.disposeChart(); if (DUAL) { try { DUAL.remove(); } catch (e) {} DUAL = null; } el.innerHTML = "";
    const M = d.bars, O = d.overlay, both = P.mode === "both";
    const chart = L.createChart(el, { autoSize: true, layout: { background: { type: L.ColorType.Solid, color: "#070A14" }, textColor: "#8A94B2", fontFamily: "ui-monospace,Menlo,monospace" },
      grid: { vertLines: { color: "rgba(35,44,69,.5)" }, horzLines: { color: "rgba(35,44,69,.5)" } },
      rightPriceScale: { borderColor: "#232c45", visible: true }, leftPriceScale: { borderColor: "#232c45", visible: both },
      timeScale: { borderColor: "#232c45", rightOffset: 4 }, crosshair: { mode: 0 }, localization: { locale: "zh-TW" },
      handleScale: { pinch: true, mouseWheel: true, axisPressedMouseMove: true }, handleScroll: { horzTouchDrag: true, vertTouchDrag: false, mouseWheel: true, pressedMouseMove: true } });
    DUAL = chart;
    const time = M.t.map(A.isoD), ot = O.t.map(A.isoD), oi = Object.fromEntries(ot.map((t, i) => [t, i]));
    const line = (scale, k, data, dashed) => chart.addSeries(L.LineSeries, { priceScaleId: scale, color: A.MA_COL[k] || "#aaa", lineWidth: k >= 100 ? 2 : 1, lineStyle: dashed ? 2 : 0, priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false })
      .setData(data.filter((x) => x.value != null));
    const ks = [].concat(P.cis ? [5, 25] : [], P.lw ? [100] : []);
    if (both) {   // 00631L：右軸、原本紅漲綠跌
      chart.addSeries(L.CandlestickSeries, { priceScaleId: "right", upColor: "#FF3B5C", downColor: "#1ED97A", borderUpColor: "#FF3B5C", borderDownColor: "#1ED97A", wickUpColor: "#FF3B5C", wickDownColor: "#1ED97A", priceLineVisible: false })
        .setData(time.map((t, i) => ({ time: t, open: M.o[i], high: M.h[i], low: M.l[i], close: M.c[i] })));
      for (const k of ks) { const m = maOf(M.c, k); line("right", k, time.map((t, i) => ({ time: t, value: m[i] }))); }
    }
    const os = both ? "left" : "right";   // 台積電：兩者時用左軸；只看 2330 時用右軸
    chart.addSeries(L.CandlestickSeries, { priceScaleId: os, upColor: both ? "rgba(59,130,246,.55)" : OV_UP, downColor: both ? "rgba(249,115,22,.55)" : OV_DOWN, borderUpColor: OV_UP, borderDownColor: OV_DOWN, wickUpColor: OV_UP, wickDownColor: OV_DOWN, priceLineVisible: false })
      .setData(ot.map((t, i) => ({ time: t, open: O.o[i], high: O.h[i], low: O.l[i], close: O.c[i] })));
    for (const k of ks) { const arr = O["ma" + k] || maOf(O.c, k); line(os, k, ot.map((t, i) => ({ time: t, value: arr[i] })), both); }
    chart.timeScale().setVisibleLogicalRange({ from: Math.max(0, time.length - 120), to: time.length + 4 });
    const $lg = document.getElementById("legend");
    const cell = (B, i, name, col) => { if (i == null || i < 0) return ""; const ch = i ? (B.c[i] / B.c[i - 1] - 1) * 100 : 0;
      return `<span style="color:${col}">${name}</span> 開 ${fmt(B.o[i])} 高 ${fmt(B.h[i])} 低 ${fmt(B.l[i])} 收 <b class="${ch >= 0 ? "up" : "down"}">${fmt(B.c[i])} (${sg(ch)}%)</b>`; };
    const legend = (t) => { t = t || time[time.length - 1]; const i = time.indexOf(t);
      $lg.innerHTML = `${t}　${both ? cell(M, i, d.symbol, "#FF3B5C") + "｜" : ""}${cell(O, oi[t], `${O.symbol} ${O.name}${both ? "（左軸）" : ""}`, OV_UP)}　${ks.map((k) => `<span style="color:${A.MA_COL[k]}">${A.MA_ZH[k]}</span>`).join(" ")}${both && ks.length ? ' <span class="muted">（虛線＝2330）</span>' : ""}`; };
    legend(); chart.subscribeCrosshairMove((p) => legend(p && p.time));
    el.addEventListener("touchmove", (e) => { if (e.touches.length > 1) e.preventDefault(); }, { passive: false });
  }
  function drawEtfChart(d, main, pat) {
    const P = chartPrefs(), el = document.getElementById("chart");
    const fail = (e) => { el.innerHTML = `<p class="loading">圖表載入失敗：${esc(e.message || e)}</p>`; };
    if (P.mode !== "main" && d.overlay && d.overlay.t && d.overlay.t.length) return drawDual(d, P).catch(fail);
    if (DUAL) { try { DUAL.remove(); } catch (e) {} DUAL = null; el.innerHTML = ""; }
    return A.drawChart(d.bars, main, pat, { ma: [].concat(P.cis ? [5, 25] : [], P.lw ? [100] : []) }).catch(fail);
  }
  function chartToolbar(d) {
    const P = chartPrefs(), hasOv = !!(d.overlay && d.overlay.t && d.overlay.t.length);
    const m = (k, t) => `<button type="button" class="seg" data-mode="${k}" aria-pressed="${P.mode === k || (!hasOv && k === "main")}" ${!hasOv && k !== "main" ? "disabled" : ""}>${t}</button>`;
    return `<div class="etf-tools" id="etftools">
      <span class="segs sm" role="group" aria-label="顯示哪一檔">${m("main", "00631L")}${m("ov", "2330 台積電")}${m("both", "兩者")}</span>
      <span class="segs sm" role="group" aria-label="均線模式">
        <button type="button" class="seg" data-ma="cis" aria-pressed="${P.cis}">CIS 5／25 日</button>
        <button type="button" class="seg" data-ma="lw" aria-pressed="${P.lw}">老王 20 週（MA100）</button></span>
      ${hasOv ? "" : `<span class="muted s">${esc(d.overlay_error || "台積電疊圖資料下次批次後才有")}</span>`}</div>`;
  }
  const LW_ZH = { ENTRY: "進場", HOLD: "持續中", EXIT_WARNING: "剛結束", EXIT: "出場", WATCH: "未成立", NO_DATA: "資料不足" };

  // ---------------------------------------------------------------- 專頁
  async function render(sym) {
    $app.innerHTML = `<p class="loading">載入 ${esc(sym)}…</p>`;
    let d; try { d = await A.getJSON(`etf_${sym}.json`); } catch (e) {
      $app.innerHTML = `<div class="bar"><button type="button" class="btn" id="back">← 方向</button><h2>${esc(sym)}</h2></div><p class="pend-t">${esc(sym)} 的資料還沒產生（每日批次跑過一次後就會有）${A.OFFLINE ? "，且目前離線" : ""}。</p>`;
      $app.querySelector("#back").addEventListener("click", () => go("#/")); return; }
    const s = d.stats || {}, c = d.cis || {}, sigs = d.signals || [];
    const pat = sigs.filter((x) => !A.isState(x.patternId)), lw = d.laowang || {};
    const main = pat.find((x) => x.state === "CONFIRMED" || x.state === "FORMING") || pat[0] || { direction: "long", state: "WATCH", levels: {}, geometry: {} };
    const kv = (k, v, c2 = "") => `<span class="kv"><i>${k}</i><b class="num ${c2}">${v}</b></span>`;
    const cisRow = (title, v) => `<tr><td>${title}</td><td class="st-${esc(v.state)}">${esc(CIS_ZH[v.state] || v.state)}</td><td class="muted">${esc((v.reasons || []).join("；"))}</td></tr>`;
    const sigCard = (x) => { const lv = x.levels || {};
      return `<div class="sigc ${x.direction}"><b>${esc(A.patternName(x.patternId))}・${A.DIR[x.direction].label}</b> <span class="st-${x.state}">${esc(A.stLabel(x))}</span>
        <div class="kvs">${lv.neckline != null ? kv("頸線", fmt(lv.neckline)) : ""}${lv.breakout != null ? kv("突破", fmt(lv.breakout)) : ""}${lv.target != null ? kv("滿足點", fmt(lv.target)) : ""}${lv.stopRef != null ? kv("停損參考", fmt(lv.stopRef)) : ""}${kv("強度", fmt(x.strength, 0))}</div>
        <ul class="reasons">${(x.reasons || []).map((r) => `<li>${esc(r)}</li>`).join("")}</ul></div>`; };
    const tvx = d.market === "TPEx" ? "TPEX" : "TWSE";
    $app.innerHTML = `
      <div class="bar stock-bar"><button type="button" class="btn" id="back">← 方向</button>
        <h2><span class="num">${esc(d.symbol)}</span> ${esc(d.name)} <span class="muted s">ETF・單日 2 倍槓桿・${esc(d.market)}</span></h2>
        <span id="watchbtn"></span>
        <button type="button" class="btn sm" id="sidebtn" aria-controls="side" aria-expanded="true">資訊欄</button>
        <a class="btn sm" href="https://www.tradingview.com/chart/?symbol=${tvx}:${encodeURIComponent(d.symbol)}" target="_blank" rel="noopener">TradingView ↗</a></div>
      <div class="asof">資料日 ${esc(d.data_as_of)}｜更新於 ${esc(A.tpe(d.generated_at))}（台北時間）｜來源 ${esc(d.source || "—")}</div>
      ${d.stale || d.error ? `<p class="note short"><b>資料可能過期：</b>${esc(d.error || `最新 K 線停在 ${d.data_as_of}，晚於交易日 ${d.trade_date}`)}</p>` : ""}
      <div class="sumstrip long"><span class="kv1"><i>收盤</i><b class="num">${fmt(s.close)}</b></span><span class="kv1"><i>漲跌</i><b class="num ${cls(s.change_pct)}">${sg(s.change_pct)}%</b></span>
        <span class="kv1"><i>MA5</i><b class="num" style="color:#FFD166">${fmt(s.ma5)}</b></span><span class="kv1"><i>MA25</i><b class="num" style="color:#B388FF">${fmt(s.ma25)}</b></span>
        <span class="kv1"><i>MA25 乖離</i><b class="num ${cls(s.dev_ma25_pct)}">${sg(s.dev_ma25_pct)}%</b></span>
        <span class="kv1"><i>CIS 持有者</i><b class="st-${esc((c.base_long || {}).state)}">${esc(CIS_ZH[(c.base_long || {}).state] || "—")}</b></span></div>
      <div class="stock" id="stockwrap">
        <div class="main-col"><section class="chart-card">${chartToolbar(d)}<div class="legend num" id="legend"></div><div id="chart" class="chart" aria-label="K 線圖"></div>
          <p class="note">K 線為還原權息（含 2026-03 分割）後序列，最新一根 = 原始收盤價；00631L 紅漲綠跌、台積電 2330 藍漲橘跌（「兩者」時 2330 用左邊價格軸、均線為虛線）；黃線 MA5、紫線 MA25、白線 MA100（≈老王 20 週線）。${pat.length ? "虛線為目前型態的頸線／突破／滿足點／停損參考。" : "目前沒有十二招型態成形或確認。"}</p></section>
          <section class="pcard lotcard" id="lots"><h3>📒 持倉紀錄</h3><p class="muted">載入中…</p></section></div>
        <div class="side-scrim" id="sidescrim"></div>
        <aside class="side" id="side" aria-label="詳細資訊">
          <div class="side-head"><b>詳細資訊</b><button type="button" class="btn sm" id="sideclose">收起 ✕</button></div>
          <section class="pcard"><h3>關鍵數據</h3><div class="kvs">
            ${kv("收盤", fmt(s.close))}${kv("當日漲跌", sg(s.change_pct) + "%", cls(s.change_pct))}${kv("MA5", fmt(s.ma5))}${kv("MA25", fmt(s.ma25))}
            ${kv("距 MA25 乖離", sg(s.dev_ma25_pct) + "%", cls(s.dev_ma25_pct))}${kv("20 日報酬", sg(s.ret20_pct) + "%", cls(s.ret20_pct))}${kv("60 日報酬", sg(s.ret60_pct) + "%", cls(s.ret60_pct))}
            ${kv(`52 週高（${esc(s.high52_date || "")}）`, fmt(s.high52))}${kv(`52 週低（${esc(s.low52_date || "")}）`, fmt(s.low52))}${kv("距高點回落", sg(s.dd_from_high_pct) + "%", cls(s.dd_from_high_pct))}
            ${kv("20 日波動（年化）", fmt(s.vol20_ann_pct, 1) + "%")}${kv("20 日均量（張）", s.avgvol20_lots == null ? "—" : s.avgvol20_lots.toLocaleString())}${kv("今日量（張）", s.vol_lots == null ? "—" : s.vol_lots.toLocaleString())}</div>
            <p class="note">乖離 = 收盤 ÷ MA25 − 1（BNF 式）。波動 = 近 20 日日報酬標準差 × √252。52 週以 250 個交易日計。</p></section>
          <section class="pcard"><h3>CIS 狀態</h3>
            <table class="cmp wrap"><tbody>${cisRow("基準線・空手", c.base_flat || {})}${cisRow("基準線・持有多單", c.base_long || {})}${cisRow("實驗組・空手", c.exp_flat || {})}${cisRow("實驗組・持有多單", c.exp_long || {})}</tbody></table>
            <p class="note">「空手」看有沒有進場訊號；「持有多單」看續抱或出場（均線出場：黑 K 收盤跌破 MA5 與 MA25）。MA5 ${fmt(c.ma5)}／MA25 ${fmt(c.ma25)}。<a href="#/appendix">規則說明</a></p></section>
          <section class="pcard"><h3>老王狀態 <span class="tag lw">老王</span> <span class="tag assume">補定義・待確認</span></h3>
            <table class="cmp wrap"><tbody>${[["四海遊龍（四線上彎）", lw.dragon], ["四面楚歌（四線下彎）", lw.chu], ["空方缺口回補", lw.gapfill]].map(([t, v]) => v ? `<tr><td>${t}</td><td class="st-${esc(v.state)}">${esc(LW_ZH[v.state] || v.state)}</td><td class="muted">${esc((v.reasons || []).join("；"))}</td></tr>` : "").join("")}</tbody></table>
            <p class="note">四線：${Object.entries(lw.ma || {}).map(([k, v]) => `${esc(k.toUpperCase())} ${fmt(v)}`).join("／") || "—"}（MA20＝月線、MA100≈20 週）。<a href="#/long/lw_dragon">規則說明</a></p></section>
          <section class="pcard"><h3>十二招型態訊號</h3>${pat.length ? pat.map(sigCard).join("") : `<p class="muted">目前沒有成形中或已確認的型態。</p>`}</section>
          <section class="pcard"><h3>三大法人買賣超（近 20 日，張）</h3>${A.instBar((d.bars || {}).inst || [])}</section>
          <section class="pcard"><h3>槓桿 ETF 注意</h3><p class="note">${esc(d.leverage_note || "")}</p><p class="note">${(d.notes || []).map(esc).join(" ")}</p></section>
        </aside>
      </div>`;
    A.sidePanel();
    $app.querySelector("#back").addEventListener("click", () => go("#/"));
    if (window.RadarPages) RadarPages.watchButton(document.getElementById("watchbtn"), d.symbol, d.name);
    renderLots(document.getElementById("lots"), d.symbol, s.close, d.data_as_of);
    if (d.bars && d.bars.t && d.bars.t.length) {
      drawEtfChart(d, main, pat);
      const tb = document.getElementById("etftools");
      tb.querySelectorAll("[data-mode]").forEach((b) => b.addEventListener("click", () => { const P = chartPrefs(); P.mode = b.dataset.mode; saveChartPrefs(P);
        tb.querySelectorAll("[data-mode]").forEach((x) => x.setAttribute("aria-pressed", x === b)); drawEtfChart(d, main, pat); }));
      tb.querySelectorAll("[data-ma]").forEach((b) => b.addEventListener("click", () => { const P = chartPrefs(); P[b.dataset.ma] = !P[b.dataset.ma]; saveChartPrefs(P);
        b.setAttribute("aria-pressed", P[b.dataset.ma]); drawEtfChart(d, main, pat); }));
    }
    else document.getElementById("chart").innerHTML = `<p class="loading">K 線資料未載入</p>`;
  }
  window.RadarEtf = { render, lotCalc, totals, FEE, TAX, chartPrefs };
})();
