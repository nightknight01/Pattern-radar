#!/usr/bin/env python3
"""盤後批次／回測實驗室後端 (§12)：全市場、全部 13 型態，X1 主軸 + X2（蔡森）/X3（CIS）對照，樣本內外並列。

usage: python3 run_backtest.py [--start 2024-01-02] [--end T] [--split 2025-07-01] [--max-positions 8]
       [--exit-exec next_open|same_close] [--workers 6] [--out ../web]
輸出：web/backtest_latest.json（並列報表、淨值曲線、分組統計）、web/backtest_trades.json（組合逐筆，供 CSV 匯出）、
      db/backtests/trades_<run>.csv、SQLite backtest_runs / backtest_trades。
"""
import argparse, datetime as dt, json, os, sys, uuid, csv, time, statistics
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
import numpy as np, pandas as pd
from zoneinfo import ZoneInfo
TPE = ZoneInfo("Asia/Taipei")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from radar import db, config, engine, adjuster, backtest as bt
from radar.context import Ctx

NOTES = [
    "統計值為歷史回測結果，不代表未來績效，不構成投資建議。",
    "成本：手續費 0.1425%×0.6（買賣各一次）、證交稅 0.3%（賣出）、滑價進出各 0.15%；來回約 0.771%。",
    "做空：融券／借券費用 short_extra_cost = 0，為假設值，未計入；融券保證金與利息亦未計入。",
    "訊號用還原權息價計算，成交價亦用還原價（還原係數另存）；T 日收盤後才知道訊號，T+1 開盤進場；開盤跳空 >4% 或漲跌停放棄。",
    "Universe 每日依當日股價 ≥10、前 20 日均量 ≥500 張判斷；處置／全額交割與可否融券沒有歷史資料，回測未排除（偏樂觀）。",
    "三大法人歷史未抓：強度的法人分項一律給一半分數。",
    "存活者偏差：已含期間內曾有日 K 的標的（含之後下市者），但更早下市者不在資料內。",
    "蔡森十二招為補定義（待 Jay 確認）；CIS 為早期座談會二手摘錄、SMA 為工作假設。",
]

G = {}


def _init(cfg, args, custom_defs=()):
    G["cfg"], G["a"] = cfg, args
    from radar import dsl as _dsl
    G["custom"] = [(d["code"], d["name"], d["directions"], d.get("native_exit", "X3"), d.get("role", "standard"),
                    _dsl.ctx_fn(_dsl.Program(d))) for d in custom_defs]


def _work(item):
    cfg, a = G["cfg"], G["a"]
    sym, meta, arr, exref = item
    dates, o, h, l, c, v, chg, ck = arr
    if len(c) < cfg["universe"]["min_bars"] + 2 or not (np.all(c > 0) and np.all(h >= l)): return sym, [], Counter()
    A = adjuster.adjust(dates, o, h, l, c, v, chg, ck, exref)
    cut = A["cut"]; rc, rv = c[cut:], v[cut:]
    if len(A["c"]) < cfg["universe"]["min_bars"] + 2: return sym, [], Counter()
    ctx = Ctx(A["dates"], A["o"], A["h"], A["l"], A["c"], A["v"], cfg, symbol=sym, market=meta["market"],
              sector=meta["sector_code"], inst_net=None, shortable=None, name=meta["name"])
    D = ctx.dates; O, H, L, C = ctx.o, ctx.h, ctx.l, ctx.c
    u = cfg["universe"]; out = []; stat = Counter(); busy = {}
    t0 = max(u["min_bars"] - 1, 21)
    for t in range(t0, ctx.n - 1):
        if D[t] < a.start or D[t] > a.end: continue
        if u["enabled"]:
            if rc[t] < u["min_price"]: continue
            if np.mean(rv[t - 20:t]) / 1000 < u["min_avg_vol20_lots"]: continue
            if meta["type"] == "etf" and not u["include_etf"]: continue
        for pid, name, dirs, nx, role, fn in list(engine.REGISTRY) + G["custom"]:
            if pid.startswith("cis") or not pid in engine.TSAI_IDS:
                r = fn(ctx, t)
                if r["state"] != "ENTRY": continue
                st, lv = r["strength"], (r.get("levels") or None)
            else:
                r = fn(ctx, t)
                if not r or r["state"] != "CONFIRMED": continue
                st, lv = engine.strength(ctx, t, r), r["levels"]
            d = r["direction"]; e = t + 1
            stat[f"{pid}|{d}|signals"] += 1
            if not bt.entry_ok(d, O[e], C[t]): stat[f"{pid}|{d}|abandoned"] += 1; continue
            gid = f"{sym}|{pid}|{d}|{D[t]}"
            for X in ("X1", nx):
                if busy.get((pid, d, X), -1) >= e: stat[f"{pid}|{d}|{X}|busy"] += 1; continue
                if X == "X1": x = bt.sim_x1(d, O, H, L, C, e)
                elif X == "X2" and lv: x = bt.sim_x2(d, O, H, L, C, e, lv, cfg["common"]["break_buf"], a.exit_exec)
                elif X == "X3": x = bt.sim_x3(d, ctx, fn, e, a.exit_exec)
                else: continue
                busy[(pid, d, X)] = x["exit_idx"]
                E = float(O[e]); path = bt.mark_path(d, E, C, e, x)
                out.append(dict(symbol=sym, name=meta["name"], market=meta["market"], sector=meta["sector_code"], pattern=pid,
                                group={"cis_base": "base", "cis_exp": "exp"}.get(pid, "—"), direction=d, exit_set=X, gid=gid,
                                signal_date=D[t], entry_date=D[e], entry_price=round(E, 4), exit_date=D[x["exit_idx"]],
                                exit_price=round(x["exit_price"], 4), net=round(path[-1], 5), hold_days=x["exit_idx"] - e + 1,
                                reason=x["reason"], at_open=x["at_open"], strength=st, path_dates=D[e:x["exit_idx"] + 1], path=path))
    return sym, out, stat


def r4(x): return None if x is None else round(float(x), 4)


def clean(m):
    return {k: (r4(v) if isinstance(v, float) else v) for k, v in m.items()}


def main():
    ap = argparse.ArgumentParser(); BD = config.backtest_defaults()   # params.json "backtest" 區段可覆寫預設
    ap.add_argument("--start", default=BD["start"]); ap.add_argument("--end"); ap.add_argument("--split", default=BD["split"])
    ap.add_argument("--max-positions", type=int, default=int(BD["max_positions"])); ap.add_argument("--exit-exec", default="next_open", choices=["next_open", "same_close"])
    ap.add_argument("--min-trades", type=int, default=int(BD["min_trades_display"])); ap.add_argument("--workers", type=int, default=6)
    ap.add_argument("--out", default=os.path.join(HERE, "..", "web")); ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--no-db", action="store_true", help="試跑：不寫 SQLite")
    a = ap.parse_args()
    cfg = config.get(); t0 = time.time(); con = db.connect()
    custom, custom_errs = engine.load_custom(con)
    a.end = a.end or con.execute("SELECT max(date) FROM trading_days WHERE twse=1 AND tpex=1").fetchone()[0]
    warm = [r[0] for r in con.execute("SELECT date FROM trading_days WHERE twse=1 AND date<? ORDER BY date DESC LIMIT 80", (a.start,))]
    d0 = warm[-1] if warm else a.start
    days = [r[0] for r in con.execute("SELECT date FROM trading_days WHERE twse=1 AND date>=? AND date<=? ORDER BY date", (a.start, a.end))]
    gidx = {d: i for i, d in enumerate(days)}
    bars = pd.read_sql("SELECT symbol,date,open,high,low,close,volume_shares v,chg,chg_known FROM daily_bars WHERE date>=? AND date<=? ORDER BY symbol,date",
                       con, params=(d0, a.end))
    exref = defaultdict(dict)
    for s, d, ref in con.execute("SELECT symbol,ex_date,ref_price FROM corporate_actions WHERE ref_price IS NOT NULL"): exref[s][d] = ref
    meta = {r[0]: dict(name=r[1], market=r[2], type=r[3], sector_code=r[4], sector_name=r[5])
            for r in con.execute("SELECT symbol,name,market,type,sector_code,sector_name FROM instruments")}
    items = []
    for sym, g in bars.groupby("symbol", sort=True):
        m = meta.get(sym)
        if not m: continue
        items.append((sym, m, (g.date.tolist(), g.open.values.astype(float), g.high.values.astype(float), g.low.values.astype(float),
                               g.close.values.astype(float), g.v.values.astype(float), g.chg.values.astype(float),
                               g.chg_known.fillna(0).values.astype(int)), exref.get(sym, {})))
    if a.limit: items = items[:a.limit]
    cands, stat = [], Counter()
    with ProcessPoolExecutor(a.workers, initializer=_init, initargs=(cfg, a, [c[6] for c in custom])) as ex:
        for sym, out, st in ex.map(_work, items, chunksize=10):
            cands += out; stat.update(st)
    for c in cands:
        c["entry_i"], c["exit_i"] = gidx[c["entry_date"]], gidx[c["exit_date"]]
        c["sample"] = "IS" if c["signal_date"] < a.split else "OOS"
    # ---- combos
    combos = defaultdict(list)
    for c in cands: combos[(c["pattern"], c["group"], c["exit_set"], c["direction"])].append(c)
    n = len(days); split_i = next((i for i, d in enumerate(days) if d >= a.split), n)
    pnames = {r[0]: r[1] for r in engine.REGISTRY}; pnames.update({c[0]: c[1] for c in custom})
    sp = os.path.join(a.out, "scan_latest.json")   # 個股頁只需要今日命中個股的逐檔統計 → 控制檔案大小
    keep = {h["symbol"] for h in json.load(open(sp))["hits"]} if os.path.exists(sp) else None
    res, all_taken = [], []
    for key in sorted(combos):
        pid, grp, X, d = key
        taken, full, dup = bt.run_portfolio(combos[key], days, a.max_positions)
        for t in taken:
            t["path_g"] = [gidx[x] for x in t["path_dates"]]
        tt = [dict(entry_i=t["entry_i"], path=t["path"]) for t in taken]
        nav_all = bt.nav_series(tt, n, a.max_positions)
        block = {}
        for smp, lo, hi in (("ALL", 0, n), ("IS", 0, split_i), ("OOS", split_i, n)):
            sel = [t for t in taken if smp == "ALL" or t["sample"] == smp]
            nav = bt.nav_series([dict(entry_i=t["entry_i"], path=t["path"]) for t in sel], n, a.max_positions)[lo:hi]
            sf = sum(1 for c in combos[key] if (smp == "ALL" or c["sample"] == smp)) - len(sel)
            block[smp] = clean(bt.metrics(sel, nav, skipped_full=max(0, sf), min_trades=a.min_trades))
            block[smp]["exit_reasons"] = dict(Counter(t["reason"] for t in sel))
        # signal-level (unconstrained, one position per symbol at a time) — for 個股頁／類股 mini card
        grp_stats = {}
        for gk, f in (("sector", lambda t: t["sector"] or "NA"), ("year", lambda t: t["signal_date"][:4]), ("market", lambda t: t["market"])):
            dd = defaultdict(list)
            for t in taken: dd[f(t)].append(t["net"])
            grp_stats[gk] = {k: dict(trades=len(v), win_rate=r4(sum(1 for x in v if x > 0) / len(v)), avg_net=r4(sum(v) / len(v)),
                                     insufficient=len(v) < a.min_trades) for k, v in sorted(dd.items())}
        sig_sector, sig_symbol = defaultdict(list), defaultdict(list)
        for c in combos[key]: sig_sector[c["sector"] or "NA"].append(c["net"]); sig_symbol[c["symbol"]].append(c["net"])
        res.append(dict(pattern=pid, name=pnames[pid], group=grp, exit_set=X, direction=d,
                        role="X1 主軸" if X == "X1" else "對照組", metrics=block,
                        signals=stat[f"{pid}|{d}|signals"], abandoned=stat[f"{pid}|{d}|abandoned"], skipped_dup=dup,
                        nav=[nav_all[i] for i in range(0, n, 1)], groups=grp_stats,
                        signal_level=dict(trades=len(combos[key]),
                                          by_sector={k: [len(v), r4(sum(1 for x in v if x > 0) / len(v)), r4(sum(v) / len(v))] for k, v in sig_sector.items()},
                                          by_symbol={k: [len(v), r4(sum(1 for x in v if x > 0) / len(v)), r4(sum(v) / len(v))] for k, v in sig_symbol.items()
                                                     if keep is None or k in keep})))
        all_taken += taken
    # ---- persist
    run_id = str(uuid.uuid4()); now = dt.datetime.now(dt.timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    fin = dt.datetime.now(TPE).isoformat(timespec="seconds")
    conf = dict(start=a.start, end=a.end, split=a.split, max_positions=a.max_positions, exit_exec=a.exit_exec, min_trades_display=a.min_trades,
                short_extra_cost=0, costs=dict(b=bt.B, s=bt.S), x1=dict(stop=-0.07, target=0.12, hold_days=10), entry_gap=0.04, params=cfg)
    summary = {f"{r['pattern']}|{r['group']}|{r['exit_set']}|{r['direction']}": r["metrics"]["ALL"] for r in res}
    if not a.no_db: con.execute("INSERT INTO backtest_runs (id,config_json,pattern_versions_json,exit_sets_json,short_extra_cost,data_cutoff,status,metrics_json,updated_at,updated_by_device) VALUES (?,?,?,?,?,?,?,?,?,?)",
                (run_id, json.dumps(conf, ensure_ascii=False), json.dumps({p[0]: engine.PATTERN_VERSION for p in engine.REGISTRY}),
                 json.dumps(["X1", "X2", "X3"]), 0, a.end, "ok", json.dumps(summary, ensure_ascii=False), now, "box-batch"))
    if not a.no_db: con.executemany("INSERT INTO backtest_trades VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    [(str(uuid.uuid4()), run_id, t["symbol"], t["sector"], t["pattern"], t["direction"], t["exit_set"], t["gid"], t["signal_date"],
                      t["entry_date"], t["entry_price"], t["exit_date"], t["exit_price"], t["net"], t["hold_days"], t["reason"], t["sample"],
                      now, "box-batch", 0, 1) for t in all_taken])
    con.commit()
    os.makedirs(os.path.join(HERE, "db", "backtests"), exist_ok=True)
    cols = ["symbol", "name", "market", "sector", "pattern", "group", "direction", "exit_set", "gid", "signal_date", "entry_date", "entry_price",
            "exit_date", "exit_price", "net", "hold_days", "reason", "sample", "strength"]
    with open(os.path.join(HERE, "db", "backtests", f"trades_{a.end.replace('-', '')}.csv"), "w", newline="") as f:
        w = csv.writer(f); w.writerow(cols + ["exit_reason_zh"])
        for t in sorted(all_taken, key=lambda t: (t["pattern"], t["exit_set"], t["entry_date"], t["symbol"])):
            w.writerow([t[c] for c in cols] + [bt.REASON_ZH.get(t["reason"], t["reason"])])
    doc = dict(schema_version=1, run_id=run_id, finished_at=fin, timezone="Asia/Taipei", days=days, config=conf, notes=NOTES,
               reason_zh=bt.REASON_ZH, patterns=engine.list_patterns(custom=custom), custom_pattern_errors=custom_errs, combos=res,
               stats=dict(candidates=len(cands), portfolio_trades=len(all_taken), symbols=len(items), runtime_sec=round(time.time() - t0, 1)))
    json.dump(doc, open(os.path.join(a.out, "backtest_latest.json"), "w"), ensure_ascii=False, separators=(",", ":"))
    tcols = ["symbol", "name", "sector", "pattern", "group", "direction", "exit_set", "signal_date", "entry_date", "entry_price", "exit_date",
             "exit_price", "net", "hold_days", "reason", "sample"]
    json.dump(dict(run_id=run_id, cols=tcols, rows=[[t[c] for c in tcols] for t in sorted(all_taken, key=lambda t: t["entry_date"])]),
              open(os.path.join(a.out, "backtest_trades.json"), "w"), ensure_ascii=False, separators=(",", ":"))
    print(json.dumps(doc["stats"], ensure_ascii=False))
    for r in res:
        m = r["metrics"]["ALL"]
        print(f"{r['pattern']:18s} {r['direction']:5s} {r['exit_set']} trades={m['trades']:4d} win={m.get('win_rate', 0):.3f} exp={m.get('expectancy', 0):+.4f} mdd={m.get('max_drawdown', 0):+.3f}")


if __name__ == "__main__":
    main()
