#!/usr/bin/env python3
"""備份與還原 CLI（box 端；與 App 的加密備份檔格式相同）。

  python3 run_backup.py export [--out FILE]       # 匯出 SQLite 使用者資料表 → 加密 .json.gz.enc
  python3 run_backup.py import FILE               # 解密並合併（新蓋舊、tombstone）到 SQLite，供盤後批次使用
  python3 run_backup.py verify FILE               # 只解密並列出各表筆數與 checksum
復原碼從環境變數 RADAR_RECOVERY_CODE 讀取（不要寫在指令或檔案裡）。
雲端 BaaS（Supabase）未接：需要 Jay 建立專案與金鑰；目前以加密檔案匯出／匯入取代（§14.2 待辦）。
"""
import argparse, datetime as dt, json, os, sys, uuid
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from radar import db, backup


def code():
    c = os.environ.get("RADAR_RECOVERY_CODE")
    if not c: sys.exit("請先設定環境變數 RADAR_RECOVERY_CODE（復原碼）")
    return c


def main():
    ap = argparse.ArgumentParser(); sp = ap.add_subparsers(dest="cmd", required=True)
    e = sp.add_parser("export"); e.add_argument("--out")
    i = sp.add_parser("import"); i.add_argument("file")
    v = sp.add_parser("verify"); v.add_argument("file")
    a = ap.parse_args(); con = db.connect()
    if a.cmd == "export":
        doc = backup.make_doc(con)
        blob, vault, cs = backup.encrypt(doc, code())
        ts = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        out = a.out or os.path.join(HERE, "db", "backups", f"backup_{vault[:8]}_{ts}.json.gz.enc")
        os.makedirs(os.path.dirname(out), exist_ok=True); open(out, "wb").write(blob)
        con.execute("INSERT INTO backups VALUES (?,?,?,?,?,?)", (str(uuid.uuid4()), doc["exported_at"], doc["schema_version"], len(blob), out, cs)); con.commit()
        print(json.dumps(dict(file=out, vault_id=vault, checksum=cs, rows={t: len(r) for t, r in doc["tables"].items()}), ensure_ascii=False, indent=1))
    else:
        doc, vault, cs = backup.decrypt(open(a.file, "rb").read(), code())
        info = dict(vault_id=vault, checksum=cs, exported_at=doc.get("exported_at"), device_id=doc.get("device_id"),
                    rows={t: len(r) for t, r in doc["tables"].items()})
        if a.cmd == "import": info["merge"] = backup.import_tables(con, doc["tables"])
        print(json.dumps(info, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
