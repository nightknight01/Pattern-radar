#!/usr/bin/env python3
"""新台幣匯率（USD/TWD，中央銀行）：寫出 web/fx_twd.json（全球指數頁的「USD/TWD 新台幣」卡片＋折線圖、資料狀態頁）。
來源與備援見 radar/fx.py。任何失敗都沿用上一份並標 stale；本程式永遠 exit 0，不會讓主批次失敗。
usage: python3 run_fx.py [--out ../web]
"""
import argparse, datetime as dt, json, os, sys, urllib.request
from zoneinfo import ZoneInfo
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from radar import fx
TPE = ZoneInfo("Asia/Taipei")
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"


def http_get(url, timeout=30):
    with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"}), timeout=timeout) as r:
        return r.read().decode("utf-8", "replace")


def run(out, get=http_get, now=None):
    now = now or dt.datetime.now(TPE)
    path = os.path.join(out, "fx_twd.json"); gen = now.isoformat(timespec="seconds")
    try:
        s, src, errs = fx.fetch(get, today=now.date().isoformat())
        if s is None: raise RuntimeError("；".join(errs) or "全部來源失敗")
        doc = fx.build_doc(s, src, errs, gen)
    except Exception as e:  # noqa: BLE001
        print(f"::warning::新台幣匯率更新失敗：{str(e)[:300]}")
        try:
            doc = json.load(open(path, encoding="utf-8"))
            doc.update(stale=True, error=f"本次抓取失敗，沿用上次資料：{str(e)[:160]}")
        except Exception:  # noqa: BLE001
            return None
    os.makedirs(out, exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f: json.dump(doc, f, ensure_ascii=False, separators=(",", ":"))
    os.replace(tmp, path)
    print(f"USD/TWD：{doc.get('data_as_of')} {doc.get('close')}（{doc.get('source')}）{'［沿用舊資料］' if doc.get('stale') else ''}")
    return doc


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--out", default=os.path.join(HERE, "..", "web")); a = ap.parse_args()
    try: run(a.out)
    except Exception as e:  # noqa: BLE001
        print(f"::warning::run_fx 例外：{e}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
