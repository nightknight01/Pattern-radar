#!/usr/bin/env python3
"""盤後批次 step 5 + 8：PatternEngine 全市場掃描 → SQLite scan_runs/scan_hits + 靜態 JSON（給 PWA）。

usage: python3 run_scan.py [--date YYYY-MM-DD] [--out ../web/data] [--workers 6]
"""
import argparse, datetime as dt, json, os, sys, uuid, csv, time
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
import numpy as np, pandas as pd
from zoneinfo import ZoneInfo
TPE = ZoneInfo("Asia/Taipei")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from radar import db, config, engine, adjuster, sectors, fundamentals
from radar.context import Ctx

DISCLAIMER = [
    "本 App 只做型態偵測與歷史驗證，不構成投資建議，也不會代為下單。",
    "蔡森十二招全部為補定義（待 Jay 確認），門檻為工程化假設，不是市場統計結果。",
    "CIS 規則來自早期座談會二手摘錄；均線用收盤價 SMA 為工作假設。cis_exp 為 Jay 2026-11-18 新增的實驗組。",
    "做空：融券／借券費用假設 0，未計入；實際可否融券依交易所與券商公告。",
    "價格為還原權息後序列（最新一根 = 原始收盤價）。",
]

G = {}


def _init(cfg, T, custom_defs=()):
    G["cfg"], G["T"] = cfg, T
    from radar import dsl as _dsl
    G["custom"] = [(d["code"], d["name"], d["directions"], d.get("native_exit", "X3"), d.get("role", "standard"),
                    _dsl.ctx_fn(_dsl.Program(d)), d) for d in custom_defs]


def _work(item):
    cfg, T = G["cfg"], G["T"]
    sym, meta, arr, exref, restr, inst, shortable = item
    dates, o, h, l, c, v, chg, ck = arr
    reason = engine.universe_check(c[-1], v, dates[-1], T, len(c), restr, cfg["universe"], meta["type"] == "etf")
    if reason: return sym, reason, [], None, None
    if not (np.all(c > 0) and np.all(h >= l)): return sym, "資料異常（價格≤0 或 高<低）", [], None, None
    a = adjuster.adjust(dates, o, h, l, c, v, chg, ck, exref)
    if len(a["c"]) < cfg["universe"]["min_bars"]: return sym, "還原後 K 線不足（未解釋跳空）", [], None, None
    ctx = Ctx(a["dates"], a["o"], a["h"], a["l"], a["c"], a["v"], cfg, symbol=sym, market=meta["market"],
              sector=meta["sector_code"], inst_net=inst, shortable=shortable, name=meta["name"])
    sigs = engine.evaluate_symbol(ctx, ctx.n - 1, custom=G.get("custom", ()))
    for s in sigs:
        s["sector_code"], s["sector_name"] = meta["sector_code"], meta["sector_name"]
        s["adjusted"] = bool(a["factors"])
    bars = None
    if sigs:  # compact series for the stock page (adjusted; volume in 張)
        k = min(len(a["c"]), 260)
        bars = dict(t=[d.replace("-", "") for d in a["dates"][-k:]], o=[round(float(x), 3) for x in a["o"][-k:]],
                    h=[round(float(x), 3) for x in a["h"][-k:]], l=[round(float(x), 3) for x in a["l"][-k:]],
                    c=[round(float(x), 3) for x in a["c"][-k:]], v=[int(round(float(x) / 1000)) for x in a["v"][-k:]],
                    adj=[[d, f] for d, f, kind in a["factors"] if kind == "ref"][-10:])
    return sym, None, sigs, meta["sector_code"], bars


def build_summary(doc):
    """Small file for the 方向入口 / 型態選單 screens (§13): counts per direction and pattern."""
    by = {}
    tot = {"long": Counter(), "short": Counter()}
    syms = {"long": set(), "short": set()}
    for s in doc["hits"]:
        d = s["direction"]
        if d not in tot: continue
        k = f"{s['patternId']}|{d}"; c = by.setdefault(k, Counter())
        st = s["state"]
        if st in ("ENTRY",) or (st == "CONFIRMED" and s.get("fresh")): key = "new"
        elif st == "CONFIRMED": key = "active"
        else: key = st.lower()
        c[key] += 1; tot[d][key] += 1
        if key == "new": syms[d].add(s["symbol"])
    for d in tot: tot[d]["new_symbols"] = len(syms[d])
    return dict(schema_version=1, trade_date=doc["trade_date"], data_as_of=doc["data_as_of"], finished_at=doc["finished_at"],
                run_id=doc["run_id"], universe=doc["stats"]["universe"], patterns=doc["patterns"],
                totals={k: dict(v) for k, v in tot.items()}, by_pattern={k: dict(v) for k, v in by.items()}, notes=doc["notes"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--date"); ap.add_argument("--out", default=os.path.join(HERE, "..", "web"))
    ap.add_argument("--workers", type=int, default=6); ap.add_argument("--lookback", type=int, default=300)
    a = ap.parse_args()
    cfg = config.get(); t0 = time.time(); started = dt.datetime.now(TPE).isoformat(timespec="seconds")
    con = db.connect()
    custom, custom_errs = engine.load_custom(con)
    custom_defs = [c[6] for c in custom]
    T = a.date or con.execute("SELECT max(date) FROM trading_days WHERE twse=1 AND tpex=1").fetchone()[0]
    days = [r[0] for r in con.execute("SELECT date FROM trading_days WHERE twse=1 AND date<=? ORDER BY date DESC LIMIT ?", (T, a.lookback))]
    d0 = days[-1]
    bars = pd.read_sql("SELECT symbol,date,open,high,low,close,volume_shares v,chg,chg_known FROM daily_bars WHERE date>=? AND date<=? ORDER BY symbol,date",
                       con, params=(d0, T))
    inst = dict(con.execute("SELECT symbol,total_net FROM institutional_flows WHERE date=?", (T,)).fetchall())
    margin_rows = con.execute("SELECT symbol,short_allowed FROM margin_daily WHERE date=?", (T,)).fetchall()
    margin = dict(margin_rows)
    fs = json.load(open(os.path.join(HERE, "db", "fetch_summary.json"))) if os.path.exists(os.path.join(HERE, "db", "fetch_summary.json")) else {}
    margin_ok = {"TWSE": (fs.get("margin") or {}).get("twse") is not None, "TPEx": (fs.get("margin") or {}).get("tpex") is not None}
    inst_ok = {"TWSE": (fs.get("institutional") or {}).get("twse", 0) > 0, "TPEx": (fs.get("institutional") or {}).get("tpex", 0) > 0}
    restr = defaultdict(set)
    for s, k in con.execute("SELECT symbol,kind FROM restrictions"): restr[s].add(k)
    exref = defaultdict(dict)
    for s, d, ref in con.execute("SELECT symbol,ex_date,ref_price FROM corporate_actions WHERE ref_price IS NOT NULL"): exref[s][d] = ref
    meta = {r[0]: dict(name=r[1], market=r[2], type=r[3], sector_code=r[4], sector_name=r[5])
            for r in con.execute("SELECT symbol,name,market,type,sector_code,sector_name FROM instruments")}
    items = []
    for sym, g in bars.groupby("symbol", sort=True):
        m = meta.get(sym)
        if not m: continue
        arr = (g.date.tolist(), g.open.values.astype(float), g.high.values.astype(float), g.low.values.astype(float),
               g.close.values.astype(float), g.v.values.astype(float), g.chg.values.astype(float), g.chg_known.fillna(0).values.astype(int))
        sh = (bool(margin[sym]) if sym in margin else (False if margin_ok[m["market"]] else None))
        items.append((sym, m, arr, exref.get(sym, {}), restr.get(sym, set()),
                      inst.get(sym) if inst_ok[m["market"]] else None, sh))
    excluded = Counter(); hits = []; n_univ = 0; members = Counter(); series = {}; univ_list = []
    with ProcessPoolExecutor(a.workers, initializer=_init, initargs=(cfg, T, custom_defs)) as ex:
        for res in ex.map(_work, items, chunksize=20):
            sym, reason, sigs = res[:3]
            if not reason:
                members[res[3]] += 1
                if res[4]: series[sym] = (res[3], res[4])
            if reason: excluded[reason] += 1; continue
            n_univ += 1; hits += sigs
            m_ = meta.get(sym) or {}
            univ_list.append([sym, m_.get("name", ""), m_.get("market", ""), m_.get("sector_code") or "NA"])   # 觀察清單搜尋用
    # ---- stats
    counts = defaultdict(Counter)
    for s in hits:
        key = s["state"] if s["patternId"].startswith("cis") or s.get("fresh", True) else "CONFIRMED_active"
        counts[f"{s['patternId']}|{s['direction']}"][key] += 1
    sec_names = {r[0]: r[1] for r in con.execute("SELECT DISTINCT sector_code, sector_name FROM instruments")}
    sector_rows = sectors.aggregate(hits, dict(members), sec_names, cfg["sector"], [(r[0], r[2]) for r in engine.REGISTRY] + [(c[0], c[2]) for c in custom])
    fsnap = fundamentals.latest_snapshot(con, T)
    univ_syms = {s["symbol"] for s in hits}
    for s in hits:
        fs_ = fsnap.get(s["symbol"]); s["fundamentals_available"] = bool(fs_)
    run_key = f"{T}|{engine.pattern_set_hash(cfg, custom)}"
    finished = dt.datetime.now(TPE).isoformat(timespec="seconds")
    stats = dict(trade_date=T, symbols_loaded=len(items), universe=n_univ, excluded=dict(excluded),
                 counts={k: dict(v) for k, v in sorted(counts.items())}, bars_from=d0, bars_days=len(days),
                 runtime_sec=round(time.time() - t0, 1), inst_available=inst_ok, margin_available=margin_ok)
    # ---- SQLite (idempotent on run_key)
    old = con.execute("SELECT id FROM scan_runs WHERE run_key=?", (run_key,)).fetchone()
    if old:
        con.execute("DELETE FROM scan_hits WHERE run_id=?", (old[0],)); con.execute("DELETE FROM scan_runs WHERE id=?", (old[0],))
    run_id = str(uuid.uuid4()); now = dt.datetime.now(dt.timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    con.execute("INSERT INTO scan_runs (id,run_key,trade_date,started_at,finished_at,status,data_as_of,stats_json,updated_at,updated_by_device) VALUES (?,?,?,?,?,?,?,?,?,?)",
                (run_id, run_key, T, started, finished, "ok", T, json.dumps(stats, ensure_ascii=False), now, "box-batch"))
    con.executemany("INSERT INTO scan_hits (id,run_id,pattern_id,pattern_ver,symbol,direction,state,strength,levels_json,geometry_json,reasons_json,fundamental_pass,updated_at,updated_by_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    [(str(uuid.uuid4()), run_id, s["patternId"], s["patternVersion"], s["symbol"], s["direction"], s["state"], s["strength"],
                      json.dumps(s["levels"], ensure_ascii=False), json.dumps(s["geometry"], ensure_ascii=False),
                      json.dumps(s["reasons"], ensure_ascii=False), None, now, "box-batch") for s in hits])
    con.execute("DELETE FROM sector_scores WHERE run_id IN (SELECT id FROM scan_runs WHERE trade_date=?) OR run_id=?", (T, run_id))
    con.executemany("INSERT INTO sector_scores (id,run_id,direction,pattern_id,sector_code,n_members,hits,forming,hit_ratio,avg_strength,score,updated_at,updated_by_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    [(str(uuid.uuid4()), run_id, r["direction"], r["pattern_id"], r["sector_code"], r["n_members"], r["hits"], r["forming"],
                      r["hit_ratio"], r["avg_strength"], r["score"], now, "box-batch") for r in sector_rows])
    con.commit()
    # ---- static JSON for the PWA
    os.makedirs(a.out, exist_ok=True)
    doc = dict(schema_version=1, run_id=run_id, run_key=run_key, trade_date=T, data_as_of=T, started_at=started, finished_at=finished,
               timezone="Asia/Taipei", patterns=engine.list_patterns(custom=custom), params=cfg, custom_pattern_errors=custom_errs,
               dsl_builtin=json.load(open(os.path.join(HERE, "radar", "dsl_builtin.json")))["patterns"], stats=stats, notes=DISCLAIMER,
               data_sources=fs, hits=hits, sector_members=dict(members), sector_names=sec_names,
               universe=sorted(univ_list),
               sectors=[r for r in sector_rows if r["hits"] or r["forming"]])
    js = json.dumps(doc, ensure_ascii=False, separators=(",", ":"), default=lambda o: o.item() if hasattr(o, "item") else str(o))
    open(os.path.join(a.out, "scan_latest.json"), "w").write(js)
    # fundamentals snapshot (only symbols that appear in hits) + bars chunks per sector (flat files for GitHub upload)
    json.dump(dict(trade_date=T, as_of_rule="只用 T 日（含）以前已公告資料", sources=fs.get("fundamentals"),
                   notes=["EPS 為本年累計至最近一季；ROE 為本年累計歸屬母公司淨利年化 ÷ 歸屬母公司權益（不是近四季）。",
                          "EPS 近四季、ROE 近四季需 MOPS 歷史季報：資料待補。", "財測：無免費官方來源。",
                          "金融保險等非一般業財報格式未抓：毛利率等可能待補。"],
                   data={k: v for k, v in fsnap.items() if k in univ_syms}),
              open(os.path.join(a.out, "fundamentals_latest.json"), "w"), ensure_ascii=False, separators=(",", ":"))
    for old_f in os.listdir(a.out):
        if old_f.startswith("bars_") and old_f.endswith(".json"): os.remove(os.path.join(a.out, old_f))
    chunks = defaultdict(dict)
    for sym, (sc, b) in series.items(): chunks[sc or "NA"][sym] = b
    inst_hist = defaultdict(list)
    for s_, d_, tn in con.execute("SELECT symbol,date,total_net FROM institutional_flows WHERE date<=? AND date>=? ORDER BY date", (T, days[min(19, len(days)-1)])):
        if s_ in series: inst_hist[s_].append([d_.replace("-", ""), round(tn / 1000)])
    for sc, dd in chunks.items():
        for sym in dd: dd[sym]["inst"] = inst_hist.get(sym, [])
        json.dump(dict(trade_date=T, sector_code=sc, series=dd), open(os.path.join(a.out, f"bars_{sc}.json"), "w"), separators=(",", ":"))
    stats["bars_files"] = len(chunks)
    os.makedirs(os.path.join(HERE, "db", "scans"), exist_ok=True)
    open(os.path.join(HERE, "db", "scans", f"scan_{T.replace('-', '')}.json"), "w").write(js)   # archive (not deployed)
    json.dump(build_summary(doc), open(os.path.join(a.out, "summary_latest.json"), "w"), ensure_ascii=False, separators=(",", ":"))
    from radar import health
    json.dump(health.build(con, doc), open(os.path.join(a.out, "health_latest.json"), "w"), ensure_ascii=False, separators=(",", ":"))
    with open(os.path.join(HERE, "db", f"hits_{T.replace('-', '')}.csv"), "w", newline="") as f:
        w = csv.writer(f); w.writerow(["symbol", "name", "market", "sector", "pattern", "direction", "state", "fresh", "confirmed_on", "strength", "close", "neckline", "target", "stopRef", "volRatio", "instNet", "shortable", "reasons"])
        for s in sorted(hits, key=lambda s: (s["patternId"], s["state"], -(s["strength"] or 0))):
            lv = s["levels"]
            w.writerow([s["symbol"], s["name"], s["market"], s["sector_name"], s["patternId"], s["direction"], s["state"], s.get("fresh"), s.get("confirmed_on"),
                        s["strength"], s["close"], lv.get("neckline", lv.get("ma25")), lv.get("target"), lv.get("stopRef"), s["volRatio"], s["instNet"], s.get("shortable"), " / ".join(s["reasons"])])
    print(json.dumps(stats, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
