#!/usr/bin/env python3
"""盤後批次 step 1–4：抓官方資料 → SQLite。

usage: python3 run_fetch.py [--start 2025-11-03] [--end YYYY-MM-DD]
Idempotent: cached raw responses are reused; 查無資料 is never cached.
"""
import argparse, datetime as dt, json, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from radar import db, ingest, dataproxy, fundamentals

ap = argparse.ArgumentParser()
ap.add_argument("--start", default="2025-11-03")
ap.add_argument("--end", default=dt.date.today().isoformat())
ap.add_argument("--skip-history", action="store_true")
a = ap.parse_args()
start, end = dt.date.fromisoformat(a.start), dt.date.fromisoformat(a.end)

con = db.connect()
print("seeded from existing box caches:", ingest.seed_from_existing(), flush=True)
names = {} if a.skip_history else ingest.ingest_range(con, start, end, log=lambda s: print(s, flush=True))
T = con.execute("SELECT max(date) FROM trading_days WHERE twse=1 AND tpex=1").fetchone()[0]
print("latest full trading day:", T, flush=True)
Td = dt.date.fromisoformat(T)
nxt = Td + dt.timedelta(days=1)
while nxt.weekday() >= 5: nxt += dt.timedelta(days=1)   # NOTE: holiday calendar not applied (approximation)
summary = {"T": T}
summary["instruments"] = ingest.ingest_instruments(con, Td)
if not names:
    names = {}
for sym, name in con.execute("""SELECT b.symbol, NULL FROM daily_bars b GROUP BY b.symbol"""):
    pass
# names from latest raw quote files
for d in con.execute("SELECT date FROM trading_days WHERE twse=1 ORDER BY date DESC LIMIT 15").fetchall()[::-1]:
    dd = dt.date.fromisoformat(d[0])
    for rows in (ingest.parse_twse_day(ingest.fetch_twse_day(dd), dd), ingest.parse_tpex_day(ingest.fetch_tpex_day(dd), dd)):
        for r in rows or []: names[r["symbol"]] = (r["name"], r["market"])
ingest.update_names(con, names)
summary["exrights"] = ingest.ingest_exrights(con, start, Td)
summary["institutional"] = ingest.ingest_institutional(con, Td)
# 三大法人近 20 個交易日（個股頁 InstitutionBar）
hist = [dt.date.fromisoformat(r[0]) for r in con.execute(
    "SELECT date FROM trading_days WHERE twse=1 AND tpex=1 AND date<? ORDER BY date DESC LIMIT 19", (T,))]
summary["institutional_hist_days"] = sum(1 for d in hist if sum(ingest.ingest_institutional(con, d).values()) > 0)
summary["fundamentals"] = fundamentals.ingest_fundamentals(con, Td)
summary["margin"] = ingest.ingest_margin(con, Td)
summary["restrictions"] = ingest.ingest_restrictions(con, Td, nxt)
dataproxy.save_health()
json.dump(summary, open(os.path.join(os.path.dirname(db.DB_PATH), "fetch_summary.json"), "w"), ensure_ascii=False, indent=1)
print(json.dumps(summary, ensure_ascii=False, indent=1))
