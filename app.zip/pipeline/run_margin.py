#!/usr/bin/env python3
"""融資／擔保維持率：寫出 web/margin_latest.json（首頁橫幅＋資料狀態頁）。
來源與計算見 radar/margin.py。任何失敗都沿用上一份並標 stale；本程式永遠 exit 0，不會讓主批次失敗。
usage: python3 run_margin.py [--out ../web]
"""
import argparse, datetime as dt, json, os, sys
from zoneinfo import ZoneInfo
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from radar import margin
TPE = ZoneInfo("Asia/Taipei")


def http_get(url, timeout=45):
    return margin.http_get(url, timeout=timeout, retries=3)


def run(out, get=http_get, now=None):
    now = now or dt.datetime.now(TPE)
    path = os.path.join(out, "margin_latest.json"); gen = now.isoformat(timespec="seconds")
    try:
        payload, errs = margin.fetch(get, today=now.date().isoformat())
        if payload is None:
            raise RuntimeError("；".join(errs) or "全部來源失敗")
        doc = margin.build_doc(payload, errs, gen)
    except Exception as e:  # noqa: BLE001
        print(f"::warning::融資維持率更新失敗：{str(e)[:300]}")
        try:
            doc = json.load(open(path, encoding="utf-8"))
            doc.update(stale=True, error=f"本次抓取失敗，沿用上次資料：{str(e)[:160]}")
        except Exception:  # noqa: BLE001
            return None
    os.makedirs(out, exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(doc, f, ensure_ascii=False, separators=(",", ":"))
    os.replace(tmp, path)
    off = doc.get("official") or {}
    comp = doc.get("computed") or {}
    print(f"擔保維持率：{doc.get('as_of')} {off.get('keepRate')}（{doc.get('status_label')}）"
          f"{'  融資 '+str(comp.get('all'))+'%' if comp else ''}{'［沿用舊資料］' if doc.get('stale') else ''}")
    return doc


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--out", default=os.path.join(HERE, "..", "web")); a = ap.parse_args()
    try:
        run(a.out)
    except Exception as e:  # noqa: BLE001
        print(f"::warning::run_margin 例外：{e}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
