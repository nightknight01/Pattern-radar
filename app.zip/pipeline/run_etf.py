#!/usr/bin/env python3
"""單一 ETF 專頁資料（預設 00631L 元大台灣50正2）：寫出 web/etf_<代號>.json（給 #/etf/<代號> 頁）。

資料：先用資料庫 daily_bars（每日 MI_INDEX 全市場行情已含 ETF，跟著 state 保存）；
      缺最近交易日或不足 2 年 → 補抓 TWSE STOCK_DAY（逐月）→ 再失敗改用 Yahoo <代號>.TW。補到的列寫回 daily_bars（INSERT OR IGNORE），跟 state 一起保存。
計算：還原權息（含 2026 分割）→ 十二招＋CIS 兩組＋老王（同全市場掃描的 engine）→ 關鍵統計。
疊圖：台積電 2330 日 K（daily_bars，還原權息，對齊 00631L 日期）＋ MA5／MA25／MA100 → overlay（前端可切換顯示）。
失敗：保留上一份 JSON 並標 stale；本程式永遠 exit 0，不會讓主批次失敗。
usage: python3 run_etf.py [--symbol 00631L] [--out ../web] [--no-fetch]
"""
import argparse, datetime as dt, json, math, os, sys, time, urllib.request
import numpy as np
from zoneinfo import ZoneInfo
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
TPE = ZoneInfo("Asia/Taipei")
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
HIST_DAYS = 500          # 約 2 年交易日
LEVERAGE_NOTE = ("00631L 是「單日」2 倍槓桿 ETF：每天追蹤台灣 50 指數當日報酬的 2 倍。持有超過一天，累積報酬不會剛好是指數的 2 倍；"
                 "盤整來回震盪時會因每日重新平衡而耗損（波動耗損）。融資買進時，還要另外承擔融資利息與追繳風險。")


def http_get(url, timeout=25):
    with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": UA}), timeout=timeout) as r:
        return r.read().decode("utf-8", "replace")


def _num(s):
    s = str(s).replace(",", "").strip()
    if s in ("", "--", "---", "X0.00"): return None
    try: return float(s.replace("X", "").replace("+", ""))
    except ValueError: return None


def parse_stock_day(j):
    """TWSE STOCK_DAY JSON → [(date, o, h, l, c, shares, chg, chg_known)]."""
    if (j or {}).get("stat") != "OK": return []
    out = []
    for r in j.get("data") or []:
        y, m, d = r[0].split("/"); day = f"{int(y) + 1911:04d}-{int(m):02d}-{int(d):02d}"
        o, h, l, c = (_num(x) for x in r[3:7]); sh = _num(r[1]); chg_s = str(r[7]).strip()
        if None in (o, h, l, c): continue
        chg = _num(chg_s); known = 0 if chg_s.startswith("X") or chg is None else 1   # X = 除權息／分割，價差不可直接用
        out.append((day, o, h, l, c, int(sh or 0), chg if known else None, known))
    return out


def fetch_twse(symbol, months, get=http_get, sleep=0.6):
    rows = []
    for ym in months:
        rows += parse_stock_day(json.loads(get(f"https://www.twse.com.tw/rwd/zh/afterTrading/STOCK_DAY?date={ym}01&stockNo={symbol}&response=json")))
        if sleep: time.sleep(sleep)
    return rows


def parse_yahoo(j):
    r = ((j or {}).get("chart") or {}).get("result") or []
    if not r: return []
    r = r[0]; ts = r.get("timestamp") or []; q = r["indicators"]["quote"][0]; off = r["meta"].get("gmtoffset", 28800) or 0
    out = []
    for i, t in enumerate(ts):
        o, h, l, c, v = (q[k][i] for k in ("open", "high", "low", "close", "volume"))
        if None in (o, h, l, c): continue
        out.append((dt.datetime.fromtimestamp(t + off, dt.timezone.utc).strftime("%Y-%m-%d"), o, h, l, c, int(v or 0), None, 0))
    return out


def fetch_yahoo(symbol, get=http_get):
    return parse_yahoo(json.loads(get(f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}.TW?range=2y&interval=1d")))


def months_between(d0, d1):
    y, m = d0.year, d0.month; out = []
    while (y, m) <= (d1.year, d1.month):
        out.append(f"{y:04d}{m:02d}"); m += 1
        if m == 13: y, m = y + 1, 1
    return out


def ensure_bars(con, symbol, T, get=http_get, log=print):
    """確保 daily_bars 有到 T 的資料、且約 2 年；不足就補抓。回傳 (來源說明, 錯誤列表)。"""
    have = con.execute("SELECT count(*), min(date), max(date) FROM daily_bars WHERE symbol=?", (symbol,)).fetchone()
    n, d0, d1 = have[0] or 0, have[1], have[2]
    if n >= HIST_DAYS * 0.9 and d1 and T and d1 >= T: return "資料庫（每日全市場行情）", []
    errs = []; today = dt.date.fromisoformat(T) if T else dt.date.today()
    start = (dt.date.fromisoformat(d1) if (d1 and n >= HIST_DAYS * 0.9) else today - dt.timedelta(days=730))
    rows, src = [], None
    try:
        rows = fetch_twse(symbol, months_between(start, today), get); src = "TWSE STOCK_DAY"
    except Exception as e:  # noqa: BLE001
        errs.append(f"TWSE STOCK_DAY: {str(e)[:120]}")
    if not rows:
        try: rows = fetch_yahoo(symbol, get); src = "Yahoo Finance"
        except Exception as e:  # noqa: BLE001
            errs.append(f"Yahoo: {str(e)[:120]}")
    if rows:
        now = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        con.executemany("INSERT OR IGNORE INTO daily_bars (symbol,date,open,high,low,close,volume_shares,source,fetched_at,chg,chg_known) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                        [(symbol, d, o, h, l, c, v, src, now, chg, k) for d, o, h, l, c, v, chg, k in rows])
        con.commit(); log(f"{symbol}: 補抓 {len(rows)} 列（{src}）")
        return ("資料庫＋" + src) if n else src, errs
    return ("資料庫（未補齊）" if n else None), errs


def stats(dates, o, h, l, c, v_sh):
    n = len(c); C = np.asarray(c, float); V = np.asarray(v_sh, float) / 1000.0
    ma = lambda k: float(C[-k:].mean()) if n >= k else None
    ret = lambda k: (float(C[-1] / C[-1 - k] - 1) * 100) if n > k else None
    w = min(n, 250); hi_i = int(np.argmax(np.asarray(h[-w:], float))); lo_i = int(np.argmin(np.asarray(l[-w:], float)))
    hi, lo = float(h[-w:][hi_i]), float(l[-w:][lo_i])
    lr = np.diff(np.log(C[-21:])) if n > 21 else np.array([])
    m5, m25 = ma(5), ma(25)
    return dict(close=round(float(C[-1]), 2), prev_close=round(float(C[-2]), 2) if n > 1 else None,
                change_pct=round((C[-1] / C[-2] - 1) * 100, 2) if n > 1 else None,
                ma5=round(m5, 2) if m5 else None, ma25=round(m25, 2) if m25 else None,
                dev_ma25_pct=round((C[-1] / m25 - 1) * 100, 2) if m25 else None,
                ret20_pct=round(ret(20), 2) if ret(20) is not None else None, ret60_pct=round(ret(60), 2) if ret(60) is not None else None,
                high52=round(hi, 2), high52_date=dates[-w:][hi_i], low52=round(lo, 2), low52_date=dates[-w:][lo_i],
                dd_from_high_pct=round((C[-1] / hi - 1) * 100, 2),
                vol20_ann_pct=round(float(lr.std(ddof=1) * math.sqrt(252) * 100), 1) if len(lr) > 2 else None,
                vol20_daily_pct=round(float(lr.std(ddof=1) * 100), 2) if len(lr) > 2 else None,
                avgvol20_lots=int(round(V[-20:].mean())) if n >= 20 else None, vol_lots=int(round(V[-1])))


OVERLAY_SYMBOL = "2330"   # 00631L 專頁疊圖：台積電（台灣 50 最大權重）


def overlay_bars(con, symbol, dates, T):
    """疊圖用日 K（還原權息，同 00631L 的日期軸）：從 daily_bars 取（每日全市場行情已含 2330），對齊 dates。"""
    from radar import adjuster
    if not dates: return None
    rows = con.execute("SELECT date,open,high,low,close,volume_shares,chg,chg_known FROM daily_bars WHERE symbol=? AND date<=? ORDER BY date DESC LIMIT ?",
                       (symbol, T, len(dates) + 140)).fetchall()[::-1]
    if len(rows) < 30: raise ValueError(f"{symbol} K 線不足（{len(rows)} 根）")
    exref = dict(con.execute("SELECT ex_date,ref_price FROM corporate_actions WHERE symbol=? AND ref_price IS NOT NULL", (symbol,)).fetchall())
    ds = [r[0] for r in rows]; arr = [np.array([r[i] if r[i] is not None else np.nan for r in rows], float) for i in range(1, 6)]
    chg = np.array([r[6] if r[6] is not None else np.nan for r in rows], float); ck = np.array([r[7] or 0 for r in rows], int)
    a = adjuster.adjust(ds, *arr, chg, ck, exref)
    idx = {d: i for i, d in enumerate(a["dates"])}
    keep = [d for d in dates if d in idx]
    if not keep: raise ValueError(f"{symbol} 與 00631L 沒有重疊的交易日")
    # MA 需要更早的資料：另給完整收盤序列的 MA5／MA25／MA100（對齊 keep）
    C = np.asarray(a["c"], float)
    def ma(n):
        out = {}
        for d in keep:
            i = idx[d]
            out[d] = round(float(C[i - n + 1:i + 1].mean()), 3) if i >= n - 1 else None
        return [out[d] for d in keep]
    name = (con.execute("SELECT name FROM instruments WHERE symbol=?", (symbol,)).fetchone() or ["台積電"])[0]
    return dict(symbol=symbol, name=name, data_as_of=a["dates"][-1],
                t=[d.replace("-", "") for d in keep], o=[round(float(a["o"][idx[d]]), 3) for d in keep],
                h=[round(float(a["h"][idx[d]]), 3) for d in keep], l=[round(float(a["l"][idx[d]]), 3) for d in keep],
                c=[round(float(a["c"][idx[d]]), 3) for d in keep], v=[int(round(float(a["v"][idx[d]]) / 1000)) for d in keep],
                ma5=ma(5), ma25=ma(25), ma100=ma(100))


def build(con, symbol, T, cfg, fetch=True, get=http_get, log=print):
    from radar import engine, adjuster, cis
    from radar.context import Ctx
    src, errs = ensure_bars(con, symbol, T, get, log) if fetch else ("資料庫", [])
    T = T or con.execute("SELECT max(date) FROM daily_bars WHERE symbol=?", (symbol,)).fetchone()[0]
    rows = con.execute("SELECT date,open,high,low,close,volume_shares,chg,chg_known FROM daily_bars WHERE symbol=? AND date<=? ORDER BY date DESC LIMIT ?",
                       (symbol, T, HIST_DAYS + 40)).fetchall()[::-1]
    if len(rows) < 80: raise ValueError(f"{symbol} K 線不足（{len(rows)} 根）")
    meta = con.execute("SELECT name,market,sector_code,sector_name FROM instruments WHERE symbol=?", (symbol,)).fetchone() or (symbol, "TWSE", "ETF", "ETF")
    exref = dict(con.execute("SELECT ex_date,ref_price FROM corporate_actions WHERE symbol=? AND ref_price IS NOT NULL", (symbol,)).fetchall())
    dates = [r[0] for r in rows]; arr = [np.array([r[i] if r[i] is not None else np.nan for r in rows], float) for i in range(1, 6)]
    chg = np.array([r[6] if r[6] is not None else np.nan for r in rows], float); ck = np.array([r[7] or 0 for r in rows], int)
    a = adjuster.adjust(dates, *arr, chg, ck, exref)
    inst_row = con.execute("SELECT total_net FROM institutional_flows WHERE symbol=? AND date=?", (symbol, T)).fetchone()
    sh = con.execute("SELECT short_allowed FROM margin_daily WHERE symbol=? AND date=?", (symbol, T)).fetchone()
    ctx = Ctx(a["dates"], a["o"], a["h"], a["l"], a["c"], a["v"], cfg, symbol=symbol, market=meta[1], sector=meta[2],
              inst_net=inst_row[0] if inst_row else None, shortable=(bool(sh[0]) if sh else None), name=meta[0])
    t = ctx.n - 1
    sigs = engine.evaluate_symbol(ctx, t)
    for s in sigs: s["sector_code"], s["sector_name"], s["adjusted"] = meta[2], meta[3], bool(a["factors"])
    # CIS 目前狀態：空手（找進場）與持有多單（續抱／出場）兩種視角
    def cis_view(fn, pos):
        r = fn(ctx, t, pos); return dict(state=r["state"], direction=r.get("direction"), reasons=r.get("reasons", []) + ([r["note"]] if r.get("note") else []))
    cis_state = dict(ma5=round(float(ctx.m5[t]), 2), ma25=round(float(ctx.m25[t]), 2),
                     base_flat=cis_view(cis.evaluate_cis_base, "NONE"), base_long=cis_view(cis.evaluate_cis_base, "LONG"),
                     exp_flat=cis_view(cis.evaluate_cis_exp, "NONE"), exp_long=cis_view(cis.evaluate_cis_exp, "LONG"))
    k = min(ctx.n, 260)
    inst = [[d.replace("-", ""), round(tn / 1000)] for d, tn in con.execute(
        "SELECT date,total_net FROM institutional_flows WHERE symbol=? AND date<=? ORDER BY date DESC LIMIT 20", (symbol, T)).fetchall()[::-1]]
    bars = dict(t=[d.replace("-", "") for d in a["dates"][-k:]], o=[round(float(x), 3) for x in a["o"][-k:]], h=[round(float(x), 3) for x in a["h"][-k:]],
                l=[round(float(x), 3) for x in a["l"][-k:]], c=[round(float(x), 3) for x in a["c"][-k:]],
                v=[int(round(float(x) / 1000)) for x in a["v"][-k:]], adj=[[d, f] for d, f, kind in a["factors"] if kind == "ref"][-10:], inst=inst)
    st = stats(a["dates"], a["o"], a["h"], a["l"], a["c"], a["v"])
    # 老王（四海遊龍／四面楚歌）目前狀態：空手視角 + MA100（≈20 週）
    from radar import laowang
    def lw_view(fn):
        r = fn(ctx, t); return dict(state=r["state"], direction=r.get("direction"), reasons=r.get("reasons", []))
    lw_state = dict(ma={f"ma{n}": (round(float(m[t]), 2) if m[t] == m[t] else None) for n, m in laowang.mas(ctx)},
                    dragon=lw_view(laowang.evaluate_dragon), chu=lw_view(laowang.evaluate_chu), gapfill=lw_view(laowang.evaluate_gapfill))
    overlay, ov_err = None, None
    try:
        overlay = overlay_bars(con, OVERLAY_SYMBOL, a["dates"][-k:], T)
    except Exception as e:  # noqa: BLE001 — 台積電疊圖失敗不影響 00631L 本身
        ov_err = f"{OVERLAY_SYMBOL} 疊圖資料失敗：{str(e)[:120]}"
    return dict(schema_version=1, symbol=symbol, name=meta[0], market=meta[1], trade_date=T, data_as_of=a["dates"][-1],
                generated_at=dt.datetime.now(TPE).isoformat(timespec="seconds"), source=src, fetch_errors=errs, stale=a["dates"][-1] < T,
                stats=st, cis=cis_state, laowang=lw_state, signals=sigs, bars=bars, n_bars=ctx.n, leverage_note=LEVERAGE_NOTE,
                overlay=overlay, overlay_error=ov_err,
                notes=["價格為還原權息（含分割）後序列；最新一根 = 原始收盤價。", "訊號為型態偵測與歷史規則，不構成投資建議。"])


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--symbol", default="00631L"); ap.add_argument("--out", default=os.path.join(HERE, "..", "web"))
    ap.add_argument("--no-fetch", action="store_true"); a = ap.parse_args()
    path = os.path.join(a.out, f"etf_{a.symbol}.json")
    try:
        from radar import db, config
        con = db.connect(); cfg = config.get()
        T = con.execute("SELECT max(date) FROM trading_days WHERE twse=1").fetchone()[0]
        doc = build(con, a.symbol, T, cfg, fetch=not a.no_fetch)
        os.makedirs(a.out, exist_ok=True)
        json.dump(doc, open(path, "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"), default=lambda o: o.item() if hasattr(o, "item") else str(o))
        print(f"{a.symbol}: 資料日 {doc['data_as_of']}，收盤 {doc['stats']['close']}，訊號 {len(doc['signals'])} 個，來源 {doc['source']}")
    except Exception as e:  # noqa: BLE001 — 絕不讓主批次失敗
        print(f"::warning::{a.symbol} 專頁資料更新失敗：{e}")
        try:
            prev = json.load(open(path, encoding="utf-8")); prev.update(stale=True, error=f"本次更新失敗，沿用上次資料：{str(e)[:160]}")
            json.dump(prev, open(path, "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))
        except Exception: pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
