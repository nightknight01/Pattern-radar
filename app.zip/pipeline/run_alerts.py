#!/usr/bin/env python3
"""盤後 Email 警示（§11）— DRY-RUN ONLY. 產生主旨／純文字／HTML 預覽與 alert_log 紀錄，**絕不寄信**。

usage: python3 run_alerts.py [--date YYYY-MM-DD] [--out ../web]
輸出：db/alerts/alert_YYYYMMDD.{txt,html,json}、web/alert_preview.html；alert_log 以 status='dry_run' 記錄（不影響日後真正寄送的去重）。
排程建議（尚未建立，需 Jay 同意後再設）：CRON_TZ=Asia/Taipei 30 17 * * 1-5，失敗每 20 分鐘重試到 20:00。
寄送：需 Jay 明確授權；App 部署版用 Gmail API OAuth 或 SMTP 應用程式密碼（憑證放 Secrets，不進前端或 Git）。
"""
import argparse, datetime as dt, glob, html, json, os, sys, uuid
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from radar import db, alerts, fundamentals

SCANS = os.path.join(HERE, "db", "scans")


def load_settings(con):
    s = json.loads(json.dumps(alerts.DEFAULT_SETTINGS)); s["recipients"] = alerts.env_recipients()
    r = con.execute("SELECT pattern_ids_json, recipients_json, cooldown_days, max_rows, send_empty_digest, fundamental_rules_json, schedule_cron "
                    "FROM alert_settings WHERE deleted=0 ORDER BY updated_at DESC LIMIT 1").fetchone()
    src = "預設值"
    if r:
        src = "alert_settings（由備份匯入）"
        if r[0]: s["patterns"] = json.loads(r[0])
        if r[1]: s["recipients"] = json.loads(r[1])
        if r[2] is not None: s["cooldown_days"] = r[2]
        if r[3] is not None: s["max_rows"] = r[3]
        if r[4] is not None: s["send_empty_digest"] = bool(r[4])
        if r[5]: s["fundamental_rules"] = json.loads(r[5])
        if r[6]: s["schedule_cron"] = r[6]
    u = con.execute("SELECT value_json FROM settings WHERE key='app_base_url' AND deleted=0").fetchone()
    if u: s["app_base_url"] = json.loads(u[0])
    c = con.execute("SELECT value_json FROM settings WHERE key='cis_exit_scope' AND deleted=0").fetchone()
    if c and json.loads(c[0]) in ("watchlist", "all"): s["cis_exit_scope"] = json.loads(c[0])
    return s, src


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--date"); ap.add_argument("--out", default=os.path.join(HERE, "..", "web"))
    a = ap.parse_args(); con = db.connect()
    files = sorted(glob.glob(os.path.join(SCANS, "scan_*.json")))
    T = a.date or con.execute("SELECT max(date) FROM trading_days WHERE twse=1 AND tpex=1").fetchone()[0]
    f = os.path.join(SCANS, f"scan_{T.replace('-', '')}.json")
    if not os.path.exists(f):
        print(json.dumps({"trade_date": T, "result": "no_mail", "reason": "T 日沒有掃描結果（休市或資料未公布）→ 不寄"}, ensure_ascii=False)); return
    doc = json.load(open(f))
    prev_f = [x for x in files if x < f]
    prev = json.load(open(prev_f[-1])) if prev_f else None
    prev_states = {(h["symbol"], h["patternId"], h["direction"]): h["state"] for h in prev["hits"]} if prev else None
    settings, src = load_settings(con)
    sent = {r[0] for r in con.execute("SELECT dedupe_key FROM alert_log WHERE status='sent' AND deleted=0")}
    days = [r[0] for r in con.execute("SELECT date FROM trading_days WHERE twse=1 AND date<? ORDER BY date DESC LIMIT ?", (T, settings["cooldown_days"]))]
    recent = set()
    if days:
        for sym, pid, d in con.execute("SELECT symbol, pattern_id, direction FROM alert_log WHERE state IN ('ENTRY','CONFIRMED') AND status IN ('sent','dry_run') "
                                       "AND trade_date>=? AND trade_date<?", (days[-1], T)):
            recent.add((sym, pid, d))
    watch = {r[0]: r[1] for r in con.execute("SELECT symbol, position FROM watchlist WHERE deleted=0")}
    exits, entries, skipped = alerts.select(doc, prev_states, settings, sent, recent, watch)
    fund = fundamentals.latest_snapshot(con, T)
    st = doc["stats"]; fs = doc.get("data_sources") or {}
    status = [f"資料日 {T}；掃描 {st['universe']} 檔（載入 {st['symbols_loaded']} 檔）",
              "排除：" + "、".join(f"{k} {v}" for k, v in sorted(st["excluded"].items(), key=lambda x: -x[1])[:6]),
              f"三大法人：上市 {'有' if st['inst_available']['TWSE'] else '未公布'}／上櫃 {'有' if st['inst_available']['TPEx'] else '未公布'}；"
              f"融資融券：上市 {'有' if st['margin_available']['TWSE'] else '未公布'}／上櫃 {'有' if st['margin_available']['TPEx'] else '未公布'}",
              f"前一交易日比對：{os.path.basename(prev_f[-1]) if prev_f else '無'}；設定來源：{src}"]
    msg = alerts.build(doc, exits, entries, skipped, settings, fund, None, prev is not None, status)
    os.makedirs(os.path.join(HERE, "db", "alerts"), exist_ok=True)
    tag = T.replace("-", ""); base = os.path.join(HERE, "db", "alerts", f"alert_{tag}")
    now = dt.datetime.now(dt.timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    will_send = not msg["empty"] or settings["send_empty_digest"]
    to_shown = [alerts.mask_email(x) for x in msg["to"]] or ["（未設定：GitHub Secrets ALERT_TO）"]
    meta = dict(mode="dry_run", sent=False, would_send=will_send, trade_date=T, to=to_shown, subject=msg["subject"],
                n_new=msg["n_new"], n_exit=msg["n_exit"], rows=len(msg["rows"]), truncated=msg["truncated"], skipped=skipped,
                note="本檔只是信件內容預覽；實際寄送由 ci/send_alert.py 在 GitHub Actions 依 Secrets 決定（未設定就不寄）。", generated_at=now)
    open(base + ".txt", "w").write(f"To: {', '.join(to_shown)}\nSubject: {msg['subject']}\n\n{msg['text']}\n")
    open(base + ".html", "w").write(msg["html"])
    json.dump(meta, open(base + ".json", "w"), ensure_ascii=False, indent=1)
    banner = (f'<div style="background:#3a2600;color:#FFD18A;padding:10px 16px;font:14px sans-serif">信件預覽 — 這一頁本身不會寄信（實際寄送見 GitHub Actions 紀錄）。'
              f'收件人：{html.escape(", ".join(to_shown))}｜主旨：{html.escape(msg["subject"])}'
              f'{"" if will_send else "｜今日無新內容：依設定不寄"}｜產生於 {html.escape(now)}（UTC）</div>')
    open(os.path.join(a.out, "alert_preview.html"), "w").write(
        '<!DOCTYPE html><html lang="zh-Hant-TW"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
        f'<title>盤後警示預覽 {T}</title></head><body style="margin:0;background:#0A0E1A">{banner}{msg["html"]}</body></html>')
    for key, pid, sym, d, s in msg["rows_meta"]:
        con.execute("INSERT OR IGNORE INTO alert_log (id,dedupe_key,trade_date,pattern_id,symbol,direction,state,sent_at,message_id,status,updated_at,updated_by_device) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", (str(uuid.uuid4()), key, T, pid, sym, d, s, None, None, "dry_run", now, "box-batch"))
    con.commit()
    print(json.dumps(meta, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
