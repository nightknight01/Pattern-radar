"""Adjuster (§4): back-adjust prices for 除權息/分割/減資 using the exchange's own reference price.

Per bar i (i>0), the exchange reference price ref_i (the price 漲跌 is measured from):
  - sign known  → ref_i = close_i − chg_i   (MI_INDEX / TPEx 漲跌)
  - sign unknown ('X' / 除息 text) → TWT49U / exDailyQ 除權息參考價 for that date
factor_i = ref_i / close_{i-1}; adjusted price on bars < i is multiplied by factor_i.
Latest bar stays == raw price (so levels match what users see in quotes).
Unexplained gaps (|close/prev−1| > 10.5% with no reference) → history before the gap is dropped
(engine assumption; 待 Jay 確認) and flagged.
Volume is divided by the factor only for split-like events (factor < 0.8 or > 1.25).
"""
import numpy as np


def adjust(dates, o, h, l, c, v, chg, chg_known, ex_ref):
    """ex_ref: {date: ref_price}. Returns dict with adjusted arrays, factors list, flags."""
    n = len(c); f = np.ones(n); flags = []; cut = 0
    for i in range(1, n):
        ref = None
        if chg_known[i] and chg[i] is not None and not np.isnan(chg[i]):
            ref = c[i] - chg[i]
        elif dates[i] in ex_ref and ex_ref[dates[i]]:
            ref = ex_ref[dates[i]]
        if ref is not None and ref > 0:
            r = ref / c[i - 1]
            if abs(r - 1) > 0.0005:   # ignore rounding noise
                f[i] = r; flags.append((dates[i], round(float(r), 6), "ref"))
        else:
            if abs(c[i] / c[i - 1] - 1) > 0.105:
                cut = i; flags.append((dates[i], None, "unexplained_gap_cut"))
    cum = np.ones(n)
    for i in range(n - 2, -1, -1):
        cum[i] = cum[i + 1] * f[i + 1]
    vf = np.ones(n)
    for i in range(n - 2, -1, -1):
        fi = f[i + 1]; vf[i] = vf[i + 1] * (fi if (fi < 0.8 or fi > 1.25) else 1.0)
    sl = slice(cut, n)
    return dict(dates=list(dates)[cut:], o=(o * cum)[sl], h=(h * cum)[sl], l=(l * cum)[sl], c=(c * cum)[sl],
                v=(v / vf)[sl], factors=flags, cut=cut)
