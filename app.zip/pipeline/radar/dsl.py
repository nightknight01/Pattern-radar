"""自訂型態 DSL 直譯器（§16）— whitelist-only expression language, vectorised over a symbol's series.

Grammar:  expr := or ; or := and ('or' and)* ; and := not ('and' not)* ; not := 'not' not | cmp
          cmp := sum (('>'|'>='|'<'|'<='|'=='|'!=') sum)? ; sum := prod (('+'|'-') prod)* ; prod := unary (('*'|'/') unary)*
          unary := '-' unary | atom ; atom := number | true | false | ident | ident '(' args ')' | '(' expr ')'
Values are numpy float arrays (booleans = 1.0 / 0.0; NaN comparisons are False). No attribute access, no
indexing, no strings, no user functions — only the FUNCS whitelist. Limits: expression ≤ 500 chars, ≤ 200 nodes,
window / lookback arguments ≤ 250 bars, ≤ 40 series, ≤ 24 states.
pivots()/trendline() are reserved (geometry helpers of the built-in 蔡森 detectors) — not exposed in DSL v1.
"""
from __future__ import annotations
import math, re
import numpy as np
from . import indicators as ind

MAX_EXPR, MAX_NODES, MAX_WIN, MAX_SERIES, MAX_STATES = 500, 200, 250, 40, 24
BASE = ("close", "open", "high", "low", "volume")
STATES = ("ENTRY", "HOLD", "EXIT_WARNING", "EXIT", "WATCH", "FORMING", "CONFIRMED", "FAILED", "TARGET_HIT")
POS = ("NONE", "LONG", "SHORT", "ANY")
RESERVED = {"pivots", "trendline"}
TOK = re.compile(r"\s*(?:(\d+\.\d*|\.\d+|\d+)|([A-Za-z_][A-Za-z0-9_]*)|(>=|<=|==|!=|[-+*/()<>,]))")


class DSLError(ValueError):
    pass


def tokenize(s):
    if len(s) > MAX_EXPR: raise DSLError(f"運算式過長（> {MAX_EXPR} 字）")
    out, i = [], 0
    while i < len(s):
        if s[i:].strip() == "": break
        m = TOK.match(s, i)
        if not m or m.end() == i: raise DSLError(f"無法辨識的字元：{s[i:i + 10]!r}")
        num, name, op = m.groups()
        out.append(("num", float(num)) if num else ("id", name) if name else ("op", op)); i = m.end()
    return out


class Parser:
    def __init__(self, s):
        self.t = tokenize(s); self.i = 0; self.nodes = 0

    def peek(self): return self.t[self.i] if self.i < len(self.t) else (None, None)

    def eat(self, kind=None, val=None):
        k, v = self.peek()
        if k is None or (kind and k != kind) or (val is not None and v != val):
            raise DSLError(f"語法錯誤：預期 {val or kind}，得到 {v!r}")
        self.i += 1; return v

    def node(self, *n):
        self.nodes += 1
        if self.nodes > MAX_NODES: raise DSLError(f"運算式過於複雜（> {MAX_NODES} 節點）")
        return n

    def parse(self):
        e = self.or_()
        if self.i != len(self.t): raise DSLError(f"語法錯誤：多餘的 {self.peek()[1]!r}")
        return e

    def or_(self):
        a = self.and_()
        while self.peek() == ("id", "or"): self.i += 1; a = self.node("or", a, self.and_())
        return a

    def and_(self):
        a = self.not_()
        while self.peek() == ("id", "and"): self.i += 1; a = self.node("and", a, self.not_())
        return a

    def not_(self):
        if self.peek() == ("id", "not"): self.i += 1; return self.node("not", self.not_())
        return self.cmp()

    def cmp(self):
        a = self.sum_()
        k, v = self.peek()
        if k == "op" and v in (">", ">=", "<", "<=", "==", "!="): self.i += 1; return self.node("cmp", v, a, self.sum_())
        return a

    def sum_(self):
        a = self.prod()
        while self.peek()[0] == "op" and self.peek()[1] in "+-": op = self.eat(); a = self.node("bin", op, a, self.prod())
        return a

    def prod(self):
        a = self.unary()
        while self.peek()[0] == "op" and self.peek()[1] in "*/": op = self.eat(); a = self.node("bin", op, a, self.unary())
        return a

    def unary(self):
        if self.peek() == ("op", "-"): self.i += 1; return self.node("neg", self.unary())
        return self.atom()

    def atom(self):
        k, v = self.peek()
        if k == "num": self.i += 1; return self.node("num", v)
        if k == "op" and v == "(":
            self.i += 1; e = self.or_(); self.eat("op", ")"); return e
        if k == "id":
            self.i += 1
            if v in ("and", "or", "not"): raise DSLError(f"語法錯誤：{v} 位置不對")
            if v in ("true", "false"): return self.node("num", 1.0 if v == "true" else 0.0)
            if self.peek() == ("op", "("):
                self.i += 1; args = []
                if self.peek() != ("op", ")"):
                    args.append(self.or_())
                    while self.peek() == ("op", ","): self.i += 1; args.append(self.or_())
                self.eat("op", ")")
                return self.node("call", v, args)
            return self.node("var", v)
        raise DSLError(f"語法錯誤：意外的 {v!r}")


def parse(s): return Parser(str(s)).parse()


# ------------------------------------------------------------------ functions (whitelist)
def _shift(x, k):
    k = int(k); out = np.full(len(x), np.nan)
    if k == 0: return x.copy()
    if k < len(x): out[k:] = x[:-k]
    return out


def _roll(x, n, f):
    n = int(n); out = np.full(len(x), np.nan)
    for i in range(n - 1, len(x)):
        w = x[i - n + 1:i + 1]
        out[i] = np.nan if np.isnan(w).any() else f(w)
    return out


def _b(x): return np.where(np.isnan(x), 0.0, (x != 0).astype(float))


def _cmp(op, a, b):
    with np.errstate(invalid="ignore"):
        r = {">": a > b, ">=": a >= b, "<": a < b, "<=": a <= b, "==": a == b, "!=": a != b}[op]
    return np.where(np.isnan(a) | np.isnan(b), 0.0, r.astype(float))


FUNCS = {  # name: (arity(s), window-arg positions, fn(env, *args))
    "sma": ((2,), (1,), lambda E, x, n: ind.sma(x, int(n))),
    "ema": ((2,), (1,), lambda E, x, n: ind.ema(x, int(n))),
    "avg_vol": ((1, 2), (0, 1), lambda E, n, ex=1.0: ind.avg_prev(E["volume"], int(n)) if ex else ind.sma(E["volume"], int(n))),
    "slope_pct": ((2,), (1,), lambda E, x, k: x / _shift(x, k) - 1),
    "ref": ((2,), (1,), lambda E, x, k: _shift(x, k)),
    "cross_up": ((2,), (), lambda E, a, b: _b(_cmp("<=", _shift(a, 1), _shift(b, 1))) * _b(_cmp(">", a, b))),
    "cross_down": ((2,), (), lambda E, a, b: _b(_cmp(">=", _shift(a, 1), _shift(b, 1))) * _b(_cmp("<", a, b))),
    "highest": ((2,), (1,), lambda E, x, n: _roll(x, n, np.max)),
    "lowest": ((2,), (1,), lambda E, x, n: _roll(x, n, np.min)),
    "count": ((2,), (1,), lambda E, c, n: _roll(_b(c), n, np.sum)),
    "min": ((2,), (), lambda E, a, b: np.where(np.isnan(a) | np.isnan(b), np.nan, np.minimum(a, b))),
    "max": ((2,), (), lambda E, a, b: np.where(np.isnan(a) | np.isnan(b), np.nan, np.maximum(a, b))),
    "abs": ((1,), (), lambda E, x: np.abs(x)),
}


def _const(node):
    if node[0] == "num": return node[1]
    if node[0] == "neg" and node[1][0] == "num": return -node[1][1]
    return None


def check(node, names, where=""):
    """Static validation: identifiers resolvable, functions whitelisted, arity ok, window args constant ≤ MAX_WIN."""
    errs = []
    def walk(n):
        k = n[0]
        if k == "var":
            if n[1] not in names: errs.append(f"{where}未知名稱 {n[1]!r}")
        elif k == "call":
            f, args = n[1], n[2]
            if f in RESERVED: errs.append(f"{where}{f}() 為內建型態專用的幾何函式，DSL v1 未開放"); return
            if f not in FUNCS: errs.append(f"{where}不允許的函式 {f}()（白名單：{', '.join(sorted(FUNCS))}）"); return
            ar, wins, _ = FUNCS[f]
            if len(args) not in ar: errs.append(f"{where}{f}() 參數數量應為 {'/'.join(map(str, ar))}"); return
            for i in wins:
                if i >= len(args): continue
                a = args[i]
                if a[0] == "var" and a[1] in names and names[a[1]] == "param": continue
                c = _const(a)
                if c is None: errs.append(f"{where}{f}() 第 {i + 1} 個參數必須是常數或參數")
                elif not (0 <= c <= MAX_WIN) or c != int(c): errs.append(f"{where}{f}() 回溯長度需為 0–{MAX_WIN} 的整數")
            for a in args: walk(a)
        elif k in ("bin", "cmp"): walk(n[2]); walk(n[3])
        elif k in ("and", "or"): walk(n[1]); walk(n[2])
        elif k in ("not", "neg"): walk(n[1])
    walk(node); return errs


def validate(d):
    """Return list of human-readable errors (empty = valid). Mirrors the §16.2 JSON Schema + expression checks."""
    E = []
    if not isinstance(d, dict): return ["定義必須是 JSON 物件"]
    for k in ("code", "name", "version", "directions", "params", "series", "states"):
        if k not in d: E.append(f"缺少必要欄位 {k}")
    if E: return E
    if not isinstance(d["code"], str) or not re.fullmatch(r"[a-z0-9_]+", d["code"]): E.append("code 只能用小寫英數與底線")
    if not isinstance(d["version"], int) or d["version"] < 1: E.append("version 必須是 ≥1 的整數")
    if not isinstance(d["directions"], list) or not d["directions"] or any(x not in ("long", "short") for x in d["directions"]): E.append("directions 只能含 long／short")
    if d.get("role", "standard") not in ("baseline", "experiment", "standard"): E.append("role 不合法")
    if d.get("native_exit", "X3") not in ("X2", "X3"): E.append("native_exit 只能是 X2 或 X3")
    if not isinstance(d["params"], dict): E.append("params 必須是物件"); return E
    names = {b: "base" for b in BASE}
    for p, spec in d["params"].items():
        if not re.fullmatch(r"[a-z_][a-z0-9_]*", p): E.append(f"參數名 {p!r} 不合法")
        if not isinstance(spec, dict) or "default" not in spec: E.append(f"參數 {p} 缺 default"); continue
        if not isinstance(spec["default"], (int, float)) or isinstance(spec["default"], bool): E.append(f"參數 {p} 的 default 必須是數字")
        names[p] = "param"
    if not isinstance(d["series"], dict) or len(d["series"]) > MAX_SERIES: E.append(f"series 必須是物件且 ≤ {MAX_SERIES} 個"); return E
    for s, expr in d["series"].items():
        if s in names or s in FUNCS or s in RESERVED or not re.fullmatch(r"[a-z_][a-z0-9_]*", s): E.append(f"series 名稱 {s!r} 重複或不合法"); continue
        try: E += check(parse(expr), names, f"series.{s}：")
        except DSLError as e: E.append(f"series.{s}：{e}")
        names[s] = "series"   # only earlier names are visible → no recursion
    for f, expr in (d.get("strong_flags") or {}).items():
        try: E += check(parse(expr), names, f"strong_flags.{f}：")
        except DSLError as e: E.append(f"strong_flags.{f}：{e}")
        names[f] = "flag"
    if not isinstance(d["states"], list) or not d["states"] or len(d["states"]) > MAX_STATES: E.append(f"states 必須是 1–{MAX_STATES} 筆的陣列"); return E
    for i, st in enumerate(d["states"]):
        w = f"states[{i}]："
        if not isinstance(st, dict) or "state" not in st or "when" not in st: E.append(w + "需要 state 與 when"); continue
        if st["state"] not in STATES: E.append(w + f"state {st['state']!r} 不合法")
        if st.get("direction") not in ("long", "short", None): E.append(w + "direction 只能 long／short／null")
        if st.get("direction") and st["direction"] not in d["directions"]: E.append(w + f"direction {st['direction']} 不在 directions 內")
        if st.get("requires_position", "ANY") not in POS: E.append(w + "requires_position 不合法")
        for fld in ("when", "strength"):
            if fld in st:
                try: E += check(parse(st[fld]), names, w + f"{fld}：")
                except DSLError as e: E.append(w + f"{fld}：{e}")
        for lk, lexpr in (st.get("levels") or {}).items():
            try: E += check(parse(lexpr), names, w + f"levels.{lk}：")
            except DSLError as e: E.append(w + f"levels.{lk}：{e}")
    return E


# ------------------------------------------------------------------ evaluation
class Program:
    def __init__(self, d, params_override=None):
        errs = validate(d)
        if errs: raise DSLError("；".join(errs))
        self.d = d; self.code = d["code"]; self.min_bars = int(d.get("min_bars", 60))
        self.params = {k: float((params_override or {}).get(k, v["default"])) for k, v in d["params"].items()}
        self.series = [(k, parse(v)) for k, v in d["series"].items()]
        self.flags = [(k, parse(v)) for k, v in (d.get("strong_flags") or {}).items()]
        self.states = [dict(st, _when=parse(st["when"]), _str=parse(st["strength"]) if st.get("strength") else None,
                            _lv={k: parse(v) for k, v in (st.get("levels") or {}).items()}) for st in d["states"]]

    def env(self, o, h, l, c, v):
        n = len(c); E = dict(close=np.asarray(c, float), open=np.asarray(o, float), high=np.asarray(h, float),
                              low=np.asarray(l, float), volume=np.asarray(v, float))
        for k, p in self.params.items(): E[k] = np.full(n, p)
        for k, node in self.series: E[k] = self._ev(node, E)
        for k, node in self.flags: E[k] = _b(self._ev(node, E))
        E["_n"] = n; E["_cache"] = {}
        return E

    def _ev(self, n, E):
        k = n[0]
        if k == "num": return np.full(len(E["close"]), float(n[1]))
        if k == "var": return E[n[1]]
        if k == "neg": return -self._ev(n[1], E)
        if k == "not": return 1.0 - _b(self._ev(n[1], E))
        if k == "and": return _b(self._ev(n[1], E)) * _b(self._ev(n[2], E))
        if k == "or": return np.maximum(_b(self._ev(n[1], E)), _b(self._ev(n[2], E)))
        if k == "cmp": return _cmp(n[1], self._ev(n[2], E), self._ev(n[3], E))
        if k == "bin":
            a, b = self._ev(n[2], E), self._ev(n[3], E)
            with np.errstate(all="ignore"):
                if n[1] == "+": return a + b
                if n[1] == "-": return a - b
                if n[1] == "*": return a * b
                r = a / b; r[~np.isfinite(r)] = np.nan; return r
        if k == "call":
            f, args = n[1], n[2]; ar, wins, fn = FUNCS[f]
            vals = []
            for i, a in enumerate(args):
                if i in wins:
                    c = _const(a); vals.append(c if c is not None else float(E[a[1]][0]))
                else: vals.append(self._ev(a, E))
            return fn(E, *vals)
        raise DSLError(f"未知節點 {k}")

    def _cached(self, E, key, node):
        c = E["_cache"]
        if key not in c: c[key] = self._ev(node, E)
        return c[key]

    def state_at(self, E, t, position="NONE", shortable=None):
        if t < self.min_bars - 1: return dict(state="NO_DATA", direction=None, reasons=[], strength=None, levels={}, strong=False)
        for i, st in enumerate(self.states):
            rp = st.get("requires_position", "ANY")
            if rp != "ANY" and rp != position: continue
            if not self._cached(E, ("w", i), st["_when"])[t]: continue
            d = st.get("direction")
            if st["state"] == "ENTRY" and d == "short" and shortable is False: continue   # PatternEngine 統一套用 shortable()
            strength = None
            if st["_str"] is not None:
                sv = self._cached(E, ("s", i), st["_str"])[t]; strength = None if math.isnan(sv) else float(sv)
            lv = {k: float(self._cached(E, ("l", i, k), node)[t]) for k, node in st["_lv"].items()}
            strong = any(E[k][t] for k, _ in self.flags)
            rs = [st.get("note") or f"DSL：{st['when']}"]
            return dict(state=st["state"], direction=d, reasons=rs, strength=strength, levels=lv, strong=bool(strong))
        return dict(state="WATCH", direction=None, reasons=[], strength=None, levels={}, strong=False)


def ctx_fn(prog):
    """Adapter with the same call shape as cis.evaluate_*(ctx, t, position) for engine / backtest use."""
    def fn(ctx, t, position="NONE"):
        E = getattr(ctx, "_dsl_env", {}).get(prog.code)
        if E is None:
            E = prog.env(ctx.o, ctx.h, ctx.l, ctx.c, ctx.v)
            if not hasattr(ctx, "_dsl_env"): ctx._dsl_env = {}
            ctx._dsl_env[prog.code] = E
        return prog.state_at(E, t, position, ctx.shortable)
    return fn
