"""SQLite main DB (§14.1, §14.4) — market-data tables used by the batch.

User-data tables (patterns, scan_runs, scan_hits …) are created too so later phases
(P4 alerts, P5 backtest, P8 backup) can resume on the same file.
Extension vs §14.4: daily_bars gains `chg`, `chg_known` (exchange 漲跌價差, used by Adjuster).
"""
import os, sqlite3

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(HERE, "db", "radar.sqlite")

SCHEMA = """
CREATE TABLE IF NOT EXISTS instruments (
  symbol TEXT PRIMARY KEY, name TEXT NOT NULL, market TEXT CHECK(market IN ('TWSE','TPEx')),
  type TEXT CHECK(type IN ('stock','etf','etn','other')), sector_code TEXT, sector_name TEXT,
  listed_date TEXT, delisted_date TEXT, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS daily_bars (
  symbol TEXT, date TEXT, open REAL, high REAL, low REAL, close REAL,
  volume_shares INTEGER, turnover REAL, trades INTEGER, source TEXT, fetched_at TEXT,
  chg REAL, chg_known INTEGER, PRIMARY KEY(symbol, date));
CREATE INDEX IF NOT EXISTS ix_bars_date ON daily_bars(date);
CREATE TABLE IF NOT EXISTS trading_days (date TEXT PRIMARY KEY, twse INTEGER, tpex INTEGER);
CREATE TABLE IF NOT EXISTS corporate_actions (
  symbol TEXT, ex_date TEXT, kind TEXT, cash_div REAL, stock_div_ratio REAL, split_ratio REAL,
  ref_price REAL, source TEXT, prev_close REAL, PRIMARY KEY(symbol, ex_date, kind));
CREATE TABLE IF NOT EXISTS adj_factors (symbol TEXT, date TEXT, factor REAL, PRIMARY KEY(symbol, date));
CREATE TABLE IF NOT EXISTS institutional_flows (
  symbol TEXT, date TEXT, foreign_net INTEGER, trust_net INTEGER, dealer_net INTEGER, total_net INTEGER,
  PRIMARY KEY(symbol, date));
CREATE TABLE IF NOT EXISTS margin_daily (symbol TEXT, date TEXT, margin_bal INTEGER, short_bal INTEGER,
  short_allowed INTEGER, PRIMARY KEY(symbol, date));
CREATE TABLE IF NOT EXISTS restrictions (symbol TEXT, kind TEXT CHECK(kind IN ('disposal','full_delivery')),
  start_date TEXT, end_date TEXT, note TEXT, PRIMARY KEY(symbol, kind, start_date));
CREATE TABLE IF NOT EXISTS scan_runs (
  id TEXT PRIMARY KEY, run_key TEXT UNIQUE, trade_date TEXT, started_at TEXT, finished_at TEXT, status TEXT,
  data_as_of TEXT, stats_json TEXT, updated_at TEXT NOT NULL, updated_by_device TEXT, deleted INTEGER DEFAULT 0,
  version INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS scan_hits (
  id TEXT PRIMARY KEY, run_id TEXT REFERENCES scan_runs(id), pattern_id TEXT, pattern_ver INTEGER,
  symbol TEXT, direction TEXT, state TEXT, strength REAL, levels_json TEXT, geometry_json TEXT,
  reasons_json TEXT, fundamental_pass INTEGER, updated_at TEXT NOT NULL, updated_by_device TEXT,
  deleted INTEGER DEFAULT 0, version INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS monthly_revenue (symbol TEXT, ym TEXT, revenue REAL, mom REAL, yoy REAL, cum_yoy REAL,
  announced_at TEXT, source TEXT, PRIMARY KEY(symbol, ym));
CREATE TABLE IF NOT EXISTS quarterly_financials (symbol TEXT, yq TEXT, eps REAL, gross_margin REAL, op_margin REAL,
  net_margin REAL, net_income REAL, equity REAL, roe_ttm REAL, announced_at TEXT, eps_basis TEXT, roe_basis TEXT, source TEXT,
  PRIMARY KEY(symbol, yq));
CREATE TABLE IF NOT EXISTS valuation_daily (symbol TEXT, date TEXT, pe REAL, pb REAL, dividend_yield REAL,
  PRIMARY KEY(symbol, date));
CREATE TABLE IF NOT EXISTS patterns (
  id TEXT PRIMARY KEY, code TEXT UNIQUE, name TEXT, directions_json TEXT,
  role TEXT CHECK(role IN ('baseline','experiment','standard')), native_exit TEXT CHECK(native_exit IN ('X2','X3')), builtin INTEGER,
  current_version INTEGER, enabled INTEGER, confirmed_by_jay INTEGER DEFAULT 0,
  updated_at TEXT NOT NULL, updated_by_device TEXT, deleted INTEGER DEFAULT 0, version INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS pattern_versions (
  id TEXT PRIMARY KEY, pattern_id TEXT REFERENCES patterns(id), ver INTEGER, definition_json TEXT,
  note TEXT, updated_at TEXT NOT NULL, updated_by_device TEXT, deleted INTEGER DEFAULT 0, version INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS watchlist (
  id TEXT PRIMARY KEY, symbol TEXT, position TEXT CHECK(position IN ('NONE','LONG','SHORT')),
  note TEXT, updated_at TEXT NOT NULL, updated_by_device TEXT, deleted INTEGER DEFAULT 0, version INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS alert_settings (
  id TEXT PRIMARY KEY, pattern_ids_json TEXT, recipients_json TEXT, schedule_cron TEXT,
  cooldown_days INTEGER, max_rows INTEGER, send_empty_digest INTEGER, fundamental_rules_json TEXT,
  updated_at TEXT NOT NULL, updated_by_device TEXT, deleted INTEGER DEFAULT 0, version INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS alert_log (
  id TEXT PRIMARY KEY, dedupe_key TEXT UNIQUE, trade_date TEXT, pattern_id TEXT, symbol TEXT,
  direction TEXT, state TEXT, sent_at TEXT, message_id TEXT, status TEXT,
  updated_at TEXT NOT NULL, updated_by_device TEXT, deleted INTEGER DEFAULT 0, version INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS fundamental_rules (
  id TEXT PRIMARY KEY, name TEXT, rules_json TEXT, updated_at TEXT NOT NULL, updated_by_device TEXT,
  deleted INTEGER DEFAULT 0, version INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value_json TEXT, updated_at TEXT NOT NULL,
  updated_by_device TEXT, deleted INTEGER DEFAULT 0, version INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS devices (device_id TEXT PRIMARY KEY, label TEXT, created_at TEXT, last_seen_at TEXT);
CREATE TABLE IF NOT EXISTS sync_meta (device_id TEXT, table_name TEXT, last_pushed_at TEXT, last_pulled_at TEXT,
  clock_skew_ms INTEGER, PRIMARY KEY(device_id, table_name));
CREATE TABLE IF NOT EXISTS backups (id TEXT PRIMARY KEY, created_at TEXT, schema_version INTEGER, size_bytes INTEGER,
  remote_path TEXT, checksum TEXT);
CREATE TABLE IF NOT EXISTS backtest_runs (
  id TEXT PRIMARY KEY, config_json TEXT, pattern_versions_json TEXT, exit_sets_json TEXT, short_extra_cost REAL DEFAULT 0, data_cutoff TEXT,
  status TEXT, metrics_json TEXT, updated_at TEXT NOT NULL, updated_by_device TEXT, deleted INTEGER DEFAULT 0, version INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS backtest_trades (
  id TEXT PRIMARY KEY, run_id TEXT, symbol TEXT, sector_code TEXT, pattern_id TEXT, direction TEXT,
  exit_set TEXT CHECK(exit_set IN ('X1','X2','X3')), entry_group_id TEXT, signal_date TEXT, entry_date TEXT, entry_price REAL,
  exit_date TEXT, exit_price REAL, net_return REAL, hold_days INTEGER, exit_reason TEXT, sample TEXT CHECK(sample IN ('IS','OOS')),
  updated_at TEXT NOT NULL, updated_by_device TEXT, deleted INTEGER DEFAULT 0, version INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS sector_scores (
  id TEXT PRIMARY KEY, run_id TEXT, direction TEXT, pattern_id TEXT, sector_code TEXT, n_members INTEGER, hits INTEGER,
  forming INTEGER, hit_ratio REAL, avg_strength REAL, score REAL, updated_at TEXT NOT NULL,
  updated_by_device TEXT, deleted INTEGER DEFAULT 0, version INTEGER DEFAULT 1);
"""


def connect(path=None):
    path = path or os.environ.get("RADAR_DB") or DB_PATH   # RADAR_DB: tests / alternate DB
    os.makedirs(os.path.dirname(path), exist_ok=True)
    con = sqlite3.connect(path)
    con.executescript(SCHEMA)
    return con
