"""SectorAggregator (§7). All weights/thresholds = 補定義 defaults in config['sector'] (A9).

hits      = signals with state ∈ {ENTRY, CONFIRMED} in direction d. CONFIRMED includes patterns confirmed
            within the last track_days and still valid (fresh=False) — ENGINE choice, flagged in output.
forming   = FORMING count; hit_ratio = hits/N_s; avg_str = mean strength of hits
inst_ratio= share of hits whose 三大法人 net is in the trade direction (long: 買超, short: 賣超), among hits with data
score     = w1·hit_ratio·100 + w2·avg_str + w3·(forming/N_s)·100 + w4·inst_ratio·100
"""
from collections import defaultdict

HIT_STATES = ("ENTRY", "CONFIRMED")


def aggregate(signals, members, names, p, patterns):
    """members: {sector_code: N valid universe symbols}; patterns: list of (pid, directions)."""
    out = []
    by = defaultdict(list)
    for s in signals:
        by[(s["direction"], s["patternId"], s.get("sector_code"))].append(s)
    for pid, dirs in patterns:
        for d in dirs:
            for sc, n in members.items():
                sig = by.get((d, pid, sc), [])
                hits = [s for s in sig if s["state"] in HIT_STATES]
                forming = sum(1 for s in sig if s["state"] == "FORMING")
                hit_ratio = len(hits) / n if n else 0.0
                strs = [s["strength"] for s in hits if s.get("strength") is not None]
                avg = sum(strs) / len(strs) if strs else 0.0
                withinst = [s for s in hits if s.get("instNet") is not None]
                same = sum(1 for s in withinst if (s["instNet"] > 0 if d == "long" else s["instNet"] < 0))
                inst_ratio = same / len(withinst) if withinst else 0.0
                score = (p["w1"] * hit_ratio * 100 + p["w2"] * avg + p["w3"] * (forming / n if n else 0) * 100
                         + p["w4"] * inst_ratio * 100)
                small = n < p["min_members"]
                out.append(dict(direction=d, pattern_id=pid, sector_code=sc, sector_name=names.get(sc, sc), n_members=n,
                                hits=len(hits), hits_fresh=sum(1 for s in hits if s.get("fresh")), forming=forming,
                                hit_ratio=round(hit_ratio, 4), avg_strength=round(avg, 1), inst_ratio=round(inst_ratio, 3),
                                score=round(score, 2), small=small,
                                is_hit=(not small) and len(hits) >= p["min_hits"] and hit_ratio >= p["min_ratio"]))
    return out
