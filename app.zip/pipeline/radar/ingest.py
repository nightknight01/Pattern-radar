"""Ingestion (§4, §9): parse official TWSE / TPEx reports into the SQLite tables.

Sources (all official, verified 2026-11-19):
- 上市日K   TWSE rwd MI_INDEX?type=ALLBUT0999 (每日收盤行情)
- 上櫃日K   TPEx www/zh-tw/afterTrading/otc (POST, type=EW)
- 產業別    TWSE OpenAPI t187ap03_L ; TPEx OpenAPI mopsfin_t187ap03_O
- 除權息    TWSE rwd exRight/TWT49U ; TPEx www bulletin/exDailyQ
- 三大法人  TWSE rwd fund/T86 ; TPEx www insti/dailyTrade
- 融資融券  TWSE rwd marginTrading/MI_MARGN ; TPEx www margin/balance
- 處置      TWSE rwd announcement/punish ; TPEx OpenAPI tpex_disposal_information
- 全額交割  TWSE OpenAPI TWT85U ; TPEx OpenAPI tpex_cmode
"""
from __future__ import annotations
import datetime as dt, json, os, re, shutil, glob
from .dataproxy import fetch_json, cache_path, RAW_DIR

NOW = lambda: dt.datetime.now().isoformat(timespec="seconds")

SECTOR_NAMES = {
    "01": "水泥工業", "02": "食品工業", "03": "塑膠工業", "04": "紡織纖維", "05": "電機機械", "06": "電器電纜",
    "08": "玻璃陶瓷", "09": "造紙工業", "10": "鋼鐵工業", "11": "橡膠工業", "12": "汽車工業", "14": "建材營造",
    "15": "航運業", "16": "觀光餐旅", "17": "金融保險", "18": "貿易百貨", "19": "綜合", "20": "其他",
    "21": "化學工業", "22": "生技醫療", "23": "油電燃氣", "24": "半導體業", "25": "電腦及週邊設備業",
    "26": "光電業", "27": "通信網路業", "28": "電子零組件業", "29": "電子通路業", "30": "資訊服務業",
    "31": "其他電子業", "32": "文化創意業", "33": "農業科技業", "34": "電子商務", "35": "綠能環保",
    "36": "數位雲端", "37": "運動休閒", "38": "居家生活", "80": "管理股票", "91": "存託憑證", "ETF": "ETF",
}


def num(s):
    if s is None: return None
    s = re.sub("<[^>]+>", "", str(s)).replace(",", "").strip()
    if s in ("", "--", "---", "----", "X"): return None
    try: return float(s)
    except ValueError: return None


def roc_to_iso(s):
    s = re.sub(r"\s", "", str(s))
    m = re.match(r"(\d{2,3})[年/](\d{1,2})[月/](\d{1,2})", s) or re.match(r"(\d{3})(\d{2})(\d{2})$", s)
    if not m: return None
    return dt.date(int(m.group(1)) + 1911, int(m.group(2)), int(m.group(3))).isoformat()


def classify(code, name):
    """Universe instrument type. Common stock = 4 digits; ETF = 00xx(x)(letter)."""
    if re.fullmatch(r"[1-9]\d{3}", code): return "stock"
    if re.fullmatch(r"00\d{2,4}[A-Z]?", code): return "etf"
    return None  # preferred shares, ETN, TDR-like, warrants … excluded


# ---------------------------------------------------------------- seeding
SEED_DIRS = ["/workspace/kd_cache", "/workspace/macd_20261027/raw", "/workspace/macd_20261023/raw",
             "/workspace/rsi_screen/raw"]


def seed_from_existing():
    """Copy (read-only) previously downloaded official MI_INDEX / TPEx otc JSON from other
    box projects into our raw cache, after validating stat+date. Returns count copied."""
    n = 0
    for d in SEED_DIRS:
        for f in glob.glob(os.path.join(d, "twse_2*.json")) + glob.glob(os.path.join(d, "tpex_2*.json")):
            base = os.path.basename(f)
            m = re.match(r"(twse|tpex)_(\d{8})\.json$", base)
            if not m: continue
            kind, ds = m.groups()
            dst = cache_path(f"{kind}_{ds}.json")
            if os.path.exists(dst): continue
            try:
                j = json.load(open(f))
                if kind == "twse":
                    if j.get("stat") != "OK" or j.get("date") != ds: continue
                else:
                    t = (j.get("tables") or [{}])[0]
                    d0 = dt.date(int(ds[:4]), int(ds[4:6]), int(ds[6:]))
                    if t.get("date") != f"{d0.year-1911}/{d0:%m/%d}" or not t.get("data"): continue
                shutil.copyfile(f, dst); n += 1
            except Exception:
                continue
    return n


# ---------------------------------------------------------------- daily quotes
def fetch_twse_day(d: dt.date):
    ds = d.strftime("%Y%m%d")
    return fetch_json("twse", f"https://www.twse.com.tw/rwd/zh/afterTrading/MI_INDEX?date={ds}&type=ALLBUT0999&response=json",
                      f"twse_{ds}.json", ok=lambda j: j.get("stat") == "OK" and j.get("date") == ds)


def parse_twse_day(j, d: dt.date):
    if not j or j.get("stat") != "OK": return None
    tb = [t for t in j.get("tables", []) if "每日收盤行情" in (t.get("title") or "")]
    if not tb: return None
    rows = []
    for r in tb[0]["data"]:
        code, name = r[0].strip(), r[1].strip()
        if not classify(code, name): continue
        sign = re.sub("<[^>]+>", "", r[9]).strip()
        ch = num(r[10])
        if sign == "+": chg, known = ch, 1
        elif sign == "-": chg, known = (-ch if ch is not None else None), 1
        elif sign == "" and ch is not None: chg, known = ch, 1  # unchanged (0.00)
        else: chg, known = None, 0                                   # 'X' = 除權息/特殊 → sign unknown
        rows.append(dict(symbol=code, name=name, market="TWSE", date=d.isoformat(), open=num(r[5]), high=num(r[6]),
                         low=num(r[7]), close=num(r[8]), volume_shares=num(r[2]), turnover=num(r[4]),
                         trades=num(r[3]), chg=chg, chg_known=known, source="TWSE MI_INDEX"))
    return rows


def fetch_tpex_day(d: dt.date):
    roc = f"{d.year-1911}/{d:%m/%d}"
    return fetch_json("tpex", "https://www.tpex.org.tw/www/zh-tw/afterTrading/otc", f"tpex_{d:%Y%m%d}.json", "POST",
                      {"date": d.strftime("%Y/%m/%d"), "type": "EW", "response": "json"},
                      ok=lambda j: bool(j.get("tables")) and j["tables"][0].get("date") == roc and bool(j["tables"][0].get("data")))


def parse_tpex_day(j, d: dt.date):
    if not j or not j.get("tables"): return None
    t = j["tables"][0]
    if t.get("date") != f"{d.year-1911}/{d:%m/%d}" or not t.get("data"): return None
    rows = []
    for r in t["data"]:
        code, name = str(r[0]).strip(), str(r[1]).strip()
        if not classify(code, name): continue
        chs = str(r[3]).strip()
        ch = num(chs) if re.fullmatch(r"[+-]?\d+(\.\d+)?", chs.replace(",", "")) else None
        rows.append(dict(symbol=code, name=name, market="TPEx", date=d.isoformat(), open=num(r[4]), high=num(r[5]),
                         low=num(r[6]), close=num(r[2]), volume_shares=num(r[7]), turnover=num(r[8]), trades=num(r[9]),
                         chg=ch, chg_known=1 if ch is not None else 0, source="TPEx afterTrading/otc"))
    return rows


def store_bars(con, rows):
    now = NOW()
    con.executemany(
        "INSERT OR REPLACE INTO daily_bars VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
        [(r["symbol"], r["date"], r["open"], r["high"], r["low"], r["close"],
          int(r["volume_shares"]) if r["volume_shares"] is not None else None, r["turnover"],
          int(r["trades"]) if r["trades"] is not None else None, r["source"], now, r["chg"], r["chg_known"])
         for r in rows if r["close"] is not None and r["open"] is not None and (r["volume_shares"] or 0) > 0])


def ingest_range(con, start: dt.date, end: dt.date, log=print):
    """Fetch every weekday in [start, end]; 查無資料 days are recorded as non-trading only when BOTH
    markets say so and the date is > 2 days old (avoids caching 'not yet published')."""
    known = {r[0] for r in con.execute("SELECT date FROM trading_days")}
    names = {}
    d = start
    while d <= end:
        if d.weekday() < 5 and d.isoformat() not in known:
            a = parse_twse_day(fetch_twse_day(d), d)
            b = parse_tpex_day(fetch_tpex_day(d), d)
            if a or b:
                store_bars(con, (a or []) + (b or []))
                for r in (a or []) + (b or []): names[r["symbol"]] = (r["name"], r["market"])
                if a and b:
                    con.execute("INSERT OR REPLACE INTO trading_days VALUES (?,?,?)", (d.isoformat(), 1, 1))
                log(f"{d} twse={len(a or [])} tpex={len(b or [])}")
            else:
                log(f"{d} 查無資料（休市或未公布）")
                if (dt.date.today() - d).days > 2:
                    con.execute("INSERT OR REPLACE INTO trading_days VALUES (?,?,?)", (d.isoformat(), 0, 0))
            con.commit()
        d += dt.timedelta(days=1)
    return names


# ---------------------------------------------------------------- instruments / sectors
def ingest_instruments(con, today: dt.date):
    tag = today.strftime("%Y%m%d")
    L = fetch_json("twse_openapi", "https://openapi.twse.com.tw/v1/opendata/t187ap03_L", f"t187ap03_L_{tag}.json",
                   ok=lambda j: isinstance(j, list) and len(j) > 500)
    O = fetch_json("tpex_openapi", "https://www.tpex.org.tw/openapi/v1/mopsfin_t187ap03_O", f"t187ap03_O_{tag}.json",
                   ok=lambda j: isinstance(j, list) and len(j) > 300)
    sector = {}
    for r in L or []:
        sector[r["公司代號"].strip()] = (r["產業別"].strip(), "TWSE", roc_to_iso(r.get("上市日期", "")) if len(r.get("上市日期", "")) == 8 else None)
    for r in O or []:
        sector[r["SecuritiesCompanyCode"].strip()] = (r["SecuritiesIndustryCode"].strip(), "TPEx", None)
    # names/markets from latest bars
    latest = {}
    for sym, src in con.execute("SELECT symbol, source FROM daily_bars GROUP BY symbol"):
        latest[sym] = "TWSE" if src.startswith("TWSE") else "TPEx"
    now = NOW(); rows = []
    for sym, mkt in latest.items():
        typ = "etf" if sym.startswith("00") else "stock"
        sc, m2, ld = sector.get(sym, ("ETF" if typ == "etf" else None, mkt, None))
        rows.append((sym, sym, mkt, typ, sc, SECTOR_NAMES.get(sc, "未分類" if sc is None else f"產業{sc}"), None, None, now))
    con.executemany("INSERT OR REPLACE INTO instruments VALUES (?,?,?,?,?,?,?,?,?)", rows)
    con.commit()
    return {"twse_list": len(L or []), "tpex_list": len(O or []), "instruments": len(rows),
            "ok": bool(L) and bool(O)}


def update_names(con, names):
    con.executemany("UPDATE instruments SET name=? WHERE symbol=?", [(n, s) for s, (n, m) in names.items()])
    con.commit()


# ---------------------------------------------------------------- corporate actions
def ingest_exrights(con, start: dt.date, end: dt.date):
    n = 0; ok = True
    s = start
    while s <= end:
        e = min(end, (s.replace(day=28) + dt.timedelta(days=4)).replace(day=1) - dt.timedelta(days=1))  # month end
        tag = f"{s:%Y%m%d}_{e:%Y%m%d}"
        final = (dt.date.today() - e).days > 2
        j = fetch_json("twse", f"https://www.twse.com.tw/rwd/zh/exRight/TWT49U?startDate={s:%Y%m%d}&endDate={e:%Y%m%d}&response=json",
                       f"twt49u_{tag}.json" if final else None, ok=lambda j: j.get("stat") == "OK")
        if j is None: ok = False
        for r in (j or {}).get("data", []) if j and j.get("stat") == "OK" else []:
            con.execute("INSERT OR REPLACE INTO corporate_actions VALUES (?,?,?,?,?,?,?,?,?)",
                        (r[1].strip(), roc_to_iso(r[0]), r[6].strip(), None, None, None, num(r[4]), "TWSE TWT49U", num(r[3]))); n += 1
        j = fetch_json("tpex", f"https://www.tpex.org.tw/www/zh-tw/bulletin/exDailyQ?startDate={s:%Y/%m/%d}&endDate={e:%Y/%m/%d}&response=json",
                       f"exdailyq_{tag}.json" if final else None, ok=lambda j: bool(j.get("tables")))
        if j is None: ok = False
        for r in ((j or {}).get("tables") or [{}])[0].get("data") or []:
            con.execute("INSERT OR REPLACE INTO corporate_actions VALUES (?,?,?,?,?,?,?,?,?)",
                        (str(r[1]).strip(), roc_to_iso(r[0]), str(r[8]).strip(), num(r[13]), None, None, num(r[4]), "TPEx exDailyQ", num(r[3]))); n += 1
        con.commit()
        s = e + dt.timedelta(days=1)
    return {"rows": n, "ok": ok}


# ---------------------------------------------------------------- chips: institutions, margin
def ingest_institutional(con, d: dt.date):
    ds = d.strftime("%Y%m%d"); res = {"twse": 0, "tpex": 0}
    j = fetch_json("twse", f"https://www.twse.com.tw/rwd/zh/fund/T86?date={ds}&selectType=ALLBUT0999&response=json",
                   f"t86_{ds}.json", ok=lambda j: j.get("stat") == "OK")
    if j and j.get("stat") == "OK":
        for r in j["data"]:
            f_ = (num(r[4]) or 0) + (num(r[7]) or 0)
            con.execute("INSERT OR REPLACE INTO institutional_flows VALUES (?,?,?,?,?,?)",
                        (r[0].strip(), d.isoformat(), int(f_), int(num(r[10]) or 0), int(num(r[11]) or 0), int(num(r[18]) or 0)))
            res["twse"] += 1
    j = fetch_json("tpex", f"https://www.tpex.org.tw/www/zh-tw/insti/dailyTrade?type=Daily&sect=EW&date={d:%Y%%2F%m%%2F%d}&response=json",
                   f"tpex_insti_{ds}.json", ok=lambda j: bool(j.get("tables")) and bool(j["tables"][0].get("data"))
                   and j["tables"][0].get("date") == f"{d.year-1911}/{d:%m/%d}")
    if j and j.get("tables") and j["tables"][0].get("date") == f"{d.year-1911}/{d:%m/%d}":
        for r in j["tables"][0]["data"]:
            con.execute("INSERT OR REPLACE INTO institutional_flows VALUES (?,?,?,?,?,?)",
                        (str(r[0]).strip(), d.isoformat(), int(num(r[10]) or 0), int(num(r[13]) or 0), int(num(r[22]) or 0), int(num(r[23]) or 0)))
            res["tpex"] += 1
    con.commit()
    return res


def ingest_margin(con, d: dt.date):
    """short_allowed for next trading day: 1 = 信用交易標的且未停止融券, 0 = 非標的或停止融券."""
    ds = d.strftime("%Y%m%d"); res = {"twse": None, "tpex": None}
    j = fetch_json("twse", f"https://www.twse.com.tw/rwd/zh/marginTrading/MI_MARGN?date={ds}&selectType=ALL&response=json",
                   f"mi_margn_{ds}.json", ok=lambda j: j.get("stat") == "OK" and len(j.get("tables", [])) > 1)
    if j and j.get("stat") == "OK" and len(j.get("tables", [])) > 1:
        res["twse"] = 0
        for r in j["tables"][1]["data"]:
            mark = r[15].strip()
            allowed = 0 if ("X" in mark or "!" in mark or (num(r[13]) or 0) <= 0) else 1
            con.execute("INSERT OR REPLACE INTO margin_daily VALUES (?,?,?,?,?)",
                        (r[0].strip(), d.isoformat(), int(num(r[6]) or 0), int(num(r[12]) or 0), allowed)); res["twse"] += 1
    j = fetch_json("tpex", f"https://www.tpex.org.tw/www/zh-tw/margin/balance?date={d:%Y%%2F%m%%2F%d}&response=json",
                   f"tpex_margin_{ds}.json", ok=lambda j: bool(j.get("tables")) and j["tables"][0].get("date") == f"{d.year-1911}/{d:%m/%d}")
    if j and j.get("tables") and j["tables"][0].get("date") == f"{d.year-1911}/{d:%m/%d}":
        res["tpex"] = 0
        for r in j["tables"][0]["data"]:
            mark = str(r[19]).strip()
            allowed = 0 if (re.search(r"X|停止融券|停券|!", mark) or (num(r[17]) or 0) <= 0) else 1
            con.execute("INSERT OR REPLACE INTO margin_daily VALUES (?,?,?,?,?)",
                        (str(r[0]).strip(), d.isoformat(), int(num(r[6]) or 0), int(num(r[14]) or 0), allowed)); res["tpex"] += 1
    con.commit()
    return res


# ---------------------------------------------------------------- restrictions
def ingest_restrictions(con, T: dt.date, next_td: dt.date):
    """Disposal (處置) + full-delivery (全額交割/變更交易) active on T or next trading day."""
    con.execute("DELETE FROM restrictions")
    ok = {}
    def add(sym, kind, s, e, note):
        con.execute("INSERT OR REPLACE INTO restrictions VALUES (?,?,?,?,?)", (sym, kind, s, e, note))
    s0 = (T - dt.timedelta(days=60)).strftime("%Y%m%d")
    j = fetch_json("twse", f"https://www.twse.com.tw/rwd/zh/announcement/punish?startDate={s0}&endDate={next_td:%Y%m%d}&response=json",
                   f"twse_punish_{T:%Y%m%d}.json", ok=lambda j: j.get("stat") == "OK")
    ok["twse_punish"] = bool(j and j.get("stat") == "OK")
    for r in (j or {}).get("data", []) if ok["twse_punish"] else []:
        m = re.findall(r"(\d+/\d+/\d+)", r[6])
        if len(m) == 2:
            s, e = roc_to_iso(m[0]), roc_to_iso(m[1])
            if e >= T.isoformat() and s <= next_td.isoformat(): add(r[2].strip(), "disposal", s, e, f"TWSE處置 {r[6]}")
    j = fetch_json("tpex_openapi", "https://www.tpex.org.tw/openapi/v1/tpex_disposal_information", f"tpex_disp_{T:%Y%m%d}.json",
                   ok=lambda j: isinstance(j, list))
    ok["tpex_disposal"] = isinstance(j, list)
    for r in j or []:
        m = re.findall(r"\d{7}", r.get("DispositionPeriod", ""))
        if len(m) == 2:
            s, e = roc_to_iso(m[0]), roc_to_iso(m[1])
            if e >= T.isoformat() and s <= next_td.isoformat():
                add(r["SecuritiesCompanyCode"].strip(), "disposal", s, e, f"TPEx處置 {r['DispositionPeriod']}")
    j = fetch_json("twse_openapi", "https://openapi.twse.com.tw/v1/exchangeReport/TWT85U", f"twse_twt85u_{T:%Y%m%d}.json",
                   ok=lambda j: isinstance(j, list))
    ok["twse_full_delivery"] = isinstance(j, list)
    for r in j or []: add(r["Code"].strip(), "full_delivery", T.isoformat(), None, "TWSE變更交易")
    j = fetch_json("tpex_openapi", "https://www.tpex.org.tw/openapi/v1/tpex_cmode", f"tpex_cmode_{T:%Y%m%d}.json",
                   ok=lambda j: isinstance(j, list))
    ok["tpex_full_delivery"] = isinstance(j, list)
    for r in j or []:
        if str(r.get("AlteredTrading", "")).strip():
            add(r["SecuritiesCompanyCode"].strip(), "full_delivery", T.isoformat(), None, "TPEx變更交易")
    con.commit()
    return ok
