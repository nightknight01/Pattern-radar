"""Per-symbol evaluation context: adjusted OHLCV arrays + cached indicators/pivots."""
from __future__ import annotations
import numpy as np
from . import indicators as ind, pivots as pv


class Ctx:
    def __init__(self, dates, o, h, l, c, v, cfg, symbol="SYN", market="TWSE", sector=None,
                 inst_net=None, shortable=None, name=""):
        self.dates = list(dates)
        self.o, self.h, self.l, self.c, self.v = (np.asarray(x, float) for x in (o, h, l, c, v))
        self.n = len(self.c)
        self.cfg = cfg; self.cc = cfg["common"]
        self.symbol, self.market, self.sector, self.name = symbol, market, sector, name
        self.inst_net = inst_net          # 三大法人合計買賣超（股）on T, or None
        self.shortable = shortable        # True / False / None(unknown)
        self.a5 = ind.avg_prev(self.v, self.cc["vol_short_n"])
        self.a20 = ind.avg_prev(self.v, self.cc["vol_long_n"])
        with np.errstate(invalid="ignore"):
            self.vol_ok = (self.v >= self.a5 * self.cc["vol_short_mult"]) & (self.v >= self.a20 * self.cc["vol_long_mult"])
        cis = cfg["cis_common"]
        self.m5 = ind.sma(self.c, cis["ma_fast"]); self.m25 = ind.sma(self.c, cis["ma_slow"])
        self._piv_all = pv.compute(self.h, self.l, self.cc) if self.cc.get("pivot_method", "zigzag") == "zigzag" else None
        self._piv_cache = {}

    def piv(self, t):
        """Confirmed pivots usable at bar t (no look-ahead)."""
        if self._piv_all is not None:
            return [p for p in self._piv_all if p.confirm_idx <= t]
        if t not in self._piv_cache:  # fractal: recompute on the truncated series
            self._piv_cache[t] = pv.compute(self.h[:t + 1], self.l[:t + 1], self.cc)
        return self._piv_cache[t]

    def vol_ratio(self, t):
        a = self.a5[t]
        return float(self.v[t] / a) if a and a > 0 and not np.isnan(a) else None
