"""老王 SOP — 三個均線／缺口型態（Jay 2026-11-27 語音新增；規則為口述摘要的工程化，全部標「補定義・待確認」）。

四條均線（config["laowang"]，收盤價 SMA，工作假設）：
  MA5（週線）、MA10（雙週線）、MA20（月線；SOP 只講 5/10 日與 20 週，第四條用月線補上 → 補定義・待確認）、
  MA100（≈ 20 週線；日 K 上以 100 日近似 5 日 × 20 週）。
「上彎／下彎」= MA[t] 與 slope_lookback 根前相比的方向（預設 1 根）。

  lw_dragon  四海遊龍（多）：四線同時上彎（且收盤站上四線）的第一天 = ENTRY；持續 = HOLD；四線不再同步上彎 = EXIT_WARNING。
  lw_chu     四面楚歌（空）：四線同時下彎（且收盤跌破四線）的第一天 = ENTRY；持續 = HOLD；四線不再同步下彎 = EXIT_WARNING。
  lw_gapfill 空方缺口回補（多，止跌訊號）：gap_lookback 根內出現向下跳空缺口（今日最高 < 前日最低，缺口 ≥ gap_min_pct），
             之後收盤從未回到缺口上緣；今天收盤 ≥ 缺口上緣（前日最低）→ 缺口回補完成 = ENTRY。

持有者出場（回測 X3 與 position=LONG/SHORT）：多方收盤跌破 MA{exit_ma}（預設月線 MA20）→ EXIT；空方收盤站上 MA{exit_ma} → EXIT。
TAIEX 關鍵低點（taiex_key_lows）只用在台股加權指數的 K 線頁（參考線＋說明），不影響個股掃描。
"""
from __future__ import annotations
import math
import numpy as np
from . import indicators as ind

IDS = ("lw_dragon", "lw_chu", "lw_gapfill")


def _nan(x): return x is None or (isinstance(x, float) and math.isnan(x))


def _st(state, direction, reasons, strength=None, levels=None, geometry=None, note=None):
    return dict(state=state, direction=direction, reasons=reasons, strength=strength,
                levels=levels or {}, geometry=geometry or {}, note=note)


def mas(ctx):
    """四條均線（快取在 ctx 上）。回傳 [(n, array)]，依 ma_lengths 順序。"""
    p = ctx.cfg["laowang"]
    key = tuple(p["ma_lengths"])
    c = getattr(ctx, "_lw_cache", None)
    if c is None or c[0] != key:
        c = (key, [(n, ind.sma(ctx.c, n)) for n in key]); ctx._lw_cache = c
    return c[1]


def _dirs(ctx, t):
    """每條均線在 t 的方向：+1 上彎、-1 下彎、0 走平、None 資料不足。"""
    k = ctx.cfg["laowang"]["slope_lookback"]
    out = []
    for n, m in mas(ctx):
        if t - k < 0 or _nan(m[t]) or _nan(m[t - k]): out.append(None); continue
        out.append(1 if m[t] > m[t - k] else -1 if m[t] < m[t - k] else 0)
    return out


def _vals(ctx, t): return [float(m[t]) for _, m in mas(ctx)]


def _levels(ctx, t):
    p = ctx.cfg["laowang"]; lv = {f"ma{n}": round(float(m[t]), 4) for n, m in mas(ctx) if not _nan(m[t])}
    ex = _exit_ma(ctx, t)
    if not _nan(ex): lv["stopRef"] = round(float(ex), 4)
    return lv


def all_up(ctx, t):
    d = _dirs(ctx, t)
    if None in d or not all(x == 1 for x in d): return False
    if ctx.cfg["laowang"]["require_close_above"]: return bool(ctx.c[t] > max(_vals(ctx, t)))
    return True


def all_down(ctx, t):
    d = _dirs(ctx, t)
    if None in d or not all(x == -1 for x in d): return False
    if ctx.cfg["laowang"]["require_close_above"]: return bool(ctx.c[t] < min(_vals(ctx, t)))
    return True


def _ready(ctx, t):
    p = ctx.cfg["laowang"]
    return t >= max(p["min_bars"], max(p["ma_lengths"]) + p["slope_lookback"] + 1) - 1


def _exit_ma(ctx, t):
    p = ctx.cfg["laowang"]
    m = dict(mas(ctx)).get(p["exit_ma"])
    if m is None: m = ind.sma(ctx.c, p["exit_ma"])
    return m[t]


def _holder(ctx, t, direction):
    """持有者視角：多方收盤跌破 MA{exit_ma} → EXIT；空方收盤站上 → EXIT；否則 HOLD。"""
    p = ctx.cfg["laowang"]; m = _exit_ma(ctx, t); c = ctx.c[t]
    if _nan(m): return _st("HOLD", direction, [])
    if direction == "long" and c < m:
        return _st("EXIT", "long", [f"收盤 {c:.2f} 跌破 MA{p['exit_ma']} {m:.2f}（老王出場，補定義）"], levels=_levels(ctx, t))
    if direction == "short" and c > m:
        return _st("EXIT", "short", [f"收盤 {c:.2f} 站上 MA{p['exit_ma']} {m:.2f}（老王回補，補定義）"], levels=_levels(ctx, t))
    return _st("HOLD", direction, [], levels=_levels(ctx, t))


def _ma_text(ctx, t):
    return "、".join(f"MA{n} {float(m[t]):.2f}" for n, m in mas(ctx))


def _strength(ctx, t, direction):
    v = _vals(ctx, t)
    aligned = all(a > b for a, b in zip(v, v[1:])) if direction == "long" else all(a < b for a, b in zip(v, v[1:]))
    vol = bool(ctx.vol_ok[t]) if t < len(ctx.vol_ok) else False
    return 50 + 25 * vol + 25 * aligned, aligned, vol


def evaluate_dragon(ctx, t, position="NONE"):
    """四海遊龍（多）。"""
    if not _ready(ctx, t): return _st("NO_DATA", None, [])
    if position == "LONG": return _holder(ctx, t, "long")
    now, prev = all_up(ctx, t), all_up(ctx, t - 1)
    if now and not prev:
        st, aligned, vol = _strength(ctx, t, "long")
        rs = [f"四線同時上彎（{_ma_text(ctx, t)}）且收盤 {ctx.c[t]:.2f} 站上四線"]
        if aligned: rs.append("均線多頭排列（短 > 長）")
        if vol: rs.append("放量（量 ≥ 前5日均量×1.3 且 ≥ 前20日均量）")
        return _st("ENTRY", "long", rs, strength=st, levels=_levels(ctx, t))
    if now:
        return _st("HOLD", "long", ["四海遊龍持續：四線同步上彎（持有者參考）"], levels=_levels(ctx, t))
    if prev:
        return _st("EXIT_WARNING", "long", ["四線不再同步上彎（遊龍結束，持有者參考）"], levels=_levels(ctx, t))
    return _st("WATCH", None, [])


def evaluate_chu(ctx, t, position="NONE"):
    """四面楚歌（空）。"""
    if not _ready(ctx, t): return _st("NO_DATA", None, [])
    if position == "SHORT": return _holder(ctx, t, "short")
    now, prev = all_down(ctx, t), all_down(ctx, t - 1)
    if now and not prev:
        st, aligned, vol = _strength(ctx, t, "short")
        rs = [f"四線同時下彎（{_ma_text(ctx, t)}）且收盤 {ctx.c[t]:.2f} 跌破四線"]
        if aligned: rs.append("均線空頭排列（短 < 長）")
        if vol: rs.append("放量")
        return _st("ENTRY", "short", rs, strength=st, levels=_levels(ctx, t))
    if now:
        return _st("HOLD", "short", ["四面楚歌持續：四線同步下彎（持有者參考）"], levels=_levels(ctx, t))
    if prev:
        return _st("EXIT_WARNING", "short", ["四線不再同步下彎（持有者參考）"], levels=_levels(ctx, t))
    return _st("WATCH", None, [])


def find_open_down_gap(ctx, t):
    """t 之前（不含 t）gap_lookback 根內、到 t-1 為止收盤都還沒回補的向下缺口；取最近的一個。
    回傳 (g, top, bottom) 或 None。缺口：H[g] < L[g-1]×(1−gap_min_pct)；上緣 = L[g-1]，下緣 = H[g]。"""
    p = ctx.cfg["laowang"]; H, L, C = ctx.h, ctx.l, ctx.c
    lo = max(1, t - p["gap_lookback"])
    for g in range(t - 1, lo - 1, -1):
        top, bot = L[g - 1], H[g]
        if not (bot < top * (1 - p["gap_min_pct"])): continue
        if g + 1 <= t - 1 and np.max(C[g + 1:t]) >= top: continue      # 已經回補過
        if C[g] >= top: continue
        return g, float(top), float(bot)
    return None


def evaluate_gapfill(ctx, t, position="NONE"):
    """空方缺口回補（多）。"""
    if not _ready(ctx, t): return _st("NO_DATA", None, [])
    if position == "LONG": return _holder(ctx, t, "long")
    gp = find_open_down_gap(ctx, t)
    if not gp or not (ctx.c[t] >= gp[1]): return _st("WATCH", None, [])
    g, top, bot = gp; L = ctx.l
    low = float(np.min(L[g:t + 1])); size = top / bot - 1
    vol = bool(ctx.vol_ok[t])
    st = 50 + 25 * vol + 25 * min(1.0, size / 0.03)
    lv = _levels(ctx, t); lv.update(gapTop=round(top, 4), gapBottom=round(bot, 4), gapLow=round(low, 4))
    geo = dict(gap=dict(idx=g, top=round(top, 4), bottom=round(bot, 4)), Lmin=dict(idx=int(g + int(np.argmin(L[g:t + 1]))), price=round(low, 4)))
    rs = [f"{ctx.dates[g]} 向下跳空缺口 {bot:.2f}～{top:.2f}（{size * 100:.1f}%），今日收盤 {ctx.c[t]:.2f} 回補到缺口上緣",
          f"缺口後最低 {low:.2f}；空方缺口被回補 = 止跌訊號（老王 SOP，補定義）"]
    if vol: rs.append("放量")
    return _st("ENTRY", "long", rs, strength=round(st, 1), levels=lv, geometry=geo)


def key_low_notes(close, lows):
    """台股加權收盤相對老王關鍵低點的說明文字。"""
    out = []
    for x in lows:
        d = (close / x - 1) * 100
        out.append(f"老王關鍵低點 {x:,.2f}：收盤 {close:,.2f} {'高於' if close >= x else '低於'}此低點 {abs(d):.2f}%")
    return out
