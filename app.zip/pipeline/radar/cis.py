"""CIS 戰法 — §6.4 pseudo-code, two independent patterns: cis_base (舊規則) and cis_exp (Jay 實驗組).

SMA on close is a 工作假設; rules are 早期座談會二手摘錄 (must be labelled in UI/email).
"""
from __future__ import annotations
import math
import numpy as np

UP, DOWN, FLAT = "UP", "DOWN", "FLAT"


def _nan(x): return x is None or (isinstance(x, float) and math.isnan(x))


def ma25_slope(m25, t, p):
    k = t - p["slope_lookback"]
    if k < 0 or _nan(m25[k]) or _nan(m25[t]): return None
    r = m25[t] / m25[k] - 1
    return UP if r > p["slope_flat_band"] else DOWN if r < -p["slope_flat_band"] else FLAT


def features(ctx, t):
    p = ctx.cfg["cis_common"]; C, O, m5, m25 = ctx.c, ctx.o, ctx.m5, ctx.m25
    f = dict(slope=ma25_slope(m25, t, p), slopePrev=ma25_slope(m25, t - 1, p))
    f["longExit"] = C[t] < O[t] and C[t] < m5[t] and C[t] < m25[t] and (C[t-1] >= m5[t-1] or C[t-1] >= m25[t-1])
    f["longWarn"] = (C[t] < m25[t] and not f["longExit"]) or (f["slopePrev"] == UP and f["slope"] == DOWN)
    f["longHold"] = f["slope"] in (UP, FLAT) and C[t] > m5[t] and C[t] > m25[t]
    f["shortExit"] = C[t] > O[t] and C[t] > m5[t] and C[t] > m25[t] and (C[t-1] <= m5[t-1] or C[t-1] <= m25[t-1])
    f["shortWarn"] = (C[t] > m25[t] and not f["shortExit"]) or (f["slopePrev"] == DOWN and f["slope"] == UP)
    f["shortHold"] = f["slope"] == DOWN and C[t] < m5[t] and C[t] < m25[t]
    f["nearMA25"] = abs(C[t] - m25[t]) / m25[t] <= p["near_ma25_pct"]
    return f


def _state(state, direction, reasons, strength=None, strong=False, note=None):
    return dict(state=state, direction=direction, reasons=reasons, strength=strength, strong=strong, note=note)


def long_state_machine(f):
    if f["longExit"]: return _state("EXIT", "long", ["首根同時跌破 MA5 與 MA25 的陰線"])
    if f["longWarn"]: return _state("EXIT_WARNING", "long", ["收盤跌破 MA25 或 MA25 由上彎轉下彎"])
    if f["longHold"]: return _state("HOLD", "long", ["MA25 上彎/走平且收盤在兩線之上"],
                                    note="貼近 MA25，CIS 會先減碼（參考）" if f["nearMA25"] else None)
    return _state("WATCH", "long", [])


def short_state_machine(f):
    if f["shortExit"]: return _state("EXIT", "short", ["首根同時站上 MA5 與 MA25 的陽線"])
    if f["shortWarn"]: return _state("EXIT_WARNING", "short", ["收盤站上 MA25 或 MA25 由下彎轉上彎"])
    if f["shortHold"]: return _state("HOLD", "short", ["MA25 下彎且收盤在兩線之下"])
    return _state("WATCH", "short", [])


def scan_state(f):
    if f["longExit"]: return _state("EXIT", "long", ["首根同時跌破 MA5 與 MA25 的陰線（持有者參考）"])
    if f["longWarn"] and f["slope"] != DOWN: return _state("EXIT_WARNING", "long", ["出場警示（持有者參考）"])
    if f["longHold"]: return _state("HOLD", "long", ["續抱條件成立（持有者參考）"])
    if f["slope"] == DOWN: return _state("WATCH", None, [], note="MA25 下彎，不做多波段")
    return _state("WATCH", None, [])


def _reclaim(C, m5, k):
    return C[k - 1] < m5[k - 1] and C[k] > m5[k]


def evaluate_cis_base(ctx, t, position="NONE"):
    pc, pb = ctx.cfg["cis_common"], ctx.cfg["cis_base"]
    if t < pc["min_bars"] - 1 or _nan(ctx.m25[t - pc["slope_lookback"] - 1]): return _state("NO_DATA", None, [])
    C, m5, m25 = ctx.c, ctx.m5, ctx.m25
    f = features(ctx, t)
    entry = C[t-1] < m5[t-1] and C[t] > m5[t] and C[t] > m25[t] and f["slope"] in (UP, FLAT)
    lb = pb["second_reclaim_lookback"]
    second = any(_reclaim(C, m5, k) for k in range(max(1, t - lb), t))
    ladle = m5[t-2] > m5[t-1] and m5[t] > m5[t-1]
    strong = bool(entry and (second or ladle))
    if position == "LONG": return long_state_machine(f)
    if entry:
        rs = [f"前日收盤 {C[t-1]:.2f} < MA5 {m5[t-1]:.2f}，今日收盤 {C[t]:.2f} 站回 MA5 {m5[t]:.2f} 且 > MA25 {m25[t]:.2f}",
              f"MA25 {'上彎' if f['slope']==UP else '走平'}；不看量"]
        if second: rs.append(f"{lb} 日內第二次站回 MA5（較強）")
        if ladle: rs.append("MA5 柄杓型（較強）")
        return _state("ENTRY", "long", rs, strength=50 + 25 * strong + 25 * (f["slope"] == UP), strong=strong)
    return scan_state(f)


def evaluate_cis_exp(ctx, t, position="NONE"):
    pc, pe = ctx.cfg["cis_common"], ctx.cfg["cis_exp"]
    if t < pc["min_bars"] - 1 or _nan(ctx.m25[t - pc["slope_lookback"] - 1]): return _state("NO_DATA", None, [])
    C, V, m5, m25 = ctx.c, ctx.v, ctx.m5, ctx.m25
    f = features(ctx, t)
    a5, a20 = ctx.a5[t], ctx.a20[t]
    vol_ok = bool(V[t] >= a5 * pe["mult_short"] and V[t] >= a20 * pe["mult_long"])
    cross_up = m5[t-1] <= m25[t-1] and m5[t] > m25[t]
    cross_dn = m5[t-1] >= m25[t-1] and m5[t] < m25[t]
    long_e = cross_up and f["slope"] in (UP, FLAT) and vol_ok
    short_ok_slope = f["slope"] == DOWN or (not pe["short_requires_ma25_down"] and f["slope"] == FLAT)
    short_e = cross_dn and short_ok_slope and vol_ok and ctx.shortable is not False
    if position == "LONG": return long_state_machine(f)
    if position == "SHORT": return short_state_machine(f)
    vr = V[t] / a5 if a5 else 0
    if long_e:
        st = min(100, 50 + 25 * min(vr / pe["mult_short"] - 1, 1) + 25 * (f["slope"] == UP))
        return _state("ENTRY", "long", [f"MA5 {m5[t]:.2f} 上穿 MA25 {m25[t]:.2f}", f"放量：量/5日均量 {vr:.2f}（≥{pe['mult_short']}）且 ≥ 20日均量",
                                         f"MA25 {'上彎' if f['slope']==UP else '走平'}"], strength=st)
    if short_e:
        st = min(100, 50 + 25 * min(vr / pe["mult_short"] - 1, 1) + 25 * (f["slope"] == DOWN))
        rs = [f"MA5 {m5[t]:.2f} 下穿 MA25 {m25[t]:.2f}", f"放量：量/5日均量 {vr:.2f}", "MA25 下彎"]
        if ctx.shortable is None: rs.append("放空可行性未知（融券狀態抓不到）")
        return _state("ENTRY", "short", rs, strength=st)
    return scan_state(f)
