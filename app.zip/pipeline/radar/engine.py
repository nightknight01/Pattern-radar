"""PatternEngine + PatternRegistry + Universe (§4, §5, §6).

scan(...) evaluates every enabled pattern for every universe symbol at the latest trading day T,
using only data ≤ T. Output = list of Signal dicts (shape of §4 `Signal`).
"""
from __future__ import annotations
import datetime as dt, hashlib, json, math
import numpy as np
from . import patterns as P, cis as CIS, dsl as DSL
from .context import Ctx

# id, name, directions, native_exit, role, fn, confirmed_by_jay(architecture), source
REGISTRY = [
    ("w_bottom", "① W底（漲幅滿足）", ["long"], "X2", "standard", P.w_bottom),
    ("bottom_reversal", "② 破底翻", ["long"], "X2", "standard", P.bottom_reversal),
    ("bottom_reversal_w", "③ 破底翻（W底）", ["long"], "X2", "standard", P.bottom_reversal_w),
    ("bull_flag", "④ 下飄旗形（波段漲幅滿足）", ["long"], "X2", "standard", P.bull_flag),
    ("bear_flag", "① 上飄旗形（波段跌幅滿足）", ["short"], "X2", "standard", P.bear_flag),
    ("m_top", "② M頭（跌幅滿足）", ["short"], "X2", "standard", P.m_top),
    ("false_breakout", "③ 假突破", ["short"], "X2", "standard", P.false_breakout),
    ("hs_top", "④ 頭肩頂（跌幅滿足）", ["short"], "X2", "standard", P.hs_top),
    ("hs_top_fake", "⑤ 假突破（頭肩頂）", ["short"], "X2", "standard", P.hs_top_fake),
    ("hs_bottom", "⑤ 頭肩底（漲幅滿足）", ["long"], "X2", "standard", P.hs_bottom),
    ("tri_top", "⑥ 收斂三角形頭部（跌幅滿足）", ["short"], "X2", "standard", P.tri_top),
    ("tri_bottom", "⑥ 收斂三角形底部（漲幅滿足）", ["long"], "X2", "standard", P.tri_bottom),
    ("cis_base", "CIS-基準線（站回 MA5）", ["long"], "X3", "baseline", CIS.evaluate_cis_base),
    ("cis_exp", "CIS-實驗組（5/25 交叉＋放量）", ["long", "short"], "X3", "experiment", CIS.evaluate_cis_exp),
]
PATTERN_VERSION = 1
TSAI_IDS = [r[0] for r in REGISTRY[:12]]


def load_custom(con):
    """User DSL patterns (P9) stored in SQLite (imported from a backup): enabled, not deleted, current version.
    Returns registry-like tuples; invalid definitions are skipped and reported."""
    out, errs = [], []
    try:
        rows = con.execute("""SELECT p.code, p.name, v.definition_json FROM patterns p JOIN pattern_versions v
                              ON v.pattern_id = p.id AND v.ver = p.current_version
                              WHERE p.builtin = 0 AND p.enabled = 1 AND p.deleted = 0 AND v.deleted = 0""").fetchall()
    except Exception as e:
        return [], [str(e)]
    builtin_ids = {r[0] for r in REGISTRY}
    for code, name, dj in rows:
        try:
            d = json.loads(dj)
            if d["code"] in builtin_ids: raise DSL.DSLError("code 與內建型態重複")
            prog = DSL.Program(d)
            out.append((d["code"], d["name"], d["directions"], d.get("native_exit", "X3"), d.get("role", "standard"), DSL.ctx_fn(prog), d))
        except Exception as e:
            errs.append(f"{code}: {e}")
    return out, errs


def list_patterns(direction=None, custom=()):
    out = []
    for pid, name, dirs, nx, role, _ in REGISTRY:
        if direction and direction not in dirs: continue
        out.append(dict(id=pid, name=name, directions=dirs, native_exit=nx, role=role, version=PATTERN_VERSION,
                        builtin=True, confirmed_by_jay=pid.startswith("cis"),
                        source=("Jay 2026-11-18 新增（實驗組）" if pid == "cis_exp" else
                                "/workspace/技術篩選/rules/CIS.md（早期座談會二手摘錄）" if pid == "cis_base" else
                                "補定義，待 Jay 確認（依《多空轉折一手抓》公開目錄與型態學原則）")))
    for c in custom:
        if direction and direction not in c[2]: continue
        out.append(dict(id=c[0], name=c[1], directions=c[2], native_exit=c[3], role=c[4], version=c[6].get("version", 1),
                        builtin=False, custom=True, confirmed_by_jay=False, source=c[6].get("source", "使用者自訂（DSL）")))
    return out


def pattern_set_hash(cfg, custom=()):
    blob = json.dumps({"v": PATTERN_VERSION, "ids": [r[0] for r in REGISTRY], "cfg": cfg,
                       "custom": [c[6] for c in custom]}, sort_keys=True, ensure_ascii=False)
    return hashlib.sha1(blob.encode()).hexdigest()[:10]


# ------------------------------------------------------------------ strength (§5.0, A8)
def strength(ctx, t, res):
    cc = ctx.cc; w = cc["strength_weights"]
    vr = ctx.vol_ratio(t) or 0.0
    s_vol = max(0.0, min(1.0, (vr - 1) / (cc["strength_vol_full"] - 1)))
    s_brk = max(0.0, min(1.0, res["break_pct"] / cc["strength_break_full"]))
    inst = ctx.inst_net
    if inst is None or inst == 0: s_inst = 0.5
    else: s_inst = 1.0 if (inst > 0) == (res["direction"] == "long") else 0.0
    return round(w["vol"] * s_vol + w["break"] * s_brk + w["shape"] * res["shape"] + w["inst"] * s_inst, 1)


def _lifecycle(ctx, t, fn):
    """Latest state at t for a 蔡森 pattern: fresh CONFIRMED / FORMING / transitions FAILED, TARGET_HIT
    on T, or an earlier still-active CONFIRMED (fresh=False)."""
    r = fn(ctx, t)
    if r and r["state"] == "CONFIRMED":
        r["fresh"] = True; r["confirmed_idx"] = t; return r
    b = ctx.cc["break_buf"]; c, h, l = ctx.c, ctx.h, ctx.l
    for k in range(1, ctx.cc["track_days"] + 1):
        tk = t - k
        if tk < 2: break
        rk = fn(ctx, tk)
        if not rk or rk["state"] != "CONFIRMED": continue
        lv = rk["levels"]; neck, tgt = lv["neckline"], lv["target"]; longd = rk["direction"] == "long"
        st = "CONFIRMED"; ev_idx = None
        for i in range(tk + 1, t + 1):
            if (longd and c[i] < neck * (1 - b)) or (not longd and c[i] > neck * (1 + b)):
                st, ev_idx = "FAILED", i; break
            if (longd and h[i] >= tgt) or (not longd and l[i] <= tgt):
                st, ev_idx = "TARGET_HIT", i; break
        if st != "CONFIRMED" and ev_idx != t:
            break  # lifecycle already ended before T → fall back to today's own evaluation
        rk["state"] = st; rk["fresh"] = st != "CONFIRMED"; rk["confirmed_idx"] = tk
        rk["reasons"] = rk["reasons"] + ([f"頸線另一側收盤 → 型態失敗"] if st == "FAILED" else
                                         [f"觸及滿足點 {tgt:.2f}"] if st == "TARGET_HIT" else [f"{k} 日前已確認，仍有效"])
        return rk
    if r: r["fresh"] = True; r["confirmed_idx"] = None
    return r


# ------------------------------------------------------------------ 量測漲跌幅（1 倍／2 倍型態高度）
# 頭部型態：高度 = 最高點 − 該點位置的頸線；目標 = 頸線 − 1×/2× 高度。底部型態對稱：目標 = 頸線 + 1×/2× 高度。
# 頸線基準用訊號的 levels.neckline（M頭／W底為水平線；頭肩為斜頸線在判斷日的值，與型態自己的滿足點一致）。
MOVE_SPECS = {
    # pid: (方向, 型態名, [極值點 key], 極值標籤)
    "m_top": ("drop", "M頭", ["H1", "H2"], "高點"),
    "hs_top": ("drop", "頭肩頂", ["Head"], "頭部"),
    "hs_top_fake": ("drop", "頭肩頂（假突破）", ["Head"], "頭部"),
    "w_bottom": ("rise", "W底", ["L1", "L2"], "低點"),
    "bottom_reversal_w": ("rise", "破底翻（W底）", ["L2"], "低點"),
    "hs_bottom": ("rise", "頭肩底", ["Head"], "頭部"),
}


def measured_move(pid, levels, geo, dates=None, close=None):
    """回傳 1×/2× 量測目標（dict）或 None。geo 為型態原始幾何（含 idx；頭肩另有 neckline slope/x0/y0）。"""
    spec = MOVE_SPECS.get(pid)
    if not spec or not levels or levels.get("neckline") is None: return None
    kind, label, keys, ext_label = spec
    pts = [geo.get(k) for k in keys if isinstance(geo.get(k), dict) and geo[k].get("price") is not None]
    if not pts: return None
    ext = max(pts, key=lambda q: q["price"]) if kind == "drop" else min(pts, key=lambda q: q["price"])
    nk = geo.get("neckline")
    if isinstance(nk, dict) and "slope" in nk and "x0" in nk and ext.get("idx") is not None:
        neck_ref = float(nk["y0"]) + float(nk["slope"]) * (ext["idx"] - nk["x0"])   # 斜頸線在頭部那天的值
    else:
        neck_ref = float(levels["neckline"])
    base = float(levels["neckline"])
    h = (ext["price"] - neck_ref) if kind == "drop" else (neck_ref - ext["price"])
    if not h > 0: return None
    sgn = -1 if kind == "drop" else 1
    t1, t2 = base + sgn * h, base + sgn * 2 * h
    r = lambda x: round(float(x), 2)
    pc = lambda x, ref: round((float(x) / float(ref) - 1) * 100, 2) if ref else None
    out = dict(kind=kind, basis=label, pattern=pid, extreme=r(ext["price"]), extreme_label=ext_label,
               extreme_date=(dates[ext["idx"]] if dates is not None and ext.get("idx") is not None and 0 <= ext["idx"] < len(dates) else ext.get("date")),
               peaks=[dict(key=k, price=r(geo[k]["price"]), date=(dates[geo[k]["idx"]] if dates is not None and geo[k].get("idx") is not None else geo[k].get("date")))
                      for k in keys if isinstance(geo.get(k), dict) and geo[k].get("price") is not None],
               neck_ref=r(neck_ref), neckline=r(base), height=r(h), height_pct=round(h / neck_ref * 100, 2),
               t1=r(t1), t2=r(t2), t1_pct=pc(t1, base), t2_pct=pc(t2, base))
    if close: out.update(close=r(close), t1_from_close_pct=pc(t1, close), t2_from_close_pct=pc(t2, close))
    return out


def _geo_dates(ctx, g, t):
    """Attach dates to geometry (idx → date) and turn line equations into dated endpoints."""
    d = ctx.dates
    def fix(o):
        if isinstance(o, dict):
            o = {k: fix(v) for k, v in o.items()}
            if "idx" in o and isinstance(o["idx"], int) and 0 <= o["idx"] < len(d): o["date"] = d[o["idx"]]
            return o
        if isinstance(o, list): return [fix(x) for x in o]
        return o
    g = fix(g)
    for k in ("start", "flag_start", "flag_end"):
        if isinstance(g.get(k), int): g[k + "_date"] = d[g[k]]
    x0 = g.get("start", g.get("flag_start"))
    for k in ("upper", "lower"):
        if k in g and x0 is not None:
            a, b0 = g[k]["slope"], g[k]["intercept"]
            g[k]["p0"] = {"date": d[x0], "price": round(a * x0 + b0, 4)}; g[k]["p1"] = {"date": d[t], "price": round(a * t + b0, 4)}
    if "neckline" in g and isinstance(g["neckline"], dict) and "x0" in g["neckline"]:
        nk = g["neckline"]; x0 = nk["x0"]
        nk["p0"] = {"date": d[x0], "price": nk["y0"]}; nk["p1"] = {"date": d[t], "price": round(nk["y0"] + nk["slope"] * (t - x0), 4)}
    return g


def evaluate_symbol(ctx, t, enabled=None, include_cis_states=("ENTRY", "EXIT", "EXIT_WARNING", "HOLD"), custom=()):
    out = []
    reg = [r + (False,) for r in REGISTRY] + [c[:6] + (True,) for c in custom]
    for pid, name, dirs, nx, role, fn, is_custom in reg:
        if enabled and pid not in enabled: continue
        if is_custom:
            r = fn(ctx, t)
            if r["state"] in ("NO_DATA", "WATCH") or not r["direction"]: continue
            if r["state"] not in include_cis_states + ("CONFIRMED", "FORMING", "FAILED", "TARGET_HIT"): continue
            lv = {k: round(v, 4) for k, v in r["levels"].items() if v == v}
            sig = dict(patternId=pid, direction=r["direction"], state=r["state"], strength=r["strength"], levels=lv,
                       geometry={"strong": r.get("strong", False)}, reasons=r["reasons"] + ["使用者自訂型態（DSL）"],
                       fresh=r["state"] in ("ENTRY", "CONFIRMED"), confirmed_on=None, custom=True)
        elif pid.startswith("cis"):
            r = fn(ctx, t)
            if r["state"] not in include_cis_states: continue
            m5, m25 = ctx.m5[t], ctx.m25[t]
            sig = dict(patternId=pid, direction=r["direction"], state=r["state"],
                       strength=float(r["strength"]) if r["strength"] is not None else None,
                       levels={"ma5": round(float(m5), 4), "ma25": round(float(m25), 4), "stopRef": round(float(m25), 4)},
                       geometry={"strong": r.get("strong", False)}, reasons=r["reasons"] + ([r["note"]] if r.get("note") else []),
                       fresh=r["state"] == "ENTRY", confirmed_on=None)
        else:
            r = _lifecycle(ctx, t, fn)
            if not r: continue
            mv = measured_move(pid, r["levels"], r["geometry"], ctx.dates, float(ctx.c[t]))
            sig = dict(patternId=pid, direction=r["direction"], state=r["state"], strength=strength(ctx, t, r),
                       levels=r["levels"], geometry=_geo_dates(ctx, r["geometry"], t), reasons=r["reasons"],
                       fresh=r.get("fresh", True),
                       confirmed_on=ctx.dates[r["confirmed_idx"]] if r.get("confirmed_idx") is not None else None)
            if mv: sig["move"] = mv
        if sig["direction"] == "short":
            sig["shortable"] = ctx.shortable
            if ctx.shortable is None: sig["reasons"] = sig["reasons"] + ["放空可行性未知"]
            elif ctx.shortable is False and pid != "cis_exp": sig["reasons"] = sig["reasons"] + ["目前不可融券（非信用標的或停止融券）"]
        sig.update(symbol=ctx.symbol, name=ctx.name, market=ctx.market, patternVersion=PATTERN_VERSION,
                   date=ctx.dates[t], dataAsOf=ctx.dates[t], close=round(float(ctx.c[t]), 4),
                   volRatio=round(ctx.vol_ratio(t), 3) if ctx.vol_ratio(t) else None, instNet=ctx.inst_net)
        out.append(sig)
    return out


# ------------------------------------------------------------------ universe (§5.0, B7)
def universe_check(raw_close_T, raw_vol, last_date, T, n_bars, restr, ucfg, is_etf):
    """Return None if tradable, else reason string."""
    if last_date != T: return "T 日無成交/資料"
    if not ucfg["enabled"]: return None
    if is_etf and not ucfg["include_etf"]: return "ETF 排除"
    if n_bars < ucfg["min_bars"]: return f"K 線不足 {ucfg['min_bars']} 根"
    if ucfg["exclude_disposal"] and "disposal" in restr: return "處置股"
    if ucfg["exclude_full_delivery"] and "full_delivery" in restr: return "全額交割/變更交易"
    if raw_close_T < ucfg["min_price"]: return f"股價 < {ucfg['min_price']:.0f}"
    prev = raw_vol[-21:-1]
    if len(prev) < 20 or np.mean(prev) / 1000 < ucfg["min_avg_vol20_lots"]: return f"20 日均量 < {ucfg['min_avg_vol20_lots']} 張"
    return None
