"""Backup / restore (§3.3, §14.3, §15) — same file format as web/backup-core.js (tested both ways).

Recovery code → PBKDF2-SHA256(210000, salt "pattern-radar/v1") → 64 bytes: [:32] AES-256-GCM key, vault_id = sha256([32:]).hex()[:32]
File: b"PRB1" + iv(12) + AESGCM(gzip(json)). JSON = {schema_version, exported_at, device_id, vault_id, tables}.
Only user tables (no market data). Merge: newer updated_at wins; tie → version; tie → updated_by_device (lexicographic).
Cloud BaaS (Supabase) is NOT wired: it needs a project/account Jay hasn't created; backups are encrypted files instead.
"""
from __future__ import annotations
import datetime as dt, gzip, hashlib, json, os, sqlite3, uuid
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

SCHEMA_VERSION, ITER, SALT, MAGIC = 1, 210000, b"pattern-radar/v1", b"PRB1"
USER_TABLES = ["patterns", "pattern_versions", "watchlist", "alert_settings", "fundamental_rules", "settings", "backtest_runs"]
JSON_COLS = {"patterns": ["directions_json"], "pattern_versions": ["definition_json"], "alert_settings": ["pattern_ids_json", "recipients_json", "fundamental_rules_json"],
             "fundamental_rules": ["rules_json"], "settings": ["value_json"]}


def norm_code(code): return "".join(ch for ch in str(code).upper() if ch.isalnum())


def derive(code):
    bits = hashlib.pbkdf2_hmac("sha256", norm_code(code).encode(), SALT, ITER, 64)
    return bits[:32], hashlib.sha256(bits[32:]).hexdigest()[:32]


def canon(v):
    return json.dumps(v, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def checksum(tables):
    srt = {t: sorted(rows, key=lambda r: r["id"]) for t, rows in sorted(tables.items())}
    # JS canon == JSON.stringify per value with sorted keys; Python json.dumps(ensure_ascii=False) matches for str/int/float/bool/None
    return hashlib.sha256(canon(srt).encode()).hexdigest()


def encrypt(doc, code):
    key, vault = derive(code)
    doc = {"schema_version": SCHEMA_VERSION, **doc, "vault_id": vault}
    iv = os.urandom(12)
    ct = AESGCM(key).encrypt(iv, gzip.compress(json.dumps(doc, ensure_ascii=False).encode()), None)
    return MAGIC + iv + ct, vault, checksum(doc.get("tables", {}))


def decrypt(blob, code):
    if blob[:4] != MAGIC: raise ValueError("不是型態雷達備份檔（檔頭不符）")
    key, vault = derive(code)
    try: pt = AESGCM(key).decrypt(blob[4:16], blob[16:], None)
    except Exception: raise ValueError("復原碼不正確，或檔案已損壞（AES-GCM 驗證失敗）")
    doc = json.loads(gzip.decompress(pt))
    if doc.get("schema_version", 1) > SCHEMA_VERSION: raise ValueError("備份 schema_version 比本程式新")
    return doc, vault, checksum(doc.get("tables", {}))


def newer(a, b):
    if a["updated_at"] != b["updated_at"]: return a["updated_at"] > b["updated_at"]
    if (a.get("version") or 1) != (b.get("version") or 1): return (a.get("version") or 1) > (b.get("version") or 1)
    return str(a.get("updated_by_device") or "") > str(b.get("updated_by_device") or "")


def merge(local, remote):
    out, stats = {}, {}
    for t in set(local) | set(remote):
        m = {r["id"]: r for r in local.get(t, [])}; added = taken = kept = 0
        for r in remote.get(t, []):
            cur = m.get(r["id"])
            if cur is None: m[r["id"]] = r; added += 1
            elif newer(r, cur): m[r["id"]] = r; taken += 1
            else: kept += 1
        out[t] = list(m.values())
        stats[t] = dict(added=added, taken=taken, kept=kept, total=len(out[t]), live=sum(1 for r in out[t] if not r.get("deleted")))
    return out, stats


# ------------------------------------------------------------------ SQLite side (box batch)
def _cols(con, t): return [r[1] for r in con.execute(f"PRAGMA table_info({t})")]


def export_tables(con):
    tables = {}
    for t in USER_TABLES:
        cols = _cols(con, t)
        if not cols: continue
        rows = []
        for r in con.execute(f"SELECT {','.join(cols)} FROM {t}"):
            d = dict(zip(cols, r))
            if t == "settings": d["id"] = d.get("key")
            rows.append(d)
        tables[t] = rows
    return tables


def import_tables(con, tables):
    """Merge remote rows into SQLite with the same newer-wins rule; returns stats."""
    local = export_tables(con)
    merged, stats = merge(local, {t: rows for t, rows in tables.items() if t in USER_TABLES})
    for t, rows in merged.items():
        cols = _cols(con, t)
        if not cols: continue
        con.execute(f"DELETE FROM {t}")
        for r in rows:
            if t == "settings": r = {**r, "key": r.get("key") or r["id"]}
            vals = [r.get(c) if not isinstance(r.get(c), (dict, list)) else json.dumps(r.get(c), ensure_ascii=False) for c in cols]
            con.execute(f"INSERT INTO {t} ({','.join(cols)}) VALUES ({','.join('?' * len(cols))})", vals)
    con.commit()
    return stats


def make_doc(con, device_id="box-batch"):
    return dict(schema_version=SCHEMA_VERSION, exported_at=dt.datetime.now(dt.timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z"),
                device_id=device_id, tables=export_tables(con))
