"""台股融資／擔保維持率 — 證交所與櫃買中心公開資料（免金鑰）。

兩個不同的數字，不要混用：
  1. 官方「全市場擔保維持率」（整戶、融資＋融券）：TWSE BFIJ3U keepRate。
     序列自 2026-08-03 起提供。這是證交所儀表板公布的數字。
  2. 民間共識口徑「大盤融資維持率」：證交所沒有每日官方序列，需自行計算
     融資股票市值 ÷ 融資金額。含 ETF；當日無收盤價時用前收／次日參考價。
     上市櫃整體以融資金額加權，不是兩個維持率的平均。

今日餘額為授信機構當日晚間初值，次日調帳後以「前日餘額」為準，故最新交易日標 provisional。
當天晚上才公布；若尚未出爐，沿用最近一個有資料的交易日並標上日期。
"""
from __future__ import annotations
import datetime as dt, json, math, time, urllib.request

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
BFIJ3U = "https://www.twse.com.tw/rwd/zh/marginTrading/BFIJ3U?response=json"
BFIJ3U_TREND = "https://www.twse.com.tw/rwd/zh/marginTrading/BFIJ3U_TREND?response=json&date={ymd}&days=60"
MI_MARGN = "https://www.twse.com.tw/rwd/zh/marginTrading/MI_MARGN?date={ymd}&selectType=ALL&response=json"
MI_INDEX = "https://www.twse.com.tw/rwd/zh/afterTrading/MI_INDEX?date={ymd}&type=ALLBUT0999&response=json"
TPEX_BAL = "https://www.tpex.org.tw/www/zh-tw/margin/balance?date={slash}&response=json"
TPEX_QUOTES = "https://www.tpex.org.tw/www/zh-tw/afterTrading/dailyQuotes?date={slash}&id=&response=json"

# 狀態燈以官方整戶擔保維持率為準：130% 為法定追繳門檻；167% ≈ 融資六成買進時的初始維持率（100/0.6）
DEFAULT_THRESHOLDS = {"alert_below": 130, "watch_below": 167}


def thresholds():
    try:
        from radar import config
        m = (config.get() or {}).get("margin") or {}
        out = dict(DEFAULT_THRESHOLDS)
        for k in DEFAULT_THRESHOLDS:
            if k in m and m[k] is not None:
                out[k] = float(m[k])
        return out
    except Exception:  # noqa: BLE001
        return dict(DEFAULT_THRESHOLDS)


def classify(keep, th=None):
    th = th or thresholds()
    if keep is None:
        return "missing", "尚無資料"
    if keep < th["alert_below"]:
        return "alert", "追繳區"
    if keep < th["watch_below"]:
        return "watch", "偏緊"
    return "ok", "安全"


def http_get(url, timeout=45, retries=3, sleep=0.8):
    last = None
    for i in range(max(1, retries)):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json,*/*"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read().decode("utf-8", "replace")
        except Exception as e:  # noqa: BLE001
            last = e
            if i + 1 < retries:
                time.sleep(sleep * (i + 1))
    raise last


def _f(x):
    try:
        v = float(str(x).replace(",", "").strip())
    except (TypeError, ValueError):
        return None
    return v if math.isfinite(v) else None


def _iso(s):
    if s is None:
        return None
    t = str(s).strip().replace("/", "").replace("-", "")
    if len(t) == 8 and t.isdigit():
        return f"{t[:4]}-{t[4:6]}-{t[6:]}"
    if len(t) == 7 and t.isdigit():          # 民國 1151126
        return f"{int(t[:3]) + 1911}-{t[3:5]}-{t[5:7]}"
    return None


def _ymd(iso):
    return iso.replace("-", "")


def _slash(iso):
    y, m, d = iso.split("-")
    return f"{y}/{m}/{d}"


def _load(text):
    if isinstance(text, dict):
        return text
    return json.loads(text)


def _ok(j):
    st = str((j or {}).get("stat") or "")
    return st.upper() == "OK"


def no_data(j):
    st = str((j or {}).get("stat") or "")
    return (not st) or ("沒有符合" in st) or ("無資料" in st) or st.upper() in {"EMPTY", "NODATA"}


# ---------- parsers（官方 JSON 形狀） ----------
def parse_bfij3u(text):
    j = _load(text)
    if no_data(j) or not _ok(j):
        raise ValueError(j.get("stat") or "BFIJ3U 無資料")
    keep = _f(j.get("keepRate"))
    if keep is None:
        raise ValueError("BFIJ3U 沒有 keepRate")
    return dict(date=_iso(j.get("date")), keepRate=keep,
                belowAccNum=int(j["belowAccNum"]) if j.get("belowAccNum") is not None else None,
                callAccNum=int(j["callAccNum"]) if j.get("callAccNum") is not None else None,
                crdAmt=_f(j.get("crdAmt")), raw=j)


def parse_bfij3u_trend(text):
    j = _load(text)
    if no_data(j) or not _ok(j):
        raise ValueError(j.get("stat") or "BFIJ3U_TREND 無資料")
    out = []
    for r in j.get("data") or []:
        d, k = _iso(r.get("date")), _f(r.get("keepRate"))
        if d and k is not None:
            out.append(dict(date=d, keepRate=k, belowAccNum=r.get("belowAccNum"), callAccNum=r.get("callAccNum")))
    return out


def parse_mi_margn(text):
    """回傳 (date, amount_thousand, [(code, name, lots), ...])。lots = 融資今日餘額（張）。"""
    j = _load(text)
    if no_data(j) or not _ok(j):
        raise ValueError(j.get("stat") or "MI_MARGN 無資料")
    tables = j.get("tables") or []
    if not tables:
        raise ValueError("MI_MARGN 沒有表格")
    amt = None
    for row in tables[0].get("data") or []:
        if row and "融資金額" in str(row[0]):
            amt = _f(row[5])          # 今日餘額（仟元）
            break
    if amt is None:
        raise ValueError("MI_MARGN 找不到融資金額今日餘額")
    rows = []
    if len(tables) > 1:
        for r in tables[1].get("data") or []:
            if not r:
                continue
            code, name, lots = str(r[0]).strip(), str(r[1]).strip(), _f(r[6] if len(r) > 6 else None)
            if code and lots is not None:
                rows.append((code, name, lots))
    if not rows:
        raise ValueError("MI_MARGN 沒有個股融資餘額")
    return _iso(j.get("date")), amt, rows


def parse_mi_index_prices(text):
    """證券代號 → 收盤價。"""
    j = _load(text)
    if no_data(j) or not _ok(j):
        raise ValueError(j.get("stat") or "MI_INDEX 無資料")
    px = {}
    for t in j.get("tables") or []:
        fields = t.get("fields") or []
        if not fields or fields[0] not in ("證券代號", "代號"):
            continue
        try:
            ci, pi = 0, fields.index("收盤價")
        except ValueError:
            continue
        for r in t.get("data") or []:
            if not r:
                continue
            v = _f(r[pi] if len(r) > pi else None)
            if v is not None:
                px[str(r[ci]).strip()] = v
    if not px:
        raise ValueError("MI_INDEX 沒有收盤價")
    return _iso(j.get("date")), px


def parse_tpex_balance(text):
    """回傳 (date, amount_thousand, [(code, name, lots), ...])。金額取 summary 融資金（仟元）今日餘額。"""
    j = _load(text)
    if no_data(j) or not _ok(j):
        raise ValueError(j.get("stat") or "櫃買融資餘額無資料")
    tables = j.get("tables") or []
    if not tables:
        raise ValueError("櫃買融資餘額沒有表格")
    t = tables[0]
    amt = None
    for row in t.get("summary") or []:
        if row and "融資金" in str(row[1] if len(row) > 1 else ""):
            amt = _f(row[6] if len(row) > 6 else None)
            break
    if amt is None:
        raise ValueError("櫃買融資餘額找不到融資金合計")
    rows = []
    for r in t.get("data") or []:
        if not r:
            continue
        code, name, lots = str(r[0]).strip(), str(r[1]).strip(), _f(r[6] if len(r) > 6 else None)
        if code and lots is not None:
            rows.append((code, name, lots))
    if not rows:
        raise ValueError("櫃買融資餘額沒有個股")
    return _iso(j.get("date") or t.get("date")), amt, rows


def parse_tpex_quotes(text):
    """回傳 (date, prices, refs)。收盤為空時 refs 放次日參考價，計算時當前收使用。"""
    j = _load(text)
    if no_data(j) or not _ok(j):
        raise ValueError(j.get("stat") or "櫃買行情無資料")
    px, ref = {}, {}
    date = _iso(j.get("date"))
    for t in j.get("tables") or []:
        fields = t.get("fields") or []
        if not fields or fields[0] not in ("代號", "證券代號"):
            continue
        def _col(*names):
            for n in names:
                if n in fields:
                    return fields.index(n)
            return None
        ci, pi, ri = 0, _col("收盤", "收盤價"), _col("次日 參考價", "次日參考價", "參考價")
        for r in t.get("data") or []:
            if not r:
                continue
            code = str(r[ci]).strip()
            if pi is not None and len(r) > pi:
                v = _f(r[pi])
                if v is not None:
                    px[code] = v
            if ri is not None and len(r) > ri:
                v = _f(r[ri])
                if v is not None:
                    ref[code] = v
    if not px and not ref:
        raise ValueError("櫃買行情沒有價格")
    return date, px, ref


def compute_ratio(rows, prices, amount_thousand, fallback=None):
    """融資維持率（%）。rows = [(code, name, lots), ...]；fallback 為無收盤時的備援價（前收／參考價）。"""
    if not amount_thousand or amount_thousand <= 0:
        raise ValueError("融資金額無效")
    fallback = fallback or {}
    mv = 0.0
    used = missed_lots = 0.0
    n_ok = n_miss = n_fb = 0
    missed = []
    for code, name, lots in rows:
        p = prices.get(code)
        src = "close"
        if p is None:
            p = fallback.get(code)
            src = "ref"
        if p is None:
            n_miss += 1
            missed_lots += lots
            if lots:
                missed.append((code, name, lots))
            continue
        mv += lots * 1000.0 * p
        used += lots
        n_ok += 1
        if src == "ref":
            n_fb += 1
    ratio = mv / (amount_thousand * 1000.0) * 100.0
    return dict(ratio=round(ratio + 1e-12, 2), ratio_raw=ratio, market_value=mv,
                amount=amount_thousand * 1000.0, names_ok=n_ok, names_miss=n_miss,
                lots_ok=used, lots_miss=missed_lots, fallback_names=n_fb, missed=missed[:20])


def _prev_days(iso, n=8):
    d = dt.date.fromisoformat(iso)
    return [(d - dt.timedelta(days=i)).isoformat() for i in range(n)]


def _get_json(get, url, timeout, errs, label):
    try:
        return _load(get(url, timeout))
    except Exception as e:  # noqa: BLE001
        errs.append(f"{label}: {str(e)[:160]}")
        return None


def fetch(get, today=None, lookback=8):
    """抓官方擔保維持率＋自行計算大盤融資維持率。

    today: 'YYYY-MM-DD'（預設台北今天）。若當日尚未公布，往前找最近一個有資料的交易日。
    回傳 (payload, errors)。payload 為 None 表示全部失敗。
    get(url, timeout) 回傳文字（與 run_fx 相同慣例）。
    """
    today = today or dt.datetime.now(dt.timezone(dt.timedelta(hours=8))).date().isoformat()
    errs = []
    official = trend = None

    # 1) 先問不帶日期的 BFIJ3U（最新已公布日），再從 today 往回補
    latest = _get_json(get, BFIJ3U, 30, errs, "BFIJ3U(最新)")
    if latest and _ok(latest):
        try:
            official = parse_bfij3u(latest)
        except Exception as e:  # noqa: BLE001
            errs.append(f"BFIJ3U 解析: {str(e)[:120]}")

    if official is None:
        for iso in _prev_days(today, lookback):
            j = _get_json(get, BFIJ3U + "&date=" + _ymd(iso), 30, errs, f"BFIJ3U {iso}")
            if not j or no_data(j):
                continue
            try:
                official = parse_bfij3u(j)
                break
            except Exception as e:  # noqa: BLE001
                errs.append(f"BFIJ3U {iso}: {str(e)[:120]}")

    as_of = (official or {}).get("date") or today

    if official:
        tj = _get_json(get, BFIJ3U_TREND.format(ymd=_ymd(as_of)), 30, errs, "BFIJ3U_TREND")
        if tj and _ok(tj):
            try:
                trend = parse_bfij3u_trend(tj)
            except Exception as e:  # noqa: BLE001
                errs.append(f"BFIJ3U_TREND: {str(e)[:120]}")

    # 2) 同一資料日計算上市／上櫃／整體融資維持率；該日行情還沒出就往回最多 lookback 天
    computed = None
    for iso in [as_of] + [d for d in _prev_days(today, lookback) if d != as_of]:
        ymd, slash = _ymd(iso), _slash(iso)
        try:
            mj = _get_json(get, MI_MARGN.format(ymd=ymd), 45, errs, f"MI_MARGN {iso}")
            ij = _get_json(get, MI_INDEX.format(ymd=ymd), 45, errs, f"MI_INDEX {iso}")
            bj = _get_json(get, TPEX_BAL.format(slash=slash), 45, errs, f"TPEx餘額 {iso}")
            qj = _get_json(get, TPEX_QUOTES.format(slash=slash), 90, errs, f"TPEx行情 {iso}")
            if not (mj and ij and bj and qj):
                continue
            if any(no_data(x) for x in (mj, ij, bj, qj)):
                continue
            d1, amt_l, rows_l = parse_mi_margn(mj)
            _, px_l = parse_mi_index_prices(ij)
            d2, amt_o, rows_o = parse_tpex_balance(bj)
            _, px_o, ref_o = parse_tpex_quotes(qj)
            listed = compute_ratio(rows_l, px_l, amt_l)
            otc = compute_ratio(rows_o, px_o, amt_o, fallback=ref_o)
            all_mv = listed["market_value"] + otc["market_value"]
            all_amt = listed["amount"] + otc["amount"]
            all_ratio = all_mv / all_amt * 100.0
            computed = dict(
                date=d1 or d2 or iso, listed=listed["ratio"], otc=otc["ratio"],
                all=round(all_ratio + 1e-12, 2),
                listed_detail={k: listed[k] for k in ("ratio_raw", "market_value", "amount", "names_ok", "names_miss", "fallback_names")},
                otc_detail={k: otc[k] for k in ("ratio_raw", "market_value", "amount", "names_ok", "names_miss", "fallback_names")},
            )
            break
        except Exception as e:  # noqa: BLE001
            errs.append(f"計算 {iso}: {str(e)[:160]}")
            continue

    if official is None and computed is None:
        return None, errs
    return dict(official=official, trend=trend or [], computed=computed, as_of=(official or computed).get("date"), today=today), errs


def build_doc(payload, errs, generated_at, stale=False, error=None):
    th = thresholds()
    official = (payload or {}).get("official") or {}
    computed = (payload or {}).get("computed")
    as_of = (payload or {}).get("as_of") or official.get("date") or (computed or {}).get("date")
    today = (payload or {}).get("today")
    keep = official.get("keepRate")
    status, label = classify(keep, th)
    provisional = True  # 使用當日「今日餘額」，次日調帳前都是暫定
    secondary = None
    if computed:
        secondary = f"融資維持率　上市 {computed['listed']:.2f}%　上櫃 {computed['otc']:.2f}%　整體 {computed['all']:.2f}%"
    notes = [
        "主數字是證交所公布的全市場整戶擔保維持率（融資＋融券、上市＋上櫃），不是民間常講的大盤融資維持率。",
        "第二行是用官方融資餘額與收盤價自行計算的大盤融資維持率（含 ETF；無收盤時用前收／次日參考價；整體以融資金額加權）。",
        "今日餘額為授信機構當日晚間初值，次日調帳後以『前日餘額』為準。",
        "資料於每個交易日晚上公布；若當天尚未出爐，本頁顯示最近一個有資料的交易日。",
    ]
    return dict(
        schema_version=1, kind="margin", title="整戶擔保維持率",
        status=status, status_label=label,
        value=keep, unit="%", value_label=None if keep is None else f"{keep:.2f}%",
        as_of=as_of, today=today, stale=bool(stale), provisional=provisional,
        generated_at=generated_at, error=error, errors=errs or [],
        official=None if not official else dict(
            date=official.get("date"), keepRate=official.get("keepRate"),
            belowAccNum=official.get("belowAccNum"), callAccNum=official.get("callAccNum"),
            crdAmt=official.get("crdAmt"), source="TWSE BFIJ3U",
        ),
        computed=None if not computed else dict(
            date=computed.get("date"), listed=computed["listed"], otc=computed["otc"], all=computed["all"],
            listed_detail=computed.get("listed_detail"), otc_detail=computed.get("otc_detail"),
            source="TWSE MI_MARGN+MI_INDEX、TPEx margin/balance+dailyQuotes",
        ),
        secondary=secondary, trend=(payload or {}).get("trend") or [],
        thresholds=th, notes=notes,
    )
