"""Backtester (§12): one entry → X1 / X2 / X3 simulated independently, then per-combo portfolios.

Cost model §12.1 (same as 技術篩選 / MJ_Agent):
  b = 1.002355 (buy: 手續費 0.1425%×0.6 + 滑價 0.15%), s = 0.994645 (sell: 手續費 + 證交稅 0.3% + 滑價 0.15%)
  long  net = exit·s / (entry·b) − 1                      stop = E·0.93·b/s   target = E·1.12·b/s
  short net = (entry·s − exit·b) / (entry·b) − extra      stop = E·(s/b+0.07) target = E·(s/b−0.12)
  short_extra_cost = 0（融券／借券費用：假設值，未計入）
Intraday stop/target by high/low; both on the same day → stop (conservative). Gap through a level
(after the entry day) fills at the open (補定義).
"""
from __future__ import annotations
import math, statistics
from collections import Counter, defaultdict

B, S = 1.002355, 0.994645
REASON_ZH = {"stop": "停損 −7%", "stop_gap": "停損（跳空開盤）", "target": "停利 +12%", "target_gap": "停利（跳空開盤）",
             "time": "持有 10 日到期", "stopref": "收盤破停損參考", "tgt_hit": "到達滿足點", "tgt_gap": "滿足點（跳空開盤）",
             "failed": "型態失敗（FAILED）", "cis_exit": "CIS 出場訊號", "open_end": "期末未平倉"}


def net(direction, entry, exit_, extra=0.0):
    if direction == "long": return exit_ * S / (entry * B) - 1
    return (entry * S - exit_ * B) / (entry * B) - extra


def x1_levels(direction, E):
    if direction == "long": return E * 0.93 * B / S, E * 1.12 * B / S
    return E * (S / B + 0.07), E * (S / B - 0.12)


def entry_ok(direction, o_next, c_sig, gap=0.04, limit=0.095):
    """T+1 open entry; abandon when open gaps > 4% in the trade direction or at limit (共同規則／鏡像補定義)."""
    g = o_next / c_sig - 1
    if direction == "long": return not (g > gap or g >= limit)
    return not (g < -gap or g <= -limit)


def _done(k, px, why, at_open=False):
    return dict(exit_idx=k, exit_price=float(px), reason=why, at_open=at_open)


def sim_x1(direction, O, H, L, C, e, hold=10):
    E = O[e]; st, tp = x1_levels(direction, E); lg = direction == "long"
    for k in range(e, min(e + hold, len(C))):
        if k > e:
            if (lg and O[k] <= st) or (not lg and O[k] >= st): return _done(k, O[k], "stop_gap", True)
            if (lg and O[k] >= tp) or (not lg and O[k] <= tp): return _done(k, O[k], "target_gap", True)
        if (lg and L[k] <= st) or (not lg and H[k] >= st): return _done(k, st, "stop")
        if (lg and H[k] >= tp) or (not lg and L[k] <= tp): return _done(k, tp, "target")
        if k == e + hold - 1: return _done(k, C[k], "time")
    return _done(len(C) - 1, C[-1], "open_end")


def sim_x2(direction, O, H, L, C, e, levels, break_buf=0.01, exit_exec="next_open"):
    """停損參考（收盤）> 滿足點（盤中）> FAILED（收盤回到頸線另一側）。訊號型出場預設 T+1 開盤成交."""
    lg = direction == "long"; stop, tgt, neck = levels.get("stopRef"), levels.get("target"), levels.get("neckline")
    pending = None
    for k in range(e, len(C)):
        if pending:
            return _done(k, O[k], pending, True)
        if k > e and tgt is not None and ((lg and O[k] >= tgt) or (not lg and O[k] <= tgt)): return _done(k, O[k], "tgt_gap", True)
        sig = None
        if stop is not None and ((lg and C[k] < stop) or (not lg and C[k] > stop)): sig = "stopref"
        elif tgt is not None and ((lg and H[k] >= tgt) or (not lg and L[k] <= tgt)): return _done(k, tgt, "tgt_hit")
        elif neck is not None and ((lg and C[k] < neck * (1 - break_buf)) or (not lg and C[k] > neck * (1 + break_buf))): sig = "failed"
        if sig:
            if exit_exec == "same_close": return _done(k, C[k], sig)
            pending = sig
    return _done(len(C) - 1, C[-1], "open_end")


def sim_x3(direction, ctx, fn, e, exit_exec="next_open"):
    pos = "LONG" if direction == "long" else "SHORT"
    O, C = ctx.o, ctx.c
    for k in range(e, len(C)):
        r = fn(ctx, k, pos)
        if r["state"] == "EXIT":
            if exit_exec == "same_close": return _done(k, C[k], "cis_exit")
            if k + 1 >= len(C): break          # 訊號在最後一天：T+1 尚未發生 → 期末未平倉
            return _done(k + 1, O[k + 1], "cis_exit", True)
    return _done(len(C) - 1, C[-1], "open_end")


def mark_path(direction, E, C, e, x, extra=0.0):
    """Daily mark-to-market net return from entry day to exit day (exit day = realised)."""
    p = [round(net(direction, E, C[k], extra), 5) for k in range(e, x["exit_idx"])]
    p.append(round(net(direction, E, x["exit_price"], extra), 5))
    return p


# ------------------------------------------------------------------ portfolio (§12.3 step 7)
def run_portfolio(cands, dates, max_positions=8):
    """cands: trades of one combo, each with entry_i, exit_i, at_open, strength, symbol, path.
    名額先扣隔天仍持有的檔數，再依強度補進；滿額記錄「滿檔不進」。同一檔已持有則不重複進場."""
    by_day = defaultdict(list)
    for c in cands: by_day[c["entry_i"]].append(c)
    held, taken, skipped_full, skipped_dup = [], [], 0, 0
    for e in sorted(by_day):
        held = [h for h in held if h["exit_i"] > e or (h["exit_i"] == e and not h["at_open"])]
        syms = {h["symbol"] for h in held}
        for c in sorted(by_day[e], key=lambda c: -(c["strength"] or 0)):
            if c["symbol"] in syms: skipped_dup += 1; continue
            if len(held) >= max_positions: skipped_full += 1; continue
            held.append(c); taken.append(c); syms.add(c["symbol"])
    return taken, skipped_full, skipped_dup


def nav_series(trades, n_days, max_positions=8):
    """等權（每筆 1/max_positions 名目，不複利）組合淨值：NAV_t = 1 + Σ w·(已實現或未實現淨報酬)."""
    delta = [0.0] * (n_days + 1)
    for t in trades:
        w = 1.0 / max_positions; prev = 0.0
        for j, r in enumerate(t["path"]):
            d = t["entry_i"] + j
            if d < n_days: delta[d] += w * (r - prev)
            prev = r
    nav, v = [], 1.0
    for d in range(n_days): v += delta[d]; nav.append(round(v, 5))
    return nav


def max_drawdown(nav):
    peak, mdd = -math.inf, 0.0
    for v in nav:
        peak = max(peak, v); mdd = min(mdd, v / peak - 1 if peak > 0 else 0)
    return mdd


def metrics(trades, nav=None, skipped_full=0, min_trades=30):
    n = len(trades)
    rets = [t["net"] for t in trades]
    wins = [r for r in rets if r > 0]; losses = [r for r in rets if r <= 0]
    hold = [t["hold_days"] for t in trades]
    m = dict(trades=n, skipped_full=skipped_full, open_at_end=sum(1 for t in trades if t["reason"] == "open_end"),
             exit_reasons=dict(Counter(t["reason"] for t in trades)), insufficient=n < min_trades)
    if n:
        wr = len(wins) / n; aw = sum(wins) / len(wins) if wins else 0.0; al = sum(losses) / len(losses) if losses else 0.0
        m.update(win_rate=wr, avg_net=sum(rets) / n, avg_win=aw, avg_loss=al,
                 payoff=(aw / abs(al)) if al else None, expectancy=wr * aw + (1 - wr) * al,
                 hold_mean=sum(hold) / n, hold_median=statistics.median(hold))
    if nav: m["max_drawdown"] = max_drawdown(nav)
    return m
