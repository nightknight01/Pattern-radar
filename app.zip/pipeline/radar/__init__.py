"""型態雷達 Pattern Radar — box-side batch pipeline (data fetch + pattern engine).

Spec: /workspace/型態雷達/SPEC.md v0.3. Official TWSE / TPEx data only (§9, B6).
"""
__version__ = "0.1.0"
