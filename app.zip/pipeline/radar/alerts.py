"""AlertService (§11) — builds the 盤後 email (subject + plain text + HTML) from a scan run.

THIS MODULE NEVER SENDS EMAIL. It only formats and returns the message; run_alerts.py writes a dry-run
preview. Sending requires Jay's explicit approval (Grok Bot rule) and credentials kept in Secrets (§11.2).

Rules implemented (§11.4):
- dedupe_key = sha1(trade_date|pattern_id|pattern_version|symbol|direction|state); a key already logged with
  status 'sent' is never included again (batch rerun ⇒ no resend).
- only state transitions: same symbol+pattern+direction whose state on the previous trading day was the same → skipped.
- cooldown: ENTRY/CONFIRMED again within cooldown_days trading days after a logged (sent or dry_run) entry → app only.
- no content ⇒ no mail unless send_empty_digest. 休市（無 T 日掃描）⇒ no mail.
"""
from __future__ import annotations
import hashlib, html, json, os, re
from collections import defaultdict
from .fundamentals import apply_rules

def env_recipients():
    """收件人只從環境變數 ALERT_TO（GitHub Secrets）讀，公開 repo 的程式碼與輸出檔不寫入信箱。"""
    return [x.strip() for x in os.environ.get("ALERT_TO", "").split(",") if x.strip()]


def mask_email(s):
    """le***@gmail.com — for files that end up public (preview page, state assets)."""
    return re.sub(r"([A-Za-z0-9._%+-]{1,2})[A-Za-z0-9._%+-]*@([A-Za-z0-9.-]+)", r"\1***@\2", str(s))


DEFAULT_SETTINGS = dict(recipients=env_recipients(), cooldown_days=5, max_rows=50, send_empty_digest=False, top_k=5,
                        patterns={"long": None, "short": None},   # None = all patterns of that direction enabled
                        fundamental_rules=[], app_base_url="index.html", cis_exit_scope="watchlist", schedule_cron="CRON_TZ=Asia/Taipei 30 17 * * 1-5")
EXIT_STATES = ("EXIT", "EXIT_WARNING", "FAILED", "TARGET_HIT")
STATE_ZH = {"CONFIRMED": "確認突破", "ENTRY": "進場", "EXIT": "出場訊號", "EXIT_WARNING": "出場警示", "FAILED": "型態失敗",
            "TARGET_HIT": "達滿足點", "HOLD": "續抱", "FORMING": "成形中"}
DIR_ZH = {"long": "做多", "short": "做空"}
NOTES = ["規則版本 patternVersion = {ver}。",
         "CIS 規則為早期座談會二手摘錄，均線用收盤價 SMA 為工作假設；cis_exp 為 Jay 2026-11-18 新增的實驗組。",
         "蔡森十二招全部為補定義型態，參數待 Jay 確認。",
         "本信不構成投資建議，App 不代為下單。"]
SHORT_NOTE = "融券／借券費用假設 0，未計入；實際可否融券依交易所與券商公告。"


def dedupe_key(s, trade_date):
    raw = f"{trade_date}|{s['patternId']}|{s.get('patternVersion', 1)}|{s['symbol']}|{s['direction']}|{s['state']}"
    return hashlib.sha1(raw.encode()).hexdigest()


def _is_entry(s): return s["state"] == "ENTRY" or (s["state"] == "CONFIRMED" and s.get("fresh"))


def select(doc, prev_states, settings, sent_keys, recent_entries, watch):
    """Return (exits, entries, skipped) after enable / transition / dedupe / cooldown filters.
    prev_states: {(symbol, pattern, direction): state on previous trading day} or None (no previous run).
    recent_entries: {(symbol, pattern, direction)} with a logged entry within cooldown window (excluding T).
    watch: {symbol: position}."""
    T = doc["trade_date"]; en = settings["patterns"]; skipped = defaultdict(int)
    exits, entries = [], []
    for s in doc["hits"]:
        d = s["direction"]
        if d not in ("long", "short"): continue
        if en.get(d) is not None and s["patternId"] not in en[d]: skipped["型態未啟用"] += 1; continue
        is_entry, is_exit = _is_entry(s), s["state"] in EXIT_STATES
        if not (is_entry or is_exit): continue
        # CIS 的 EXIT／EXIT_WARNING 是「持有者參考」：預設只寄追蹤清單內的標的（ENGINE 預設，可設 cis_exit_scope="all"）
        if is_exit and s["patternId"].startswith("cis") and settings.get("cis_exit_scope", "watchlist") == "watchlist" and s["symbol"] not in watch:
            skipped["CIS 出場僅限追蹤清單"] += 1; continue
        k3 = (s["symbol"], s["patternId"], d)
        if prev_states is not None and prev_states.get(k3) == s["state"]: skipped["狀態未轉換"] += 1; continue
        key = dedupe_key(s, T)
        if key in sent_keys: skipped["已寄過（去重）"] += 1; continue
        if is_entry and k3 in recent_entries: skipped[f"冷卻期內（{settings['cooldown_days']} 日）"] += 1; continue
        row = dict(s, dedupe_key=key, watch=watch.get(s["symbol"]))
        (entries if is_entry else exits).append(row)
    # 追蹤清單內的持有標的優先（方向一致），其次出場訊號 > 警示 > 失敗 > 滿足點
    pri = {"EXIT": 0, "EXIT_WARNING": 1, "FAILED": 2, "TARGET_HIT": 3}
    held = lambda r: (r["watch"] == "LONG" and r["direction"] == "long") or (r["watch"] == "SHORT" and r["direction"] == "short")
    exits.sort(key=lambda r: (not held(r), r["watch"] is None, pri[r["state"]], r["symbol"]))
    entries.sort(key=lambda r: (r["direction"] != "long", r["patternId"], -(r.get("strength") or 0)))
    return exits, entries, dict(skipped)


def _fmt(x, d=2): return "—" if x is None else f"{x:.{d}f}"


def build(doc, exits, entries, skipped, settings, fund, names, prev_available, data_status):
    T = doc["trade_date"]; mx = settings["max_rows"]; base = settings["app_base_url"]
    rules = settings.get("fundamental_rules") or []
    pname = {p["id"]: p["name"] for p in doc["patterns"]}
    link = lambda s: f"{base}#/{s['direction']}/{s['patternId']}/{s.get('sector_code') or 'ALL'}/{s['symbol']}"
    fchip = lambda s: ("未設條件" if not rules else {"pass": "通過", "fail": "未通過", "pending": "待補"}[apply_rules(fund.get(s["symbol"]), rules)[0]])
    n_new = len({r["symbol"] for r in entries}); n_exit = len({r["symbol"] for r in exits})
    subject = f"[型態雷達] {T} 盤後｜新命中 {n_new} 檔｜出場訊號 {n_exit} 檔"
    shown = 0; cut_ex = cut_en = 0
    ex_rows, en_rows = [], []
    for r in exits:
        if shown >= mx: cut_ex += 1; continue
        ex_rows.append(r); shown += 1
    for r in entries:
        if shown >= mx: cut_en += 1; continue
        en_rows.append(r); shown += 1
    # ---- plain text
    L = [subject, "", "一、出場訊號／出場警示（追蹤清單內的持有標的優先）"]
    for r in ex_rows:
        lv = r["levels"]; key = f"MA5 {_fmt(lv.get('ma5'))}/MA25 {_fmt(lv.get('ma25'))}" if "ma25" in lv else f"頸線 {_fmt(lv.get('neckline'))}"
        L.append(f"  {r['symbol']} {r['name']}｜{pname.get(r['patternId'], r['patternId'])}｜{DIR_ZH[r['direction']]}｜{STATE_ZH.get(r['state'], r['state'])}"
                 f"{'（追蹤：' + r['watch'] + '）' if r['watch'] else ''}｜收盤 {_fmt(r['close'])}｜{key}｜{r['reasons'][-1] if r['reasons'] else ''}")
        L.append(f"    {link(r)}")
    if not ex_rows: L.append("  （無）")
    if cut_ex: L.append(f"  …其餘 {cut_ex} 筆見 App")
    L += ["", "二、新進場訊號"]
    for d in ("long", "short"):
        rows = [r for r in en_rows if r["direction"] == d]
        L.append(f"【{DIR_ZH[d]}】" + ("　※" + SHORT_NOTE if d == "short" else ""))
        if not rows: L.append("  （無）")
        cur = None
        for r in rows:
            if r["patternId"] != cur:
                cur = r["patternId"]; L.append(f"  ◆ {pname.get(cur, cur)}")
            lv = r["levels"]
            L.append(f"    {r['symbol']} {r['name']}｜{r.get('sector_name') or ''}｜{DIR_ZH[d]}｜強度 {_fmt(r.get('strength'), 0)}｜收盤 {_fmt(r['close'])}"
                     f"｜頸線 {_fmt(lv.get('neckline', lv.get('ma25')))}｜滿足點 {_fmt(lv.get('target'))}｜停損參考 {_fmt(lv.get('stopRef'))}"
                     f"｜量比 {_fmt(r.get('volRatio'))}｜三大法人 {'—' if r.get('instNet') is None else f'{round(r['instNet'] / 1000):,} 張'}｜基本面 {fchip(r)}")
            L.append(f"      {link(r)}")
    if cut_en: L.append(f"  …其餘 {cut_en} 筆見 App")
    L += ["", f"三、類股雷達 Top {settings['top_k']}"]
    secs = defaultdict(list)
    for s in doc.get("sectors", []):
        if s["is_hit"]: secs[(s["direction"], s["pattern_id"])].append(s)
    en = settings["patterns"]; any_sec = False
    for (d, pid), rows in sorted(secs.items()):
        if en.get(d) is not None and pid not in en[d]: continue
        any_sec = True; L.append(f"  {DIR_ZH[d]}・{pname.get(pid, pid)}")
        for s in sorted(rows, key=lambda s: -s["score"])[:settings["top_k"]]:
            L.append(f"    {s['sector_name']}｜{s['hits']}/{s['n_members']}｜命中比例 {s['hit_ratio'] * 100:.1f}%｜綜合分 {s['score']:.1f}")
    if not any_sec: L.append("  （今日無類股達命中門檻）")
    L += ["", "四、資料狀態"] + [f"  {x}" for x in data_status]
    if not prev_available: L.append("  前一交易日沒有掃描紀錄：本次全部視為新狀態（無法判斷狀態轉換）。")
    if skipped: L.append("  未列入：" + "、".join(f"{k} {v}" for k, v in skipped.items()))
    L += ["", "五、附註"] + [f"  {n.format(ver=doc['hits'][0]['patternVersion'] if doc['hits'] else 1)}" for n in NOTES] + [f"  做空區：{SHORT_NOTE}"]
    text = "\n".join(L)
    # ---- HTML (深色霓虹，inline CSS for mail clients)
    e = html.escape
    css_td = "padding:6px 8px;border-bottom:1px solid #232c45;font-size:13px;vertical-align:top"
    def table(head, rows):
        return (f'<table style="border-collapse:collapse;width:100%;margin:6px 0 14px">'
                f'<tr>{"".join(f"<th style=\"{css_td};color:#8A94B2;text-align:left;font-weight:500\">{e(h)}</th>" for h in head)}</tr>'
                + "".join("<tr>" + "".join(f'<td style="{css_td}">{c}</td>' for c in r) + "</tr>" for r in rows) + "</table>")
    a = lambda r: f'<a style="color:#00F0FF" href="{e(link(r))}">{e(r["symbol"])} {e(r["name"])}</a>'
    H = [f'<div style="background:#0A0E1A;color:#E8ECF8;font-family:\'Noto Sans TC\',\'PingFang TC\',sans-serif;padding:18px">',
         f'<h1 style="font-size:18px;margin:0 0 4px">{e(subject)}</h1><div style="color:#8A94B2;font-size:12px">資料日 {e(T)}｜掃描完成 {e(doc["finished_at"][:16].replace("T", " "))}（台北時間）</div>',
         '<h2 style="font-size:15px;color:#FF8A00;margin:16px 0 4px">一、出場訊號／出場警示</h2>']
    H.append(table(["個股", "型態", "方向", "狀態", "收盤", "關鍵價", "觸發條件"],
                   [[a(r) + (f' <span style="color:#B6FF3B">（追蹤 {e(r["watch"])}）</span>' if r["watch"] else ""), e(pname.get(r["patternId"], "")),
                     DIR_ZH[r["direction"]], e(STATE_ZH.get(r["state"], r["state"])), _fmt(r["close"]),
                     _fmt(r["levels"].get("ma25", r["levels"].get("neckline"))), e(r["reasons"][-1] if r["reasons"] else "")] for r in ex_rows]) if ex_rows else "<p style='color:#8A94B2'>（無）</p>")
    if cut_ex: H.append(f"<p style='color:#8A94B2'>…其餘 {cut_ex} 筆見 App</p>")
    H.append('<h2 style="font-size:15px;color:#B6FF3B;margin:16px 0 4px">二、新進場訊號</h2>')
    for d, col in (("long", "#00F0FF"), ("short", "#FF2BD6")):
        rows = [r for r in en_rows if r["direction"] == d]
        H.append(f'<h3 style="font-size:14px;color:{col};border-left:3px solid {col};padding-left:8px">【{DIR_ZH[d]}】</h3>')
        if d == "short": H.append(f'<p style="color:#f9a8e8;font-size:12px">{e(SHORT_NOTE)}</p>')
        if not rows: H.append("<p style='color:#8A94B2'>（無）</p>"); continue
        for pid in dict.fromkeys(r["patternId"] for r in rows):
            H.append(f'<div style="font-weight:700;margin-top:6px">◆ {e(pname.get(pid, pid))}</div>')
            H.append(table(["個股", "類股", "強度", "收盤", "頸線", "滿足點", "停損參考", "量比", "三大法人", "基本面"],
                           [[a(r), e(r.get("sector_name") or ""), _fmt(r.get("strength"), 0), _fmt(r["close"]),
                             _fmt(r["levels"].get("neckline", r["levels"].get("ma25"))), _fmt(r["levels"].get("target")), _fmt(r["levels"].get("stopRef")),
                             _fmt(r.get("volRatio")), "—" if r.get("instNet") is None else f"{round(r['instNet'] / 1000):,} 張", fchip(r)]
                            for r in rows if r["patternId"] == pid]))
    if cut_en: H.append(f"<p style='color:#8A94B2'>…其餘 {cut_en} 筆見 App</p>")
    sec_html = []
    for (d, pid), rows in sorted(secs.items()):
        if en.get(d) is not None and pid not in en[d]: continue
        sec_html.append(f"<div style='margin-top:6px'>{DIR_ZH[d]}・{e(pname.get(pid, pid))}</div>" + table(["類股", "hits/N", "命中比例", "綜合分"],
                        [[e(s["sector_name"]), f"{s['hits']}/{s['n_members']}", f"{s['hit_ratio'] * 100:.1f}%", f"{s['score']:.1f}"]
                         for s in sorted(rows, key=lambda s: -s["score"])[:settings["top_k"]]]))
    H.append(f'<h2 style="font-size:15px;margin:16px 0 4px">三、類股雷達 Top {settings["top_k"]}</h2>' + ("".join(sec_html) or "<p style='color:#8A94B2'>（今日無類股達命中門檻）</p>"))
    st = list(data_status) + ([] if prev_available else ["前一交易日沒有掃描紀錄：本次全部視為新狀態。"]) + (["未列入：" + "、".join(f"{k} {v}" for k, v in skipped.items())] if skipped else [])
    H.append('<h2 style="font-size:15px;margin:16px 0 4px">四、資料狀態</h2><ul style="color:#8A94B2;font-size:12px">' + "".join(f"<li>{e(x)}</li>" for x in st) + "</ul>")
    H.append('<h2 style="font-size:15px;margin:16px 0 4px">五、附註</h2><ul style="color:#8A94B2;font-size:12px">'
             + "".join(f"<li>{e(n.format(ver=doc['hits'][0]['patternVersion'] if doc['hits'] else 1))}</li>" for n in NOTES) + f"<li>做空區：{e(SHORT_NOTE)}</li></ul></div>")
    return dict(subject=subject, text=text, html="".join(H), to=settings["recipients"], n_new=n_new, n_exit=n_exit,
                rows=[r["dedupe_key"] for r in ex_rows + en_rows], rows_meta=[(r["dedupe_key"], r["patternId"], r["symbol"], r["direction"], r["state"]) for r in ex_rows + en_rows],
                truncated=cut_ex + cut_en, empty=not (exits or entries))
