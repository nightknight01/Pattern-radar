"""DataProxy (§4): throttled fetch of official endpoints with retry + raw cache.

Rules from spec:
- 每來源可設定請求間隔、指數退避重試、原始回應快取。
- 「查無資料」不寫入快取（KD_Agent 2026-10-26 修正經驗）。
"""
from __future__ import annotations
import json, os, time, datetime as dt
import requests

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW_DIR = os.path.join(HERE, "cache", "raw")
HEALTH_PATH = os.path.join(HERE, "cache", "health.json")
UA = {"User-Agent": "Mozilla/5.0 (PatternRadar batch; official data)"}

# seconds between requests per source (configurable)
THROTTLE = {"twse": 3.0, "tpex": 3.0, "twse_openapi": 1.0, "tpex_openapi": 1.0}
_last = {}
HEALTH: dict = {}


def _health(source, ok, msg=""):
    h = HEALTH.setdefault(source, {"ok": 0, "fail": 0, "last_ok": None, "last_error": None})
    now = dt.datetime.now().isoformat(timespec="seconds")
    if ok:
        h["ok"] += 1; h["last_ok"] = now
    else:
        h["fail"] += 1; h["last_error"] = f"{now} {msg}"[:300]


def save_health():
    old = {}
    if os.path.exists(HEALTH_PATH):
        try: old = json.load(open(HEALTH_PATH))
        except Exception: old = {}
    old.update(HEALTH)
    json.dump(old, open(HEALTH_PATH, "w"), ensure_ascii=False, indent=1)


def cache_path(name):
    return os.path.join(RAW_DIR, name)


def fetch_json(source, url, cache_name, method="GET", data=None, ok=lambda j: True,
               retries=4, timeout=45, use_cache=True):
    """Return parsed JSON or None. Only responses passing `ok` are cached."""
    os.makedirs(RAW_DIR, exist_ok=True)
    p = cache_path(cache_name) if cache_name else None
    if use_cache and p and os.path.exists(p):
        try:
            return json.load(open(p))
        except Exception:
            os.remove(p)
    err = None
    for i in range(retries):
        wait = THROTTLE.get(source, 2.0) - (time.time() - _last.get(source, 0))
        if wait > 0: time.sleep(wait)
        _last[source] = time.time()
        try:
            r = requests.request(method, url, data=data, headers=UA, timeout=timeout)
            if r.status_code != 200:
                raise RuntimeError(f"HTTP {r.status_code}")
            j = r.json()
            if ok(j):
                if p: json.dump(j, open(p, "w"), ensure_ascii=False)
                _health(source, True)
            else:
                _health(source, True, "no-data")  # reachable, but 查無資料 → not cached
            return j
        except Exception as e:  # noqa
            err = e
            time.sleep(min(60, 5 * 2 ** i))  # exponential backoff
    _health(source, False, f"{url} :: {err}")
    return None
