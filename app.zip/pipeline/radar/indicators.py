"""Indicators (§4): pure functions on numpy arrays. Index t means 'as of the close of bar t'."""
import numpy as np


def sma(x, n):
    x = np.asarray(x, float); out = np.full(len(x), np.nan)
    if len(x) >= n:
        c = np.cumsum(np.insert(x, 0, 0.0))
        out[n - 1:] = (c[n:] - c[:-n]) / n
    return out


def ema(x, n):
    x = np.asarray(x, float); out = np.full(len(x), np.nan)
    if len(x) == 0: return out
    a = 2 / (n + 1); out[0] = x[0]
    for i in range(1, len(x)): out[i] = a * x[i] + (1 - a) * out[i - 1]
    out[:n - 1] = np.nan
    return out


def avg_prev(x, n):
    """Mean of x[t-n .. t-1] (excludes bar t) — 均量不含 T 日."""
    s = sma(x, n); out = np.full(len(x), np.nan); out[1:] = s[:-1]; return out


def vol_ok_series(v, p):
    a5, a20 = avg_prev(v, p["vol_short_n"]), avg_prev(v, p["vol_long_n"])
    with np.errstate(invalid="ignore"):
        return (v >= a5 * p["vol_short_mult"]) & (v >= a20 * p["vol_long_mult"])


def linreg(xs, ys):
    """slope, intercept of least squares y = a*x + b."""
    xs = np.asarray(xs, float); ys = np.asarray(ys, float)
    if len(xs) < 2: return np.nan, np.nan
    a, b = np.polyfit(xs, ys, 1)
    return float(a), float(b)


def highest(x, n):
    x = np.asarray(x, float); out = np.full(len(x), np.nan)
    for i in range(n - 1, len(x)): out[i] = x[i - n + 1:i + 1].max()
    return out


def lowest(x, n):
    x = np.asarray(x, float); out = np.full(len(x), np.nan)
    for i in range(n - 1, len(x)): out[i] = x[i - n + 1:i + 1].min()
    return out
