"""蔡森十二招 — programmable definitions per SPEC §5.2 (all 補定義，待 Jay 確認).

Each detector(ctx, t) evaluates bar t using only data ≤ t and confirmed pivots, and returns
None or a dict: {state: CONFIRMED|FORMING, direction, levels, geometry, reasons, break_pct, shape}.
Prices are the Adjuster's back-adjusted series (latest bar == raw price).
"""
from __future__ import annotations
import numpy as np
from .indicators import linreg

LONG, SHORT = "long", "short"


def _up_cross(c, t, lv_t, lv_p, b):
    return c[t] > lv_t * (1 + b) and c[t - 1] <= lv_p * (1 + b)


def _dn_cross(c, t, lv_t, lv_p, b):
    return c[t] < lv_t * (1 - b) and c[t - 1] >= lv_p * (1 - b)


def _clip01(x):
    return float(max(0.0, min(1.0, x)))


def _res(state, direction, levels, geometry, reasons, break_pct=0.0, shape=0.5):
    return dict(state=state, direction=direction, levels={k: (round(float(v), 4) if v is not None else None) for k, v in levels.items()},
                geometry=geometry, reasons=reasons, break_pct=float(break_pct), shape=_clip01(shape))


def _g(p):
    return {"idx": p.idx, "price": round(p.price, 4)}


def _tail_triples(P, k1, k2):
    """Yield (a,b,c,extra) where (a,b,c) kinds == (k1,k2,k1) and c is the latest k1 pivot;
    extra = pivots after c (at most one, of kind k2)."""
    for j in range(len(P) - 1, max(-1, len(P) - 3), -1):
        if P[j].kind == k1 and j >= 2 and P[j - 1].kind == k2 and P[j - 2].kind == k1:
            yield P[j - 2], P[j - 1], P[j], P[j + 1:]
            return


# ------------------------------------------------------------------ ① W 底（多）
def w_bottom(ctx, t, pid="w_bottom"):
    p, cc = ctx.cfg[pid], ctx.cc; b = cc["break_buf"]; c, h, l = ctx.c, ctx.h, ctx.l
    if t < 1: return None
    for L1, H1, L2, extra in _tail_triples(ctx.piv(t), "L", "H"):
        if abs(L2.price - L1.price) / L1.price > p["bottom_tol"]: return None
        if not (p["min_width"] <= L2.idx - L1.idx <= p["max_width"]): return None
        s0 = max(0, L1.idx - p["trend_lookback"])
        if L1.idx - s0 < 5 or h[s0:L1.idx].max() < L1.price * (1 + p["prior_trend_pct"]): return None
        neck = H1.price
        if any(e.price > neck * (1 + b) for e in extra): return None
        if t - L2.idx > cc["breakout_window"]: return None
        lo = min(L1.price, L2.price); target = neck + (neck - lo)
        geo = {"L1": _g(L1), "H1": _g(H1), "L2": _g(L2)}
        shape = 1 - abs(L2.price - L1.price) / L1.price / p["bottom_tol"]
        if _up_cross(c, t, neck, neck, b) and ctx.vol_ok[t]:
            return _res("CONFIRMED", LONG, {"neckline": neck, "breakout": c[t], "target": target, "stopRef": max(lo, l[t])}, geo,
                        [f"W底：左腳 {L1.price:.2f}、右腳 {L2.price:.2f}（差 {abs(L2.price-L1.price)/L1.price:.1%}）",
                         f"收盤 {c[t]:.2f} 帶量突破頸線 {neck:.2f}×(1+{b:.0%})"], c[t] / neck - 1, shape)
        if neck * (1 - cc["near_pct"]) <= c[t] <= neck * (1 + b):
            return _res("FORMING", LONG, {"neckline": neck, "target": target, "stopRef": lo}, geo,
                        [f"W底右腳已確認，收盤 {c[t]:.2f} 距頸線 {neck:.2f} 在 {cc['near_pct']:.0%} 內"], c[t] / neck - 1, shape)
    return None


# ------------------------------------------------------------------ ⑥ M 頭（空）
def m_top(ctx, t, pid="m_top"):
    p, cc = ctx.cfg[pid], ctx.cc; b = cc["break_buf"]; c, h, l, v = ctx.c, ctx.h, ctx.l, ctx.v
    if t < 1: return None
    for H1, L1, H2, extra in _tail_triples(ctx.piv(t), "H", "L"):
        if abs(H2.price - H1.price) / H1.price > p["top_tol"]: return None
        if not (p["min_width"] <= H2.idx - H1.idx <= p["max_width"]): return None
        s0 = max(0, H1.idx - p["trend_lookback"])
        if H1.idx - s0 < 5 or H1.price < l[s0:H1.idx].min() * (1 + p["prior_trend_pct"]): return None
        neck = L1.price
        if any(e.price < neck * (1 - b) for e in extra): return None
        if t - H2.idx > cc["breakout_window"]: return None
        hi = max(H1.price, H2.price); target = neck - (hi - neck)
        geo = {"H1": _g(H1), "L1": _g(L1), "H2": _g(H2)}
        diverge = v[H2.idx] < v[H1.idx]
        shape = 0.7 * _clip01(1 - abs(H2.price - H1.price) / H1.price / p["top_tol"]) + 0.3 * diverge
        volreq = cc["vol_required_short_break"]
        if _dn_cross(c, t, neck, neck, b) and (ctx.vol_ok[t] or not volreq):
            return _res("CONFIRMED", SHORT, {"neckline": neck, "breakout": c[t], "target": target, "stopRef": hi}, geo,
                        [f"M頭：H1 {H1.price:.2f}、H2 {H2.price:.2f}", f"收盤 {c[t]:.2f} 跌破頸線 {neck:.2f}×(1−{b:.0%})"]
                        + (["H2 量低於 H1（量價背離，加分）"] if diverge else []), 1 - c[t] / neck, shape)
        if neck * (1 - b) <= c[t] <= neck * (1 + cc["near_pct"]):
            return _res("FORMING", SHORT, {"neckline": neck, "target": target, "stopRef": hi}, geo,
                        [f"M頭右肩已確認，收盤 {c[t]:.2f} 距頸線 {neck:.2f} 在 {cc['near_pct']:.0%} 內"], 1 - c[t] / neck, shape)
    return None


# ------------------------------------------------------------------ ② 破底翻（多）
def bottom_reversal(ctx, t, pid="bottom_reversal"):
    p, cc = ctx.cfg[pid], ctx.cc; b = cc["break_buf"]; c, h, l = ctx.c, ctx.h, ctx.l
    rw, cw, sl = p["reclaim_window"], cc["confirm_window"], p["support_lookback"]
    if t < 1: return None
    lows = [q for q in ctx.piv(t) if q.kind == "L" and q.idx >= t - (sl + rw + cw)]
    for S in reversed(lows):
        B = next((i for i in range(S.confirm_idx + 1, t + 1) if c[i] < S.price * (1 - b)), None)
        if B is None or B - S.idx > sl: continue
        Rd = next((i for i in range(B + 1, min(B + rw, t) + 1) if c[i] > S.price * (1 + b) and ctx.vol_ok[i]), None)
        if Rd is None or t - Rd > cw: continue
        neck = float(h[S.idx:B + 1].max()); lmin = float(l[B:t + 1].min())
        if neck <= S.price * (1 + b): neck = S.price * (1 + b)
        target = neck + (neck - lmin)
        geo = {"S": _g(S), "B": {"idx": B, "price": round(float(c[B]), 4)}, "reclaim": {"idx": Rd, "price": round(float(c[Rd]), 4)},
               "Lmin": {"idx": int(B + np.argmin(l[B:t + 1])), "price": round(lmin, 4)}}
        shape = 1 - (Rd - B - 1) / rw
        if _up_cross(c, t, neck, neck, b) and ctx.vol_ok[t]:
            return _res("CONFIRMED", LONG, {"neckline": neck, "breakout": c[t], "target": target, "stopRef": lmin}, geo,
                        [f"破底翻：支撐 {S.price:.2f} 被跌破後 {Rd-B} 日內帶量站回", f"收盤 {c[t]:.2f} 帶量突破頸線 {neck:.2f}"],
                        c[t] / neck - 1, shape)
        if c[t] <= neck * (1 + b) and c[t] > S.price:
            return _res("FORMING", LONG, {"neckline": neck, "target": target, "stopRef": lmin}, geo,
                        [f"破底翻：已帶量站回支撐 {S.price:.2f}，等待突破頸線 {neck:.2f}"], c[t] / neck - 1, shape)
        return None
    return None


# ------------------------------------------------------------------ ⑦ 假突破（空）
def false_breakout(ctx, t, pid="false_breakout"):
    p, cc = ctx.cfg[pid], ctx.cc; b = cc["break_buf"]; c, h, l = ctx.c, ctx.h, ctx.l
    rw, cw, rl = p["reclaim_window"], cc["confirm_window"], p["resist_lookback"]
    if t < 1: return None
    highs = [q for q in ctx.piv(t) if q.kind == "H" and q.idx >= t - (rl + rw + cw)]
    for R in reversed(highs):
        U = next((i for i in range(R.confirm_idx + 1, t + 1) if c[i] > R.price * (1 + b)), None)
        if U is None or U - R.idx > rl: continue
        Fd = next((i for i in range(U + 1, min(U + rw, t) + 1) if c[i] < R.price * (1 - b)), None)
        if Fd is None or t - Fd > cw: continue
        neck = float(l[R.idx:U + 1].min()); hmax = float(h[U:t + 1].max())
        target = neck - (hmax - neck)
        geo = {"R": _g(R), "U": {"idx": U, "price": round(float(c[U]), 4)}, "fail": {"idx": Fd, "price": round(float(c[Fd]), 4)},
               "Hmax": {"idx": int(U + np.argmax(h[U:t + 1])), "price": round(hmax, 4)}}
        shape = 1 - (Fd - U - 1) / rw
        if p["fakeout_trigger"] == "breakout_bar_low":
            trig = c[t] < l[U] and c[t - 1] >= l[U]; lvl = float(l[U])
        else:
            trig = _dn_cross(c, t, neck, neck, b); lvl = neck
        volreq = cc["vol_required_short_break"]
        if trig and t >= Fd and (ctx.vol_ok[t] or not volreq):
            return _res("CONFIRMED", SHORT, {"neckline": lvl, "breakout": c[t], "target": target, "stopRef": hmax}, geo,
                        [f"假突破：壓力 {R.price:.2f} 被突破後 {Fd-U} 日內跌回", f"收盤 {c[t]:.2f} 跌破頸線 {lvl:.2f}"],
                        1 - c[t] / lvl, shape)
        if c[t] >= lvl * (1 - b) and c[t] < R.price:
            return _res("FORMING", SHORT, {"neckline": lvl, "target": target, "stopRef": hmax}, geo,
                        [f"假突破：已跌回壓力 {R.price:.2f} 之下，等待跌破頸線 {lvl:.2f}"], 1 - c[t] / lvl, shape)
        return None
    return None


# ------------------------------------------------------------------ ③ 破底翻（W 底）（多）
def bottom_reversal_w(ctx, t, pid="bottom_reversal_w"):
    p, cc = ctx.cfg[pid], ctx.cc; b = cc["break_buf"]; c, h, l = ctx.c, ctx.h, ctx.l
    if t < 1: return None
    for L1, H1, L2, extra in _tail_triples(ctx.piv(t), "L", "H"):
        if not L2.price < L1.price * (1 - b): return None
        if not (p["min_width"] <= L2.idx - L1.idx <= p["max_width"]): return None
        s0 = max(0, L1.idx - p["trend_lookback"])
        if L1.idx - s0 < 5 or h[s0:L1.idx].max() < L1.price * (1 + p["prior_trend_pct"]): return None
        neck = H1.price
        if any(e.price > neck * (1 + b) for e in extra): return None
        if t - L2.idx > cc["breakout_window"]: return None
        Rd = next((i for i in range(L2.idx + 1, min(L2.idx + p["reclaim_window"], t) + 1) if c[i] > L1.price), None)
        if Rd is None: return None
        target = neck + (neck - L2.price)
        geo = {"L1": _g(L1), "H1": _g(H1), "L2": _g(L2), "reclaim": {"idx": Rd, "price": round(float(c[Rd]), 4)}}
        shape = 1 - (Rd - L2.idx - 1) / p["reclaim_window"]
        if _up_cross(c, t, neck, neck, b) and ctx.vol_ok[t]:
            return _res("CONFIRMED", LONG, {"neckline": neck, "breakout": c[t], "target": target, "stopRef": L2.price}, geo,
                        [f"破底翻W：右腳 {L2.price:.2f} 假跌破左腳 {L1.price:.2f} 後站回", f"收盤 {c[t]:.2f} 帶量突破頸線 {neck:.2f}"],
                        c[t] / neck - 1, shape)
        if L1.price <= c[t] <= neck * (1 + b):
            return _res("FORMING", LONG, {"neckline": neck, "target": target, "stopRef": L2.price}, geo,
                        [f"破底翻W：已站回左腳 {L1.price:.2f}，等待突破頸線 {neck:.2f}"], c[t] / neck - 1, shape)
    return None


# ------------------------------------------------------------------ ④⑤ 旗形
def _flag_fit(ctx, top, end, up):
    """Validate flag on bars top+1..end. up=True: 下飄旗形 after an up-pole (top = pole high)."""
    p = ctx.cfg["bull_flag" if up else "bear_flag"]; h, l, v = ctx.h, ctx.l, ctx.v
    n = end - top
    if n < p["flag_min"] or n > p["flag_max"]: return None
    seg = slice(top + 1, end + 1)
    if up:
        if h[top] < h[seg].max(): return None
        lo0 = max(0, top - p["pole_max_days"]); base = int(lo0 + np.argmin(l[lo0:top])) if top > lo0 else None
        if base is None: return None
        pole = h[top] - l[base]
        if h[top] / l[base] - 1 < p["pole_pct"]: return None
    else:
        if l[top] > l[seg].min(): return None
        lo0 = max(0, top - p["pole_max_days"]); base = int(lo0 + np.argmax(h[lo0:top])) if top > lo0 else None
        if base is None: return None
        pole = h[base] - l[top]
        if pole / h[base] < p["pole_pct"]: return None
    if base < 20: return None
    pole_vol = v[base:top + 1].mean()
    if pole_vol <= v[base - 20:base].mean(): return None
    xs = np.arange(top + 1, end + 1)
    sh, bh = linreg(xs, h[seg]); sl, bl = linreg(xs, l[seg])
    if up and not (sh < 0 and sl < 0): return None
    if not up and not (sh > 0 and sl > 0): return None
    par = abs(sh - sl) / max(abs(sh), abs(sl))
    if par > p["parallel_tol"]: return None
    if up and h[top] - l[seg].min() > pole * p["flag_retrace_max"]: return None
    if not up and h[seg].max() - l[top] > pole * p["flag_retrace_max"]: return None
    if v[seg].mean() >= pole_vol: return None
    return dict(base=base, top=top, pole=float(pole), sh=sh, bh=bh, sl=sl, bl=bl, par=par,
                flag_low=float(l[seg].min()), flag_high=float(h[seg].max()))


def _flag(ctx, t, up):
    p = ctx.cfg["bull_flag" if up else "bear_flag"]; b = ctx.cc["break_buf"]; c = ctx.c
    if t < 25: return None
    # CONFIRMED: flag on top+1..t-1, breakout at t
    for n in range(p["flag_min"], p["flag_max"] + 1):
        top = t - 1 - n
        if top < 1: break
        f = _flag_fit(ctx, top, t - 1, up)
        if not f: continue
        geo = {"pole_base": {"idx": f["base"], "price": round(float(ctx.l[f["base"]] if up else ctx.h[f["base"]]), 4)},
               "pole_top": {"idx": top, "price": round(float(ctx.h[top] if up else ctx.l[top]), 4)},
               "upper": {"slope": f["sh"], "intercept": f["bh"]}, "lower": {"slope": f["sl"], "intercept": f["bl"]},
               "flag_start": top + 1, "flag_end": t - 1}
        if up:
            ut, up_ = f["sh"] * t + f["bh"], f["sh"] * (t - 1) + f["bh"]
            if _up_cross(c, t, ut, up_, b) and ctx.vol_ok[t]:
                return _res("CONFIRMED", LONG, {"neckline": ut, "breakout": c[t], "target": c[t] + f["pole"], "stopRef": f["flag_low"]}, geo,
                            [f"下飄旗形：旗桿 {f['pole']:.2f}、旗面 {n} 日量縮", f"收盤 {c[t]:.2f} 帶量突破旗面上緣 {ut:.2f}"],
                            c[t] / ut - 1, 1 - f["par"] / p["parallel_tol"])
        else:
            lt, lp = f["sl"] * t + f["bl"], f["sl"] * (t - 1) + f["bl"]
            if _dn_cross(c, t, lt, lp, b) and ctx.vol_ok[t]:
                return _res("CONFIRMED", SHORT, {"neckline": lt, "breakout": c[t], "target": c[t] - f["pole"], "stopRef": f["flag_high"]}, geo,
                            [f"上飄旗形：旗桿 {f['pole']:.2f}、旗面 {n} 日量縮", f"收盤 {c[t]:.2f} 帶量跌破旗面下緣 {lt:.2f}"],
                            1 - c[t] / lt, 1 - f["par"] / p["parallel_tol"])
    # FORMING: flag valid through t, not yet broken
    for n in range(p["flag_min"], p["flag_max"] + 1):
        top = t - n
        if top < 1: break
        f = _flag_fit(ctx, top, t, up)
        if not f: continue
        geo = {"pole_top": {"idx": top, "price": round(float(ctx.h[top] if up else ctx.l[top]), 4)},
               "upper": {"slope": f["sh"], "intercept": f["bh"]}, "lower": {"slope": f["sl"], "intercept": f["bl"]},
               "flag_start": top + 1, "flag_end": t}
        if up:
            ut = f["sh"] * t + f["bh"]
            if c[t] <= ut * (1 + b):
                return _res("FORMING", LONG, {"neckline": ut, "target": ut + f["pole"], "stopRef": f["flag_low"]}, geo,
                            [f"下飄旗形整理中（{n} 日），上緣 {ut:.2f}"], c[t] / ut - 1, 1 - f["par"] / p["parallel_tol"])
        else:
            lt = f["sl"] * t + f["bl"]
            if c[t] >= lt * (1 - b):
                return _res("FORMING", SHORT, {"neckline": lt, "target": lt - f["pole"], "stopRef": f["flag_high"]}, geo,
                            [f"上飄旗形整理中（{n} 日），下緣 {lt:.2f}"], 1 - c[t] / lt, 1 - f["par"] / p["parallel_tol"])
    return None


def bull_flag(ctx, t): return _flag(ctx, t, True)
def bear_flag(ctx, t): return _flag(ctx, t, False)


# ------------------------------------------------------------------ ⑧⑨⑩ 頭肩
def _hs_find(ctx, t, top, pid):
    """Return (LS, T1, Head, T2, RS, extra) for the latest shoulder pivot, or None."""
    P = ctx.piv(t); k1, k2 = ("H", "L") if top else ("L", "H"); p = ctx.cfg[pid]
    for j in range(len(P) - 1, max(-1, len(P) - 3), -1):
        if P[j].kind != k1 or j < 4: continue
        seq = P[j - 4:j + 1]
        if [q.kind for q in seq] != [k1, k2, k1, k2, k1]: continue
        LS, T1, HD, T2, RS = seq
        if seq[-1].idx - seq[0].idx > p["max_span"]: return None
        if top:
            if HD.price <= max(LS.price, RS.price) * (1 + p["head_margin"]): return None
        else:
            if HD.price >= min(LS.price, RS.price) * (1 - p["head_margin"]): return None
        if abs(LS.price - RS.price) / HD.price > p["shoulder_tol"]: return None
        return LS, T1, HD, T2, RS, P[j + 1:]
    return None


def _hs(ctx, t, top, pid, fake=False):
    cc = ctx.cc; b = cc["break_buf"]; c, v = ctx.c, ctx.v; p = ctx.cfg[pid]
    if t < 1: return None
    r = _hs_find(ctx, t, top, pid)
    if not r: return None
    LS, T1, HD, T2, RS, extra = r
    if t - RS.idx > cc["breakout_window"]: return None
    k = (T2.price - T1.price) / (T2.idx - T1.idx)
    neck = lambda i: T1.price + k * (i - T1.idx)
    geo = {"LS": _g(LS), "T1": _g(T1), "Head": _g(HD), "T2": _g(T2), "RS": _g(RS),
           "neckline": {"slope": k, "x0": T1.idx, "y0": round(T1.price, 4)}}
    reasons = []
    if fake:  # ⑨: head is a fake breakout above LS or a prior resistance R
        Rs = [LS.price] + [q.price for q in ctx.piv(t) if q.kind == "H" and LS.idx - p["resist_lookback"] <= q.idx < LS.idx]
        ok = None
        for R in sorted(set(Rs)):
            if R >= HD.price: continue
            U = next((i for i in range(T1.idx + 1, min(HD.idx + p["reclaim_window"], t) + 1) if c[i] > R * (1 + b)), None)
            if U is None: continue
            Fd = next((i for i in range(U + 1, min(U + p["reclaim_window"], t) + 1) if c[i] < R * (1 - b)), None)
            if Fd is not None: ok = (R, U, Fd); break
        if not ok: return None
        geo["fake"] = {"R": round(ok[0], 4), "U": ok[1], "fail": ok[2]}
        reasons.append(f"頭部對壓力 {ok[0]:.2f} 假突破後 {ok[2]-ok[1]} 日內收回")
    sym = 1 - abs(LS.price - RS.price) / HD.price / p["shoulder_tol"]
    if top:
        if any(e.price < neck(e.idx) * (1 - b) for e in extra): return None
        shape = 0.6 * _clip01(sym) + 0.4 * (v[RS.idx] < v[HD.idx])
        tgt = neck(t) - (HD.price - neck(HD.idx))
        volreq = cc["vol_required_short_break"]
        if _dn_cross(c, t, neck(t), neck(t - 1), b) and (ctx.vol_ok[t] or not volreq):
            return _res("CONFIRMED", SHORT, {"neckline": neck(t), "breakout": c[t], "target": tgt, "stopRef": RS.price}, geo,
                        reasons + [f"頭肩頂：頭 {HD.price:.2f}、左右肩 {LS.price:.2f}/{RS.price:.2f}", f"收盤 {c[t]:.2f} 跌破頸線 {neck(t):.2f}"]
                        + (["右肩量 < 頭部量（加分）"] if v[RS.idx] < v[HD.idx] else []), 1 - c[t] / neck(t), shape)
        if neck(t) * (1 - b) <= c[t] <= neck(t) * (1 + cc["near_pct"]):
            return _res("FORMING", SHORT, {"neckline": neck(t), "target": tgt, "stopRef": RS.price}, geo,
                        reasons + [f"頭肩頂右肩已確認，收盤距頸線 {neck(t):.2f} 在 {cc['near_pct']:.0%} 內"], 1 - c[t] / neck(t), shape)
    else:
        if any(e.price > neck(e.idx) * (1 + b) for e in extra): return None
        shape = _clip01(sym)
        tgt = neck(t) + (neck(HD.idx) - HD.price)
        if _up_cross(c, t, neck(t), neck(t - 1), b) and ctx.vol_ok[t]:
            return _res("CONFIRMED", LONG, {"neckline": neck(t), "breakout": c[t], "target": tgt, "stopRef": RS.price}, geo,
                        [f"頭肩底：頭 {HD.price:.2f}、左右肩 {LS.price:.2f}/{RS.price:.2f}", f"收盤 {c[t]:.2f} 帶量突破頸線 {neck(t):.2f}"],
                        c[t] / neck(t) - 1, shape)
        if neck(t) * (1 - cc["near_pct"]) <= c[t] <= neck(t) * (1 + b):
            return _res("FORMING", LONG, {"neckline": neck(t), "target": tgt, "stopRef": RS.price}, geo,
                        [f"頭肩底右肩已確認，收盤距頸線 {neck(t):.2f} 在 {cc['near_pct']:.0%} 內"], c[t] / neck(t) - 1, shape)
    return None


def hs_top(ctx, t): return _hs(ctx, t, True, "hs_top")
def hs_top_fake(ctx, t): return _hs(ctx, t, True, "hs_top_fake", fake=True)
def hs_bottom(ctx, t): return _hs(ctx, t, False, "hs_bottom")


# ------------------------------------------------------------------ ⑪⑫ 收斂三角形
def _tri(ctx, t, top):
    pid = "tri_top" if top else "tri_bottom"; p, cc = ctx.cfg[pid], ctx.cc; b = cc["break_buf"]
    c, h, l, v = ctx.c, ctx.h, ctx.l, ctx.v
    if t < 1: return None
    P = ctx.piv(t)
    for m in (6, 5, 4):
        if len(P) < m: break
        sel = P[-m:]; s = sel[0].idx
        if not (p["tri_min"] <= t - s <= p["tri_max"]): continue
        H = [q for q in sel if q.kind == "H"]; L = [q for q in sel if q.kind == "L"]
        if len(H) < 2 or len(L) < 2: continue
        sh, bh = linreg([q.idx for q in H], [q.price for q in H]); sl, bl = linreg([q.idx for q in L], [q.price for q in L])
        if not (sh < 0 < sl): continue
        apex = (bl - bh) / (sh - sl)
        if apex <= t: continue
        pos = (t - s) / (apex - s)
        vs, _ = linreg(np.arange(s, t), v[s:t])
        if not vs < 0: continue
        s0 = max(0, s - p["trend_lookback"])
        if s - s0 < 5: continue
        if top and h[s:t].max() < l[s0:s].min() * (1 + p["prior_trend_pct"]): continue
        if not top and l[s:t].min() > h[s0:s].max() / (1 + p["prior_trend_pct"]): continue
        up = lambda i: sh * i + bh; lo = lambda i: sl * i + bl
        height = up(s) - lo(s)
        geo = {"upper": {"slope": sh, "intercept": bh}, "lower": {"slope": sl, "intercept": bl}, "start": s,
               "apex": round(apex, 2), "pos": round(pos, 3), "pivots": [_g(q) for q in sel]}
        shape = 1 - abs(pos - (p["apex_from"] + p["apex_to"]) / 2) / ((p["apex_to"] - p["apex_from"]) / 2)
        in_zone = p["apex_from"] <= pos <= p["apex_to"]
        if top:
            stop = H[-1].price
            if in_zone and _dn_cross(c, t, lo(t), lo(t - 1), b) and (ctx.vol_ok[t] or not cc["vol_required_short_break"]):
                return _res("CONFIRMED", SHORT, {"neckline": lo(t), "breakout": c[t], "target": c[t] - height, "stopRef": stop}, geo,
                            [f"收斂三角形頭部：{len(H)} 高 {len(L)} 低收斂、量縮，位置 {pos:.0%}", f"收盤 {c[t]:.2f} 跌破下緣 {lo(t):.2f}"],
                            1 - c[t] / lo(t), shape)
            if pos <= p["apex_to"] and lo(t) * (1 - b) <= c[t] <= lo(t) * (1 + cc["near_pct"]):
                return _res("FORMING", SHORT, {"neckline": lo(t), "target": lo(t) - height, "stopRef": stop}, geo,
                            [f"收斂三角形頭部整理中，位置 {pos:.0%}，收盤接近下緣 {lo(t):.2f}"], 1 - c[t] / lo(t), shape)
        else:
            stop = L[-1].price
            if in_zone and _up_cross(c, t, up(t), up(t - 1), b) and ctx.vol_ok[t]:
                return _res("CONFIRMED", LONG, {"neckline": up(t), "breakout": c[t], "target": c[t] + height, "stopRef": stop}, geo,
                            [f"收斂三角形底部：{len(H)} 高 {len(L)} 低收斂、量縮，位置 {pos:.0%}", f"收盤 {c[t]:.2f} 帶量突破上緣 {up(t):.2f}"],
                            c[t] / up(t) - 1, shape)
            if pos <= p["apex_to"] and up(t) * (1 - cc["near_pct"]) <= c[t] <= up(t) * (1 + b):
                return _res("FORMING", LONG, {"neckline": up(t), "target": up(t) + height, "stopRef": stop}, geo,
                            [f"收斂三角形底部整理中，位置 {pos:.0%}，收盤接近上緣 {up(t):.2f}"], c[t] / up(t) - 1, shape)
    return None


def tri_top(ctx, t): return _tri(ctx, t, True)
def tri_bottom(ctx, t): return _tri(ctx, t, False)
