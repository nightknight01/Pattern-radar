"""Pivot detection with delayed confirmation (§5.0, A2) — no look-ahead.

Each pivot = (idx, price, kind 'H'|'L', confirm_idx). A pivot may only be used when evaluating
bar t if confirm_idx <= t. ZigZag: a swing high is confirmed on the first bar whose LOW is
≥ pivot_pct below the running high (and vice-versa). Highs use bar highs, lows use bar lows.
"""
from dataclasses import dataclass
import numpy as np


@dataclass(frozen=True)
class Pivot:
    idx: int
    price: float
    kind: str        # 'H' or 'L'
    confirm_idx: int


def zigzag(high, low, pct):
    high = np.asarray(high, float); low = np.asarray(low, float); n = len(high)
    piv = []
    if n == 0: return piv
    mode = 0          # 0 = undecided, 1 = up leg (tracking a high), -1 = down leg (tracking a low)
    hi_i, lo_i = 0, 0
    for i in range(1, n):
        if mode == 0:
            if high[i] > high[hi_i]: hi_i = i
            if low[i] < low[lo_i]: lo_i = i
            if hi_i < i and low[i] <= high[hi_i] * (1 - pct):
                piv.append(Pivot(hi_i, float(high[hi_i]), "H", i)); mode = -1; lo_i = i
            elif lo_i < i and high[i] >= low[lo_i] * (1 + pct):
                piv.append(Pivot(lo_i, float(low[lo_i]), "L", i)); mode = 1; hi_i = i
        elif mode == 1:
            if high[i] > high[hi_i]: hi_i = i
            elif low[i] <= high[hi_i] * (1 - pct):
                piv.append(Pivot(hi_i, float(high[hi_i]), "H", i)); mode = -1; lo_i = i
        else:
            if low[i] < low[lo_i]: lo_i = i
            elif high[i] >= low[lo_i] * (1 + pct):
                piv.append(Pivot(lo_i, float(low[lo_i]), "L", i)); mode = 1; hi_i = i
    return piv


def fractal(high, low, k):
    """Local extreme with k bars each side, confirmed k bars later; alternation enforced
    by keeping only the more extreme of consecutive same-kind pivots *at confirmation time*."""
    high = np.asarray(high, float); low = np.asarray(low, float); n = len(high); raw = []
    for i in range(k, n - k):
        if high[i] == high[i - k:i + k + 1].max(): raw.append(Pivot(i, float(high[i]), "H", i + k))
        if low[i] == low[i - k:i + k + 1].min(): raw.append(Pivot(i, float(low[i]), "L", i + k))
    raw.sort(key=lambda p: (p.confirm_idx, p.idx))
    out = []
    for p in raw:
        if out and out[-1].kind == p.kind:
            better = p.price > out[-1].price if p.kind == "H" else p.price < out[-1].price
            if better: out[-1] = Pivot(p.idx, p.price, p.kind, p.confirm_idx)
            continue
        out.append(p)
    return out


def compute(high, low, cfg_common):
    if cfg_common.get("pivot_method", "zigzag") == "fractal":
        return fractal(high, low, cfg_common["pivot_k"])
    return zigzag(high, low, cfg_common["pivot_pct"])


def confirmed(pivots, t):
    """Pivots usable at bar t (confirm_idx <= t)."""
    return [p for p in pivots if p.confirm_idx <= t]
