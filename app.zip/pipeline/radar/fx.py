"""新台幣匯率（USD/TWD）— 中央銀行（cbc.gov.tw）公開資料。

主來源（都是央行官方、免金鑰）：
  1. 央行統計資料庫 DataAPI：https://cpx.cbc.gov.tw/API/DataAPI/Get?FileName=BP01D01
     「我國與主要貿易對手通貨對美元之匯率」日資料（1993 起；第 1 欄 新台幣NTD/USD；台灣時間 16:00 銀行間即期匯率）。
     約每月初更新一次 → 只當歷史。
  2. 央行網站「新臺幣/美元 銀行間收盤匯率」：https://www.cbc.gov.tw/tw/lp-645-1.html
     最近 20 個營業日的收盤匯率（資料來源：台北外匯經紀公司），每個營業日更新 → 補最近一個月到今天。
  同一天兩邊都有時用 2（收盤匯率）。
備援：央行兩個都失敗 → Yahoo Finance TWD=X（明確標示「非央行」）。全部失敗 → 沿用上一份並標 stale。
數值意義：1 美元 = X 新台幣；數字變大 = 新台幣貶值（資金流出傾向），變小 = 升值（資金流入傾向）。
"""
from __future__ import annotations
import datetime as dt, html, json, math, re

CBC_API = "https://cpx.cbc.gov.tw/API/DataAPI/Get?FileName=BP01D01"
CBC_PAGE = "https://www.cbc.gov.tw/tw/lp-645-1.html"
YAHOO = "https://query1.finance.yahoo.com/v8/finance/chart/TWD=X?range=2y&interval=1d"


def _f(x):
    try: v = float(str(x).replace(",", "").strip())
    except (TypeError, ValueError): return None
    return v if math.isfinite(v) and v > 0 else None


def parse_cbc_api(text):
    """BP01D01 JSON → {date: rate}。找標題含 NTD/USD 的欄位（預設第 1 欄）。"""
    j = json.loads(text)
    d = j.get("data") or {}
    cols = [str((c or {}).get("data", "")) for c in ((d.get("structure") or {}).get("Table1") or [])]
    ci = next((i for i, c in enumerate(cols) if "NTD/USD" in c.replace(" ", "")), 0)
    out = {}
    for r in d.get("dataSets") or []:
        if not r or len(r) <= ci + 1: continue
        ds = str(r[0]).strip()
        if not re.fullmatch(r"\d{8}", ds): continue
        v = _f(r[ci + 1])
        if v is not None and 5 < v < 100: out[f"{ds[:4]}-{ds[4:6]}-{ds[6:]}"] = v
    if not out: raise ValueError("央行 DataAPI 沒有可用的 NTD/USD 資料")
    return out


def parse_cbc_page(text):
    """央行收盤匯率頁 HTML → {date: rate}（表格：日期 YYYY/MM/DD、NTD/USD）。"""
    out = {}
    for ds, v in re.findall(r"(\d{4}/\d{2}/\d{2})\s*</span>\s*</td>\s*<td[^>]*>\s*<span>\s*([\d.,]+)\s*<", text):
        x = _f(v)
        if x is not None and 5 < x < 100: out[ds.replace("/", "-")] = x
    if not out:   # 版面改了：退一步用去標籤後的純文字配對
        t = re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", text)))
        for ds, v in re.findall(r"(\d{4}/\d{2}/\d{2}) ([\d.]{5,7})", t):
            x = _f(v)
            if x is not None and 5 < x < 100: out[ds.replace("/", "-")] = x
    if not out: raise ValueError("央行收盤匯率頁找不到資料（版面可能改了）")
    return out


def parse_yahoo(text):
    r = ((json.loads(text).get("chart") or {}).get("result") or [None])[0]
    if not r: raise ValueError("Yahoo 沒有資料")
    off = (r.get("meta") or {}).get("gmtoffset", 28800) or 0
    q = r["indicators"]["quote"][0]; out = {}
    for i, ts in enumerate(r.get("timestamp") or []):
        c = _f(q["close"][i])
        if c is not None: out[dt.datetime.fromtimestamp(ts + off, dt.timezone.utc).strftime("%Y-%m-%d")] = c
    if not out: raise ValueError("Yahoo 收盤全空")
    return out


def fetch(get, today=None):
    """回傳 (series {date: rate}, 來源說明, 錯誤列表)。series 為 None 表示全部失敗。"""
    errs, hist, recent = [], {}, {}
    try: hist = parse_cbc_api(get(CBC_API, 60))
    except Exception as e:  # noqa: BLE001
        errs.append(f"央行 DataAPI: {str(e)[:120]}")
    try: recent = parse_cbc_page(get(CBC_PAGE, 30))
    except Exception as e:  # noqa: BLE001
        errs.append(f"央行收盤匯率頁: {str(e)[:120]}")
    if hist or recent:
        s = dict(hist); s.update(recent)
        if today: s = {d: v for d, v in s.items() if d <= today}
        src = "中央銀行（" + "＋".join(x for x, ok in (("統計資料庫 BP01D01", hist), ("收盤匯率頁", recent)) if ok) + "）"
        return s, src, errs
    try:
        s = parse_yahoo(get(YAHOO, 30))
        return s, "Yahoo Finance TWD=X（央行來源失敗時的備援，非央行資料）", errs
    except Exception as e:  # noqa: BLE001
        errs.append(f"Yahoo TWD=X: {str(e)[:120]}")
    return None, None, errs


def build_doc(series, src, errs, generated_at, keep=500, spark=60):
    days = sorted(series)[-keep:]
    c = [round(series[d], 4) for d in days]
    if len(c) < 2: raise ValueError(f"匯率資料只有 {len(c)} 筆")
    last, prev = c[-1], c[-2]
    return dict(schema_version=1, id="usdtwd", name="USD/TWD 新台幣", symbol="NTD/USD", region="台灣", source=src,
                data_as_of=days[-1], generated_at=generated_at, stale=False, errors=errs, line_only=True, has_volume=False,
                n_bars=len(c), close=last, prev_close=prev, change=round(last - prev, 4), change_pct=round((last / prev - 1) * 100, 3),
                spark=c[-spark:], spark_from=days[-spark:][0],
                bars=dict(t=[d.replace("-", "") for d in days], o=c, h=c, l=c, c=c, v=[0] * len(c)),
                notes=["1 美元兌新台幣（銀行間）。數字變大 = 新台幣貶值（外資匯出傾向），變小 = 升值（資金匯入傾向）。",
                       "央行只公布每日收盤（無開高低），所以畫折線，不畫 K 棒、不判型態。"])
