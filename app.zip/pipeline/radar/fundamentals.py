"""Fundamentals ingestion (§8) — official free sources only (TWSE / TPEx OpenAPI, which republish MOPS data).

What the OpenAPI provides is the LATEST period only:
- 月營收  t187ap05_L / mopsfin_t187ap05_O : 當月營收、MoM、YoY、累計 YoY（as_of = 出表日期）
- 損益    t187ap14_L / mopsfin_t187ap14_O : 基本每股盈餘（本年累計至最近一季）
- 營益分析 t187ap17_L（上市）；上櫃 mopsfin_t187ap17_O 無法取得 → 由 mopsfin_t187ap06_O_ci 科目自行相除
- 綜合損益/資產負債 t187ap06_*_ci / t187ap07_*_ci（一般業）：ROE = 本年累計歸屬母公司淨利 × 4/季數 ÷ 歸屬母公司權益（年化）
- 本益比/殖利率/淨值比 BWIBBU_ALL / tpex_mainboard_peratio_analysis（每日）
Limits (labelled in UI): EPS 近四季、ROE 近四季需要歷史季報（MOPS），本版標「資料待補」；
金融保險業等非一般業格式（_basi/_bd/_fh/_ins）未抓 → 毛利率等標待補；財測無免費官方來源。
"""
import datetime as dt, re
from .dataproxy import fetch_json
from .ingest import roc_to_iso


def f(x):
    try:
        s = str(x).replace(",", "").strip()
        return float(s) if s not in ("", "-", "--", "N/A") else None
    except ValueError:
        return None


def _get(src, url, tag):
    return fetch_json(src, url, tag, ok=lambda j: isinstance(j, list) and len(j) > 100)


def ingest_fundamentals(con, T: dt.date):
    tag = T.strftime("%Y%m%d"); res = {}
    # ---- monthly revenue
    n = 0
    for src, url, mk in (("twse_openapi", "https://openapi.twse.com.tw/v1/opendata/t187ap05_L", "L"),
                         ("tpex_openapi", "https://www.tpex.org.tw/openapi/v1/mopsfin_t187ap05_O", "O")):
        j = _get(src, url, f"t187ap05_{mk}_{tag}.json")
        res[f"revenue_{mk}"] = bool(j)
        for r in j or []:
            ym = r["資料年月"].strip(); ym = f"{int(ym[:-2]) + 1911}-{ym[-2:]}"
            con.execute("INSERT OR REPLACE INTO monthly_revenue VALUES (?,?,?,?,?,?,?,?)",
                        (r["公司代號"].strip(), ym, f(r["營業收入-當月營收"]), f(r["營業收入-上月比較增減(%)"]),
                         f(r["營業收入-去年同月增減(%)"]), f(r["累計營業收入-前期比較增減(%)"]), roc_to_iso(r["出表日期"]), f"OpenAPI t187ap05_{mk}")); n += 1
    res["revenue_rows"] = n
    # ---- quarterly: EPS, margins, ROE
    fin = {}
    def rec(sym, yq, **kw):
        d = fin.setdefault((sym, yq), {}); d.update({k: v for k, v in kw.items() if v is not None})
    for src, url, mk in (("twse_openapi", "https://openapi.twse.com.tw/v1/opendata/t187ap14_L", "L"),
                         ("tpex_openapi", "https://www.tpex.org.tw/openapi/v1/mopsfin_t187ap14_O", "O")):
        j = _get(src, url, f"t187ap14_{mk}_{tag}.json"); res[f"eps_{mk}"] = bool(j)
        for r in j or []:
            sym = (r.get("公司代號") or r.get("SecuritiesCompanyCode")).strip()
            y = (r.get("年度") or r.get("Year")).strip(); q = r["季別"].strip()
            rec(sym, f"{int(y)+1911}Q{q}", eps=f(r.get("基本每股盈餘(元)", r.get("基本每股盈餘"))),
                announced_at=roc_to_iso(r.get("出表日期") or r.get("Date")), q=int(q))
    j = _get("twse_openapi", "https://openapi.twse.com.tw/v1/opendata/t187ap17_L", f"t187ap17_L_{tag}.json"); res["margins_L"] = bool(j)
    for r in j or []:
        rec(r["公司代號"].strip(), f"{int(r['年度'])+1911}Q{r['季別'].strip()}", gm=f(r["毛利率(%)(營業毛利)/(營業收入)"]),
            om=f(r["營業利益率(%)(營業利益)/(營業收入)"]), nm=f(r["稅後純益率(%)(稅後純益)/(營業收入)"]))
    for mk, src, base in (("L", "twse_openapi", "https://openapi.twse.com.tw/v1/opendata/t187ap"),
                          ("O", "tpex_openapi", "https://www.tpex.org.tw/openapi/v1/mopsfin_t187ap")):
        inc = _get(src, f"{base}06_{mk}_ci", f"t187ap06_{mk}_ci_{tag}.json")
        bal = _get(src, f"{base}07_{mk}_ci", f"t187ap07_{mk}_ci_{tag}.json")
        res[f"income_{mk}"], res[f"balance_{mk}"] = bool(inc), bool(bal)
        def key(r):
            sym = (r.get("公司代號") or r.get("SecuritiesCompanyCode")).strip()
            y = (r.get("年度") or r.get("Year")).strip(); q = (r.get("季別") or r.get("Season")).strip()
            return sym, f"{int(y)+1911}Q{q}", int(q)
        for r in inc or []:
            sym, yq, q = key(r)
            rev = f(r.get("營業收入")); gp = f(r.get("營業毛利（毛損）淨額")) or f(r.get("營業毛利（毛損）")); op = f(r.get("營業利益（損失）"))
            ni = f(r.get("淨利（淨損）歸屬於母公司業主")); ni = ni if ni is not None else f(r.get("本期淨利（淨損）"))
            kw = dict(net_income=ni, q=q)
            if mk == "O" and rev:
                kw.update(gm=gp / rev * 100 if gp is not None else None, om=op / rev * 100 if op is not None else None,
                          nm=(f(r.get("本期淨利（淨損）")) or 0) / rev * 100)
            rec(sym, yq, **kw)
        for r in bal or []:
            sym, yq, q = key(r)
            rec(sym, yq, equity=f(r.get("歸屬於母公司業主之權益合計")) or f(r.get("權益總計")))
    n = 0
    for (sym, yq), d in fin.items():
        roe = None
        if d.get("net_income") is not None and d.get("equity") and d.get("q"):
            roe = d["net_income"] * 4 / d["q"] / d["equity"] * 100
        con.execute("INSERT OR REPLACE INTO quarterly_financials VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (sym, yq, d.get("eps"), d.get("gm"), d.get("om"), d.get("nm"), d.get("net_income"), d.get("equity"), roe,
                     d.get("announced_at"), "本年累計", "本年累計年化（非近四季）", "TWSE/TPEx OpenAPI")); n += 1
    res["financial_rows"] = n
    # ---- valuation (daily)
    n = 0
    j = _get("twse_openapi", "https://openapi.twse.com.tw/v1/exchangeReport/BWIBBU_ALL", f"bwibbu_all_{tag}.json"); res["valuation_L"] = bool(j)
    for r in j or []:
        con.execute("INSERT OR REPLACE INTO valuation_daily VALUES (?,?,?,?,?)",
                    (r["Code"].strip(), roc_to_iso(r["Date"]), f(r["PEratio"]), f(r["PBratio"]), f(r["DividendYield"]))); n += 1
    j = _get("tpex_openapi", "https://www.tpex.org.tw/openapi/v1/tpex_mainboard_peratio_analysis", f"tpex_peratio_{tag}.json"); res["valuation_O"] = bool(j)
    for r in j or []:
        con.execute("INSERT OR REPLACE INTO valuation_daily VALUES (?,?,?,?,?)",
                    (r["SecuritiesCompanyCode"].strip(), roc_to_iso(r["Date"]), f(r["PriceEarningRatio"]), f(r["PriceBookRatio"]), f(r["YieldRatio"]))); n += 1
    res["valuation_rows"] = n
    con.commit()
    return res


def latest_snapshot(con, T: str):
    """{symbol: {rev:{…}, fin:{…}, val:{…}}} using only rows announced on/before T (防未來函數)."""
    out = {}
    for sym, ym, rv, mom, yoy, cy, ann in con.execute(
            """SELECT symbol, ym, revenue, mom, yoy, cum_yoy, announced_at FROM monthly_revenue m
               WHERE announced_at <= ? AND ym = (SELECT max(ym) FROM monthly_revenue WHERE symbol=m.symbol AND announced_at <= ?)""", (T, T)):
        out.setdefault(sym, {})["rev"] = dict(ym=ym, revenue=rv, mom=mom, yoy=yoy, cum_yoy=cy, as_of=ann)
    for sym, yq, eps, gm, om, nm, roe, ann in con.execute(
            """SELECT symbol, yq, eps, gross_margin, op_margin, net_margin, roe_ttm, announced_at FROM quarterly_financials q
               WHERE announced_at <= ? AND yq = (SELECT max(yq) FROM quarterly_financials WHERE symbol=q.symbol AND announced_at <= ?)""", (T, T)):
        out.setdefault(sym, {})["fin"] = dict(yq=yq, eps_ytd=eps, gross_margin=gm, op_margin=om, net_margin=nm, roe_ann=roe, as_of=ann)
    for sym, d, pe, pb, dy in con.execute(
            """SELECT symbol, date, pe, pb, dividend_yield FROM valuation_daily v
               WHERE date <= ? AND date = (SELECT max(date) FROM valuation_daily WHERE symbol=v.symbol AND date <= ?)""", (T, T)):
        out.setdefault(sym, {})["val"] = dict(date=d, pe=pe, pb=pb, dividend_yield=dy)
    return out


# ---------------------------------------------------------------- FundamentalFilter (§4, §8)
FIELDS = {  # key: (group, field, label)
    "rev_yoy": ("rev", "yoy", "月營收 YoY(%)"), "rev_mom": ("rev", "mom", "月營收 MoM(%)"), "rev_cum_yoy": ("rev", "cum_yoy", "累計營收 YoY(%)"),
    "eps_ytd": ("fin", "eps_ytd", "EPS 本年累計(元)"), "gross_margin": ("fin", "gross_margin", "毛利率(%)"),
    "op_margin": ("fin", "op_margin", "營益率(%)"), "net_margin": ("fin", "net_margin", "淨利率(%)"),
    "roe_ann": ("fin", "roe_ann", "ROE 年化(%)"), "pe": ("val", "pe", "本益比"), "pb": ("val", "pb", "股價淨值比"),
    "dividend_yield": ("val", "dividend_yield", "殖利率(%)"),
}


def apply_rules(snap, rules):
    """rules: [{key, mode: off|required|bonus, op: '>='|'<=', value}]. Default: all off → everything 'pass'.
    Returns (status, bonus, detail) where status ∈ pass / fail / pending(資料待補 — never eliminated)."""
    status, bonus, detail = "pass", 0, []
    for r in rules or []:
        if r.get("mode", "off") == "off" or r.get("value") is None: continue
        g, fld, label = FIELDS[r["key"]]
        v = ((snap or {}).get(g) or {}).get(fld)
        if v is None:
            detail.append((r["key"], "pending"))
            if r["mode"] == "required" and status == "pass": status = "pending"
            continue
        ok = v >= r["value"] if r.get("op", ">=") == ">=" else v <= r["value"]
        detail.append((r["key"], "pass" if ok else "fail"))
        if r["mode"] == "required" and not ok: status = "fail"
        if r["mode"] == "bonus" and ok: bonus += 1
    return status, bonus, detail
