"""All tunable parameters with their spec defaults (§5.0, §5.2, §6.3, §7, App. A).

Every value here is a configurable setting, NOT a market statistic. Items marked
ASSUMED are 補定義（待 Jay 確認）; items marked ENGINE are extra engineering defaults
this implementation needed that the spec does not state (also 待 Jay 確認).
"""
import copy, json, os

DEFAULTS = {
    "common": {
        "pivot_method": "zigzag",   # A2 ASSUMED: zigzag | fractal
        "pivot_pct": 0.05,          # A2 ASSUMED 5%
        "pivot_k": 3,               # A2 ASSUMED (fractal mode)
        "break_buf": 0.02,          # A3 decided 2% (Jay 2026-11-23)
        "near_pct": 0.03,           # §5.2① FORMING band 3%
        "vol_short_n": 5, "vol_short_mult": 1.3, "vol_long_n": 20, "vol_long_mult": 1.0,  # A4 (技術篩選共同門檻)
        "vol_required_short_break": False,   # A5 ASSUMED
        "breakout_window": 60,      # ENGINE: max bars between last structural pivot and trigger
        "confirm_window": 20,       # ENGINE: max bars between FORMING (reclaim/fail) and neckline trigger (②③⑦)
        "track_days": 10,           # ENGINE: lifecycle look-back for FAILED / TARGET_HIT after CONFIRMED
        "strength_weights": {"vol": 25, "break": 25, "shape": 25, "inst": 25},  # A8 ASSUMED
        "strength_vol_full": 3.0,   # ENGINE: vol ratio at which the vol component is full (1.0 → 0)
        "strength_break_full": 0.06,# ENGINE: breakout % at which the breakout component is full
    },
    "universe": {                    # B7 (技術篩選共同排除), can be disabled
        "enabled": True, "exclude_disposal": True, "exclude_full_delivery": True,
        "min_price": 10.0, "min_avg_vol20_lots": 500, "min_bars": 60,
        "include_etf": True,
    },
    "w_bottom":        {"trend_lookback": 60, "prior_trend_pct": 0.15, "bottom_tol": 0.03, "min_width": 10, "max_width": 120},
    "bottom_reversal": {"support_lookback": 60, "reclaim_window": 10},
    "bottom_reversal_w": {"trend_lookback": 60, "prior_trend_pct": 0.15, "min_width": 10, "max_width": 120, "reclaim_window": 10},
    "bull_flag":  {"pole_max_days": 15, "pole_pct": 0.15, "flag_min": 5, "flag_max": 25, "parallel_tol": 0.30, "flag_retrace_max": 0.50},
    "bear_flag":  {"pole_max_days": 15, "pole_pct": 0.15, "flag_min": 5, "flag_max": 25, "parallel_tol": 0.30, "flag_retrace_max": 0.50},
    "m_top":      {"trend_lookback": 60, "prior_trend_pct": 0.15, "top_tol": 0.03, "min_width": 10, "max_width": 120},
    "false_breakout": {"resist_lookback": 60, "reclaim_window": 10, "fakeout_trigger": "neckline"},  # neckline | breakout_bar_low
    "hs_top":     {"head_margin": 0.03, "shoulder_tol": 0.05, "max_span": 160},
    "hs_top_fake":{"head_margin": 0.03, "shoulder_tol": 0.05, "max_span": 160, "resist_lookback": 60, "reclaim_window": 10},
    "hs_bottom":  {"head_margin": 0.03, "shoulder_tol": 0.05, "max_span": 160},
    "tri_top":    {"tri_min": 15, "tri_max": 120, "apex_from": 0.50, "apex_to": 0.80, "trend_lookback": 60, "prior_trend_pct": 0.15},
    "tri_bottom": {"tri_min": 15, "tri_max": 120, "apex_from": 0.50, "apex_to": 0.80, "trend_lookback": 60, "prior_trend_pct": 0.15},
    "cis_common": {"ma_fast": 5, "ma_slow": 25, "slope_lookback": 5, "slope_flat_band": 0.002,
                   "near_ma25_pct": 0.01, "min_bars": 60},
    "cis_base":   {"second_reclaim_lookback": 10, "ladle_lookback": 3},
    "cis_exp":    {"short_requires_ma25_down": True, "ma_short_n": 5, "mult_short": 1.3, "ma_long_n": 20, "mult_long": 1.0},
    "sector":     {"w1": 0.4, "w2": 0.3, "w3": 0.1, "w4": 0.2, "min_hits": 2, "min_ratio": 0.10, "min_members": 5},  # A9
}


# 回測設定（§12.5）：樣本內外切分日等，可由 params.json 的 "backtest" 區段覆寫
BACKTEST_DEFAULTS = {"start": "2024-01-02", "split": "2025-07-01", "max_positions": 8, "min_trades_display": 30}


def _strip(d):
    """Drop explanation keys (starting with '_') at any level of a params.json document."""
    if isinstance(d, dict): return {k: _strip(v) for k, v in d.items() if not str(k).startswith("_")}
    return d


def load_params_file(path=None):
    """Overrides from the file named by env RADAR_PARAMS (GitHub 版 repo 根目錄的 params.json).
    Unset → {} (box behaviour unchanged). Invalid JSON or unknown keys → ValueError (fail loudly)."""
    path = path or os.environ.get("RADAR_PARAMS")
    if not path: return {}
    doc = _strip(json.load(open(path, encoding="utf-8")))
    allowed = set(DEFAULTS) | {"backtest"}
    bad = [k for k in doc if k not in allowed]
    if bad: raise ValueError(f"params.json 有不認得的區段：{bad}（可用：{sorted(allowed)}）")
    for sec, v in doc.items():
        if not isinstance(v, dict): raise ValueError(f"params.json 的 {sec} 必須是 {{...}}")
        ref = BACKTEST_DEFAULTS if sec == "backtest" else DEFAULTS[sec]
        unknown = [k for k in v if k not in ref]
        if unknown: raise ValueError(f"params.json 的 {sec} 有不認得的參數：{unknown}")
    return doc


def backtest_defaults():
    b = dict(BACKTEST_DEFAULTS); b.update(load_params_file().get("backtest", {})); return b


def get(overrides=None):
    cfg = copy.deepcopy(DEFAULTS)
    for k, v in load_params_file().items():
        if k != "backtest": cfg.setdefault(k, {}).update(v)
    for k, v in (overrides or {}).items():
        cfg.setdefault(k, {}).update(v)
    return cfg
