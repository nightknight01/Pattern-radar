"""資料狀態（§13 DataHealth）：每個資料源最後成功時間、錯誤、節流；各資料表最新日期與筆數。寫 web/health_latest.json。
cache/health.json 的時間是 box 本機時間（naive）；這裡一律轉成台北時間輸出。"""
import datetime as dt, json, os
from zoneinfo import ZoneInfo
from . import dataproxy

TPE = ZoneInfo("Asia/Taipei")
SOURCE_ZH = {"twse": "TWSE 證交所（網站 API）", "tpex": "TPEx 櫃買中心（網站 API）", "twse_openapi": "TWSE OpenAPI", "tpex_openapi": "TPEx OpenAPI"}
TABLES = [("daily_bars", "date", "日 K（上市＋上櫃）"), ("institutional_flows", "date", "三大法人買賣超"), ("margin_daily", "date", "融資融券／可否融券"),
          ("valuation_daily", "date", "本益比／淨值比／殖利率"), ("monthly_revenue", "ym", "月營收"), ("quarterly_financials", "yq", "季財報"),
          ("corporate_actions", "ex_date", "除權息"), ("trading_days", "date", "交易日曆")]


def _tpe(s):
    if not s: return None
    try:
        t = dt.datetime.fromisoformat(s.split(" ")[0] if " " in s and s[4] == "-" and "T" in s else s)
    except ValueError:
        return s
    if t.tzinfo is None: t = t.astimezone()  # box local → aware
    return t.astimezone(TPE).isoformat(timespec="seconds")


def build(con, scan_doc=None):
    raw = {}
    if os.path.exists(dataproxy.HEALTH_PATH):
        try: raw = json.load(open(dataproxy.HEALTH_PATH))
        except Exception: raw = {}
    sources = []
    for k, h in raw.items():
        err = h.get("last_error")
        if err and " " in err: ts, msg = err.split(" ", 1); err = f"{_tpe(ts)} {msg}"
        sources.append(dict(id=k, name=SOURCE_ZH.get(k, k), ok=h.get("ok", 0), fail=h.get("fail", 0), last_ok=_tpe(h.get("last_ok")),
                            last_error=err, throttle_sec=dataproxy.THROTTLE.get(k)))
    tables = []
    for t, col, zh in TABLES:
        try:
            mx = con.execute(f"SELECT max({col}) FROM {t}").fetchone()[0]
            n = con.execute(f"SELECT count(*) FROM {t} WHERE {col}=?", (mx,)).fetchone()[0] if mx else 0
            tot = con.execute(f"SELECT count(*) FROM {t}").fetchone()[0]
            mn = con.execute(f"SELECT min({col}) FROM {t}").fetchone()[0]
            tables.append(dict(table=t, name=zh, latest=mx, earliest=mn, rows_latest=n, rows=tot))
        except Exception as e:
            tables.append(dict(table=t, name=zh, error=str(e)))
    td = con.execute("SELECT count(*), min(date), max(date) FROM trading_days WHERE twse=1 AND tpex=1").fetchone()
    out = dict(schema_version=1, generated_at=dt.datetime.now(TPE).isoformat(timespec="seconds"), timezone="Asia/Taipei",
               sources=sources, tables=tables, trading_days=dict(count=td[0], first=td[1], last=td[2]))
    if scan_doc:
        out["trade_date"] = scan_doc.get("trade_date")
        out["scan"] = dict(trade_date=scan_doc.get("trade_date"), data_as_of=scan_doc.get("data_as_of"), finished_at=scan_doc.get("finished_at"),
                           universe=(scan_doc.get("stats") or {}).get("universe"), excluded=(scan_doc.get("stats") or {}).get("excluded"),
                           inst_available=(scan_doc.get("stats") or {}).get("inst_available"), margin_available=(scan_doc.get("stats") or {}).get("margin_available"),
                           data_sources=scan_doc.get("data_sources"), custom_pattern_errors=scan_doc.get("custom_pattern_errors") or [])
    out["notes"] = ["節流：每來源固定請求間隔＋失敗時指數退避重試（最多等 60 秒）；「查無資料」不寫入快取。",
                    "警示信目前只產生 dry-run 預覽，未寄出（需 Jay 授權）。"]
    return out
