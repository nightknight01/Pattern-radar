#!/usr/bin/env python3
"""全球指數儀表板資料：寫出 web/indices_latest.json（給 #/markets 頁）。

來源：Yahoo chart API（免金鑰）→ 失敗改用 stooq CSV → 中國指數再退 新浪財經 K 線。
任何一檔失敗：沿用上次的值並標 stale；整支程式失敗也不會讓主批次失敗（run_ci.sh 以 `|| true` 呼叫）。
usage: python3 run_indices.py [--out ../web]
"""
import argparse, csv, datetime as dt, io, json, os, sys, time, urllib.request
from zoneinfo import ZoneInfo

HERE = os.path.dirname(os.path.abspath(__file__))
TPE = ZoneInfo("Asia/Taipei")
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
KEEP = 60          # sparkline 長度（交易日）
MIN_POINTS = 20    # 少於這麼多根視為來源異常（例：Yahoo 的 000300.SS 只回 1 根）
# (id, Yahoo 代號, 中文名, 地區, stooq 代號, 新浪代號)
INDICES = [
    ("spx", "^GSPC", "S&P 500", "美國", "^spx", None),
    ("dji", "^DJI", "道瓊工業", "美國", "^dji", None),
    ("ixic", "^IXIC", "那斯達克綜合", "美國", "^ndq", None),
    ("rut", "^RUT", "羅素 2000", "美國", "^rut", None),
    ("sox", "^SOX", "費城半導體 SOX", "美國", "^sox", None),
    ("twii", "^TWII", "台股加權指數", "台灣", "^twse", None),
    ("n225", "^N225", "日經 225", "日本", "^nkx", None),
    ("dax", "^GDAXI", "德國 DAX", "德國", "^dax", None),
    ("cac", "^FCHI", "法國 CAC 40", "法國", "^cac", None),
    ("csi300", "000300.SS", "滬深 300", "中國", None, "sh000300"),
    ("sse", "000001.SS", "上證綜合", "中國", "^shc", "sh000001"),
]


def http_get(url, timeout=20):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", "replace")


def _clean(pairs):
    """[(date, close)] → 去掉空值、同日取最後一筆、依日期排序。"""
    d = {}
    for day, c in pairs:
        if c is None: continue
        try: c = float(c)
        except (TypeError, ValueError): continue
        if c != c or c <= 0: continue
        d[day] = c
    return sorted(d.items())


def from_yahoo(sym, get=http_get):
    j = json.loads(get(f"https://query1.finance.yahoo.com/v8/finance/chart/{urllib.request.quote(sym)}?range=3mo&interval=1d"))
    r = (j.get("chart") or {}).get("result") or []
    if not r: raise ValueError("Yahoo 無資料：" + str((j.get("chart") or {}).get("error")))
    r = r[0]; ts = r.get("timestamp") or []; q = ((r.get("indicators") or {}).get("quote") or [{}])[0]
    off = (r.get("meta") or {}).get("gmtoffset", 0) or 0
    closes = q.get("close") or []
    return _clean((dt.datetime.fromtimestamp(t + off, dt.timezone.utc).strftime("%Y-%m-%d"), closes[i] if i < len(closes) else None) for i, t in enumerate(ts))


def from_stooq(sym, get=http_get):
    if not sym: raise ValueError("無 stooq 代號")
    txt = get(f"https://stooq.com/q/d/l/?s={urllib.request.quote(sym)}&i=d")
    rows = list(csv.DictReader(io.StringIO(txt)))
    if not rows or "Close" not in rows[0]: raise ValueError("stooq 回應不是 CSV")
    return _clean((r["Date"], r["Close"]) for r in rows)[-(KEEP + 30):]


def from_sina(sym, get=http_get):
    if not sym: raise ValueError("無新浪代號")
    j = json.loads(get(f"https://money.finance.sina.com.cn/quotes_service/api/json_v2.php/CN_MarketData.getKLineData?symbol={sym}&scale=240&ma=no&datalen={KEEP + 10}"))
    return _clean((r["day"], r["close"]) for r in j or [])


def build_one(spec, get=http_get):
    iid, ysym, name, region, ssym, sina = spec
    errs = []
    for src, fn, arg in (("Yahoo Finance", from_yahoo, ysym), ("stooq", from_stooq, ssym), ("新浪財經", from_sina, sina)):
        if arg is None: continue
        try:
            pts = fn(arg, get)
            if len(pts) < MIN_POINTS: raise ValueError(f"只有 {len(pts)} 根")
            pts = pts[-(KEEP + 1):]
            last, prev = pts[-1][1], pts[-2][1]
            spark = pts[-KEEP:]
            return dict(id=iid, symbol=ysym, name=name, region=region, close=round(last, 2), prev_close=round(prev, 2),
                        change=round(last - prev, 2), change_pct=round((last / prev - 1) * 100, 2), date=pts[-1][0],
                        spark=[round(c, 2) for _, c in spark], spark_from=spark[0][0], source=src, stale=False), errs
        except Exception as e:  # noqa: BLE001 — 每個來源都可能失敗，記錄後換下一個
            errs.append(f"{src}: {str(e)[:120]}")
    return None, errs


def build(prev=None, get=http_get, sleep=0.4):
    old = {x["id"]: x for x in (prev or {}).get("indices", [])}
    out, errors = [], {}
    for spec in INDICES:
        rec, errs = build_one(spec, get)
        if rec is None:
            errors[spec[0]] = errs
            if spec[0] in old:
                rec = dict(old[spec[0]], stale=True, error="本次抓取失敗，沿用上次資料")
            else:
                rec = dict(id=spec[0], symbol=spec[1], name=spec[2], region=spec[3], close=None, change_pct=None, date=None,
                           spark=[], source=None, stale=True, error="抓取失敗，尚無資料")
        out.append(rec)
        if sleep: time.sleep(sleep)
    return dict(schema_version=1, generated_at=dt.datetime.now(TPE).isoformat(timespec="seconds"), timezone="Asia/Taipei",
                note="每天台北時間 15:00／17:30／21:30 更新；美股與歐股顯示的是前一晚（當地時間前一個交易日）的收盤。",
                indices=out, errors=errors)


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--out", default=os.path.join(HERE, "..", "web")); a = ap.parse_args()
    path = os.path.join(a.out, "indices_latest.json")
    prev = None
    try: prev = json.load(open(path, encoding="utf-8"))
    except Exception: prev = None
    try:
        doc = build(prev)
    except Exception as e:  # 絕不讓主批次失敗
        print(f"::warning::全球指數整體失敗：{e}")
        if not prev: return 0
        doc = dict(prev, indices=[dict(x, stale=True) for x in prev.get("indices", [])], errors={"_all": str(e)[:200]})
    os.makedirs(a.out, exist_ok=True)
    json.dump(doc, open(path, "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))
    ok = sum(1 for x in doc["indices"] if not x.get("stale"))
    print(f"indices: {ok}/{len(doc['indices'])} 更新成功" + (f"；失敗 {list(doc['errors'])}" if doc.get("errors") else ""))
    return 0


if __name__ == "__main__":
    try: sys.exit(main())
    except Exception as e:  # noqa: BLE001
        print(f"::warning::run_indices 例外：{e}"); sys.exit(0)
