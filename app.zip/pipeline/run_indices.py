#!/usr/bin/env python3
"""全球指數儀表板資料：寫出 web/indices_latest.json（給 #/markets 頁）＋每個指數一份 web/idx_<id>.json（給 #/markets/<id> K 線頁）。

來源：Yahoo chart API（免金鑰，日 K 約 2 年）→ 失敗改用 stooq CSV → 中國指數再退 新浪財經 K 線。
K 線頁：取最近 LOOKBACK（=300，同全市場掃描的 --lookback）根日 K，跑十二招型態偵測（同 radar.engine，不含 CIS）。
  有型態 → 前端畫頸線／突破／滿足點／停損與趨勢線；沒有 → 只畫 K 線。
  盤中尚未收盤的最後一根（例：台北 15:00 時歐股開盤中）不納入，避免用半根 K 棒判型態。
  指數沒有成交量（例：部分來源回 0）→ 量能條件不適用（視為通過），並在說明中註記。
任何一檔失敗：沿用上次的值並標 stale；整支程式失敗也不會讓主批次失敗（run_ci.sh 以 `|| true` 呼叫）。
usage: python3 run_indices.py [--out ../web]
"""
import argparse, csv, datetime as dt, io, json, math, os, sys, time, urllib.request
from zoneinfo import ZoneInfo

HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
TPE = ZoneInfo("Asia/Taipei")
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
KEEP = 60          # sparkline 長度（交易日）
MIN_POINTS = 20    # 少於這麼多根視為來源異常（例：Yahoo 的 000300.SS 只回 1 根）
LOOKBACK = 300     # K 線頁與型態偵測用的日 K 根數（同 run_scan.py --lookback 預設）
MIN_PATTERN_BARS = 80   # 少於這麼多根不判型態（只畫 K 線）
# (id, Yahoo 代號, 中文名, 地區, stooq 代號, 新浪代號)
INDICES = [
    ("spx", "^GSPC", "S&P 500", "美國", "^spx", None),
    ("dji", "^DJI", "道瓊工業", "美國", "^dji", None),
    ("ixic", "^IXIC", "那斯達克綜合", "美國", "^ndq", None),
    ("rut", "^RUT", "羅素 2000", "美國", "^rut", None),
    ("sox", "^SOX", "費城半導體 SOX", "美國", "^sox", None),
    ("twii", "^TWII", "台股加權指數", "台灣", "^twse", None),
    ("n225", "^N225", "日經 225", "日本", "^nkx", None),
    ("dax", "^GDAXI", "德國 DAX", "德國", "^dax", None),
    ("cac", "^FCHI", "法國 CAC 40", "法國", "^cac", None),
    ("csi300", "000300.SS", "滬深 300", "中國", None, "sh000300"),
    ("sse", "000001.SS", "上證綜合", "中國", "^shc", "sh000001"),
]
IDS = [x[0] for x in INDICES]


def http_get(url, timeout=20):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", "replace")


def _f(x):
    try: x = float(x)
    except (TypeError, ValueError): return None
    return x if x == x and math.isfinite(x) else None


def _clean(rows):
    """[(date, o, h, l, c, v)]（o/h/l/v 可缺）→ 去掉收盤空值、同日取最後一筆、依日期排序；
    缺開高低用收盤補，並修正高低使其包住開收；量缺 → 0。回傳 [(date, o, h, l, c, v)]。"""
    d = {}
    for r in rows:
        day, c = r[0], _f(r[4] if len(r) > 4 else r[1])
        if c is None or c <= 0: continue
        if len(r) > 4:
            o, h, l, v = (_f(x) for x in (r[1], r[2], r[3], r[5] if len(r) > 5 else None))
        else:
            o = h = l = v = None
        o = o if o and o > 0 else c; h = h if h and h > 0 else max(o, c); l = l if l and l > 0 else min(o, c)
        if h < l: h, l = l, h                       # 來源偶有高低欄位顛倒
        h, l = max(h, o, c), min(l, o, c)
        d[day] = (day, o, h, l, c, v if v and v > 0 else 0.0)
    return [d[k] for k in sorted(d)]


def _partial_last(meta, rows, now=None):
    """Yahoo meta.currentTradingPeriod.regular：現在還在當地盤中，且最後一根就是今天 → 這根還沒收盤。"""
    try:
        reg = meta["currentTradingPeriod"]["regular"]; off = meta.get("gmtoffset", 0) or 0
        now = int(now if now is not None else time.time())
        if not (reg["start"] <= now < reg["end"]): return False
        today = dt.datetime.fromtimestamp(now + off, dt.timezone.utc).strftime("%Y-%m-%d")
        return bool(rows) and rows[-1][0] == today
    except Exception:  # noqa: BLE001 — 沒有這個欄位就當作已收盤
        return False


def from_yahoo(sym, get=http_get, now=None):
    j = json.loads(get(f"https://query1.finance.yahoo.com/v8/finance/chart/{urllib.request.quote(sym)}?range=2y&interval=1d"))
    r = (j.get("chart") or {}).get("result") or []
    if not r: raise ValueError("Yahoo 無資料：" + str((j.get("chart") or {}).get("error")))
    r = r[0]; ts = r.get("timestamp") or []; q = ((r.get("indicators") or {}).get("quote") or [{}])[0]
    meta = r.get("meta") or {}; off = meta.get("gmtoffset", 0) or 0
    col = lambda k, i: (q.get(k) or [])[i] if i < len(q.get(k) or []) else None
    rows = _clean((dt.datetime.fromtimestamp(t + off, dt.timezone.utc).strftime("%Y-%m-%d"),
                   col("open", i), col("high", i), col("low", i), col("close", i), col("volume", i)) for i, t in enumerate(ts))
    if _partial_last(meta, rows, now): rows = rows[:-1]
    return rows


def from_stooq(sym, get=http_get, now=None):
    if not sym: raise ValueError("無 stooq 代號")
    txt = get(f"https://stooq.com/q/d/l/?s={urllib.request.quote(sym)}&i=d")
    rows = list(csv.DictReader(io.StringIO(txt)))
    if not rows or "Close" not in rows[0]: raise ValueError("stooq 回應不是 CSV")
    return _clean((r["Date"], r.get("Open"), r.get("High"), r.get("Low"), r["Close"], r.get("Volume")) for r in rows)[-(LOOKBACK + 30):]


def from_sina(sym, get=http_get, now=None):
    if not sym: raise ValueError("無新浪代號")
    j = json.loads(get(f"https://money.finance.sina.com.cn/quotes_service/api/json_v2.php/CN_MarketData.getKLineData?symbol={sym}&scale=240&ma=no&datalen={LOOKBACK + 10}"))
    return _clean((r["day"], r.get("open"), r.get("high"), r.get("low"), r["close"], r.get("volume")) for r in j or [])


def fetch_ohlc(spec, get=http_get, now=None):
    """依序試 Yahoo → stooq → 新浪；回傳 (rows, 來源, 錯誤列表)；全部失敗 rows=None。"""
    iid, ysym, name, region, ssym, sina = spec
    errs = []
    for src, fn, arg in (("Yahoo Finance", from_yahoo, ysym), ("stooq", from_stooq, ssym), ("新浪財經", from_sina, sina)):
        if arg is None: continue
        try:
            rows = fn(arg, get, now)
            if len(rows) < MIN_POINTS: raise ValueError(f"只有 {len(rows)} 根")
            return rows, src, errs
        except Exception as e:  # noqa: BLE001 — 每個來源都可能失敗，記錄後換下一個
            errs.append(f"{src}: {str(e)[:120]}")
    return None, None, errs


def summary_rec(spec, rows, src):
    iid, ysym, name, region = spec[:4]
    pts = [(r[0], r[4]) for r in rows][-(KEEP + 1):]
    last, prev = pts[-1][1], pts[-2][1]
    spark = pts[-KEEP:]
    return dict(id=iid, symbol=ysym, name=name, region=region, close=round(last, 2), prev_close=round(prev, 2),
                change=round(last - prev, 2), change_pct=round((last / prev - 1) * 100, 2), date=pts[-1][0],
                spark=[round(c, 2) for _, c in spark], spark_from=spark[0][0], source=src, stale=False)


def build_one(spec, get=http_get, now=None):
    rows, src, errs = fetch_ohlc(spec, get, now)
    if rows is None: return None, errs
    rec = summary_rec(spec, rows, src); rec["_rows"] = rows
    return rec, errs


# ------------------------------------------------------------------ K 線頁＋十二招
NO_VOL_NOTE = "此指數來源沒有成交量，量能條件不適用（視為通過）"


def detect(rows, cfg, symbol="IDX", name=""):
    """rows=[(date,o,h,l,c,v)] → (signals, notes)。只跑十二招（不含 CIS）；最多用最近 LOOKBACK 根。"""
    from radar import engine
    from radar.context import Ctx
    rows = rows[-LOOKBACK:]
    if len(rows) < MIN_PATTERN_BARS:
        return [], [f"K 線只有 {len(rows)} 根（少於 {MIN_PATTERN_BARS}），不判斷型態"]
    has_vol = sum(1 for r in rows[-60:] if r[5] > 0) >= 50
    v = [r[5] if has_vol else 0.0 for r in rows]
    ctx = Ctx([r[0] for r in rows], [r[1] for r in rows], [r[2] for r in rows], [r[3] for r in rows], [r[4] for r in rows], v, cfg,
              symbol=symbol, market="INDEX", sector=None, inst_net=None, shortable=None, name=name)
    sigs = engine.evaluate_symbol(ctx, ctx.n - 1, enabled=set(engine.TSAI_IDS))
    out = []
    for s in sigs:
        s["reasons"] = [x for x in s.get("reasons", []) if "放空可行性" not in x and "融券" not in x] + ([] if has_vol else [NO_VOL_NOTE])
        s.pop("shortable", None)
        out.append(s)
    return out, ([] if has_vol else [NO_VOL_NOTE])


def chart_doc(spec, rows, src, cfg, generated_at, detect_fn=detect):
    """單一指數 K 線頁資料。型態偵測失敗不影響 K 線（signals=[] 並附註）。"""
    iid, ysym, name, region = spec[:4]
    rows = rows[-LOOKBACK:]
    try:
        sigs, notes = detect_fn(rows, cfg, symbol=ysym, name=name)
    except Exception as e:  # noqa: BLE001
        sigs, notes = [], [f"型態偵測失敗：{str(e)[:120]}"]
    has_vol = any(r[5] > 0 for r in rows[-60:])
    bars = dict(t=[r[0].replace("-", "") for r in rows], o=[round(r[1], 2) for r in rows], h=[round(r[2], 2) for r in rows],
                l=[round(r[3], 2) for r in rows], c=[round(r[4], 2) for r in rows], v=[int(round(r[5])) for r in rows])
    return dict(schema_version=1, id=iid, symbol=ysym, name=name, region=region, source=src, data_as_of=rows[-1][0],
                generated_at=generated_at, stale=False, n_bars=len(rows), has_volume=has_vol, bars=bars,
                signals=sigs, patterns=sorted({s["patternId"] for s in sigs}), notes=notes)


def build(prev=None, get=http_get, sleep=0.4, out=None, cfg=None, now=None):
    """回傳 indices_latest 文件；給 out 目錄時同時寫出每個指數的 idx_<id>.json（失敗沿用上一份並標 stale）。"""
    old = {x["id"]: x for x in (prev or {}).get("indices", [])}
    gen = dt.datetime.now(TPE).isoformat(timespec="seconds")
    if out is not None and cfg is None:
        try:
            from radar import config; cfg = config.get()
        except Exception as e:  # noqa: BLE001
            print(f"::warning::讀參數失敗，指數不判型態：{e}"); cfg = None
    res, errors = [], {}
    for spec in INDICES:
        rec, errs = build_one(spec, get, now)
        if rec is None:
            errors[spec[0]] = errs
            if spec[0] in old:
                rec = dict(old[spec[0]], stale=True, error="本次抓取失敗，沿用上次資料")
            else:
                rec = dict(id=spec[0], symbol=spec[1], name=spec[2], region=spec[3], close=None, change_pct=None, date=None,
                           spark=[], source=None, stale=True, error="抓取失敗，尚無資料")
            if out is not None: rec["chart"] = mark_chart_stale(out, spec[0])
        else:
            rows = rec.pop("_rows")
            if out is not None:
                rec["chart"] = False
                try:
                    doc = chart_doc(spec, rows, rec["source"], cfg, gen) if cfg is not None else \
                        chart_doc(spec, rows, rec["source"], None, gen, detect_fn=lambda *a, **k: ([], ["未讀到參數，不判斷型態"]))
                    write_json(os.path.join(out, f"idx_{spec[0]}.json"), doc)
                    rec["chart"] = True; rec["patterns"] = [[s["patternId"], s["direction"], s["state"]] for s in doc["signals"]]
                except Exception as e:  # noqa: BLE001
                    print(f"::warning::{spec[0]} K 線頁資料失敗：{e}")
        res.append(rec)
        if sleep: time.sleep(sleep)
    return dict(schema_version=1, generated_at=gen, timezone="Asia/Taipei",
                note="每天台北時間 15:00／17:30／21:30 更新；美股與歐股顯示的是前一晚（當地時間前一個交易日）的收盤。",
                indices=res, errors=errors)


def write_json(path, doc):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(doc, f, ensure_ascii=False, separators=(",", ":"), default=lambda o: o.item() if hasattr(o, "item") else str(o))
    os.replace(tmp, path)


def mark_chart_stale(out, iid):
    """抓取失敗：上一份 idx_<id>.json 還在就標 stale 沿用；沒有就回 False（前端顯示「無資料」）。"""
    path = os.path.join(out, f"idx_{iid}.json")
    try:
        with open(path, encoding="utf-8") as f: doc = json.load(f)
        if not (doc.get("bars") or {}).get("t"): return False
        doc.update(stale=True, error="本次抓取失敗，沿用上次資料"); write_json(path, doc); return True
    except Exception:  # noqa: BLE001
        return False


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--out", default=os.path.join(HERE, "..", "web")); a = ap.parse_args()
    path = os.path.join(a.out, "indices_latest.json")
    prev = None
    try: prev = json.load(open(path, encoding="utf-8"))
    except Exception: prev = None
    try:
        doc = build(prev, out=a.out)
    except Exception as e:  # 絕不讓主批次失敗
        print(f"::warning::全球指數整體失敗：{e}")
        if not prev: return 0
        doc = dict(prev, indices=[dict(x, stale=True) for x in prev.get("indices", [])], errors={"_all": str(e)[:200]})
    write_json(path, doc)
    ok = sum(1 for x in doc["indices"] if not x.get("stale"))
    pats = {x["id"]: len(x.get("patterns") or []) for x in doc["indices"] if x.get("patterns")}
    print(f"indices: {ok}/{len(doc['indices'])} 更新成功；K 線頁 {sum(1 for x in doc['indices'] if x.get('chart'))} 檔；有型態 {pats or '無'}"
          + (f"；失敗 {list(doc['errors'])}" if doc.get("errors") else ""))
    return 0


if __name__ == "__main__":
    try: sys.exit(main())
    except Exception as e:  # noqa: BLE001
        print(f"::warning::run_indices 例外：{e}"); sys.exit(0)
