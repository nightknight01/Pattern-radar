// node pipeline/tests/web_rules_parity.js — checks web/app.js applyRules matches radar/fundamentals.apply_rules cases (test_p1.py)
const fs = require("fs"), src = fs.readFileSync(__dirname + "/../../web/app.js", "utf8");
const body = src.slice(src.indexOf("  const FFIELDS"), src.indexOf("  const CHIP"));
const { applyRules } = new Function(body + "; return { applyRules };")();
const snap = { rev: { yoy: 25, mom: -3 }, fin: { eps_ytd: 4.2, gross_margin: null }, val: { pe: 30 } };
const eq = (a, b, m) => { if (JSON.stringify(a) !== JSON.stringify(b)) { console.error("FAIL", m, a, b); process.exit(1); } };
eq(applyRules(snap, []).status, "pass", "default off");
eq(applyRules(snap, [{ key: "rev_yoy", mode: "required", op: ">=", value: 10 }, { key: "pe", mode: "required", op: "<=", value: 20 }]).status, "fail", "required fail");
eq([applyRules(snap, [{ key: "eps_ytd", mode: "bonus", op: ">=", value: 3 }])].map((r) => [r.status, r.bonus])[0], ["pass", 1], "bonus");
eq(applyRules(snap, [{ key: "gross_margin", mode: "required", op: ">=", value: 30 }]).status, "pending", "missing");
eq(applyRules(undefined, [{ key: "rev_yoy", mode: "required", op: ">=", value: 10 }]).status, "pending", "no snap");
console.log("web applyRules parity OK (5 cases)");
