import json, os, sqlite3, subprocess, tempfile, unittest
from radar import backup as bk, db

NODE = __file__.rsplit("/", 1)[0] + "/backup_interop.js"


def rec(i, ts, v=1, dev="A", deleted=0, **kw):
    return dict(id=i, updated_at=ts, version=v, updated_by_device=dev, deleted=deleted, **kw)


def node(*args):
    return json.loads(subprocess.check_output(["node", NODE, *args], text=True))


class MergeTests(unittest.TestCase):
    def test_newer_wins_tie_version_then_device_and_tombstone(self):
        local = {"watchlist": [rec("1", "2026-11-19T01:00:00.000Z", symbol="2330"), rec("2", "2026-11-19T01:00:00.000Z", v=2),
                               rec("3", "2026-11-19T01:00:00.000Z", dev="A"), rec("4", "2026-11-19T05:00:00.000Z")]}
        remote = {"watchlist": [rec("1", "2026-11-19T02:00:00.000Z", symbol="2317"), rec("2", "2026-11-19T01:00:00.000Z", v=1),
                                rec("3", "2026-11-19T01:00:00.000Z", dev="B"), rec("4", "2026-11-19T06:00:00.000Z", deleted=1),
                                rec("5", "2026-11-18T00:00:00.000Z")]}
        out, st = bk.merge(local, remote)
        m = {r["id"]: r for r in out["watchlist"]}
        self.assertEqual(m["1"]["symbol"], "2317"); self.assertEqual(m["2"]["version"], 2)
        self.assertEqual(m["3"]["updated_by_device"], "B"); self.assertEqual(m["4"]["deleted"], 1)
        self.assertEqual(st["watchlist"], dict(added=1, taken=3, kept=1, total=5, live=4))
        # JS merge gives the identical result
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f: json.dump(dict(local=local, remote=remote), f)
        js = node("merge", f.name)
        self.assertEqual(sorted(js["tables"]["watchlist"], key=lambda r: r["id"]), sorted(out["watchlist"], key=lambda r: r["id"]))
        self.assertEqual(js["stats"]["watchlist"], st["watchlist"])


class CryptoInteropTests(unittest.TestCase):
    doc = dict(exported_at="2026-11-19T10:00:00.000Z", device_id="dev-1",
               tables={"watchlist": [rec("b", "2026-11-19T01:00:00.000Z", symbol="2330", position="LONG", note="台積電")],
                       "settings": [rec("sound", "2026-11-19T01:00:00.000Z", key="sound", value_json="false")]})
    code = "ABCD-EFGH-JKMN-PQRS-TUVW-XYZ2"

    def test_python_roundtrip_and_wrong_code(self):
        blob, vault, cs = bk.encrypt(self.doc, self.code)
        doc, vault2, cs2 = bk.decrypt(blob, self.code.lower().replace("-", " "))
        self.assertEqual((vault, cs), (vault2, cs2)); self.assertEqual(doc["tables"], self.doc["tables"])
        with self.assertRaises(ValueError): bk.decrypt(blob, "WRONG-CODE")
        with self.assertRaises(ValueError): bk.decrypt(blob[:20] + bytes([blob[20] ^ 1]) + blob[21:], self.code)

    def test_js_to_python_and_back(self):
        d = tempfile.mkdtemp()
        json.dump(self.doc, open(d + "/in.json", "w"), ensure_ascii=False)
        js = node("encrypt", d + "/in.json", self.code, d + "/js.enc")
        doc, vault, cs = bk.decrypt(open(d + "/js.enc", "rb").read(), self.code)
        self.assertEqual((js["vault_id"], js["checksum"]), (vault, cs))
        self.assertEqual(doc["tables"], self.doc["tables"])
        blob, vault, cs = bk.encrypt(self.doc, self.code); open(d + "/py.enc", "wb").write(blob)
        r = node("decrypt", d + "/py.enc", self.code)
        self.assertEqual((r["vault_id"], r["checksum"]), (vault, cs)); self.assertEqual(r["doc"]["tables"], self.doc["tables"])
        self.assertIn("復原碼不正確", node("decrypt", d + "/py.enc", "XXXX")["error"])

    def test_recovery_code_shape(self):
        c = subprocess.check_output(["node", NODE, "code"], text=True).strip()
        self.assertRegex(c, r"^([A-HJKMNP-Z2-9]{4}-){5}[A-HJKMNP-Z2-9]{4}$")


class SQLiteImportTests(unittest.TestCase):
    def test_import_export_roundtrip(self):
        con = sqlite3.connect(":memory:"); con.executescript(db.SCHEMA)
        st = bk.import_tables(con, {"watchlist": [rec("w1", "2026-11-19T01:00:00.000Z", symbol="2330", position="LONG", note="")],
                                    "settings": [rec("sound", "2026-11-19T01:00:00.000Z", key="sound", value_json="true")],
                                    "daily_bars": [{"id": "x"}]})   # market tables ignored
        self.assertEqual(st["watchlist"]["live"], 1)
        t = bk.export_tables(con)
        self.assertEqual(t["watchlist"][0]["symbol"], "2330"); self.assertEqual(t["settings"][0]["id"], "sound")
        self.assertNotIn("daily_bars", t)
        bk.import_tables(con, {"watchlist": [rec("w1", "2026-11-19T03:00:00.000Z", deleted=1, symbol="2330", position="LONG", note="")]})
        self.assertEqual(bk.export_tables(con)["watchlist"][0]["deleted"], 1)   # tombstone kept, not hard-deleted


if __name__ == "__main__":
    unittest.main()
