"""web/dsl.js 與 radar/dsl.py 語意一致（P9：瀏覽器即時預覽 = 批次結果）。"""
import json, os, subprocess, tempfile, unittest
import numpy as np
from radar import dsl
from tests import synth
from tests.test_dsl import DEFS as _D

ALLF = {"code": "allf", "name": "全函式", "version": 1, "directions": ["long", "short"], "min_bars": 30,
        "params": {"n": {"default": 12}}, "series": {
            "e": "ema(close, n)", "hh": "highest(high, 20)", "ll": "lowest(low, 20)", "rg": "abs(close - ref(close, 3)) / close",
            "mx": "max(e, sma(close, 20))", "mn": "min(e, sma(close, 20))", "vv": "avg_vol(20, 0) / avg_vol(5)"},
        "states": [
            {"state": "ENTRY", "direction": "short", "requires_position": "NONE", "when": "cross_down(close, mn) and vv > 0.5", "strength": "50 + 100 * rg"},
            {"state": "EXIT", "direction": "long", "requires_position": "LONG", "when": "close < ll * 1.02 or not (close > mn)"},
            {"state": "ENTRY", "direction": "long", "requires_position": "NONE", "when": "cross_up(close, mx) or close >= hh", "strength": "slope_pct(e, 3) * 1000 - -2"},
            {"state": "HOLD", "when": "count(close > e, 5) >= 3 and true"}]}
DEFS = dict(_D, allf=ALLF)

JS = os.path.join(os.path.dirname(__file__), "dsl_parity.js")


class JsParity(unittest.TestCase):
    def test_states_identical(self):
        rng = np.random.default_rng(11)
        c = synth.path(50, [(50, 70), (30, 45), (40, 80), (30, 60), (30, 75)]) * (1 + rng.normal(0, 0.012, 181))
        o = np.r_[c[0], c[:-1]] * (1 + rng.normal(0, 0.006, len(c))); h = np.maximum(o, c) * 1.01; l = np.minimum(o, c) * 0.99
        v = rng.lognormal(14, 0.7, len(c))
        f = tempfile.NamedTemporaryFile("w", suffix=".json", delete=False)
        json.dump(dict(defs=list(DEFS.values()), o=o.tolist(), h=h.tolist(), l=l.tolist(), c=c.tolist(), v=v.tolist(), shortable=None), f); f.close()
        js = json.loads(subprocess.check_output(["node", JS, f.name], text=True))
        n_entry = 0
        for code, d in DEFS.items():
            P = dsl.Program(d); E = P.env(o, h, l, c, v)
            py = []
            for t in range(len(c)):
                for pos in ("NONE", "LONG", "SHORT"):
                    s = P.state_at(E, t, pos, None)
                    py.append([t, pos, s["state"], s["direction"], None if s["strength"] is None else round(s["strength"], 9)])
                    n_entry += s["state"] == "ENTRY"
            self.assertEqual(js[code], py, code)
        self.assertGreater(n_entry, 0)

    def test_validation_identical(self):
        bad = json.loads(json.dumps(DEFS["cis_exp"])); bad["series"]["m5"] = "pivots(0.05)"; bad["states"][1]["when"] = "close >"
        bad2 = {"code": "X", "name": "x", "version": 0, "directions": [], "params": {}, "series": {}, "states": []}
        f = tempfile.NamedTemporaryFile("w", suffix=".json", delete=False); json.dump(dict(validate=[DEFS["cis_base"], bad, bad2]), f); f.close()
        js = json.loads(subprocess.check_output(["node", JS, f.name], text=True))
        self.assertEqual(js[0], [])
        self.assertEqual(len(js[1]), len(dsl.validate(bad))); self.assertTrue(js[1])
        self.assertEqual(js[2], dsl.validate(bad2))


if __name__ == "__main__":
    unittest.main()
