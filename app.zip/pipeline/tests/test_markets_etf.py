"""v6：全球指數（run_indices）與 00631L 專頁（run_etf）— 全部用假資料，不連網。"""
import datetime as dt, json, os, sqlite3, sys, tempfile, unittest
import numpy as np
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
import run_indices as RI, run_etf as RE


def yahoo_json(closes, start="2026-08-01", off=0):
    d0 = dt.datetime.fromisoformat(start).replace(tzinfo=dt.timezone.utc)
    ts = [int((d0 + dt.timedelta(days=i)).timestamp()) for i in range(len(closes))]
    return json.dumps({"chart": {"result": [{"meta": {"gmtoffset": off}, "timestamp": ts,
        "indicators": {"quote": [{"close": closes, "open": closes, "high": closes, "low": closes, "volume": [1000] * len(closes)}]}}], "error": None}})


class TestIndices(unittest.TestCase):
    def test_build_ok_and_change(self):
        closes = [100 + i for i in range(70)]
        doc = RI.build(get=lambda url: yahoo_json(closes), sleep=0)
        self.assertEqual(len(doc["indices"]), 11)
        x = doc["indices"][0]
        self.assertEqual(x["close"], 169); self.assertEqual(x["prev_close"], 168)
        self.assertAlmostEqual(x["change_pct"], round((169 / 168 - 1) * 100, 2))
        self.assertEqual(len(x["spark"]), 60); self.assertFalse(x["stale"]); self.assertEqual(x["source"], "Yahoo Finance")
        self.assertEqual(x["date"], "2026-10-09")
        self.assertEqual(doc["errors"], {})

    def test_yahoo_too_short_falls_back(self):
        sina = json.dumps([{"day": f"2026-09-{i + 1:02d}", "close": str(3000 + i)} for i in range(28)])
        def get(url):
            if "yahoo" in url: return yahoo_json([1.0])          # 像 000300.SS 只回 1 根
            if "stooq" in url: raise IOError("blocked")
            return sina
        rec, errs = RI.build_one(next(x for x in RI.INDICES if x[0] == "csi300"), get)            # 滬深 300：Yahoo → 新浪
        self.assertEqual(rec["source"], "新浪財經"); self.assertEqual(rec["close"], 3027)
        self.assertTrue(any("Yahoo" in e for e in errs))

    def test_failure_keeps_previous_stale(self):
        prev = {"indices": [{"id": "spx", "name": "S&P 500", "close": 5000, "change_pct": 1.0, "date": "2026-11-18", "spark": [1, 2], "source": "Yahoo Finance", "stale": False}]}
        def get(url): raise IOError("network down")
        doc = RI.build(prev, get=get, sleep=0)
        spx = doc["indices"][0]
        self.assertTrue(spx["stale"]); self.assertEqual(spx["close"], 5000); self.assertIn("沿用", spx["error"])
        self.assertIsNone(doc["indices"][1]["close"]); self.assertTrue(doc["indices"][1]["stale"])
        self.assertIn("spx", doc["errors"])


class TestEtf(unittest.TestCase):
    def test_parse_stock_day(self):
        j = {"stat": "OK", "data": [["115/11/19", "1,000,000", "x", "26.73", "27.06", "24.40", "24.57", "-2.27", "1", ""],
                                    ["115/03/31", "2,000", "x", "19.67", "19.88", "19.10", "19.26", "X0.00", "1", ""]]}
        r = RE.parse_stock_day(j)
        self.assertEqual(r[0], ("2026-11-19", 26.73, 27.06, 24.40, 24.57, 1000000, -2.27, 1))
        self.assertEqual(r[1][7], 0); self.assertIsNone(r[1][6])
        self.assertEqual(RE.parse_stock_day({"stat": "很抱歉，沒有符合條件的資料!"}), [])

    def test_stats(self):
        n = 300; c = np.linspace(10, 40, n); dates = [f"d{i:03d}" for i in range(n)]
        s = RE.stats(dates, c, c * 1.01, c * 0.99, c, np.full(n, 2_000_000.0))
        self.assertEqual(s["close"], 40.0); self.assertAlmostEqual(s["ma5"], round(float(c[-5:].mean()), 2))
        self.assertAlmostEqual(s["dev_ma25_pct"], round((40 / c[-25:].mean() - 1) * 100, 2))
        self.assertAlmostEqual(s["ret20_pct"], round((c[-1] / c[-21] - 1) * 100, 2))
        self.assertEqual(s["avgvol20_lots"], 2000); self.assertLessEqual(s["dd_from_high_pct"], 0)

    def test_build_from_mocked_fetch(self):
        """空資料庫 → 補抓（假 TWSE 回應，含一次 1:22 分割）→ 還原後計算 → 有 CIS 狀態與 K 線。"""
        tmp = tempfile.mkdtemp(); os.environ["RADAR_DB"] = os.path.join(tmp, "t.sqlite")
        try:
            from radar import db, config
            con = db.connect()
            rng = np.random.default_rng(1); px = 200.0; data = {}
            day = dt.date(2024, 11, 1)
            while day <= dt.date(2026, 11, 20):
                if day.weekday() < 5:
                    prev = px; px = max(5, px * (1 + rng.normal(0.001, 0.02)))
                    split = day == dt.date(2026, 3, 31)
                    if split: px = px / 22
                    roc = f"{day.year - 1911}/{day.month:02d}/{day.day:02d}"
                    chg = "X0.00" if split else f"{px - prev:+.2f}"
                    data.setdefault(f"{day.year:04d}{day.month:02d}", []).append([roc, "5,000,000", "x", f"{px:.2f}", f"{px * 1.01:.2f}", f"{px * 0.99:.2f}", f"{px:.2f}", chg, "1", ""])
                day += dt.timedelta(days=1)
            def get(url):
                ym = url.split("date=")[1][:6]
                return json.dumps({"stat": "OK", "data": data.get(ym, [])} if ym in data else {"stat": "沒有資料"})
            RE.time.sleep = lambda s: None
            doc = RE.build(con, "00631L", "2026-11-20", config.get(), fetch=True, get=get, log=lambda s: None)
            self.assertEqual(doc["data_as_of"], "2026-11-20"); self.assertEqual(doc["source"], "TWSE STOCK_DAY")
            self.assertFalse(doc["stale"]); self.assertGreater(doc["n_bars"], 150)   # X（分割）那天沒有參考價 → 從分割後起算，不畫假跳空
            self.assertIn(doc["cis"]["base_long"]["state"], ("HOLD", "EXIT_WARNING", "EXIT", "WATCH"))
            self.assertEqual(len(doc["bars"]["t"]), min(260, doc["n_bars"]))
            c = doc["bars"]["c"]; jumps = max(abs(c[i] / c[i - 1] - 1) for i in range(1, len(c)))
            self.assertLess(jumps, 0.5)   # 分割已還原，不會出現 -95% 的假跳空
            self.assertIn("2 倍", doc["leverage_note"])
        finally:
            os.environ.pop("RADAR_DB", None)


if __name__ == "__main__":
    unittest.main()
