import inspect, unittest
from radar import alerts


def hit(sym, pid, d, state, fresh=True, strength=50):
    return dict(symbol=sym, name=sym, patternId=pid, direction=d, state=state, fresh=fresh, strength=strength, patternVersion=1,
                levels={"neckline": 10, "target": 12, "stopRef": 9}, reasons=["r1", "event"], close=10.5, volRatio=1.5, instNet=1000,
                sector_code="24", sector_name="半導體業")


DOC = dict(trade_date="2026-11-19", finished_at="2026-11-19T17:40:00+08:00", patterns=[{"id": "w_bottom", "name": "W底"}, {"id": "cis_base", "name": "CIS"}],
           sectors=[], hits=[hit("A", "w_bottom", "long", "CONFIRMED"), hit("B", "w_bottom", "long", "CONFIRMED", fresh=False),
                            hit("C", "w_bottom", "long", "FAILED"), hit("D", "cis_base", "long", "EXIT"), hit("E", "cis_base", "long", "ENTRY"),
                            hit("F", "cis_base", "long", "HOLD")])
S = dict(alerts.DEFAULT_SETTINGS)


class AlertTests(unittest.TestCase):
    def sel(self, prev=None, sent=(), recent=(), watch=None, settings=S):
        return alerts.select(DOC, prev, settings, set(sent), set(recent), watch or {})

    def test_basic_selection(self):
        ex, en, sk = self.sel()
        self.assertEqual([r["symbol"] for r in en], ["E", "A"])   # fresh CONFIRMED + ENTRY; stale CONFIRMED / HOLD never mailed
        self.assertEqual([r["symbol"] for r in ex], ["C"])        # CIS EXIT only for watchlist by default
        self.assertEqual(sk["CIS 出場僅限追蹤清單"], 1)
        ex, _, _ = self.sel(watch={"D": "LONG"})
        self.assertEqual([r["symbol"] for r in ex], ["D", "C"])   # held watchlist first

    def test_transition_dedupe_cooldown(self):
        ex, en, sk = self.sel(prev={("A", "w_bottom", "long"): "CONFIRMED"})
        self.assertNotIn("A", [r["symbol"] for r in en]); self.assertEqual(sk["狀態未轉換"], 1)
        key = alerts.dedupe_key(DOC["hits"][4], "2026-11-19")
        _, en, sk = self.sel(sent={key}); self.assertNotIn("E", [r["symbol"] for r in en]); self.assertEqual(sk["已寄過（去重）"], 1)
        _, en, sk = self.sel(recent={("E", "cis_base", "long")}); self.assertNotIn("E", [r["symbol"] for r in en])

    def test_disabled_pattern_and_subject(self):
        st = dict(S, patterns={"long": ["cis_base"], "short": None})
        ex, en, sk = self.sel(settings=st)
        self.assertEqual([r["symbol"] for r in en], ["E"]); self.assertEqual(sk["型態未啟用"], 3)
        ex, en, sk = self.sel()
        m = alerts.build(DOC, ex, en, sk, S, {}, None, False, ["資料日 2026-11-19"])
        self.assertEqual(m["subject"], "[型態雷達] 2026-11-19 盤後｜新命中 2 檔｜出場訊號 1 檔")
        self.assertIn("融券／借券費用假設 0，未計入", m["text"]); self.assertIn("不構成投資建議", m["html"])
        self.assertIn("前一交易日沒有掃描紀錄", m["text"]); self.assertFalse(m["empty"])

    def test_max_rows_and_empty(self):
        ex, en, sk = self.sel()
        m = alerts.build(DOC, ex, en, sk, dict(S, max_rows=1), {}, None, True, [])
        self.assertEqual((len(m["rows"]), m["truncated"]), (1, 2)); self.assertIn("見 App", m["text"])
        m = alerts.build(DOC, [], [], {}, S, {}, None, True, []); self.assertTrue(m["empty"])

    def test_module_cannot_send(self):
        src = inspect.getsource(alerts)
        for bad in ("smtplib", "sendmail", "gmail.send", "requests.post", "urllib"):
            self.assertNotIn(bad, src)


if __name__ == "__main__":
    unittest.main()
