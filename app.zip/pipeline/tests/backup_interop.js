// node pipeline/tests/backup_interop.js <mode> ... — used by test_backup.py for JS↔Python format checks
const fs = require("fs"); const RB = require(__dirname + "/../../web/backup-core.js");
(async () => {
  const [mode, a1, a2, a3] = process.argv.slice(2);
  if (mode === "encrypt") { // encrypt <json-in> <code> <out>
    const doc = JSON.parse(fs.readFileSync(a1, "utf8")); const r = await RB.encryptBackup(doc, a2);
    fs.writeFileSync(a3, Buffer.from(r.bytes)); console.log(JSON.stringify({ vault_id: r.vault_id, checksum: r.checksum }));
  } else if (mode === "decrypt") { // decrypt <file> <code>
    try { const r = await RB.decryptBackup(fs.readFileSync(a1), a2); console.log(JSON.stringify({ vault_id: r.vault_id, checksum: r.checksum, doc: r.doc })); }
    catch (e) { console.log(JSON.stringify({ error: e.message })); }
  } else if (mode === "merge") { // merge <json {local, remote}>
    const j = JSON.parse(fs.readFileSync(a1, "utf8")); console.log(JSON.stringify(RB.mergeTables(j.local, j.remote)));
  } else if (mode === "code") { console.log(RB.newRecoveryCode()); }
})();
