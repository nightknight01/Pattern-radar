import os, sys, unittest
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from synth import path, make, truncate
from radar import patterns as P, cis as CIS, config, indicators as ind, pivots as pv, engine, adjuster

T = -1


def last(ctx): return ctx.n - 1


class Indicators(unittest.TestCase):
    def test_sma_avgprev(self):
        x = np.arange(1, 11, dtype=float)
        self.assertTrue(np.isnan(ind.sma(x, 5)[3])); self.assertEqual(ind.sma(x, 5)[4], 3.0)
        self.assertEqual(ind.avg_prev(x, 5)[5], 3.0)  # mean of bars 0..4, excludes bar 5

    def test_zigzag_basic(self):
        c = np.array([10, 11, 12, 13, 12, 11, 10.5, 11, 12, 13.5, 14, 13, 12.5, 12.0])
        p = pv.zigzag(c, c, 0.05)
        self.assertEqual([(q.kind, q.idx) for q in p], [("L", 0), ("H", 3), ("L", 6), ("H", 10)])
        for q in p: self.assertGreater(q.confirm_idx, q.idx)

    def test_pivots_no_lookahead(self):
        rng = np.random.default_rng(7)
        c = 100 * np.exp(np.cumsum(rng.normal(0, 0.02, 400)))
        h, l = c * 1.01, c * 0.99
        full = pv.zigzag(h, l, 0.05)
        for t in range(50, 400, 7):
            trunc = pv.zigzag(h[:t + 1], l[:t + 1], 0.05)
            self.assertEqual([q for q in full if q.confirm_idx <= t], trunc)

    def test_fractal_no_lookahead_via_ctx(self):
        rng = np.random.default_rng(3)
        c = 100 * np.exp(np.cumsum(rng.normal(0, 0.02, 200)))
        cfg = config.get({"common": {"pivot_method": "fractal"}})
        ctx = make(c, cfg=cfg)
        for t in range(30, 200, 11):
            self.assertEqual(ctx.piv(t), truncate(ctx, t).piv(t))


class Tsai(unittest.TestCase):
    def check(self, fn, ctx, direction, state="CONFIRMED"):
        r = fn(ctx, last(ctx))
        self.assertIsNotNone(r, fn.__name__); self.assertEqual(r["state"], state, (fn.__name__, r))
        self.assertEqual(r["direction"], direction)
        lv = r["levels"]
        if direction == "long": self.assertGreater(lv["target"], lv["neckline"]); self.assertLess(lv["stopRef"], ctx.c[-1])
        else: self.assertLess(lv["target"], lv["neckline"]); self.assertGreater(lv["stopRef"], ctx.c[-1])
        return r

    # ① W 底
    def w_series(self):
        return path(100, [(40, 80), (15, 90), (15, 80.5), (12, 89.5), (1, 93)])  # close 93 > neck 90.45×1.02

    def test_w_bottom(self):
        c = self.w_series(); r = self.check(P.w_bottom, make(c, spikes=[-1]), "long")
        self.assertAlmostEqual(r["levels"]["neckline"], 90 * 1.005, places=2)

    def test_w_bottom_needs_volume(self):
        self.assertIsNone(P.w_bottom(make(self.w_series()), len(self.w_series()) - 1))

    def test_w_bottom_forming(self):
        c = self.w_series()[:-1]; self.check(P.w_bottom, make(c), "long", "FORMING")

    def test_w_bottom_rejects_unequal_feet(self):
        c = path(100, [(40, 80), (15, 90), (15, 84), (10, 89.5), (1, 92)])
        r = P.w_bottom(make(c, spikes=[-1]), len(c) - 1)
        self.assertTrue(r is None or r["state"] != "CONFIRMED")

    # ② 破底翻
    def test_bottom_reversal(self):
        c = path(100, [(20, 90), (8, 96), (6, 87), (3, 92), (6, 96), (1, 99)])  # break/reclaim/neck all clear 2%
        rec = 20 + 8 + 6 + 3
        self.check(P.bottom_reversal, make(c, spikes=[rec, -1]), "long")

    def test_bottom_reversal_requires_reclaim_volume(self):
        # final breakout is > reclaim_window after the breakdown, and the reclaim day had no volume
        c = path(100, [(20, 90), (8, 96), (6, 87), (3, 92), (9, 96), (1, 99)])
        r = P.bottom_reversal(make(c, spikes=[-1]), len(c) - 1)
        self.assertIsNone(r)

    # ③ 破底翻（W 底）
    def test_bottom_reversal_w(self):
        c = path(100, [(30, 80), (15, 90), (15, 77), (12, 89.5), (1, 93)])
        self.check(P.bottom_reversal_w, make(c, spikes=[-1]), "long")
        r1 = P.w_bottom(make(c, spikes=[-1]), len(c) - 1)
        self.assertIsNone(r1)  # right foot 4% below → not a plain W (bottom_tol 3%)

    # ④ 下飄旗形 / ⑤ 上飄旗形
    def test_bull_flag(self):
        c = path(50, [(30, 50), (8, 60), (10, 56), (1, 58)])
        v = np.r_[np.full(31, 1e6), np.full(8, 2e6), np.full(10, 0.8e6), [3e6]]
        self.check(P.bull_flag, make(c, vol=v), "long")

    def test_bull_flag_no_volume_contraction(self):
        c = path(50, [(30, 50), (8, 60), (10, 56), (1, 58)])
        v = np.r_[np.full(31, 1e6), np.full(8, 2e6), np.full(10, 2.5e6), [9e6]]
        r = P.bull_flag(make(c, vol=v), len(c) - 1)
        self.assertTrue(r is None or r["state"] != "CONFIRMED")

    def test_bear_flag(self):
        c = path(60, [(30, 60), (8, 50), (10, 53), (1, 51)])
        v = np.r_[np.full(31, 1e6), np.full(8, 2e6), np.full(10, 0.8e6), [3e6]]
        self.check(P.bear_flag, make(c, vol=v), "short")

    # ⑥ M 頭
    def test_m_top(self):
        c = path(80, [(30, 100), (15, 90), (15, 99.5), (12, 90.5), (1, 87)])  # close 87 < neck 89.55×0.98
        r = self.check(P.m_top, make(c), "short")  # no volume required (A5)
        self.assertAlmostEqual(r["levels"]["neckline"], 90 * 0.995, places=2)

    def test_m_top_volume_switch(self):
        c = path(80, [(30, 100), (15, 90), (15, 99.5), (12, 90.5), (1, 87)])
        cfg = config.get({"common": {"vol_required_short_break": True}})
        self.assertIsNone(P.m_top(make(c, cfg=cfg), len(c) - 1))

    # ⑦ 假突破
    def test_false_breakout(self):
        c = path(90, [(20, 100), (8, 94), (6, 103), (4, 97), (4, 95), (1, 91)])
        self.check(P.false_breakout, make(c), "short")

    def test_false_breakout_forming(self):
        c = path(90, [(20, 100), (8, 94), (6, 103), (4, 97)])
        self.check(P.false_breakout, make(c), "short", "FORMING")

    # ⑧ 頭肩頂 / ⑨ 假突破（頭肩頂）
    def hs_series(self):
        return path(70, [(20, 90), (10, 80), (6, 100), (8, 80.5), (10, 90.5), (9, 81), (1, 78)])

    def test_hs_top(self):
        self.check(P.hs_top, make(self.hs_series()), "short")

    def test_hs_top_fake(self):
        r = self.check(P.hs_top_fake, make(self.hs_series()), "short")
        self.assertIn("fake", r["geometry"])

    def test_hs_top_fake_requires_fakeout(self):
        # head rises slowly and stays above LS for > reclaim_window → not a fake breakout
        c = path(70, [(20, 90), (10, 80), (20, 100), (25, 80.5), (10, 90.5), (9, 81), (1, 78)])
        self.assertIsNone(P.hs_top_fake(make(c), len(c) - 1))

    def test_hs_bottom(self):
        c = path(110, [(20, 90), (10, 100), (6, 80), (8, 99.5), (10, 90.5), (9, 99), (1, 102)])
        self.check(P.hs_bottom, make(c, spikes=[-1]), "long")

    # ⑪⑫ 收斂三角形
    def test_tri_top(self):
        n = 53
        c = path(70, [(20, 100), (8, 88), (8, 97), (8, 90.5), (4, 95), (4, 89.0)])  # last close clearly >2% below lower edge
        v = np.linspace(2e6, 0.8e6, len(c))
        self.check(P.tri_top, make(c, vol=v), "short")

    def test_tri_bottom(self):
        c = path(130, [(20, 100), (8, 112), (8, 103), (8, 109.5), (4, 104.5), (4, 111)])
        v = np.linspace(2e6, 0.8e6, len(c)); v[-1] = 3e6
        self.check(P.tri_bottom, make(c, vol=v), "long")


class Cis(unittest.TestCase):
    def find(self, fn, ctx, state, direction, rng):
        return [t for t in rng if (r := fn(ctx, t))["state"] == state and r["direction"] == direction]

    def test_cis_base_entry_rule(self):
        c = path(100, [(70, 121), (2, 119.5), (1, 121.5)])
        ctx = make(c); t = ctx.n - 1
        r = CIS.evaluate_cis_base(ctx, t)
        self.assertEqual(r["state"], "ENTRY"); self.assertEqual(r["direction"], "long")
        self.assertTrue(ctx.c[t - 1] < ctx.m5[t - 1] and ctx.c[t] > ctx.m5[t] > 0 and ctx.c[t] > ctx.m25[t])

    def test_cis_base_no_entry_when_ma25_down(self):
        c = path(130, [(70, 100), (2, 98.5), (1, 101)])
        r = CIS.evaluate_cis_base(make(c), len(c) - 1)
        self.assertNotEqual(r["state"], "ENTRY")

    def test_cis_base_exit_signal(self):
        c = path(100, [(70, 121), (1, 117)])  # bearish bar breaking both MAs
        ctx = make(c); t = ctx.n - 1
        # force a 陰線: open above close
        ctx.o[t] = 121.5
        r = CIS.evaluate_cis_base(ctx, t, position="LONG")
        self.assertIn(r["state"], ("EXIT", "EXIT_WARNING"))

    def test_cis_exp_long_cross_with_volume(self):
        c = path(100, [(70, 100), (8, 108)])
        ctx_nov = make(c)
        hits = self.find(CIS.evaluate_cis_exp, ctx_nov, "ENTRY", "long", range(60, len(c)))
        self.assertEqual(hits, [])               # no volume → no entry
        spikes = list(range(70, len(c)))
        ctx = make(c, spikes=spikes, spike_mult=3)
        # the spike only satisfies ×1.3 of the 5-day mean on the first spike days; cross must coincide
        hits = self.find(CIS.evaluate_cis_exp, ctx, "ENTRY", "long", range(60, len(c)))
        for t in hits:
            self.assertTrue(ctx.m5[t - 1] <= ctx.m25[t - 1] and ctx.m5[t] > ctx.m25[t])

    def test_cis_exp_long_entry_exists(self):
        c = path(100, [(70, 100), (8, 108)])
        ctx = make(c, vol=np.r_[np.full(71, 1e6), np.full(8, 4e6)])
        ctx.v[:] = np.r_[np.full(71, 1e6), np.geomspace(1.5e6, 2e7, 8)]  # rising volume keeps ×1.3 true
        ctx.__init__(ctx.dates, ctx.o, ctx.h, ctx.l, ctx.c, ctx.v, ctx.cfg)
        hits = self.find(CIS.evaluate_cis_exp, ctx, "ENTRY", "long", range(60, len(c)))
        self.assertEqual(len(hits), 1)

    def test_cis_exp_short_and_shortable(self):
        c = path(150, [(60, 115), (8, 124), (8, 108)])
        v = np.r_[np.full(69, 1e6), np.geomspace(1.5e6, 2e7, 8)]
        ok = make(c, vol=v, shortable=True)
        hits = self.find(CIS.evaluate_cis_exp, ok, "ENTRY", "short", range(60, len(c)))
        self.assertEqual(len(hits), 1)
        t = hits[0]; self.assertEqual(CIS.ma25_slope(ok.m25, t, ok.cfg["cis_common"]), CIS.DOWN)
        blocked = make(c, vol=v, shortable=False)
        self.assertEqual(self.find(CIS.evaluate_cis_exp, blocked, "ENTRY", "short", range(60, len(c))), [])
        unknown = make(c, vol=v, shortable=None)
        r = CIS.evaluate_cis_exp(unknown, t)
        self.assertEqual(r["state"], "ENTRY"); self.assertTrue(any("未知" in x for x in r["reasons"]))

    def test_cis_base_long_only(self):
        c = path(150, [(60, 115), (8, 124), (8, 108)])
        ctx = make(c, vol=np.r_[np.full(69, 1e6), np.geomspace(1.5e6, 2e7, 8)])
        for t in range(60, len(c)):
            self.assertNotEqual(CIS.evaluate_cis_base(ctx, t)["direction"], "short")


class NoLookahead(unittest.TestCase):
    def test_all_patterns_causal(self):
        rng = np.random.default_rng(11)
        for seed in range(3):
            c = 100 * np.exp(np.cumsum(rng.normal(0, 0.025, 260)))
            v = rng.uniform(0.5e6, 3e6, 260)
            ctx = make(c, vol=v)
            for t in range(80, 260, 9):
                tr = truncate(ctx, t)
                for pid, *_rest, fn in engine.REGISTRY:
                    a, b = fn(ctx, t), fn(tr, t)
                    self.assertEqual(a, b, (pid, t))
                    self.assertEqual(engine.evaluate_symbol(ctx, t), engine.evaluate_symbol(tr, t))

    def test_engine_registry_directions(self):
        longs = [p["id"] for p in engine.list_patterns("long")]
        shorts = [p["id"] for p in engine.list_patterns("short")]
        self.assertEqual(set(longs), {"w_bottom", "bottom_reversal", "bottom_reversal_w", "bull_flag", "hs_bottom", "tri_bottom", "cis_base", "cis_exp", "lw_dragon", "lw_gapfill"})
        self.assertEqual(set(shorts), {"bear_flag", "m_top", "false_breakout", "hs_top", "hs_top_fake", "tri_top", "cis_exp", "lw_chu"})


class Adjust(unittest.TestCase):
    def test_dividend_back_adjust(self):
        dates = ["d0", "d1", "d2"]
        c = np.array([100., 101., 96.]); o = h = l = c.copy(); v = np.ones(3)
        # d2 ex-dividend 5: ref = 96; exchange chg sign unknown, TWT49U ref 96
        a = adjuster.adjust(dates, o, h, l, c, v, np.array([np.nan, 1.0, np.nan]), np.array([0, 1, 0]), {"d2": 96.0})
        self.assertAlmostEqual(a["c"][-1], 96.0)
        self.assertAlmostEqual(a["c"][1], 101 * 96 / 101)
        self.assertAlmostEqual(a["c"][0], 100 * 96 / 101)

    def test_split_adjusts_volume(self):
        dates = ["d0", "d1"]; c = np.array([200., 50.5]); v = np.array([1000., 4000.])
        a = adjuster.adjust(dates, c, c, c, c, v, np.array([np.nan, 0.5]), np.array([0, 1]), {})
        self.assertAlmostEqual(a["c"][0], 50.0); self.assertAlmostEqual(a["v"][0], 4000.0)

    def test_unexplained_gap_cut(self):
        dates = ["d0", "d1", "d2"]; c = np.array([100., 60., 61.])
        a = adjuster.adjust(dates, c, c, c, c, np.ones(3), np.array([np.nan, np.nan, 1.0]), np.array([0, 0, 1]), {})
        self.assertEqual(a["dates"], ["d1", "d2"])


if __name__ == "__main__":
    unittest.main()
