"""v10：^TWII 當日 K 棒 Yahoo 收盤空白 → 用證交所（MI_5MINS_HIST＋FMTQIK）補；其他指數維持 Yahoo。全部假資料，不連網。"""
import datetime as dt, json, os, sys, unittest
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
import run_indices as RI

TPE = RI.TPE
TWII = next(x for x in RI.INDICES if x[0] == "twii")
SPX = next(x for x in RI.INDICES if x[0] == "spx")


def days(end=dt.date(2026, 11, 26), n=40):
    out, d = [], end
    while len(out) < n:
        if d.weekday() < 5: out.append(d)
        d -= dt.timedelta(days=1)
    return out[::-1]


def yahoo(blank_last=True, n=40):
    ds = days(n=n)
    ts = [int(dt.datetime.combine(d, dt.time(1, 0), dt.timezone.utc).timestamp()) for d in ds]   # 台北 09:00
    c = [38000.0 + 10 * i for i in range(n)]; v = [4_000_000.0] * n
    o = list(c); h = [x + 50 for x in c]; l = [x - 50 for x in c]
    if blank_last: c[-1] = None; v[-1] = 0
    return json.dumps({"chart": {"result": [{"meta": {"gmtoffset": 28800}, "timestamp": ts,
                       "indicators": {"quote": [{"open": o, "high": h, "low": l, "close": c, "volume": v}]}}], "error": None}})


def roc(d): return f"{d.year - 1911}/{d.month:02d}/{d.day:02d}"


def twse_hist(ym):
    rows = [[roc(d), "38,435.99", "39,459.95", "38,435.99", "39,151.81" if d == dt.date(2026, 11, 26) else f"{38000 + i:,.2f}"]
            for i, d in enumerate(days()) if f"{d.year:04d}{d.month:02d}" == ym]
    return json.dumps({"stat": "OK", "fields": ["日期", "開盤指數", "最高指數", "最低指數", "收盤指數"], "data": rows})


def twse_vol(ym):
    rows = [[roc(d), "16,000,000,000" if d != dt.date(2026, 11, 26) else "12,000,000,000", "1", "1", "1", "1"]
            for d in days() if f"{d.year:04d}{d.month:02d}" == ym]
    return json.dumps({"stat": "OK", "data": rows})


def at(h, m=0, d=dt.date(2026, 11, 26)): return dt.datetime.combine(d, dt.time(h, m), TPE).timestamp()


class Getter:
    def __init__(self, twse_fail=False, blank_last=True):
        self.urls, self.twse_fail, self.blank = [], twse_fail, blank_last
    def __call__(self, url):
        self.urls.append(url)
        if "twse.com.tw" in url:
            if self.twse_fail: raise IOError("TWSE down")
            ym = url.split("date=")[1][:6]
            return twse_hist(ym) if "MI_5MINS_HIST" in url else twse_vol(ym)
        if "yahoo" in url: return yahoo(self.blank)
        raise IOError("unexpected " + url)
    def twse_calls(self): return [u for u in self.urls if "twse" in u]


class TwiiFallback(unittest.TestCase):
    def test_parse_twse(self):
        h = RI.twse_taiex_month("202611", lambda u: twse_hist("202611"))
        self.assertEqual(h["2026-11-26"], (38435.99, 39459.95, 38435.99, 39151.81))
        self.assertEqual(RI.twse_taiex_month("202611", lambda u: json.dumps({"stat": "很抱歉，沒有符合條件的資料!"})), {})
        self.assertEqual(RI.twse_volume_month("202611", lambda u: twse_vol("202611"))["2026-11-26"], 12e9)

    def test_blank_yahoo_close_filled_from_twse_after_close(self):
        g = Getter()
        rows, src, errs = RI.fetch_ohlc(TWII, g, now=at(16))
        self.assertEqual(rows[-1][0], "2026-11-26"); self.assertEqual(rows[-1][1:5], (38435.99, 39459.95, 38435.99, 39151.81))
        self.assertAlmostEqual(rows[-1][5], 12e9 * (4_000_000 / 16e9))            # 量依重疊日比例換算成 Yahoo 單位
        self.assertIn("證交所（2026-11-26）", src); self.assertEqual(errs, [])
        rec, _ = RI.build_one(TWII, Getter(), now=at(16))
        self.assertEqual((rec["date"], rec["close"]), ("2026-11-26", 39151.81))

    def test_before_tw_close_no_twse_call(self):
        g = Getter()
        rows, src, _ = RI.fetch_ohlc(TWII, g, now=at(11))
        self.assertEqual(rows[-1][0], "2026-11-25"); self.assertEqual(g.twse_calls(), []); self.assertEqual(src, "Yahoo Finance")

    def test_twse_failure_keeps_yahoo(self):
        rows, src, errs = RI.fetch_ohlc(TWII, Getter(twse_fail=True), now=at(16))
        self.assertEqual(rows[-1][0], "2026-11-25"); self.assertEqual(src, "Yahoo Finance")
        self.assertTrue(any("證交所" in e for e in errs))

    def test_yahoo_complete_no_twse_call(self):
        g = Getter(blank_last=False)
        rows, src, _ = RI.fetch_ohlc(TWII, g, now=at(16))
        self.assertEqual(rows[-1][0], "2026-11-26"); self.assertEqual(g.twse_calls(), []); self.assertEqual(src, "Yahoo Finance")

    def test_other_indices_unchanged(self):
        g = Getter()
        rows, src, _ = RI.fetch_ohlc(SPX, g, now=at(16))
        self.assertEqual(rows[-1][0], "2026-11-25"); self.assertEqual(g.twse_calls(), []); self.assertEqual(src, "Yahoo Finance")

    def test_holiday_nothing_to_add(self):
        g = Getter()
        g2 = lambda u: json.dumps({"stat": "OK", "data": [r for r in json.loads(twse_hist(u.split("date=")[1][:6]))["data"] if r[0] != "115/11/26"]}) \
            if "MI_5MINS_HIST" in u else g(u)
        rows, src, _ = RI.fetch_ohlc(TWII, g2, now=at(16))
        self.assertEqual(rows[-1][0], "2026-11-25"); self.assertEqual(src, "Yahoo Finance")

    def test_needs_fill_rules(self):
        r = [("2026-11-25", 1, 1, 1, 1, 0)]
        self.assertEqual(RI.twii_needs_fill(r, at(16)), ["202611"])
        self.assertEqual(RI.twii_needs_fill(r, at(9)), [])                                   # 盤中／收盤前
        self.assertEqual(RI.twii_needs_fill([("2026-11-26", 1, 1, 1, 1, 0)], at(16)), [])    # 已經有今天
        self.assertEqual(RI.twii_needs_fill(r, at(10, d=dt.date(2026, 11, 28))), ["202611"]) # 週六：缺週四、五
        self.assertEqual(RI.twii_needs_fill([("2026-10-01", 1, 1, 1, 1, 0)], at(16)), [])    # 斷太久不補
        self.assertEqual(RI.twii_needs_fill([("2026-10-30", 1, 1, 1, 1, 0)], at(16, d=dt.date(2026, 11, 2))), ["202610", "202611"])


if __name__ == "__main__":
    unittest.main()
