"""run_ci.sh「4. 重算判斷」那一段（# >>> decide ～ # <<< decide）用真的 bash 執行。
2026-11-26 事故：PREV_EX="${PREV_EX:-{}}" 多接一個「}」→ 判斷崩潰 → 新交易日卻靜靜略過掃描。"""
import os, re, shutil, subprocess, tempfile, unittest
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SH = os.path.join(HERE, "ci", "run_ci.sh")


def snippet():
    with open(SH, encoding="utf-8") as f: s = f.read()
    a = s.index("# >>> decide"); b = s.index("# <<< decide")
    return s[a:b]


@unittest.skipUnless(shutil.which("bash"), "沒有 bash")
class DecideSnippet(unittest.TestCase):
    def run_snip(self, **env):
        ws = tempfile.mkdtemp()
        e = dict(os.environ, RADAR_DB=os.path.join(ws, "t.sqlite"), WS=ws, NEW_T="2026-11-26", PREV_T="2026-11-25", PH="h1", PREV_PH="h1",
                 FORCE="false", WEB_T="2026-11-25", PREV_EX='{"institutional": 2261, "margin": 2235}')
        e.pop("RADAR_PARAMS", None); e.update(env)
        script = 'out() { echo "OUT $1=$2"; }\n' + snippet() + '\necho "RESULT recompute=$RECOMPUTE backtest=$DO_BT"\n'
        r = subprocess.run(["bash", "-c", script], cwd=HERE, env=e, capture_output=True, text=True, timeout=120)
        m = re.search(r"RESULT recompute=(\S*) backtest=(\S*)", r.stdout)
        self.assertIsNotNone(m, r.stdout + r.stderr)
        return m.group(1), m.group(2), r.stdout + r.stderr

    def test_no_double_brace_default(self):
        with open(SH, encoding="utf-8") as f: self.assertNotIn('PREV_EX="${PREV_EX:-{}}"', f.read())

    def test_new_trading_day_with_previous_extras_rescans(self):
        rc, bt, log = self.run_snip()                         # 11-26 事故的情境：PREV_EX 有值、新交易日
        self.assertEqual((rc, bt), ("1", "1")); self.assertNotIn("::error::", log); self.assertIn("新交易日", log)

    def test_nothing_changed_skips(self):
        rc, bt, log = self.run_snip(NEW_T="2026-11-26", PREV_T="2026-11-26", WEB_T="2026-11-26", PREV_EX='{"institutional": 0, "margin": 0}')
        self.assertEqual(rc, "0"); self.assertNotIn("::error::", log)

    def test_empty_prev_extras(self):
        rc, bt, log = self.run_snip(PREV_EX="")
        self.assertEqual(rc, "1"); self.assertNotIn("::error::", log)

    def test_decide_crash_fails_loudly_and_forces_rescan(self):
        rc, bt, log = self.run_snip(NEW_T="2026-11-26", PREV_T="2026-11-26", WEB_T="2026-11-26", PREV_EX="not json")
        self.assertEqual((rc, bt), ("1", "1")); self.assertIn("::error::", log); self.assertIn("OUT decide_fallback=1", log)


if __name__ == "__main__":
    unittest.main()
