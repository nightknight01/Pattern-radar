"""Synthetic bar builder for unit tests (no market data)."""
import numpy as np, datetime as dt
from radar.context import Ctx
from radar import config


def path(start, legs):
    """legs: list of (n_bars, end_price) → close series with linear interpolation."""
    c = [float(start)]
    for n, end in legs:
        s = c[-1]
        c += [s + (end - s) * (i + 1) / n for i in range(n)]
    return np.array(c)


def make(c, vol=None, spikes=(), spike_mult=3.0, base_vol=1e6, cfg=None, shortable=True, inst=None, spread=0.005):
    c = np.asarray(c, float); n = len(c)
    o = np.concatenate([[c[0]], c[:-1]])
    h = np.maximum(o, c) * (1 + spread); l = np.minimum(o, c) * (1 - spread)
    v = np.full(n, base_vol) if vol is None else np.asarray(vol, float)
    v = v.copy()
    for s in spikes: v[s if s >= 0 else n + s] = base_vol * spike_mult
    d0 = dt.date(2025, 1, 1)
    dates = [(d0 + dt.timedelta(days=i)).isoformat() for i in range(n)]
    return Ctx(dates, o, h, l, c, v, cfg or config.get(), shortable=shortable, inst_net=inst)


def truncate(ctx, t):
    return Ctx(ctx.dates[:t + 1], ctx.o[:t + 1], ctx.h[:t + 1], ctx.l[:t + 1], ctx.c[:t + 1], ctx.v[:t + 1], ctx.cfg,
               shortable=ctx.shortable, inst_net=ctx.inst_net)
