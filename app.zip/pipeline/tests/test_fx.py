"""v11：央行新台幣匯率（radar/fx.py、run_fx.py）— 解析、來源合併、備援、失敗沿用 — 全部假資料，不連網。"""
import datetime as dt, json, os, sys, tempfile, unittest
from zoneinfo import ZoneInfo
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
from radar import fx
import run_fx

API = json.dumps({"meta": {"title": "我國與主要貿易對手通貨對美元之匯率依期間"}, "data": {
    "structure": {"Table1": [{"data": "新台幣NTD/USD"}, {"data": "日圓JPY/USD"}]},
    "dataSets": [["20261028", "32.418", "157.78"], ["20261029", "32.492", "157.83"], ["20261030", "32.478", "157.55"], ["bad", "1", "2"], ["20261031", "-", "1"]]}})
PAGE = """<table class="rwd-table"><tr><th>標題(日期)</th><th>NTD/USD</th></tr>
  <tr>
    <td data-th="標題(日期)"><span>2026/11/26</span></td>
    <td data-th="NTD/USD"><span>32.947</span></td>
  </tr>
  <tr><td data-th="標題(日期)"><span>2026/11/25</span></td><td data-th="NTD/USD"><span>33.126</span></td></tr>
  <tr><td data-th="標題(日期)"><span>2026/10/30</span></td><td data-th="NTD/USD"><span>32.480</span></td></tr></table>"""
YH = json.dumps({"chart": {"result": [{"meta": {"gmtoffset": 28800}, "timestamp": [1795622400, 1795708800],
                                       "indicators": {"quote": [{"close": [32.9, None]}]}}]}})


def getter(api=API, page=PAGE, yh=YH):
    def get(url, timeout=30):
        src = api if "cpx.cbc" in url else page if "cbc.gov.tw/tw" in url else yh
        if isinstance(src, Exception): raise src
        return src
    return get


class TestParse(unittest.TestCase):
    def test_api(self):
        s = fx.parse_cbc_api(API)
        self.assertEqual(s, {"2026-10-28": 32.418, "2026-10-29": 32.492, "2026-10-30": 32.478})

    def test_page(self):
        s = fx.parse_cbc_page(PAGE)
        self.assertEqual(s["2026-11-26"], 32.947); self.assertEqual(len(s), 3)

    def test_page_fallback_text_and_empty(self):
        self.assertEqual(fx.parse_cbc_page("<p>2026/11/26 32.947</p>")["2026-11-26"], 32.947)
        with self.assertRaises(ValueError): fx.parse_cbc_page("<html>維護中</html>")
        with self.assertRaises(ValueError): fx.parse_cbc_api(json.dumps({"data": {"dataSets": []}}))

    def test_yahoo(self):
        self.assertEqual(list(fx.parse_yahoo(YH).values()), [32.9])


class TestFetch(unittest.TestCase):
    def test_merge_page_overrides_api(self):
        s, src, errs = fx.fetch(getter(), today="2026-11-26")
        self.assertEqual(s["2026-10-30"], 32.480)   # 同一天：收盤匯率頁優先
        self.assertEqual(max(s), "2026-11-26"); self.assertIn("中央銀行", src); self.assertEqual(errs, [])

    def test_api_down_page_ok(self):
        s, src, errs = fx.fetch(getter(api=IOError("timeout")))
        self.assertEqual(len(s), 3); self.assertIn("收盤匯率頁", src); self.assertNotIn("BP01D01", src); self.assertEqual(len(errs), 1)

    def test_both_cbc_down_yahoo_labelled(self):
        s, src, errs = fx.fetch(getter(api=IOError("x"), page=IOError("y")))
        self.assertIn("非央行", src); self.assertEqual(len(errs), 2)

    def test_all_down(self):
        s, src, errs = fx.fetch(getter(api=IOError("x"), page=IOError("y"), yh=IOError("z")))
        self.assertIsNone(s); self.assertEqual(len(errs), 3)

    def test_build_doc(self):
        s, src, errs = fx.fetch(getter())
        d = fx.build_doc(s, src, errs, "2026-11-27T00:00:00+08:00")
        self.assertEqual(d["close"], 32.947); self.assertEqual(d["prev_close"], 33.126); self.assertTrue(d["line_only"])
        self.assertEqual(d["bars"]["t"][-1], "20261126"); self.assertEqual(d["bars"]["c"], d["bars"]["o"])
        self.assertAlmostEqual(d["change_pct"], round((32.947 / 33.126 - 1) * 100, 3))


class TestRunFx(unittest.TestCase):
    def test_write_then_failure_keeps_previous_stale(self):
        out = tempfile.mkdtemp(); now = dt.datetime(2026, 11, 26, 17, 0, tzinfo=ZoneInfo("Asia/Taipei"))
        d1 = run_fx.run(out, get=getter(), now=now)
        self.assertFalse(d1["stale"]); self.assertTrue(os.path.exists(os.path.join(out, "fx_twd.json")))
        bad = getter(api=IOError("x"), page=IOError("y"), yh=IOError("z"))
        d2 = run_fx.run(out, get=bad, now=now)
        self.assertTrue(d2["stale"]); self.assertEqual(d2["close"], d1["close"]); self.assertIn("沿用", d2["error"])
        self.assertIsNone(run_fx.run(tempfile.mkdtemp(), get=bad, now=now))   # 沒有上一份：不寫檔、不丟例外


if __name__ == "__main__":
    unittest.main()
