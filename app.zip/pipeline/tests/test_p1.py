import unittest, sqlite3
from radar import sectors, fundamentals, config, db


def sig(sym, sc, state, d="long", pid="w_bottom", strength=60, inst=100, fresh=True):
    return dict(symbol=sym, sector_code=sc, state=state, direction=d, patternId=pid, strength=strength, instNet=inst, fresh=fresh)


class SectorTests(unittest.TestCase):
    P = config.get()["sector"]

    def test_score_and_hit_rule(self):
        sigs = [sig("a", "24", "CONFIRMED"), sig("b", "24", "ENTRY", strength=80, inst=-5), sig("c", "24", "FORMING")]
        rows = sectors.aggregate(sigs, {"24": 10, "01": 3}, {"24": "半導體業"}, self.P, [("w_bottom", ("long",))])
        r = [x for x in rows if x["sector_code"] == "24"][0]
        self.assertEqual((r["hits"], r["forming"], r["n_members"]), (2, 1, 10))
        self.assertAlmostEqual(r["hit_ratio"], 0.2)
        self.assertAlmostEqual(r["avg_strength"], 70)
        self.assertAlmostEqual(r["inst_ratio"], 0.5)
        self.assertAlmostEqual(r["score"], 0.4 * 20 + 0.3 * 70 + 0.1 * 10 + 0.2 * 50)
        self.assertTrue(r["is_hit"])
        small = [x for x in rows if x["sector_code"] == "01"][0]
        self.assertTrue(small["small"]); self.assertFalse(small["is_hit"])

    def test_short_inst_direction_and_threshold(self):
        sigs = [sig("a", "24", "CONFIRMED", d="short", inst=-1), sig("b", "24", "CONFIRMED", d="short", inst=-2)]
        r = sectors.aggregate(sigs, {"24": 30}, {}, self.P, [("w_bottom", ("short",))])[0]
        self.assertEqual(r["inst_ratio"], 1.0)
        self.assertFalse(r["is_hit"])  # 2/30 < 10%


class FundamentalFilterTests(unittest.TestCase):
    snap = {"rev": {"yoy": 25.0, "mom": -3.0}, "fin": {"eps_ytd": 4.2, "gross_margin": None}, "val": {"pe": 30}}

    def test_default_all_off_passes(self):
        self.assertEqual(fundamentals.apply_rules(self.snap, [])[0], "pass")
        self.assertEqual(fundamentals.apply_rules(None, [{"key": "rev_yoy", "mode": "off", "value": 10}])[0], "pass")

    def test_required_fail_and_bonus(self):
        st, b, _ = fundamentals.apply_rules(self.snap, [{"key": "rev_yoy", "mode": "required", "op": ">=", "value": 10},
                                                       {"key": "pe", "mode": "required", "op": "<=", "value": 20}])
        self.assertEqual(st, "fail")
        st, b, _ = fundamentals.apply_rules(self.snap, [{"key": "eps_ytd", "mode": "bonus", "op": ">=", "value": 3}])
        self.assertEqual((st, b), ("pass", 1))

    def test_missing_is_pending_not_eliminated(self):
        st, _, det = fundamentals.apply_rules(self.snap, [{"key": "gross_margin", "mode": "required", "op": ">=", "value": 30}])
        self.assertEqual(st, "pending"); self.assertEqual(det, [("gross_margin", "pending")])
        st, _, _ = fundamentals.apply_rules(None, [{"key": "rev_yoy", "mode": "required", "op": ">=", "value": 10}])
        self.assertEqual(st, "pending")

    def test_snapshot_no_lookahead(self):
        con = sqlite3.connect(":memory:"); con.executescript(db.SCHEMA)
        con.execute("INSERT INTO monthly_revenue VALUES ('2330','2026-09',1,1,10,1,'2026-10-09','t')")
        con.execute("INSERT INTO monthly_revenue VALUES ('2330','2026-10',1,1,99,1,'2026-11-10','t')")
        self.assertEqual(fundamentals.latest_snapshot(con, "2026-11-05")["2330"]["rev"]["yoy"], 10)
        self.assertEqual(fundamentals.latest_snapshot(con, "2026-11-10")["2330"]["rev"]["yoy"], 99)


if __name__ == "__main__":
    unittest.main()
