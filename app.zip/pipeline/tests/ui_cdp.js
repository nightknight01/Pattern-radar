// 無頭 Chrome（CDP）UI 檢查：node ui_cdp.js steps.json
// steps: [{go:url}|{wait:ms}|{shot:path,w,h}|{size:[w,h]}|{eval:js}|{offline:true/false}|{click:selector}|{waitFor:jsExpr}]
// 會輸出 console 錯誤與 eval 結果；任何頁面例外會讓 exit code = 1。
const { spawn } = require("child_process"); const fs = require("fs");
const steps = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
const port = 9300 + Math.floor(Math.random() * 500), prof = process.env.PROFILE || `/tmp/radar-cdp-${port}`;
const chrome = spawn("google-chrome", ["--headless=new", "--no-sandbox", "--disable-gpu", "--hide-scrollbars", `--remote-debugging-port=${port}`, `--user-data-dir=${prof}`, "--no-first-run", "--no-proxy-server", "about:blank"], { stdio: "ignore" });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  let tgt; for (let i = 0; i < 50 && !tgt; i++) { await sleep(200); try { tgt = (await (await fetch(`http://127.0.0.1:${port}/json`)).json()).find((t) => t.type === "page"); } catch (e) {} }
  const ws = new WebSocket(tgt.webSocketDebuggerUrl); await new Promise((r) => (ws.onopen = r));
  let id = 0; const pend = {}; const errs = [];
  ws.onmessage = (m) => { const j = JSON.parse(m.data); if (j.id && pend[j.id]) { pend[j.id](j); delete pend[j.id]; }
    if (j.method === "Page.javascriptDialogOpening") { console.log("DIALOG", j.params.type, JSON.stringify(j.params.message)); ws.send(JSON.stringify({ id: ++id, method: "Page.handleJavaScriptDialog", params: { accept: true } })); }
    if (j.method === "Runtime.exceptionThrown") errs.push("EXC " + (j.params.exceptionDetails.exception || {}).description || j.params.exceptionDetails.text);
    if (j.method === "Runtime.consoleAPICalled" && j.params.type === "error") errs.push("ERR " + j.params.args.map((a) => a.value || a.description).join(" "));
    if (j.method === "Log.entryAdded" && j.params.entry.level === "error" && !/favicon|ERR_INTERNET_DISCONNECTED|Failed to load resource/.test(j.params.entry.text)) errs.push("LOG " + j.params.entry.text); };
  const send = (method, params = {}) => new Promise((r) => { const i = ++id; pend[i] = r; ws.send(JSON.stringify({ id: i, method, params })); });
  await send("Page.enable"); await send("Runtime.enable"); await send("Log.enable"); await send("Network.enable");
  await send("Emulation.setDeviceMetricsOverride", { width: 1366, height: 1024, deviceScaleFactor: 1, mobile: false });
  for (const s of steps) {
    if (s.size) await send("Emulation.setDeviceMetricsOverride", { width: s.size[0], height: s.size[1], deviceScaleFactor: 1, mobile: false });
    if (s.go) { await send("Page.navigate", { url: s.go }); await sleep(s.after || 1500); }
    if (s.wait) await sleep(s.wait);
    if (s.offline !== undefined) await send("Network.emulateNetworkConditions", { offline: s.offline, latency: 0, downloadThroughput: -1, uploadThroughput: -1 });
    if (s.click) { const r = await send("Runtime.evaluate", { expression: `(()=>{const e=document.querySelector(${JSON.stringify(s.click)}); if(!e) return "NOEL"; e.click(); return "ok"})()` }); if (r.result.result.value !== "ok") errs.push("click failed " + s.click); await sleep(s.after || 600); }
    if (s.waitFor) { let ok = false; for (let i = 0; i < 60 && !ok; i++) { const r = await send("Runtime.evaluate", { expression: s.waitFor, awaitPromise: true }); ok = !!r.result.result.value; if (!ok) await sleep(250); } if (!ok) errs.push("waitFor timeout " + s.waitFor); }
    if (s.eval) { const r = await send("Runtime.evaluate", { expression: s.eval, awaitPromise: true, returnByValue: true }); console.log("EVAL", s.label || "", JSON.stringify(r.result.result.value ?? r.result.exceptionDetails?.exception?.description)); }
    if (s.file) { const d = await send("DOM.getDocument"); const q = await send("DOM.querySelector", { nodeId: d.result.root.nodeId, selector: s.file[0] });
      await send("DOM.setFileInputFiles", { nodeId: q.result.nodeId, files: [s.file[1]] }); await sleep(300); }
    if (s.saveB64) { const r = await send("Runtime.evaluate", { expression: s.saveB64, awaitPromise: true, returnByValue: true }); fs.writeFileSync(s.to, Buffer.from(r.result.result.value, "base64")); console.log("SAVED", s.to, fs.statSync(s.to).size); }
    if (s.shot) { const r = await send("Page.captureScreenshot", { format: "png", captureBeyondViewport: !!s.full }); fs.writeFileSync(s.shot, Buffer.from(r.result.data, "base64")); console.log("SHOT", s.shot); }
  }
  if (errs.length) console.log("ERRORS\n" + errs.join("\n")); else console.log("NO_ERRORS");
  ws.close(); chrome.kill(); await sleep(500); if (!process.env.PROFILE) try { fs.rmSync(prof, { recursive: true, force: true }); } catch (e) {} process.exit(errs.length ? 1 : 0);
})().catch((e) => { console.error(e); chrome.kill(); process.exit(2); });
