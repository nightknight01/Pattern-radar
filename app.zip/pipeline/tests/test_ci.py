"""GitHub Actions 版：params.json 覆寫、信箱遮罩、state 打包／還原、寄信略過。"""
import json, os, sqlite3, subprocess, sys, tempfile, unittest
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
from radar import config, alerts, db


class TestParams(unittest.TestCase):
    def tearDown(self): os.environ.pop("RADAR_PARAMS", None)

    def _write(self, doc):
        f = tempfile.NamedTemporaryFile("w", suffix=".json", delete=False, encoding="utf-8"); json.dump(doc, f, ensure_ascii=False); f.close()
        os.environ["RADAR_PARAMS"] = f.name; return f.name

    def test_unset_is_defaults(self):
        os.environ.pop("RADAR_PARAMS", None)
        self.assertEqual(config.get(), config.DEFAULTS); self.assertEqual(config.backtest_defaults()["split"], "2025-07-01")

    def test_override_and_notes_ignored(self):
        self._write({"_說明": "x", "w_bottom": {"_說明": "y", "bottom_tol": 0.04}, "backtest": {"split": "2025-01-02"}})
        c = config.get()
        self.assertEqual(c["w_bottom"]["bottom_tol"], 0.04); self.assertEqual(c["w_bottom"]["min_width"], 10)
        self.assertNotIn("_說明", c); self.assertNotIn("_說明", c["w_bottom"]); self.assertNotIn("backtest", c)
        self.assertEqual(config.backtest_defaults()["split"], "2025-01-02")

    def test_unknown_key_fails_loudly(self):
        self._write({"w_bottom": {"bottom_toll": 0.04}})
        with self.assertRaises(ValueError): config.get()
        self._write({"nope": {}})
        with self.assertRaises(ValueError): config.get()

    def test_release_params_has_laowang_section(self):
        p = os.path.join(HERE, "..", "..", "release", "build", "params.json")
        if not os.path.exists(p): self.skipTest("release params.json not built")
        doc = config._strip(json.load(open(p, encoding="utf-8")))
        self.assertEqual(doc["laowang"], config.DEFAULTS["laowang"])
        self.assertEqual(set(doc), set(config.DEFAULTS) | {"backtest"})   # 每個區段都在 params.json（含 v11 laowang）
        self._write({"laowang": {"ma_lenghts": [5]}})
        with self.assertRaises(ValueError): config.get()

    def test_release_params_file_equals_defaults(self):
        p = os.path.join(HERE, "..", "..", "release", "build", "params.json")
        if not os.path.exists(p): self.skipTest("release params.json not built")
        os.environ["RADAR_PARAMS"] = p
        self.assertEqual(config.get(), config.DEFAULTS)


class TestMask(unittest.TestCase):
    def test_mask(self):
        self.assertEqual(alerts.mask_email("someone@gmail.com"), "so***@gmail.com")
        self.assertNotIn("someone", alerts.mask_email("To: someone@gmail.com, ab@x.org"))


class TestState(unittest.TestCase):
    def test_roundtrip(self):
        d = tempfile.mkdtemp(); src = os.path.join(d, "a.sqlite"); dst = os.path.join(d, "b.sqlite"); out = os.path.join(d, "st")
        os.environ["RADAR_DB"] = src
        try:
            con = db.connect()
            rows = [("2330", "2025-12-31", 1000.0, 1010.5, 990.25, 1005.0, 12345000, 1.2e10, 20000, "TWSE MI_INDEX", "x", 5.0, 1),
                    ("2330", "2026-01-02", 1005.0, 1020.0, 1000.0, 1015.0, 2000, None, None, "TWSE MI_INDEX", "x", None, 0),
                    ("6488", "2026-01-02", 500.1, 510.0, 495.0, 505.5, 3000, 1.5e6, 15, "TPEx afterTrading/otc", "x", -1.5, 1)]
            con.executemany("INSERT INTO daily_bars VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)
            con.executemany("INSERT INTO trading_days VALUES (?,?,?)", [("2025-12-31", 1, 1), ("2026-01-02", 1, 1)])
            con.execute("INSERT INTO alert_log (id,dedupe_key,trade_date,status,updated_at) VALUES ('i','k','2026-01-02','sent','t')")
            con.execute("INSERT INTO backtest_trades (id,run_id,updated_at) VALUES ('t','r','t')"); con.commit(); con.close()
            sys.path.insert(0, HERE); from ci import state
            state.export(out)
            info = json.load(open(os.path.join(out, "state_info.json")))
            self.assertEqual(info["T"], "2026-01-02"); self.assertEqual(sorted(info["bar_counts"]), ["2025", "2026"])
            os.environ["RADAR_DB"] = dst
            state.import_(out, root=os.path.join(d, "root"))
            c2 = sqlite3.connect(dst)
            got = c2.execute("SELECT symbol,date,open,high,low,close,volume_shares,turnover,trades,source,chg,chg_known FROM daily_bars ORDER BY symbol,date").fetchall()
            self.assertEqual(got, [r[:10] + r[11:] for r in rows])
            self.assertEqual(c2.execute("SELECT status FROM alert_log").fetchone()[0], "sent")
            self.assertEqual(c2.execute("SELECT count(*) FROM backtest_trades").fetchone()[0], 0)
            # reuse: unchanged years are copied, not recompressed
            out2 = os.path.join(d, "st2"); state.export(out2, reuse=out)
            self.assertEqual(open(os.path.join(out, "bars_2025.csv.xz"), "rb").read(), open(os.path.join(out2, "bars_2025.csv.xz"), "rb").read())
        finally:
            os.environ.pop("RADAR_DB", None)


class TestSendSkip(unittest.TestCase):
    def test_no_secrets_no_send(self):
        d = tempfile.mkdtemp(); p = os.path.join(d, "x.sqlite")
        con = db.connect(p); con.execute("INSERT INTO trading_days VALUES ('2099-01-02',1,1)"); con.commit(); con.close()
        env = {k: v for k, v in os.environ.items() if k not in ("SMTP_USER", "SMTP_PASS", "ALERT_TO")}; env["RADAR_DB"] = p
        r = subprocess.run([sys.executable, os.path.join(HERE, "ci", "send_alert.py")], env=env, capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stderr); self.assertIn("不寄", r.stdout)




class TestExtras(unittest.TestCase):
    """15:00 盤後主跑時法人／融資可能還沒公布；同一交易日稍後補跑才重算。"""

    def setUp(self):
        self.d = tempfile.mkdtemp(); self.db = os.path.join(self.d, "x.sqlite")
        os.environ["RADAR_DB"] = self.db
        self.con = db.connect()
        self.con.execute("INSERT INTO trading_days VALUES ('2026-11-25',1,1)")
        self.con.commit()

    def tearDown(self):
        self.con.close()
        os.environ.pop("RADAR_DB", None)

    def test_coverage_zero_when_unpublished(self):
        from ci.state import extras_coverage, extras_improved
        z = extras_coverage(self.con, "2026-11-25")
        self.assertEqual(z, {"institutional": 0, "margin": 0})
        self.assertEqual(extras_coverage(self.con, None), z)
        self.assertFalse(extras_improved(z, z))
        self.assertFalse(extras_improved(z, {"institutional": 0, "margin": 0}))

    def test_improved_when_rows_arrive(self):
        from ci.state import extras_coverage, extras_improved
        self.con.execute("INSERT INTO institutional_flows VALUES ('2330','2026-11-25',1000,0,0,1000)")
        self.con.execute("INSERT INTO institutional_flows VALUES ('6488','2026-11-25',-200,0,0,-200)")
        self.con.commit()
        mid = extras_coverage(self.con, "2026-11-25")
        self.assertEqual(mid, {"institutional": 2, "margin": 0})
        self.assertTrue(extras_improved({"institutional": 0, "margin": 0}, mid))
        self.con.execute("INSERT INTO margin_daily VALUES ('2330','2026-11-25',10,5,1)")
        self.con.commit()
        after = extras_coverage(self.con, "2026-11-25")
        self.assertEqual(after, {"institutional": 2, "margin": 1})
        self.assertTrue(extras_improved(mid, after))
        self.assertFalse(extras_improved(after, after))
        self.assertFalse(extras_improved(after, {"institutional": 2, "margin": 0}))  # 減少不算新資料

    def test_decide_recompute_cases(self):
        from ci.state import decide_recompute
        z = {"institutional": 0, "margin": 0}
        chips = {"institutional": 1800, "margin": 0}
        both = {"institutional": 1800, "margin": 1600}
        empty = decide_recompute("", "2026-11-24", "aaa", "aaa", "false", "", z, z)
        self.assertEqual(empty, {"recompute": 0, "backtest": 0, "why": "", "status": "no_data"})
        # 15:00：新交易日、籌碼還是 0 → 全量重算，status 仍 ok（主流程成功，網站先上股價與型態）
        d = decide_recompute("2026-11-25", "2026-11-24", "aaa", "aaa", "false", "2026-11-24", z, z)
        self.assertEqual(d["recompute"], 1); self.assertEqual(d["backtest"], 1)
        self.assertIn("新交易日", d["why"]); self.assertEqual(d["status"], "ok")
        # 17:30：同一天法人到了 → 重跑掃描、略過回測
        d = decide_recompute("2026-11-25", "2026-11-25", "aaa", "aaa", "false", "2026-11-25", z, chips)
        self.assertEqual(d["recompute"], 1); self.assertEqual(d["backtest"], 0)
        self.assertEqual(d["why"], "法人或融資融券到了")
        # 21:30：融資也到了 → 再重跑掃描
        d = decide_recompute("2026-11-25", "2026-11-25", "aaa", "aaa", "false", "2026-11-25", chips, both)
        self.assertEqual(d["recompute"], 1); self.assertEqual(d["backtest"], 0)
        # 什麼都沒變 → 很快略過
        d = decide_recompute("2026-11-25", "2026-11-25", "aaa", "aaa", "false", "2026-11-25", both, both)
        self.assertEqual(d, {"recompute": 0, "backtest": 0, "why": "", "status": "ok"})
        # 15:00 股價還沒出（T 沒變、籌碼已齊）→ 略過，等稍後補跑接到新交易日
        d = decide_recompute("2026-11-24", "2026-11-24", "aaa", "aaa", "false", "2026-11-24", both, both)
        self.assertEqual(d["recompute"], 0)
        # 手動重算仍全量
        d = decide_recompute("2026-11-25", "2026-11-25", "aaa", "aaa", "true", "2026-11-25", both, both)
        self.assertEqual(d["recompute"], 1); self.assertEqual(d["backtest"], 1)
        self.assertIn("手動要求重算", d["why"])


if __name__ == "__main__":
    unittest.main()


class TestSendFake(unittest.TestCase):
    """Send path with a fake SMTP server object: correct recipients/subject, marks alert_log sent, never resends."""
    def test_send_once(self):
        import datetime as dt, importlib, smtplib
        d = tempfile.mkdtemp(); p = os.path.join(d, "x.sqlite"); ad = os.path.join(d, "alerts"); os.makedirs(ad)
        T = dt.datetime.now(dt.timezone(dt.timedelta(hours=8))).date().isoformat()
        con = db.connect(p); con.execute("INSERT INTO trading_days VALUES (?,1,1)", (T,))
        con.execute("INSERT INTO alert_log (id,dedupe_key,trade_date,status,updated_at) VALUES ('i','k',?,'dry_run','t')", (T,)); con.commit(); con.close()
        b = os.path.join(ad, f"alert_{T.replace('-', '')}")
        json.dump({"would_send": True, "subject": "[型態雷達] 測試", "trade_date": T}, open(b + ".json", "w"), ensure_ascii=False)
        open(b + ".txt", "w").write("To: x\nSubject: s\n\n本文第一行\n"); open(b + ".html", "w").write("<p>hi</p>")
        sent = []
        class FakeSSL:
            def __init__(s, host, port, context=None, timeout=None): sent.append(("connect", host, port))
            def __enter__(s): return s
            def __exit__(s, *a): return False
            def login(s, u, pw): sent.append(("login", u))
            def send_message(s, m): sent.append(("msg", m["To"], m["Subject"], m.get_body(("plain",)).get_content()))
        env = dict(RADAR_DB=p, RADAR_ALERTS_DIR=ad, SMTP_USER="bot@example.com", SMTP_PASS="not-a-real-pass", ALERT_TO="a@example.com, b@example.com")
        old = {k: os.environ.get(k) for k in env}; os.environ.update(env); orig = smtplib.SMTP_SSL; smtplib.SMTP_SSL = FakeSSL
        try:
            sys.path.insert(0, HERE); from ci import send_alert; importlib.reload(send_alert)
            self.assertEqual(send_alert.main(), 0)
            self.assertEqual(sent[0], ("connect", "smtp.gmail.com", 465))
            self.assertEqual(sent[2][1], "a@example.com, b@example.com"); self.assertEqual(sent[2][2], "[型態雷達] 測試")
            self.assertIn("本文第一行", sent[2][3]); self.assertNotIn("Subject: s", sent[2][3])
            self.assertEqual(sqlite3.connect(p).execute("SELECT status FROM alert_log").fetchone()[0], "sent")
            n = len(sent); self.assertEqual(send_alert.main(), 0); self.assertEqual(len(sent), n)   # no resend
        finally:
            smtplib.SMTP_SSL = orig
            for k, v in old.items():
                if v is None: os.environ.pop(k, None)
                else: os.environ[k] = v
