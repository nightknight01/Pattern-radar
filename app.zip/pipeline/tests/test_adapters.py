"""Adapter tests on trimmed real official responses (TWSE MI_INDEX / TPEx otc, 2026-11-19)."""
import os, sys, json, unittest, datetime as dt
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from radar import ingest
FX = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fixtures")
D = dt.date(2026, 11, 19)


class Adapters(unittest.TestCase):
    def test_twse_mi_index(self):
        rows = {r["symbol"]: r for r in ingest.parse_twse_day(json.load(open(os.path.join(FX, "twse_20261119_min.json"))), D)}
        self.assertIn("2330", rows); self.assertNotIn("2881A", rows)   # preferred share excluded
        r = rows["2330"]
        self.assertEqual((r["open"], r["high"], r["low"], r["close"]), (2165.0, 2190.0, 2085.0, 2100.0))
        self.assertEqual(r["chg"], -75.0); self.assertEqual(r["chg_known"], 1); self.assertEqual(r["volume_shares"], 56582314)

    def test_twse_wrong_date_rejected(self):
        self.assertIsNone(ingest.parse_twse_day({"stat": "很抱歉，沒有符合條件的資料!"}, D))

    def test_tpex_otc(self):
        rows = {r["symbol"]: r for r in ingest.parse_tpex_day(json.load(open(os.path.join(FX, "tpex_20261119_min.json"))), D)}
        self.assertIn("6488", rows); self.assertEqual(rows["6488"]["market"], "TPEx")
        self.assertIsNone(ingest.parse_tpex_day(json.load(open(os.path.join(FX, "tpex_20261119_min.json"))), dt.date(2026, 11, 18)))

    def test_roc_dates(self):
        self.assertEqual(ingest.roc_to_iso("115年11月19日"), "2026-11-19")
        self.assertEqual(ingest.roc_to_iso("115/10/01"), "2026-10-01")
        self.assertEqual(ingest.roc_to_iso("1151119"), "2026-11-19")

    def test_classify(self):
        self.assertEqual(ingest.classify("2330", ""), "stock"); self.assertEqual(ingest.classify("00631L", ""), "etf")
        self.assertIsNone(ingest.classify("2881A", "")); self.assertIsNone(ingest.classify("020011", ""))


if __name__ == "__main__":
    unittest.main()
