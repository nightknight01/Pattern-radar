"""run_backup.py CLI（export → import 到另一個乾淨 DB，筆數與 checksum 一致）＋ health.build。"""
import json, os, subprocess, sys, tempfile, unittest
from radar import db, backup, health

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CODE = "ABCD-EFGH-JKMN-PQRS-TUVW-XYZ2"


def run(args, dbp):
    env = dict(os.environ, RADAR_DB=dbp, RADAR_RECOVERY_CODE=CODE)
    return json.loads(subprocess.check_output([sys.executable, os.path.join(HERE, "run_backup.py")] + args, env=env, text=True))


class Cli(unittest.TestCase):
    def test_roundtrip(self):
        d = tempfile.mkdtemp(); a, b, f = os.path.join(d, "a.sqlite"), os.path.join(d, "b.sqlite"), os.path.join(d, "x.prb")
        con = db.connect(a)
        con.execute("INSERT INTO watchlist VALUES ('w1','2330','LONG','n','2026-11-19T00:00:00.000Z','dev',0,1)")
        con.execute("INSERT INTO watchlist VALUES ('w2','2317','NONE','','2026-11-19T00:00:00.000Z','dev',1,2)")
        con.execute("INSERT INTO settings VALUES ('cis_exit_scope','\"all\"','2026-11-19T00:00:00.000Z','dev',0,1)"); con.commit(); con.close()
        ex = run(["export", "--out", f], a)
        self.assertEqual(ex["rows"]["watchlist"], 2)
        im = run(["import", f], b)
        self.assertEqual(im["checksum"], ex["checksum"])
        con2 = db.connect(b)
        self.assertEqual(con2.execute("SELECT count(*), sum(deleted) FROM watchlist").fetchone(), (2, 1))
        self.assertEqual(con2.execute("SELECT value_json FROM settings WHERE key='cis_exit_scope'").fetchone()[0], '"all"')
        doc = backup.make_doc(con2); self.assertEqual(backup.checksum(doc["tables"]), ex["checksum"])
        env = dict(os.environ, RADAR_DB=b, RADAR_RECOVERY_CODE="WRNG-CODE-WRNG-CODE-WRNG-CODE")
        r = subprocess.run([sys.executable, os.path.join(HERE, "run_backup.py"), "verify", f], env=env, capture_output=True, text=True)
        self.assertNotEqual(r.returncode, 0)

    def test_health(self):
        con = db.connect(os.path.join(tempfile.mkdtemp(), "h.sqlite"))
        con.execute("INSERT INTO trading_days VALUES ('2026-11-19',1,1)"); con.commit()
        h = health.build(con, {"trade_date": "2026-11-19", "stats": {"universe": 5}})
        self.assertEqual(h["trading_days"]["last"], "2026-11-19"); self.assertEqual(h["scan"]["universe"], 5)
        self.assertEqual({t["table"] for t in h["tables"]} >= {"daily_bars", "monthly_revenue"}, True)
        self.assertTrue(h["generated_at"].endswith("+08:00"))


if __name__ == "__main__":
    unittest.main()
