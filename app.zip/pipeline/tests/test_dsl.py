import json, os, random, sqlite3, unittest
import numpy as np
from radar import dsl, cis, config, adjuster
from radar.context import Ctx
from tests import synth

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFS = {p["code"]: p for p in json.load(open(os.path.join(HERE, "radar", "dsl_builtin.json")))["patterns"]}
DBP = os.path.join(HERE, "db", "radar.sqlite")


def compare(ctx, code, positions):
    prog = dsl.Program(DEFS[code]); fn = dsl.ctx_fn(prog)
    ref = cis.evaluate_cis_base if code == "cis_base" else cis.evaluate_cis_exp
    bad = []
    for t in range(59, ctx.n):
        for pos in positions:
            a, b = ref(ctx, t, pos), fn(ctx, t, pos)
            if pos == "NONE":   # scan mode: ENTRY decision + direction + strength (non-ENTRY = 持有者參考 states, not part of DSL)
                ea, eb = a["state"] == "ENTRY", b["state"] == "ENTRY"
                if ea != eb or (ea and (a["direction"] != b["direction"] or abs((a["strength"] or 0) - (b["strength"] or 0)) > 1e-9)):
                    bad.append((t, pos, a["state"], b["state"], a.get("strength"), b.get("strength")))
            else:
                if (a["state"], a["direction"]) != (b["state"], b["direction"] if b["state"] != "WATCH" else a["direction"]):
                    bad.append((t, pos, a["state"], b["state"]))
    return bad


class ParserTests(unittest.TestCase):
    def test_rejects_illegal(self):
        bad = ["__import__('os')", "close.real", "open[1]", "exec(close)", "sma(close, close)", "ref(close, 999)", "close >", "pivots(0.05)",
               "x" * 600, "'abc'", "close ; volume", "lambda: 1"]
        for s in bad:
            with self.subTest(s=s):
                try: errs = dsl.check(dsl.parse(s), {b: "base" for b in dsl.BASE})
                except dsl.DSLError: errs = ["parse"]
                self.assertTrue(errs, s)

    def test_validate_schema(self):
        d = json.loads(json.dumps(DEFS["cis_exp"]))
        self.assertEqual(dsl.validate(d), [])
        d["code"] = "Bad-Code"; d["states"][0]["state"] = "BUY"; d["series"]["m5"] = "sma(close)"; d["directions"] = ["up"]
        errs = dsl.validate(d)
        self.assertTrue(any("code" in e for e in errs) and any("BUY" in e for e in errs) and any("參數數量" in e for e in errs))
        d = json.loads(json.dumps(DEFS["cis_base"])); d["series"] = {"a": "b + 1", "b": "close"}   # forward reference / recursion
        self.assertTrue(any("未知名稱 'b'" in e for e in dsl.validate(d)))
        with self.assertRaises(dsl.DSLError): dsl.Program({"code": "x"})

    def test_functions(self):
        P = dsl.Program({"code": "t", "name": "t", "version": 1, "directions": ["long"], "params": {"k": {"default": 2}},
                         "series": {"a": "ref(close, k)", "u": "cross_up(close, a)", "h": "highest(close,3)", "n": "count(close > 2, 3)"},
                         "states": [{"state": "ENTRY", "direction": "long", "requires_position": "NONE", "when": "u", "strength": "h + n"}], "min_bars": 1})
        c = np.array([1, 2, 3, 1, 5.0]); E = P.env(c, c, c, c, c)
        np.testing.assert_array_equal(np.nan_to_num(E["a"], nan=-1), [-1, -1, 1, 2, 3])
        np.testing.assert_array_equal(E["u"], [0, 0, 0, 0, 1])
        self.assertEqual(P.state_at(E, 4)["strength"], 5 + 2)


class SynthParityTests(unittest.TestCase):
    def test_parity_on_synthetic_paths(self):
        cfg = config.get(); rng = np.random.default_rng(7)
        for seed in range(6):
            c = synth.path(100, [(40, 130), (25, 95), (30, 140), (25, 110), (20, 125)]) * (1 + rng.normal(0, 0.01, 141))
            o = np.r_[c[0], c[:-1]] * (1 + rng.normal(0, 0.005, len(c)))
            v = rng.lognormal(14, 0.6, len(c))
            ctx = Ctx([str(i) for i in range(len(c))], o, np.maximum(o, c) * 1.01, np.minimum(o, c) * 0.99, c, v, cfg)
            self.assertEqual(compare(ctx, "cis_base", ("NONE", "LONG")), [])
            self.assertEqual(compare(ctx, "cis_exp", ("NONE", "LONG", "SHORT")), [])


@unittest.skipUnless(os.path.exists(DBP), "no market DB")
class RealDataParityTests(unittest.TestCase):
    """P9 驗收：DSL 版 cis_base / cis_exp 與內建版在真實日 K 上逐日一致。"""
    def test_parity_real(self):
        con = sqlite3.connect(DBP, timeout=30); cfg = config.get()
        syms = [r[0] for r in con.execute("SELECT symbol FROM instruments ORDER BY symbol")]
        random.Random(3).shuffle(syms); n_ok = 0; n_entry = 0
        for sym in syms[:60]:
            rows = con.execute("SELECT date,open,high,low,close,volume_shares,chg,chg_known FROM daily_bars WHERE symbol=? AND date>='2025-06-01' ORDER BY date", (sym,)).fetchall()
            if len(rows) < 120: continue
            d, o, h, l, c, v, chg, ck = (np.array([r[i] for r in rows], dtype=object if i == 0 else float) for i in range(8))
            if not (np.all(c > 0) and np.all(h >= l)): continue
            a = adjuster.adjust(list(d), o, h, l, c, v, chg, np.nan_to_num(ck).astype(int), {})
            if len(a["c"]) < 120: continue
            ctx = Ctx(a["dates"], a["o"], a["h"], a["l"], a["c"], a["v"], cfg, symbol=sym)
            self.assertEqual(compare(ctx, "cis_base", ("NONE", "LONG")), [], sym)
            self.assertEqual(compare(ctx, "cis_exp", ("NONE", "LONG", "SHORT")), [], sym)
            n_entry += sum(1 for t in range(59, ctx.n) if cis.evaluate_cis_exp(ctx, t)["state"] == "ENTRY"); n_ok += 1
        self.assertGreater(n_ok, 20); self.assertGreater(n_entry, 0)


if __name__ == "__main__":
    unittest.main()
