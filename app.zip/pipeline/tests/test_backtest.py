import csv, os, unittest
import numpy as np
from radar import backtest as bt

MJ = "/workspace/backtest_2024_2026/MJ"


class CostTests(unittest.TestCase):
    def test_levels_give_exact_net(self):
        for d in ("long", "short"):
            st, tp = bt.x1_levels(d, 100.0)
            self.assertAlmostEqual(bt.net(d, 100, st), -0.07, places=9)
            self.assertAlmostEqual(bt.net(d, 100, tp), 0.12, places=9)
        self.assertAlmostEqual(bt.x1_levels("long", 1)[0], 0.9372, places=4)
        self.assertAlmostEqual(bt.x1_levels("short", 1)[0], 1.0623, places=4)
        self.assertAlmostEqual(bt.net("long", 100, 100), 100 * bt.S / (100 * bt.B) - 1)  # round trip ≈ −0.771%
        self.assertAlmostEqual(bt.net("long", 100, 100), -0.00769, places=4)

    def test_same_day_both_is_stop(self):
        O = np.array([100, 100.0]); H = np.array([101, 200.0]); L = np.array([99, 50.0]); C = np.array([100, 100.0])
        x = bt.sim_x1("long", O, H, L, C, 0)
        self.assertEqual(x["reason"], "stop"); self.assertEqual(x["exit_idx"], 1)

    def test_gap_open_fill(self):
        O = np.array([100, 80.0]); H = np.array([101, 85.0]); L = np.array([99, 79.0]); C = np.array([100, 84.0])
        x = bt.sim_x1("long", O, H, L, C, 0); self.assertEqual((x["reason"], x["exit_price"]), ("stop_gap", 80.0))
        x = bt.sim_x1("short", O, H, L, C, 0); self.assertEqual(x["reason"], "target_gap")

    def test_time_exit_day10(self):
        n = 15; O = H = L = C = np.full(n, 100.0)
        x = bt.sim_x1("long", O, H + 1, L - 1, C, 2); self.assertEqual((x["reason"], x["exit_idx"]), ("time", 11))

    def test_x2_priority_and_next_open(self):
        O = np.array([10, 10, 10, 9.0]); H = np.array([10.5, 12.5, 10.2, 9.5]); L = np.array([9.8, 9.0, 9.0, 8.8]); C = np.array([10, 9.1, 9.2, 9.0])
        x = bt.sim_x2("long", O, H, L, C, 0, {"stopRef": 9.5, "target": 12, "neckline": 9.9})
        self.assertEqual((x["reason"], x["exit_idx"], x["exit_price"]), ("stopref", 2, 10.0))  # close<stop beats intraday target
        x = bt.sim_x2("long", O, H, L, C, 0, {"stopRef": 9.5, "target": 12, "neckline": 9.9}, exit_exec="same_close")
        self.assertEqual((x["reason"], x["exit_idx"]), ("stopref", 1))

    def test_portfolio_slots_and_strength(self):
        mk = lambda s, e, x, st: dict(symbol=s, entry_i=e, exit_i=x, at_open=False, strength=st, path=[0.0] * (x - e + 1))
        c = [mk("A", 1, 5, 10), mk("B", 1, 3, 90), mk("C", 1, 9, 50), mk("D", 4, 6, 10), mk("B", 2, 4, 99)]
        taken, full, dup = bt.run_portfolio(c, None, max_positions=2)
        self.assertEqual([t["symbol"] for t in taken], ["B", "C", "D"])
        self.assertEqual((full, dup), (1, 1))

    def test_nav_and_mdd(self):
        t = [dict(entry_i=0, path=[0.1, -0.2, 0.05])]
        nav = bt.nav_series(t, 4, max_positions=1)
        self.assertEqual(nav, [1.1, 0.8, 1.05, 1.05])
        self.assertAlmostEqual(bt.max_drawdown(nav), 0.8 / 1.1 - 1)


@unittest.skipUnless(os.path.exists(MJ + "/trades.csv"), "MJ baseline not on this box")
class MJBaselineTests(unittest.TestCase):
    """§12.6：用 MJ 規則的進場重跑，X1 撮合與成本須與 /workspace/backtest_2024_2026/MJ/trades.csv 逐筆一致."""
    def test_x1_matches_mj_trades(self):
        rows = list(csv.DictReader(open(MJ + "/trades.csv")))
        self.assertTrue(rows)
        for r in rows:
            d = list(csv.DictReader(open(f"{MJ}/data_{r['ticker']}_adjusted.csv")))
            dates = [x["date"][:10] for x in d]
            O, H, L, C = (np.array([float(x[k]) for x in d]) for k in "OHLC")
            i = dates.index(r["signal_date"])
            self.assertTrue(bt.entry_ok("long", float(d[i + 1]["rawO"]), float(d[i]["rawC"])))
            x = bt.sim_x1("long", O, H, L, C, i + 1)
            self.assertEqual(dates[i + 1], r["buy_date"])
            self.assertEqual(dates[x["exit_idx"]], r["sell_date"], r)
            # MJ 用四捨五入係數 0.9372／1.1287；本引擎用精確 0.93·b/s（淨報酬剛好 −7%）→ 價格容差 5e-5 相對（另含 MJ 輸出四捨五入到 3 位）
            self.assertLess(abs(x["exit_price"] / float(r["sell_price"]) - 1), 5e-5)
            self.assertEqual(x["reason"].split("_")[0], {"stop": "stop", "time": "time", "target": "target"}[r["exit_reason"].split()[0]])
            self.assertAlmostEqual(bt.net("long", O[i + 1], x["exit_price"]) * 100, float(r["net_return_pct"]), delta=0.006)


if __name__ == "__main__":
    unittest.main()
