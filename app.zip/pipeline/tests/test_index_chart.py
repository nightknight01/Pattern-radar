"""v8：全球指數 K 線頁（run_indices：日 K 整理、盤中 K 棒、十二招有型態才畫線、無資料）— 全部用假資料，不連網。"""
import datetime as dt, json, os, sys, tempfile, unittest
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE); sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import run_indices as RI
from synth import path
from radar import config


def rows_from_close(c, vol=1e6, start=dt.date(2025, 1, 1), spread=0.005):
    out, prev = [], c[0]
    for i, x in enumerate(c):
        o = prev; prev = x
        out.append(((start + dt.timedelta(days=i)).isoformat(), o, max(o, x) * (1 + spread), min(o, x) * (1 - spread), x, vol))
    return out


def M_TOP(): return path(80, [(40, 80), (30, 100), (15, 90), (15, 99.5), (12, 90.5), (1, 87)])      # 收 87 < 頸線 89.55×0.98 → M頭確認
def W_BOTTOM(): return path(100, [(40, 100), (40, 80), (15, 90), (15, 80.5), (10, 89.5), (1, 93)])  # 末根突破頸線（需量）


def yahoo(rows, meta=None):
    ts = [int(dt.datetime.fromisoformat(r[0]).replace(tzinfo=dt.timezone.utc).timestamp()) for r in rows]
    q = {k: [r[i] for r in rows] for k, i in (("open", 1), ("high", 2), ("low", 3), ("close", 4), ("volume", 5))}
    return json.dumps({"chart": {"result": [{"meta": dict({"gmtoffset": 0}, **(meta or {})), "timestamp": ts, "indicators": {"quote": [q]}}], "error": None}})


def load(p):
    with open(p, encoding="utf-8") as f: return json.load(f)


class Shaping(unittest.TestCase):
    def test_clean_fills_and_fixes(self):
        r = RI._clean([("2026-11-02", None, None, None, 100, None), ("2026-11-01", 99, 98, 101, 100.5, 5),
                       ("2026-11-02", 100, 103, 99, 102, 7), ("2026-11-03", 1, 2, 3, None, 4), ("2026-11-04", 0, 0, 0, float("nan"), 1)])
        self.assertEqual([x[0] for x in r], ["2026-11-01", "2026-11-02"])            # 排序、同日取最後一筆、收盤空值剔除
        self.assertEqual(r[0], ("2026-11-01", 99, 101, 98, 100.5, 5))              # 高低顛倒 → 修正成包住開收
        self.assertEqual(r[1], ("2026-11-02", 100, 103, 99, 102, 7))

    def test_clean_close_only_and_missing_volume(self):
        r = RI._clean([("2026-11-01", 50.0), ("2026-11-02", None, None, None, 51, None)])
        self.assertEqual(r[0], ("2026-11-01", 50.0, 50.0, 50.0, 50.0, 0.0))
        self.assertEqual(r[1][5], 0.0)

    def test_yahoo_drops_unfinished_bar(self):
        rows = rows_from_close(list(range(100, 130)), start=dt.date(2026, 10, 27))
        last = int(dt.datetime.fromisoformat(rows[-1][0]).replace(tzinfo=dt.timezone.utc).timestamp())
        meta = {"currentTradingPeriod": {"regular": {"start": last + 9 * 3600, "end": last + 17 * 3600}}}
        live = RI.from_yahoo("^GDAXI", lambda u: yahoo(rows, meta), now=last + 12 * 3600)           # 當地盤中
        closed = RI.from_yahoo("^GDAXI", lambda u: yahoo(rows, meta), now=last + 18 * 3600)         # 已收盤
        self.assertEqual(len(live), len(rows) - 1); self.assertEqual(len(closed), len(rows))
        urls = []; RI.from_yahoo("^GDAXI", lambda u: urls.append(u) or yahoo(rows))
        self.assertIn("range=2y", urls[0])                                                # 約 2 年日 K

    def test_chart_doc_shape(self):
        rows = rows_from_close(list(M_TOP()) * 3)
        doc = RI.chart_doc(RI.INDICES[0], RI._clean(rows), "Yahoo Finance", None, "2026-11-25T15:00:00+08:00",
                           detect_fn=lambda *a, **k: ([], []))
        b = doc["bars"]
        self.assertEqual(doc["n_bars"], RI.LOOKBACK); self.assertEqual(len(b["t"]), RI.LOOKBACK)
        self.assertTrue(all(len(b[k]) == RI.LOOKBACK for k in "ohlcv"))
        self.assertRegex(b["t"][0], r"^\d{8}$"); self.assertEqual(doc["data_as_of"], rows[-1][0])
        self.assertTrue(doc["has_volume"]); self.assertEqual(doc["signals"], []); self.assertEqual(doc["patterns"], [])
        self.assertTrue(all(b["l"][i] <= min(b["o"][i], b["c"][i]) and b["h"][i] >= max(b["o"][i], b["c"][i]) for i in range(len(b["t"]))))


class PatternOrPlain(unittest.TestCase):
    cfg = config.get()

    def test_pattern_found_gives_overlay_geometry(self):
        sigs, notes = RI.detect(RI._clean(rows_from_close(M_TOP())), self.cfg, symbol="^GSPC", name="S&P 500")
        m = [s for s in sigs if s["patternId"] == "m_top"]
        self.assertTrue(m, [s["patternId"] for s in sigs]); s = m[0]
        self.assertEqual(s["direction"], "short"); self.assertEqual(s["state"], "CONFIRMED")
        self.assertIn("neckline", s["levels"]); self.assertTrue(any("date" in g for g in s["geometry"].values() if isinstance(g, dict)))
        self.assertFalse(any("放空可行性" in r or "融券" in r for r in s["reasons"]))        # 指數不談融券
        self.assertFalse(any(x["patternId"].startswith("cis") for x in sigs))             # 只有十二招
        self.assertEqual(notes, [])
        mv = s["move"]                                                                     # 1 倍／2 倍跌幅（指數頁圖下方面板）
        self.assertEqual(mv["basis"], "M頭"); self.assertAlmostEqual(mv["t1"], s["levels"]["target"], places=2)
        self.assertAlmostEqual(mv["t2"], mv["neckline"] - 2 * mv["height"], places=1)
        json.dumps(sigs)                                                                   # 可寫成 JSON

    def test_no_pattern_plain_chart(self):
        c = [100 + 0.1 * i for i in range(200)]                                          # 平穩上升，沒有任何型態
        doc = RI.chart_doc(RI.INDICES[0], RI._clean(rows_from_close(c)), "Yahoo Finance", self.cfg, "x")
        self.assertEqual(doc["signals"], []); self.assertEqual(doc["patterns"], []); self.assertEqual(doc["n_bars"], 200)

    def test_too_few_bars_no_detection(self):
        sigs, notes = RI.detect(RI._clean(rows_from_close([100.0] * 50)), self.cfg)
        self.assertEqual(sigs, []); self.assertIn("不判斷型態", notes[0])

    def test_index_without_volume(self):
        c = W_BOTTOM()
        with_vol = RI._clean(rows_from_close(c, vol=1e6))                                 # 有量但末根沒放量 → 不確認
        no_vol = RI._clean(rows_from_close(c, vol=0))                                    # 指數沒有量 → 量能條件不適用
        conf = lambda sigs: [s for s in sigs if s["patternId"] == "w_bottom" and s["state"] == "CONFIRMED"]
        self.assertFalse(conf(RI.detect(with_vol, self.cfg)[0]))
        sigs, notes = RI.detect(no_vol, self.cfg)
        self.assertTrue(conf(sigs)); self.assertIn(RI.NO_VOL_NOTE, notes); self.assertIn(RI.NO_VOL_NOTE, conf(sigs)[0]["reasons"])

    def test_detector_crash_still_gives_chart(self):
        def boom(*a, **k): raise RuntimeError("bad")
        doc = RI.chart_doc(RI.INDICES[0], RI._clean(rows_from_close(M_TOP())), "Yahoo Finance", self.cfg, "x", detect_fn=boom)
        self.assertEqual(doc["signals"], []); self.assertIn("型態偵測失敗", doc["notes"][0]); self.assertTrue(doc["bars"]["t"])


class BuildFiles(unittest.TestCase):
    def test_writes_files_and_handles_missing(self):
        out = tempfile.mkdtemp()
        good = yahoo(rows_from_close(M_TOP()))
        def get(url):
            if "GSPC" in url or "gspc" in url: return good
            raise IOError("down")
        doc = RI.build(get=get, sleep=0, out=out, cfg=config.get())
        spx = doc["indices"][0]
        self.assertTrue(spx["chart"]); self.assertIn(["m_top", "short", "CONFIRMED"], spx["patterns"])
        f = load(os.path.join(out, "idx_spx.json"))
        self.assertEqual(f["id"], "spx"); self.assertIn("m_top", f["patterns"])
        dji = doc["indices"][1]
        self.assertFalse(dji["chart"]); self.assertFalse(os.path.exists(os.path.join(out, "idx_dji.json")))   # 前端顯示「無資料」
        # 下一次 S&P 也失敗 → 沿用上一份 K 線並標 stale
        doc2 = RI.build(prev=doc, get=lambda u: (_ for _ in ()).throw(IOError("down")), sleep=0, out=out, cfg=config.get())
        self.assertTrue(doc2["indices"][0]["chart"]); self.assertTrue(doc2["indices"][0]["stale"])
        f2 = load(os.path.join(out, "idx_spx.json"))
        self.assertTrue(f2["stale"]); self.assertIn("沿用", f2["error"]); self.assertEqual(f2["bars"], f["bars"])

    def test_without_out_dir_no_private_fields(self):
        doc = RI.build(get=lambda u: yahoo(rows_from_close(M_TOP())), sleep=0)
        self.assertNotIn("_rows", doc["indices"][0]); self.assertNotIn("chart", doc["indices"][0])
        json.dumps(doc)


if __name__ == "__main__":
    unittest.main()
