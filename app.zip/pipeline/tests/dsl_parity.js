// node dsl_parity.js <in.json> — evaluate DSL in JS on given bars; print states per t/position (compared by test_dsl_js.py)
const fs = require("fs"); const D = require(__dirname + "/../../web/dsl.js");
const j = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
const out = {};
if (j.validate) { console.log(JSON.stringify(j.validate.map((d) => D.validate(d)))); process.exit(0); }
for (const d of j.defs) {
  const p = D.compile(d), E = p.env(j.o, j.h, j.l, j.c, j.v), r = [];
  for (let t = 0; t < j.c.length; t++) for (const pos of ["NONE", "LONG", "SHORT"]) { const s = p.stateAt(E, t, pos, j.shortable); r.push([t, pos, s.state, s.direction, s.strength == null ? null : +s.strength.toFixed(9)]); }
  out[d.code] = r;
}
console.log(JSON.stringify(out));
