"""v13：融資／擔保維持率（radar/margin.py、run_margin.py）— 以 2026-11-26 實測 fixtures 核對，不連網。"""
import datetime as dt, json, os, sys, tempfile, unittest
from zoneinfo import ZoneInfo
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIX = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fixtures", "margin")
sys.path.insert(0, HERE)
from radar import margin, config
import run_margin

TPE = ZoneInfo("Asia/Taipei")


def _load(name):
    with open(os.path.join(FIX, name), encoding="utf-8") as f:
        return f.read()


def getter(today_empty=False, fail=(), override=None):
    """依 URL 回傳對應的 11/26 fixture。fail 為會丟例外的關鍵字列表。"""
    override = override or {}

    def get(url, timeout=45):
        u = url
        for k in fail:
            if k in u:
                raise OSError("simulated fail " + k)
        if u in override:
            v = override[u]
            if isinstance(v, Exception):
                raise v
            return v
        if "BFIJ3U_TREND" in u:
            return _load("bfij3u_trend_20261126.json")
        if "BFIJ3U" in u:
            if today_empty and "date=20261127" in u:
                return _load("bfij3u_empty.json")
            if "date=" in u and "date=20261126" not in u and "BFIJ3U_TREND" not in u:
                return _load("bfij3u_empty.json")
            return _load("bfij3u_20261126.json")
        if "MI_MARGN" in u:
            if "date=20261126" not in u:
                return json.dumps({"stat": "很抱歉，沒有符合條件的資料"})
            return _load("mi_margn_20261126.json")
        if "MI_INDEX" in u:
            if "date=20261126" not in u:
                return json.dumps({"stat": "很抱歉，沒有符合條件的資料"})
            return _load("mi_index_20261126.json")
        if "margin/balance" in u:
            if "2026/11/26" not in u and "2026%2F11%2F26" not in u:
                return json.dumps({"stat": "很抱歉，沒有符合條件的資料"})
            return _load("tpex_balance_20261126.json")
        if "dailyQuotes" in u or "afterTrading/otc" in u:
            if "2026/11/26" not in u and "2026%2F11%2F26" not in u:
                return json.dumps({"stat": "很抱歉，沒有符合條件的資料"})
            return _load("tpex_quotes_20261126.json")
        raise KeyError("unexpected url " + u)
    return get


class TestParseAndCompute(unittest.TestCase):
    def test_official_keepRate_170_07(self):
        o = margin.parse_bfij3u(_load("bfij3u_20261126.json"))
        self.assertEqual(o["date"], "2026-11-26")
        self.assertEqual(o["keepRate"], 170.07)
        self.assertEqual(o["belowAccNum"], 149)
        self.assertEqual(o["callAccNum"], 3)

    def test_trend(self):
        t = margin.parse_bfij3u_trend(_load("bfij3u_trend_20261126.json"))
        self.assertEqual(t[0]["date"], "2026-11-20")
        self.assertEqual(t[-1]["keepRate"], 170.07)
        self.assertEqual(len(t), 5)

    def test_computed_matches_istock_20261126(self):
        d1, amt_l, rows_l = margin.parse_mi_margn(_load("mi_margn_20261126.json"))
        _, px_l = margin.parse_mi_index_prices(_load("mi_index_20261126.json"))
        d2, amt_o, rows_o = margin.parse_tpex_balance(_load("tpex_balance_20261126.json"))
        _, px_o, ref_o = margin.parse_tpex_quotes(_load("tpex_quotes_20261126.json"))
        self.assertEqual(d1, "2026-11-26")
        self.assertEqual(d2, "2026-11-26")
        listed = margin.compute_ratio(rows_l, px_l, amt_l)
        otc = margin.compute_ratio(rows_o, px_o, amt_o, fallback=ref_o)
        all_ratio = (listed["market_value"] + otc["market_value"]) / (listed["amount"] + otc["amount"]) * 100
        self.assertEqual(listed["ratio"], 159.67)
        self.assertEqual(otc["ratio"], 150.73)
        self.assertEqual(round(all_ratio + 1e-12, 2), 157.62)
        self.assertGreater(otc["fallback_names"], 0)   # 停牌檔用次日參考價

    def test_otc_without_ref_is_lower(self):
        _d, amt_o, rows_o = margin.parse_tpex_balance(_load("tpex_balance_20261126.json"))
        _, px_o, ref_o = margin.parse_tpex_quotes(_load("tpex_quotes_20261126.json"))
        bare = margin.compute_ratio(rows_o, px_o, amt_o)
        filled = margin.compute_ratio(rows_o, px_o, amt_o, fallback=ref_o)
        self.assertLess(bare["ratio"], filled["ratio"])
        self.assertEqual(filled["ratio"], 150.73)

    def test_empty_official(self):
        with self.assertRaises(ValueError):
            margin.parse_bfij3u(_load("bfij3u_empty.json"))
        self.assertTrue(margin.no_data(json.loads(_load("bfij3u_empty.json"))))

    def test_classify(self):
        th = {"alert_below": 130, "watch_below": 167}
        self.assertEqual(margin.classify(170.07, th)[0], "ok")
        self.assertEqual(margin.classify(151.78, th), ("watch", "偏緊"))
        self.assertEqual(margin.classify(129.0, th), ("alert", "追繳區"))
        self.assertEqual(margin.classify(None, th)[0], "missing")
        self.assertEqual(config.DEFAULTS["margin"], {"alert_below": 130, "watch_below": 167})


class TestFetch(unittest.TestCase):
    def test_today_not_out_uses_previous_session(self):
        payload, errs = margin.fetch(getter(today_empty=True), today="2026-11-27")
        self.assertEqual(payload["official"]["date"], "2026-11-26")
        self.assertEqual(payload["official"]["keepRate"], 170.07)
        self.assertEqual(payload["computed"]["listed"], 159.67)
        self.assertEqual(payload["computed"]["otc"], 150.73)
        self.assertEqual(payload["computed"]["all"], 157.62)
        doc = margin.build_doc(payload, errs, "2026-11-27T22:00:00+08:00")
        self.assertEqual(doc["kind"], "margin")
        self.assertEqual(doc["title"], "整戶擔保維持率")
        self.assertEqual(doc["value"], 170.07)
        self.assertEqual(doc["as_of"], "2026-11-26")
        self.assertEqual(doc["status"], "ok")
        self.assertEqual(doc["status_label"], "安全")
        self.assertTrue(doc["provisional"])
        self.assertFalse(doc["stale"])
        self.assertIn("159.67", doc["secondary"])
        self.assertEqual(doc["thresholds"]["alert_below"], 130)
        self.assertEqual(len(doc["trend"]), 5)

    def test_all_down(self):
        def boom(url, timeout=45):
            raise OSError("down")
        payload, errs = margin.fetch(boom, today="2026-11-26", lookback=2)
        self.assertIsNone(payload)
        self.assertGreaterEqual(len(errs), 2)


class TestRetry(unittest.TestCase):
    def test_http_get_retries_then_succeeds(self):
        calls = {"n": 0}
        real = margin.urllib.request.urlopen

        class R:
            def read(self): return b'{"stat":"OK","keepRate":1}'
            def __enter__(self): return self
            def __exit__(self, *a): pass

        def fake(req, timeout=45):
            calls["n"] += 1
            if calls["n"] < 3:
                raise OSError("temp")
            return R()
        margin.urllib.request.urlopen = fake
        try:
            text = margin.http_get("https://example.invalid/x", timeout=1, retries=3, sleep=0)
            self.assertIn("OK", text)
            self.assertEqual(calls["n"], 3)
        finally:
            margin.urllib.request.urlopen = real


class TestRunMargin(unittest.TestCase):
    def test_write_then_failure_keeps_previous_stale(self):
        out = tempfile.mkdtemp()
        now = dt.datetime(2026, 11, 27, 17, 0, tzinfo=TPE)
        d1 = run_margin.run(out, get=getter(today_empty=True), now=now)
        self.assertFalse(d1["stale"])
        self.assertTrue(os.path.exists(os.path.join(out, "margin_latest.json")))
        self.assertEqual(d1["value"], 170.07)
        def bad(url, timeout=45):
            raise OSError("down")
        d2 = run_margin.run(out, get=bad, now=now)
        self.assertTrue(d2["stale"])
        self.assertEqual(d2["value"], d1["value"])
        self.assertIn("沿用", d2["error"])
        self.assertIsNone(run_margin.run(tempfile.mkdtemp(), get=bad, now=now))

    def test_ci_wires_run_margin_nonfatal(self):
        sh = open(os.path.join(HERE, "ci", "run_ci.sh"), encoding="utf-8").read()
        self.assertIn("run_margin.py", sh)
        self.assertIn("margin_latest.json", sh)
        # 失敗只警告、不讓主流程失敗
        self.assertRegex(sh, r"run_margin\.py \|\| echo \"::warning::")
        yml = os.path.join(HERE, "..", "..", "release", "build", "radar.yml")
        if os.path.exists(yml):
            t = open(yml, encoding="utf-8").read()
            self.assertIn("0 7 * * 1-5", t)
            self.assertIn("30 9 * * 1-5", t)
            self.assertIn("30 13 * * 1-5", t)


if __name__ == "__main__":
    unittest.main()
