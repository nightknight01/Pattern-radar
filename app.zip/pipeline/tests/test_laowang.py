"""v11：老王三型態（四海遊龍／四面楚歌／空方缺口回補）＋註冊表＋指數頁關鍵低點 — 全部假資料。"""
import datetime as dt, os, sys, unittest
import numpy as np
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE); sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from synth import path, make
from radar import config, engine, laowang as LW, backtest as bt
from radar.context import Ctx


def first(fn, ctx, state, lo=0):
    return next((t for t in range(lo, ctx.n) if fn(ctx, t)["state"] == state), None)


class TestDragonChu(unittest.TestCase):
    def test_dragon_entry_first_day_then_hold(self):
        ctx = make(path(100, [(150, 70), (80, 110)]))   # 長跌後反轉上漲：四線最後才一起上彎
        t = first(LW.evaluate_dragon, ctx, "ENTRY", 110)
        self.assertIsNotNone(t)
        self.assertTrue(LW.all_up(ctx, t)); self.assertFalse(LW.all_up(ctx, t - 1))
        vals = LW._vals(ctx, t); self.assertGreater(ctx.c[t], max(vals))
        self.assertEqual(LW.evaluate_dragon(ctx, t + 1)["state"], "HOLD")
        r = LW.evaluate_dragon(ctx, t)
        self.assertEqual(r["direction"], "long"); self.assertGreaterEqual(r["strength"], 50)
        self.assertEqual(set(r["levels"]) >= {"ma5", "ma10", "ma20", "ma100", "stopRef"}, True)
        self.assertEqual(r["levels"]["stopRef"], r["levels"]["ma20"])   # 出場參考 = 月線

    def test_chu_is_mirror(self):
        ctx = make(path(100, [(150, 130), (80, 90)]))
        t = first(LW.evaluate_chu, ctx, "ENTRY", 110)
        self.assertIsNotNone(t); self.assertTrue(LW.all_down(ctx, t)); self.assertLess(ctx.c[t], min(LW._vals(ctx, t)))
        self.assertEqual(LW.evaluate_chu(ctx, t)["direction"], "short")
        self.assertIsNone(first(LW.evaluate_dragon, ctx, "ENTRY", 150))   # 一路下跌不會有四海遊龍

    def test_flat_or_short_history_no_signal(self):
        ctx = make(np.full(200, 50.0))
        self.assertIsNone(first(LW.evaluate_dragon, ctx, "ENTRY")); self.assertIsNone(first(LW.evaluate_chu, ctx, "ENTRY"))
        short = make(path(100, [(60, 120)]))   # < min_bars
        self.assertEqual(LW.evaluate_dragon(short, short.n - 1)["state"], "NO_DATA")

    def test_dragon_end_warning_and_holder_exit(self):
        ctx = make(path(100, [(150, 70), (80, 110), (40, 90)]))
        t = first(LW.evaluate_dragon, ctx, "EXIT_WARNING", 230)
        self.assertIsNotNone(t)
        k = next(k for k in range(t, ctx.n) if ctx.c[k] < LW._exit_ma(ctx, k))
        self.assertEqual(LW.evaluate_dragon(ctx, k, "LONG")["state"], "EXIT")
        x = bt.sim_x3("long", ctx, LW.evaluate_dragon, first(LW.evaluate_dragon, ctx, "ENTRY", 110) + 1)
        self.assertEqual(x["reason"], "cis_exit")   # 回測「均線出場」：收盤跌破 MA20 → 隔日開盤

    def test_params_change_ma_lengths(self):
        cfg = config.get({"laowang": {"ma_lengths": [5, 10, 20, 60], "min_bars": 70}})
        ctx = make(path(100, [(100, 70), (60, 110)]), cfg=cfg)
        self.assertEqual([n for n, _ in LW.mas(ctx)], [5, 10, 20, 60])
        self.assertIsNotNone(first(LW.evaluate_dragon, ctx, "ENTRY", 70))


def gap_ctx(fill=True):
    """平盤 140 根 → 向下跳空（缺口 100→97）→ 再跌 → 反彈回補（fill=True 時最後一根收 100.5 ≥ 上緣 99.5）。"""
    n0 = 140; c = list(np.full(n0, 100.0)); o = list(c); h = [x + 0.5 for x in c]; l = [x - 0.5 for x in c]
    seq = [(97.0, 96.0, 97.5, 95.5), (95.5, 96.0, 96.5, 95.0), (95.0, 94.5, 95.5, 94.0), (94.5, 96.0, 96.2, 94.2),
           (96.0, 98.0, 98.3, 95.8), (98.0, 99.0, 99.2, 97.8)]
    if fill: seq.append((99.0, 100.5, 100.8, 98.8))
    for oo, cc, hh, ll in seq: o.append(oo); c.append(cc); h.append(hh); l.append(ll)
    n = len(c); d0 = dt.date(2025, 1, 1)
    return Ctx([(d0 + dt.timedelta(days=i)).isoformat() for i in range(n)], o, h, l, c, np.full(n, 1e6), config.get())


class TestGapFill(unittest.TestCase):
    def test_entry_on_fill_day(self):
        ctx = gap_ctx(True); t = ctx.n - 1
        g = LW.find_open_down_gap(ctx, t)
        self.assertEqual(g[0], 140); self.assertAlmostEqual(g[1], 99.5); self.assertAlmostEqual(g[2], 97.5)
        r = LW.evaluate_gapfill(ctx, t)
        self.assertEqual(r["state"], "ENTRY"); self.assertEqual(r["direction"], "long")
        self.assertAlmostEqual(r["levels"]["gapTop"], 99.5); self.assertAlmostEqual(r["levels"]["gapLow"], 94.0)
        self.assertEqual([LW.evaluate_gapfill(ctx, k)["state"] for k in range(141, t)], ["WATCH"] * (t - 141))

    def test_no_entry_before_fill_or_after_filled(self):
        self.assertEqual(LW.evaluate_gapfill(gap_ctx(False), gap_ctx(False).n - 1)["state"], "WATCH")
        ctx = gap_ctx(True)
        ext = Ctx(ctx.dates + ["2026-01-01"], list(ctx.o) + [100.5], list(ctx.h) + [101.0], list(ctx.l) + [100.0],
                  list(ctx.c) + [100.8], list(ctx.v) + [1e6], ctx.cfg)
        self.assertEqual(LW.evaluate_gapfill(ext, ext.n - 1)["state"], "WATCH")   # 已回補過 → 不重複

    def test_small_gap_ignored(self):
        cfg = config.get({"laowang": {"gap_min_pct": 0.05}})
        ctx = gap_ctx(True); ctx.cfg = cfg
        self.assertEqual(LW.evaluate_gapfill(ctx, ctx.n - 1)["state"], "WATCH")


class TestRegistry(unittest.TestCase):
    def test_rows_and_listing(self):
        rows = {r[0]: r for r in engine.REGISTRY}
        self.assertEqual(engine.LAOWANG_IDS, ["lw_dragon", "lw_chu", "lw_gapfill"])
        self.assertEqual(rows["lw_dragon"][2], ["long"]); self.assertEqual(rows["lw_chu"][2], ["short"]); self.assertEqual(rows["lw_gapfill"][2], ["long"])
        for pid in engine.LAOWANG_IDS:
            self.assertEqual(rows[pid][3], "X3"); self.assertEqual(rows[pid][4], "laowang"); self.assertTrue(engine.is_state_pattern(pid))
        self.assertEqual(len(engine.TSAI_IDS), 12); self.assertNotIn("lw_dragon", engine.TSAI_IDS)
        lp = {p["id"]: p for p in engine.list_patterns("long")}
        self.assertIn("lw_dragon", lp); self.assertIn("lw_gapfill", lp); self.assertNotIn("lw_chu", lp)
        self.assertIn("老王", lp["lw_dragon"]["source"])

    def test_evaluate_symbol_emits_laowang(self):
        ctx = make(path(100, [(150, 70), (80, 110)]))
        t = first(LW.evaluate_dragon, ctx, "ENTRY", 110)
        sub = Ctx(ctx.dates[:t + 1], ctx.o[:t + 1], ctx.h[:t + 1], ctx.l[:t + 1], ctx.c[:t + 1], ctx.v[:t + 1], ctx.cfg)
        sigs = [s for s in engine.evaluate_symbol(sub, t) if s["patternId"] == "lw_dragon"]
        self.assertEqual(len(sigs), 1); s = sigs[0]
        self.assertEqual((s["state"], s["direction"], s["fresh"]), ("ENTRY", "long", True))
        self.assertIn("ma100", s["levels"]); self.assertEqual(s["date"], sub.dates[t])

    def test_defaults_and_key_lows(self):
        p = config.DEFAULTS["laowang"]
        self.assertEqual(p["ma_lengths"], [5, 10, 20, 100]); self.assertEqual(p["taiex_key_lows"], [39384.85, 37837.05])
        n = LW.key_low_notes(39151.81, p["taiex_key_lows"])
        self.assertIn("低於", n[0]); self.assertIn("高於", n[1])


class TestIndexPass(unittest.TestCase):
    def test_twii_ref_lines_and_laowang_in_detect(self):
        import run_indices as RI
        from test_index_chart import rows_from_close
        rows = rows_from_close(list(path(100, [(150, 70), (80, 110)])))
        cfg = config.get()
        doc = RI.chart_doc(RI.INDICES[[x[0] for x in RI.INDICES].index("twii")], rows, "test", cfg, "2026-11-27T00:00:00+08:00")
        self.assertEqual([r["price"] for r in doc["ref_lines"]], [39384.85, 37837.05])
        self.assertTrue(any("老王關鍵低點" in x for x in doc["notes"]))
        self.assertTrue(all(s["patternId"] in engine.TSAI_IDS + engine.LAOWANG_IDS for s in doc["signals"]))
        self.assertTrue(any(s["patternId"].startswith("lw_") for s in doc["signals"]))
        spx = RI.chart_doc(RI.INDICES[0], rows, "test", cfg, "x")
        self.assertEqual(spx["ref_lines"], [])   # 關鍵低點只給台股加權



class TestWebSketch(unittest.TestCase):
    def test_every_builtin_pattern_has_card_sketch_and_laowang_tag(self):
        js = open(os.path.join(HERE, "..", "web", "app.js"), encoding="utf-8").read()
        import re
        block = js[js.index("const SKETCH = {"):js.index("};", js.index("const SKETCH = {"))]
        keys = set(re.findall(r"(\w+):\s*\"", block))
        for pid, *_ in engine.REGISTRY: self.assertIn(pid, keys)
        self.assertIn('role === "laowang"', js); self.assertIn("老王", js)
        sw = open(os.path.join(HERE, "..", "web", "sw.js"), encoding="utf-8").read()
        self.assertIn("radar-shell-v12", sw); self.assertIn("fx_twd.json", sw)


if __name__ == "__main__":
    unittest.main()
