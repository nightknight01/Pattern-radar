"""v9：量測漲跌幅（1 倍／2 倍型態高度）— radar.engine.measured_move 與前端 app.js measuredMove 一致。"""
import json, os, re, shutil, subprocess, sys, unittest
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE); sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from synth import path, make
from radar import engine, config


def sig_of(ctx, pid):
    return next((s for s in engine.evaluate_symbol(ctx, ctx.n - 1, enabled={pid}) if s["patternId"] == pid), None)


class MeasuredMove(unittest.TestCase):
    def test_m_top_two_peaks_and_targets(self):
        c = path(80, [(40, 80), (30, 100), (15, 90), (15, 99.5), (12, 90.5), (1, 87)])
        s = sig_of(make(c), "m_top"); self.assertIsNotNone(s); m = s["move"]
        self.assertEqual((m["kind"], m["basis"]), ("drop", "M頭"))
        self.assertEqual([p["key"] for p in m["peaks"]], ["H1", "H2"])
        peak = max(p["price"] for p in m["peaks"]); neck = s["levels"]["neckline"]
        self.assertAlmostEqual(m["extreme"], peak, places=2); self.assertAlmostEqual(m["neckline"], neck, places=2)
        self.assertAlmostEqual(m["height"], peak - neck, places=2)
        self.assertAlmostEqual(m["t1"], neck - (peak - neck), places=2); self.assertAlmostEqual(m["t2"], neck - 2 * (peak - neck), places=2)
        self.assertAlmostEqual(m["t1"], s["levels"]["target"], places=2)            # 1 倍 = 型態原本的滿足點
        self.assertAlmostEqual(m["t1_pct"], (m["t1"] / neck - 1) * 100, places=1); self.assertLess(m["t2_pct"], m["t1_pct"])
        self.assertIn("close", m); self.assertTrue(m["peaks"][0]["date"])

    def test_hs_top_sloped_neckline_uses_head_day(self):
        geo = {"LS": {"idx": 10, "price": 110}, "T1": {"idx": 20, "price": 100}, "Head": {"idx": 30, "price": 130},
               "T2": {"idx": 40, "price": 104}, "RS": {"idx": 50, "price": 112}, "neckline": {"slope": 0.2, "x0": 20, "y0": 100}}
        m = engine.measured_move("hs_top", {"neckline": 106.0, "target": 0}, geo)
        self.assertAlmostEqual(m["neck_ref"], 102.0); self.assertAlmostEqual(m["height"], 28.0)
        self.assertAlmostEqual(m["t1"], 78.0); self.assertAlmostEqual(m["t2"], 50.0); self.assertEqual(m["basis"], "頭肩頂")

    def test_bottom_rise(self):
        geo = {"L1": {"idx": 5, "price": 80}, "H1": {"idx": 20, "price": 90}, "L2": {"idx": 35, "price": 80.5}}
        m = engine.measured_move("w_bottom", {"neckline": 90.0}, geo, close=91)
        self.assertEqual(m["kind"], "rise"); self.assertAlmostEqual(m["height"], 10.0)
        self.assertAlmostEqual(m["t1"], 100.0); self.assertAlmostEqual(m["t2"], 110.0); self.assertAlmostEqual(m["t1_from_close_pct"], round((100 / 91 - 1) * 100, 2))

    def test_not_applicable(self):
        self.assertIsNone(engine.measured_move("bear_flag", {"neckline": 10}, {"H1": {"idx": 1, "price": 12}}))
        self.assertIsNone(engine.measured_move("m_top", {"neckline": 10}, {}))
        self.assertIsNone(engine.measured_move("m_top", {"neckline": 10}, {"H1": {"idx": 1, "price": 9}}))   # 高度 ≤ 0
        self.assertIsNone(engine.measured_move("m_top", {}, {"H1": {"idx": 1, "price": 12}}))

    def test_no_pattern_no_move(self):
        ctx = make([100 + 0.1 * i for i in range(200)])
        self.assertEqual([s for s in engine.evaluate_symbol(ctx, ctx.n - 1, enabled=set(engine.TSAI_IDS)) if "move" in s], [])

    @unittest.skipUnless(shutil.which("node"), "node 不在")
    def test_js_fallback_matches_python(self):
        """前端遇到沒有 move 的舊資料時由幾何現算，結果要跟 Python 一樣。"""
        with open(os.path.join(HERE, "..", "web", "app.js"), encoding="utf-8") as f: src = f.read()
        a = src.index("const MOVE_SPECS"); b = src.index("const PEAK_ZH")
        cases = []
        c1 = path(80, [(40, 80), (30, 100), (15, 90), (15, 99.5), (12, 90.5), (1, 87)]); ctx1 = make(c1)
        cases.append((ctx1, sig_of(ctx1, "m_top")))
        geo = {"LS": {"idx": 10, "price": 110}, "T1": {"idx": 20, "price": 100}, "Head": {"idx": 30, "price": 130},
               "T2": {"idx": 40, "price": 104}, "RS": {"idx": 50, "price": 112}, "neckline": {"slope": 0.2, "x0": 20, "y0": 100}}
        dates = [f"2026-01-{i:02d}" if i < 32 else f"2026-02-{i - 31:02d}" for i in range(1, 61)]
        py_hs = engine.measured_move("hs_top", {"neckline": 106.0}, geo, dates, 105.0)
        jgeo = {k: dict(v, date=dates[v["idx"]]) for k, v in geo.items() if "idx" in v}
        jgeo["neckline"] = {"p0": {"date": dates[20], "price": 100}, "p1": {"date": dates[50], "price": 106.0}}
        js_in = [{"sig": {k: v for k, v in cases[0][1].items() if k != "move"}, "time": cases[0][0].dates, "close": float(ctx1.c[-1])},
                 {"sig": {"patternId": "hs_top", "levels": {"neckline": 106.0}, "geometry": jgeo}, "time": dates, "close": 105.0}]
        prog = "const fmt=(x)=>x;const esc=(x)=>x;\n" + src[a:b] + "\nconst I=" + json.dumps(js_in) + \
               ";console.log(JSON.stringify(I.map((c)=>measuredMove(c.sig,c.time,c.close))));"
        out = json.loads(subprocess.run(["node", "-e", prog], capture_output=True, text=True, check=True).stdout)
        for js, py in ((out[0], cases[0][1]["move"]), (out[1], py_hs)):
            for k in ("extreme", "neck_ref", "neckline", "height", "height_pct", "t1", "t2", "t1_pct", "t2_pct", "t1_from_close_pct", "t2_from_close_pct"):
                self.assertAlmostEqual(js[k], py[k], places=1, msg=k)


if __name__ == "__main__":
    unittest.main()
