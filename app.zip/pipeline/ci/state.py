#!/usr/bin/env python3
"""GitHub 版的資料狀態（state）打包／還原。

radar.sqlite 有 248 MB，放不進 GitHub（單檔上限 100 MB、網頁上傳 25 MB），所以改存成「壓縮後的小檔」：
  bars_YYYY.csv.xz   日K（每年一檔，約 8–9 MB；只有當年那一檔每天會變）
  meta.sqlite.xz     其他所有資料表（不含 daily_bars；backtest_trades/backtest_runs 每天重算，不存）
  extra.tar.xz       db/scans、db/alerts（信箱已遮罩）、fetch_summary、cache/health.json、近 45 天的原始回應快取、
                     上一次產生的網頁資料 JSON（抓取失敗時拿來重新上線）
  state_info.json    最後處理的交易日 T、params 雜湊、各年日K筆數、產生時間

usage:
  python3 ci/state.py export OUT_DIR [--reuse IN_DIR]   # 從 db/radar.sqlite 打包
  python3 ci/state.py import IN_DIR                     # 還原成 db/radar.sqlite（覆蓋）
  python3 ci/state.py info [IN_DIR]                     # 印出 state_info.json（或目前 DB 的 T）
"""
import argparse, csv, datetime as dt, glob, hashlib, io, json, lzma, os, re, shutil, sqlite3, subprocess, sys, tarfile, time

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))     # pipeline/
sys.path.insert(0, HERE)
from radar import db  # noqa: E402

WEB = os.path.abspath(os.path.join(HERE, "..", "web"))
BAR_COLS = ["symbol", "date", "open", "high", "low", "close", "volume_shares", "turnover", "trades", "chg", "chg_known", "source"]
SKIP_TABLES = {"daily_bars", "backtest_trades", "backtest_runs"}
WEB_DATA = ["scan_latest.json", "summary_latest.json", "fundamentals_latest.json", "health_latest.json",
            "backtest_latest.json", "backtest_trades.json", "alert_preview.html"]
DBP = lambda: os.environ.get("RADAR_DB") or db.DB_PATH
RAW_KEEP = re.compile(r"^(twse|tpex|t86|tpex_insti)_(\d{8})\.json$")
EMAIL = re.compile(r"([A-Za-z0-9._%+-]{1,2})[A-Za-z0-9._%+-]*@([A-Za-z0-9.-]+\.[A-Za-z]{2,})")


def _xz(data: bytes) -> bytes:
    """xz with all cores when the CLI exists (GitHub runner / box), else python lzma."""
    if shutil.which("xz"):
        return subprocess.run(["xz", "-T0", "-6", "-c"], input=data, stdout=subprocess.PIPE, check=True).stdout
    return lzma.compress(data, preset=6)


def _fmt(x):
    if x is None: return ""
    if isinstance(x, float):
        return str(int(x)) if x.is_integer() else repr(x)
    return str(x)


def params_hash():
    p = os.environ.get("RADAR_PARAMS")
    blob = open(p, "rb").read() if p and os.path.exists(p) else b""
    return hashlib.sha1(blob).hexdigest()[:12]


def latest_T(con):
    return con.execute("SELECT max(date) FROM trading_days WHERE twse=1 AND tpex=1").fetchone()[0]


def export(out, reuse=None):
    t0 = time.time(); os.makedirs(out, exist_ok=True)
    con = sqlite3.connect(DBP())
    T = latest_T(con)
    old = json.load(open(os.path.join(reuse, "state_info.json"))) if reuse and os.path.exists(os.path.join(reuse, "state_info.json")) else {}
    years = [r[0] for r in con.execute("SELECT DISTINCT substr(date,1,4) FROM daily_bars ORDER BY 1")]
    counts = {}
    for y in years:
        n, mx = con.execute("SELECT count(*), max(date) FROM daily_bars WHERE date LIKE ?", (f"{y}%",)).fetchone()
        counts[y] = [n, mx]
        fn = f"bars_{y}.csv.xz"
        if reuse and old.get("bar_counts", {}).get(y) == [n, mx] and os.path.exists(os.path.join(reuse, fn)):
            shutil.copyfile(os.path.join(reuse, fn), os.path.join(out, fn)); continue   # unchanged year: reuse
        buf = io.StringIO(); w = csv.writer(buf, lineterminator="\n"); w.writerow(BAR_COLS)
        for r in con.execute(f"SELECT {','.join(BAR_COLS)} FROM daily_bars WHERE date LIKE ? ORDER BY symbol,date", (f"{y}%",)):
            w.writerow([_fmt(x) for x in r])
        open(os.path.join(out, fn), "wb").write(_xz(buf.getvalue().encode()))
    con.close()
    # meta: everything except the big / regenerated tables
    tmp = os.path.join(out, "meta.sqlite")
    if os.path.exists(tmp): os.remove(tmp)
    src = sqlite3.connect(DBP()); dst = sqlite3.connect(tmp)
    dst.executescript(db.SCHEMA)
    tables = [r[0] for r in src.execute("SELECT name FROM sqlite_master WHERE type='table'")]
    for t in tables:
        if t in SKIP_TABLES: continue
        cols = [r[1] for r in src.execute(f"PRAGMA table_info([{t}])")]
        rows = src.execute(f"SELECT {','.join('['+c+']' for c in cols)} FROM [{t}]").fetchall()
        if rows:
            dst.executemany(f"INSERT OR REPLACE INTO [{t}] ({','.join('['+c+']' for c in cols)}) VALUES ({','.join('?' * len(cols))})", rows)
    dst.commit(); dst.execute("VACUUM"); dst.close(); src.close()
    open(tmp + ".xz", "wb").write(_xz(open(tmp, "rb").read())); os.remove(tmp)
    # extra files
    bio = io.BytesIO()
    with tarfile.open(fileobj=bio, mode="w") as tar:
        def add(path, arc, scrub=False):
            if not os.path.isfile(path): return
            data = open(path, "rb").read()
            if scrub: data = EMAIL.sub(lambda m: m.group(1) + "***@" + m.group(2), data.decode("utf-8", "replace")).encode()
            ti = tarfile.TarInfo(arc); ti.size = len(data); ti.mtime = int(os.path.getmtime(path)); tar.addfile(ti, io.BytesIO(data))
        for f in sorted(glob.glob(os.path.join(HERE, "db", "scans", "scan_*.json")))[-30:]:
            add(f, "pipeline/db/scans/" + os.path.basename(f))
        for f in sorted(glob.glob(os.path.join(HERE, "db", "alerts", "alert_*")))[-180:]:
            add(f, "pipeline/db/alerts/" + os.path.basename(f), scrub=True)
        for f in ("fetch_summary.json", "last_scan_stats.json"):
            add(os.path.join(HERE, "db", f), "pipeline/db/" + f)
        add(os.path.join(HERE, "cache", "health.json"), "pipeline/cache/health.json")
        lim = (dt.date.fromisoformat(T) - dt.timedelta(days=45)).strftime("%Y%m%d") if T else "0"
        for f in sorted(glob.glob(os.path.join(HERE, "cache", "raw", "*.json"))):
            m = RAW_KEEP.match(os.path.basename(f))
            if m and m.group(2) >= lim: add(f, "pipeline/cache/raw/" + os.path.basename(f))
        for f in WEB_DATA + [os.path.basename(x) for x in sorted(glob.glob(os.path.join(WEB, "bars_*.json")))]:
            add(os.path.join(WEB, f), "web/" + f, scrub=f.endswith(".html"))
    open(os.path.join(out, "extra.tar.xz"), "wb").write(_xz(bio.getvalue()))
    info = dict(schema=1, T=T, params_hash=params_hash(), bar_counts=counts,
                web_T=_web_T(), created_at=dt.datetime.now(dt.timezone(dt.timedelta(hours=8))).isoformat(timespec="seconds"),
                export_sec=round(time.time() - t0, 1))
    json.dump(info, open(os.path.join(out, "state_info.json"), "w"), ensure_ascii=False, indent=1)
    sizes = {f: round(os.path.getsize(os.path.join(out, f)) / 1e6, 2) for f in sorted(os.listdir(out))}
    print(json.dumps(dict(info, sizes_mb=sizes), ensure_ascii=False))


def _web_T():
    try: return json.load(open(os.path.join(WEB, "summary_latest.json")))["trade_date"]
    except Exception: return None


def import_(src_dir, root=None):
    t0 = time.time(); P = DBP()
    if os.path.exists(P): os.remove(P)
    os.makedirs(os.path.dirname(P), exist_ok=True)
    open(P, "wb").write(lzma.decompress(open(os.path.join(src_dir, "meta.sqlite.xz"), "rb").read()))
    con = db.connect()   # applies SCHEMA (creates skipped tables/indexes)
    con.execute("DROP INDEX IF EXISTS ix_bars_date")
    n = 0
    for f in sorted(glob.glob(os.path.join(src_dir, "bars_*.csv.xz"))):
        rd = csv.reader(io.StringIO(lzma.decompress(open(f, "rb").read()).decode()))
        hdr = next(rd); assert hdr == BAR_COLS, hdr
        num = lambda s: None if s == "" else float(s)
        it = lambda s: None if s == "" else int(float(s))
        rows = [(r[0], r[1], num(r[2]), num(r[3]), num(r[4]), num(r[5]), it(r[6]), num(r[7]), it(r[8]), r[11], None, num(r[9]), it(r[10]))
                for r in rd]
        con.executemany("INSERT OR REPLACE INTO daily_bars (symbol,date,open,high,low,close,volume_shares,turnover,trades,source,fetched_at,chg,chg_known) "
                        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)
        n += len(rows)
    con.commit()
    con.execute("CREATE INDEX IF NOT EXISTS ix_bars_date ON daily_bars(date)"); con.commit()
    root = root or os.path.abspath(os.path.join(HERE, ".."))
    ex = os.path.join(src_dir, "extra.tar.xz")
    if os.path.exists(ex):
        with tarfile.open(fileobj=io.BytesIO(lzma.decompress(open(ex, "rb").read()))) as tar:
            for m in tar.getmembers():
                if m.name.startswith("/") or ".." in m.name.split("/"): continue
                try: tar.extract(m, root, filter="data")
                except TypeError: tar.extract(m, root)
    print(json.dumps(dict(bars=n, T=latest_T(con), sec=round(time.time() - t0, 1)), ensure_ascii=False))


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("cmd", choices=["export", "import", "info"]); ap.add_argument("dir", nargs="?")
    ap.add_argument("--reuse"); a = ap.parse_args()
    if a.cmd == "export": export(a.dir, a.reuse)
    elif a.cmd == "import": import_(a.dir)
    else:
        if a.dir: print(open(os.path.join(a.dir, "state_info.json")).read())
        else: print(json.dumps(dict(T=latest_T(db.connect()), params_hash=params_hash(), web_T=_web_T())))
