#!/usr/bin/env bash
# 型態雷達：GitHub Actions 每日批次（由 .github/workflows/radar.yml 呼叫）。
# 目錄：$GITHUB_WORKSPACE = repo（app.zip、params.json、seed_*）；$B = 解壓後的 app（pipeline/ + web/）
# 狀態：存在 repo 的 Release「radar-state」附檔 state-*.tar（每天一份，保留最近 7 份）；第一次用 repo 裡的 seed_* 檔。
# 結果：$B/web = 要上線的網站；狀態寫到 $GITHUB_OUTPUT（status=ok|fetch_failed|send_failed|...）。
set -uo pipefail
WS="${GITHUB_WORKSPACE:-$(pwd)}"; B="${RADAR_BUILD:-$WS/_build}"; SIN="$WS/_state_in"; SOUT="$WS/_state_out"
REL="radar-state"; KEEP=7; WORKERS="${RADAR_WORKERS:-4}"; FORCE="${FORCE:-false}"; OFFLINE="${RADAR_OFFLINE:-0}"
export TZ=Asia/Taipei RADAR_PARAMS="$WS/params.json" PYTHONUNBUFFERED=1
out() { echo "$1=$2" >> "${GITHUB_OUTPUT:-/dev/null}"; echo "::notice::$1=$2"; }
log() { echo "::group::$1"; }; endlog() { echo "::endgroup::"; }
STATUS=ok
cd "$B/pipeline" || exit 1

log "1. 檢查 params.json"
python3 -c "from radar import config; config.get(); print('params OK', config.backtest_defaults())" || { out status params_invalid; exit 1; }
endlog

log "2. 還原資料狀態"
rm -rf "$SIN" "$SOUT"; mkdir -p "$SIN" "$SOUT"; SRC=none
if [ "$OFFLINE" != "1" ] && gh release view "$REL" >/dev/null 2>&1; then
  LATEST=$(gh release view "$REL" --json assets --jq '[.assets[].name | select(startswith("state-"))] | sort | last // ""')
  if [ -n "$LATEST" ]; then gh release download "$REL" -p "$LATEST" -D "$SIN" && tar -xf "$SIN/$LATEST" -C "$SIN" && rm "$SIN/$LATEST" && SRC="release:$LATEST"; fi
fi
if [ "$SRC" = none ] && ls "$WS"/seed_meta.sqlite.xz >/dev/null 2>&1; then
  for f in "$WS"/seed_*; do cp "$f" "$SIN/$(basename "$f" | sed 's/^seed_//')"; done; SRC=seed
fi
echo "state source: $SRC"; out state_source "$SRC"
if [ "$SRC" != none ]; then python3 ci/state.py import "$SIN" || { out status state_import_failed; exit 1; }; fi
PREV_T=$(python3 -c "from radar import db; print(db.connect().execute(\"SELECT max(date) FROM trading_days WHERE twse=1 AND tpex=1\").fetchone()[0] or '')")
PREV_PH=$(python3 -c "import json,sys; print(json.load(open(sys.argv[1])).get('params_hash',''))" "$SIN/state_info.json" 2>/dev/null || echo "")
echo "previous T=$PREV_T params_hash=$PREV_PH"
# 信件連結用的網址（https://<owner>.github.io/<repo>/）
if [ -n "${GITHUB_REPOSITORY:-}" ]; then
  OWNER=$(echo "${GITHUB_REPOSITORY%%/*}" | tr 'A-Z' 'a-z'); REPO="${GITHUB_REPOSITORY#*/}"
  python3 - "$OWNER" "$REPO" <<'PY'
import sys, json, datetime as dt
from radar import db
con = db.connect(); url = f"https://{sys.argv[1]}.github.io/{sys.argv[2]}/"
con.execute("INSERT OR REPLACE INTO settings (key,value_json,updated_at,updated_by_device) VALUES ('app_base_url',?,?,?)",
            (json.dumps(url), dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "github-actions")); con.commit(); print("app_base_url", url)
PY
fi
endlog

log "3. 抓官方資料（TWSE／TPEx）"
if [ -n "$PREV_T" ]; then START=$(date -d "$PREV_T -10 days" +%F); else START=2024-01-02; fi
FETCH_OK=1
if [ "$OFFLINE" = "1" ]; then echo "RADAR_OFFLINE=1 → 不抓資料"; else
  # 先探測連線：GitHub 主機在國外，若證交所／櫃買擋連線就不要空等重試
  P1=$(curl -s -o /dev/null -w "%{http_code}" --max-time 40 -A "Mozilla/5.0" "https://www.twse.com.tw/rwd/zh/afterTrading/MI_INDEX?type=ALLBUT0999&response=json" || echo 000)
  P2=$(curl -s -o /dev/null -w "%{http_code}" --max-time 40 -A "Mozilla/5.0" "https://www.tpex.org.tw/openapi/v1/tpex_cmode" || echo 000)
  echo "connectivity: TWSE=$P1 TPEx=$P2"; out connectivity "TWSE=$P1,TPEx=$P2"
  if [ "$P1" != 200 ] && [ "$P2" != 200 ]; then FETCH_OK=0; echo "::error::連不到證交所與櫃買中心（可能擋國外連線）→ 本次不更新資料"; else
    RUN_START=$(date +%FT%T)
    python3 run_fetch.py --start "$START" --end "$(date +%F)" > "$WS/_fetch.log" 2>&1 || FETCH_OK=0
    tail -n 60 "$WS/_fetch.log"
    python3 - "$RUN_START" <<'PY' || FETCH_OK=0
import json, sys
h = json.load(open("cache/health.json"))
bad = {k: v["last_error"] for k, v in h.items() if (v.get("last_error") or "")[:19] >= sys.argv[1]}
if bad:
    print("::warning::本次有資料源抓取失敗（重試後仍失敗）：" + json.dumps(bad, ensure_ascii=False)[:1500])
    if set(bad) & {"twse", "tpex"}: sys.exit(1)   # 行情來源失敗才算失敗；OpenAPI（基本面等）只警告
print("all sources OK")
PY
  fi
fi
NEW_T=$(python3 -c "from radar import db; print(db.connect().execute(\"SELECT max(date) FROM trading_days WHERE twse=1 AND tpex=1\").fetchone()[0] or '')")
echo "T: $PREV_T → $NEW_T"; out trade_date "$NEW_T"
[ "$FETCH_OK" = 1 ] || STATUS=fetch_failed
endlog

log "4. 掃描／回測／警示"
PH=$(python3 -c "from ci.state import params_hash; print(params_hash())")
WEB_T=$(python3 -c "import json; print(json.load(open('../web/summary_latest.json'))['trade_date'])" 2>/dev/null || echo "")
RECOMPUTE=0; WHY=""
[ "$NEW_T" != "$PREV_T" ] && { RECOMPUTE=1; WHY="新交易日"; }
[ "$PH" != "$PREV_PH" ] && { RECOMPUTE=1; WHY="$WHY params.json 改了"; }
[ "$FORCE" = "true" ] && { RECOMPUTE=1; WHY="$WHY 手動要求重算"; }
[ "$WEB_T" != "$NEW_T" ] && { RECOMPUTE=1; WHY="$WHY 網頁資料($WEB_T)≠T"; }
[ -z "$NEW_T" ] && { RECOMPUTE=0; STATUS=no_data; }
echo "recompute=$RECOMPUTE ($WHY)"; out recomputed "$RECOMPUTE"
if [ "$RECOMPUTE" = 1 ]; then
  python3 run_scan.py --workers "$WORKERS" || { out status scan_failed; exit 1; }
  python3 run_backtest.py --workers "$WORKERS" | tail -n 5 || { out status backtest_failed; exit 1; }
  python3 run_alerts.py | tail -n 20 || { out status alerts_failed; exit 1; }
fi
endlog

log "4b. 00631L 專頁＋全球指數（失敗不影響主流程，沿用上次資料並標示過期）"
# 網頁目錄是每次從 app.zip 解出來的，先把上一份線上 JSON 帶回來當「上次資料」
if [ "$OFFLINE" != "1" ] && [ -n "${GITHUB_REPOSITORY:-}" ]; then
  BASE="https://${OWNER}.github.io/${REPO}"
  for f in indices_latest.json etf_00631L.json; do
    [ -f "../web/$f" ] || curl -sf --max-time 30 "$BASE/$f" -o "../web/$f" || rm -f "../web/$f"; done
fi
[ "$OFFLINE" = "1" ] && ETF_ARGS="--no-fetch" || ETF_ARGS=""
timeout 600 python3 run_etf.py --symbol 00631L $ETF_ARGS || echo "::warning::run_etf 失敗（已忽略）"
if [ "$OFFLINE" != "1" ]; then timeout 300 python3 run_indices.py || echo "::warning::run_indices 失敗（已忽略）"; fi
endlog

log "5. 寄信（看 Secrets）"
python3 ci/send_alert.py; RC=$?
[ "$RC" = 0 ] || { [ "$STATUS" = ok ] && STATUS=send_failed; }
endlog

log "6. 儲存資料狀態"
python3 ci/state.py export "$SOUT" --reuse "$SIN" || { out status state_export_failed; exit 1; }
if [ "$OFFLINE" != "1" ]; then
  NAME="state-$(date +%Y%m%d-%H%M%S).tar"; tar -cf "$WS/$NAME" -C "$SOUT" .
  gh release view "$REL" >/dev/null 2>&1 || gh release create "$REL" --prerelease --title "資料狀態（自動產生，請勿刪除）" \
     --notes "型態雷達每日批次的資料狀態。每天自動更新，保留最近 ${KEEP} 份。刪掉會讓下次執行從 repo 裡的 seed 檔重新開始。"
  if gh release upload "$REL" "$WS/$NAME"; then
    gh release view "$REL" --json assets --jq '[.assets[].name | select(startswith("state-"))] | sort | .[:-'"$KEEP"'] | .[]' | while read -r old; do
      gh release delete-asset "$REL" "$old" -y || true; done
  else STATUS=state_upload_failed; fi
fi
endlog
# 公開 repo 的排程在 60 天沒有活動後會被 GitHub 自動停用；每次執行都用 API 重新啟用（不產生 commit）
if [ "$OFFLINE" != "1" ] && [ -n "${GITHUB_REPOSITORY:-}" ]; then
  gh api -X PUT "repos/$GITHUB_REPOSITORY/actions/workflows/radar.yml/enable" >/dev/null 2>&1 && echo "keepalive ok" || echo "keepalive skipped"
fi
out status "$STATUS"
exit 0
