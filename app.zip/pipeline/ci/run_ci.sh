#!/usr/bin/env bash
# 型態雷達：GitHub Actions 每日批次（由 .github/workflows/radar.yml 呼叫）。
# 目錄：$GITHUB_WORKSPACE = repo（app.zip、params.json、seed_*）；$B = 解壓後的 app（pipeline/ + web/）
# 狀態：存在 repo 的 Release「radar-state」附檔 state-*.tar（每天一份，保留最近 7 份）；第一次用 repo 裡的 seed_* 檔。
# 結果：$B/web = 要上線的網站；狀態寫到 $GITHUB_OUTPUT（status=ok|fetch_failed|send_failed|...）。
set -uo pipefail
WS="${GITHUB_WORKSPACE:-$(pwd)}"; B="${RADAR_BUILD:-$WS/_build}"; SIN="$WS/_state_in"; SOUT="$WS/_state_out"
REL="radar-state"; KEEP=7; WORKERS="${RADAR_WORKERS:-4}"; FORCE="${FORCE:-false}"; OFFLINE="${RADAR_OFFLINE:-0}"
export TZ=Asia/Taipei RADAR_PARAMS="$WS/params.json" PYTHONUNBUFFERED=1
out() { echo "$1=$2" >> "${GITHUB_OUTPUT:-/dev/null}"; echo "::notice::$1=$2"; }
log() { echo "::group::$1"; }; endlog() { echo "::endgroup::"; }
STATUS=ok
cd "$B/pipeline" || exit 1

log "1. 檢查 params.json"
python3 -c "from radar import config; config.get(); print('params OK', config.backtest_defaults())" || { out status params_invalid; exit 1; }
endlog

log "2. 還原資料狀態"
rm -rf "$SIN" "$SOUT"; mkdir -p "$SIN" "$SOUT"; SRC=none
if [ "$OFFLINE" != "1" ] && gh release view "$REL" >/dev/null 2>&1; then
  LATEST=$(gh release view "$REL" --json assets --jq '[.assets[].name | select(startswith("state-"))] | sort | last // ""')
  if [ -n "$LATEST" ]; then gh release download "$REL" -p "$LATEST" -D "$SIN" && tar -xf "$SIN/$LATEST" -C "$SIN" && rm "$SIN/$LATEST" && SRC="release:$LATEST"; fi
fi
if [ "$SRC" = none ] && ls "$WS"/seed_meta.sqlite.xz >/dev/null 2>&1; then
  for f in "$WS"/seed_*; do cp "$f" "$SIN/$(basename "$f" | sed 's/^seed_//')"; done; SRC=seed
fi
echo "state source: $SRC"; out state_source "$SRC"
if [ "$SRC" != none ]; then python3 ci/state.py import "$SIN" || { out status state_import_failed; exit 1; }; fi
PREV_T=$(python3 -c "from radar import db; print(db.connect().execute(\"SELECT max(date) FROM trading_days WHERE twse=1 AND tpex=1\").fetchone()[0] or '')")
PREV_PH=$(python3 -c "import json,sys; print(json.load(open(sys.argv[1])).get('params_hash',''))" "$SIN/state_info.json" 2>/dev/null || echo "")
PREV_EX=$(PREV_T="$PREV_T" python3 -c "import json,os; from radar import db; from ci.state import extras_coverage; print(json.dumps(extras_coverage(db.connect(), os.environ.get('PREV_T') or None)))")
echo "previous T=$PREV_T params_hash=$PREV_PH extras=$PREV_EX"
# 信件連結用的網址（https://<owner>.github.io/<repo>/）
if [ -n "${GITHUB_REPOSITORY:-}" ]; then
  OWNER=$(echo "${GITHUB_REPOSITORY%%/*}" | tr 'A-Z' 'a-z'); REPO="${GITHUB_REPOSITORY#*/}"
  python3 - "$OWNER" "$REPO" <<'PY'
import sys, json, datetime as dt
from radar import db
con = db.connect(); url = f"https://{sys.argv[1]}.github.io/{sys.argv[2]}/"
con.execute("INSERT OR REPLACE INTO settings (key,value_json,updated_at,updated_by_device) VALUES ('app_base_url',?,?,?)",
            (json.dumps(url), dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "github-actions")); con.commit(); print("app_base_url", url)
PY
fi
endlog

log "3. 抓官方資料（TWSE／TPEx）"
if [ -n "$PREV_T" ]; then START=$(date -d "$PREV_T -10 days" +%F); else START=2024-01-02; fi
FETCH_OK=1
if [ "$OFFLINE" = "1" ]; then echo "RADAR_OFFLINE=1 → 不抓資料"; else
  # 先探測連線：GitHub 主機在國外，若證交所／櫃買擋連線就不要空等重試
  P1=$(curl -s -o /dev/null -w "%{http_code}" --max-time 40 -A "Mozilla/5.0" "https://www.twse.com.tw/rwd/zh/afterTrading/MI_INDEX?type=ALLBUT0999&response=json" || echo 000)
  P2=$(curl -s -o /dev/null -w "%{http_code}" --max-time 40 -A "Mozilla/5.0" "https://www.tpex.org.tw/openapi/v1/tpex_cmode" || echo 000)
  echo "connectivity: TWSE=$P1 TPEx=$P2"; out connectivity "TWSE=$P1,TPEx=$P2"
  if [ "$P1" != 200 ] && [ "$P2" != 200 ]; then FETCH_OK=0; echo "::error::連不到證交所與櫃買中心（可能擋國外連線）→ 本次不更新資料"; else
    RUN_START=$(date +%FT%T)
    python3 run_fetch.py --start "$START" --end "$(date +%F)" > "$WS/_fetch.log" 2>&1 || FETCH_OK=0
    tail -n 60 "$WS/_fetch.log"
    python3 - "$RUN_START" <<'PY' || FETCH_OK=0
import json, sys
h = json.load(open("cache/health.json"))
bad = {k: v["last_error"] for k, v in h.items() if (v.get("last_error") or "")[:19] >= sys.argv[1]}
if bad:
    print("::warning::本次有資料源抓取失敗（重試後仍失敗）：" + json.dumps(bad, ensure_ascii=False)[:1500])
    if set(bad) & {"twse", "tpex"}: sys.exit(1)   # 行情來源失敗才算失敗；OpenAPI（基本面等）只警告
print("all sources OK")
PY
  fi
fi
NEW_T=$(python3 -c "from radar import db; print(db.connect().execute(\"SELECT max(date) FROM trading_days WHERE twse=1 AND tpex=1\").fetchone()[0] or '')")
echo "T: $PREV_T → $NEW_T"; out trade_date "$NEW_T"
[ "$FETCH_OK" = 1 ] || STATUS=fetch_failed
endlog

log "4. 掃描／回測／警示"
PH=$(python3 -c "from ci.state import params_hash; print(params_hash())")
WEB_T=$(python3 -c "import json; print(json.load(open('../web/summary_latest.json'))['trade_date'])" 2>/dev/null || echo "")
# >>> decide（tests/test_ci_decide.py 會單獨執行這一段）
# 舊寫法（:-{} 預設值）在 PREV_EX 有值時會多接一個「}」→ JSON 壞掉 → 下面判斷崩潰 → 靜靜略過掃描（2026-11-26 事故）。
[ -n "${PREV_EX:-}" ] || PREV_EX='{}'
rm -f "$WS/_decide.json"
WS="$WS" NEW_T="$NEW_T" PREV_T="$PREV_T" PH="$PH" PREV_PH="$PREV_PH" FORCE="$FORCE" WEB_T="$WEB_T" PREV_EX="$PREV_EX" python3 - <<'PY'
import json, os
from radar import db
from ci.state import decide_recompute, extras_coverage
new_t = os.environ.get("NEW_T") or ""
prev_ex = json.loads(os.environ.get("PREV_EX") or "{}")
new_ex = extras_coverage(db.connect(), new_t or None)
d = decide_recompute(new_t, os.environ.get("PREV_T") or "", os.environ.get("PH") or "",
                     os.environ.get("PREV_PH") or "", os.environ.get("FORCE") or "false",
                     os.environ.get("WEB_T") or "", prev_ex, new_ex)
d["extras_before"] = prev_ex
d["extras_after"] = new_ex
open(os.environ["WS"] + "/_decide.json", "w").write(json.dumps(d, ensure_ascii=False))
print(json.dumps(d, ensure_ascii=False))
PY
DEC_RC=$?
if [ "$DEC_RC" != 0 ] || ! python3 -c "import json,sys; json.load(open(sys.argv[1]))" "$WS/_decide.json" 2>/dev/null; then
  # 判斷步驟失敗：大聲警告，並改成強制全量重算（寧可多算一次，也不要靜靜停在舊資料）
  echo "::error::重算判斷失敗（rc=$DEC_RC）→ 強制重跑掃描＋回測＋警示"
  printf '%s' '{"recompute": 1, "backtest": 1, "why": "判斷失敗→強制重算", "status": "ok", "extras_after": {}}' > "$WS/_decide.json"
  out decide_fallback 1
fi
RECOMPUTE=$(python3 -c "import json; print(json.load(open('$WS/_decide.json')).get('recompute',0))")
DO_BT=$(python3 -c "import json; print(json.load(open('$WS/_decide.json')).get('backtest',0))")
WHY=$(python3 -c "import json; print(json.load(open('$WS/_decide.json')).get('why',''))")
DEC_STATUS=$(python3 -c "import json; print(json.load(open('$WS/_decide.json')).get('status',''))")
EX_AFTER=$(python3 -c "import json; print(json.dumps(json.load(open('$WS/_decide.json')).get('extras_after',{}), ensure_ascii=False))")
echo "recompute=$RECOMPUTE backtest=$DO_BT ($WHY) extras=$EX_AFTER"
# <<< decide
out recomputed "$RECOMPUTE"
out extras "$EX_AFTER"
[ "$DEC_STATUS" = "no_data" ] && STATUS=no_data
python3 -c "
import json
d=json.load(open('$WS/_decide.json'))
e=d.get('extras_after') or {}
if d.get('status')=='ok' and (not e.get('institutional') or not e.get('margin')):
    print('::notice::本次交易日的三大法人或融資融券尚未公布（或為 0 筆）。股價與型態訊號仍會上線；17:30／21:30 補跑會再抓並更新網頁。')
"
if [ "$RECOMPUTE" = 1 ]; then
  python3 run_scan.py --workers "$WORKERS" || { out status scan_failed; exit 1; }
  if [ "$DO_BT" = 1 ]; then
    python3 run_backtest.py --workers "$WORKERS" | tail -n 5 || { out status backtest_failed; exit 1; }
  else
    echo "略過回測（只有籌碼到了，回測不依當日法人／融資，結果不變）"
  fi
  python3 run_alerts.py | tail -n 20 || { out status alerts_failed; exit 1; }
else
  echo "略過掃描／回測／警示（沒有新交易日，籌碼也沒有新增）"
fi
endlog

log "4b. 00631L 專頁＋全球指數＋新台幣匯率＋融資維持率（失敗不影響主流程，沿用上次資料並標示過期）"
# 網頁目錄是每次從 app.zip 解出來的，先把上一份線上 JSON 帶回來當「上次資料」
if [ "$OFFLINE" != "1" ] && [ -n "${GITHUB_REPOSITORY:-}" ]; then
  BASE="https://${OWNER}.github.io/${REPO}"
  IDX_FILES=$(python3 -c "import run_indices as r; print(' '.join('idx_%s.json' % i for i in r.IDS))" 2>/dev/null || true)
  for f in indices_latest.json etf_00631L.json fx_twd.json margin_latest.json $IDX_FILES; do
    [ -f "../web/$f" ] || curl -sf --max-time 30 "$BASE/$f" -o "../web/$f" || rm -f "../web/$f"; done
fi
[ "$OFFLINE" = "1" ] && ETF_ARGS="--no-fetch" || ETF_ARGS=""
timeout 600 python3 run_etf.py --symbol 00631L $ETF_ARGS || echo "::warning::run_etf 失敗（已忽略）"
if [ "$OFFLINE" != "1" ]; then timeout 300 python3 run_indices.py || echo "::warning::run_indices 失敗（已忽略）"; fi
if [ "$OFFLINE" != "1" ]; then timeout 180 python3 run_fx.py || echo "::warning::run_fx（央行新台幣匯率）失敗（已忽略）"; fi
if [ "$OFFLINE" != "1" ]; then timeout 300 python3 run_margin.py || echo "::warning::run_margin（融資／擔保維持率）失敗（已忽略）"; fi
endlog

log "5. 寄信（看 Secrets）"
python3 ci/send_alert.py; RC=$?
[ "$RC" = 0 ] || { [ "$STATUS" = ok ] && STATUS=send_failed; }
endlog

log "6. 儲存資料狀態"
if [ "$RECOMPUTE" = 1 ]; then
  python3 ci/state.py export "$SOUT" --reuse "$SIN" || { out status state_export_failed; exit 1; }
  if [ "$OFFLINE" != "1" ]; then
    NAME="state-$(date +%Y%m%d-%H%M%S).tar"; tar -cf "$WS/$NAME" -C "$SOUT" .
    gh release view "$REL" >/dev/null 2>&1 || gh release create "$REL" --prerelease --title "資料狀態（自動產生，請勿刪除）" \
       --notes "型態雷達每日批次的資料狀態。每天自動更新，保留最近 ${KEEP} 份。刪掉會讓下次執行從 repo 裡的 seed 檔重新開始。"
    if gh release upload "$REL" "$WS/$NAME"; then
      gh release view "$REL" --json assets --jq '[.assets[].name | select(startswith("state-"))] | sort | .[:-'"$KEEP"'] | .[]' | while read -r old; do
        gh release delete-asset "$REL" "$old" -y || true; done
    else STATUS=state_upload_failed; fi
  fi
else
  echo "略過 state 匯出／上傳（沒有新交易日也沒有新籌碼，沿用上次的 radar-state 附檔）"
fi
endlog
# 公開 repo 的排程在 60 天沒有活動後會被 GitHub 自動停用；每次執行都用 API 重新啟用（不產生 commit）
if [ "$OFFLINE" != "1" ] && [ -n "${GITHUB_REPOSITORY:-}" ]; then
  gh api -X PUT "repos/$GITHUB_REPOSITORY/actions/workflows/radar.yml/enable" >/dev/null 2>&1 && echo "keepalive ok" || echo "keepalive skipped"
fi
out status "$STATUS"
exit 0
