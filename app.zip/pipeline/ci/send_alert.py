#!/usr/bin/env python3
"""寄出盤後警示信（只在 GitHub Actions 用）。

讀 run_alerts.py 產生的 db/alerts/alert_YYYYMMDD.{json,txt,html}，用 SMTP 寄出。
帳密只從環境變數（GitHub repository secrets）讀，絕不寫進檔案或輸出：
  SMTP_USER   寄件帳號（例：Gmail 地址）
  SMTP_PASS   SMTP 密碼（Gmail 要用「應用程式密碼」）
  ALERT_TO    收件人，逗號分隔
  SMTP_HOST   選填，預設 smtp.gmail.com；SMTP_PORT 選填，預設 465（SSL）；587 走 STARTTLS
任一必要值沒設 → 印出「略過」並正常結束（exit 0）。
只寄最新交易日、且 4 天內的那一封；同一交易日寄過就不再寄（alert_log status='sent' 記錄）。
寄送失敗 → exit 2（workflow 最後會標成失敗，GitHub 會通知 repo 擁有者）。
"""
import datetime as dt, glob, json, os, smtplib, ssl, sys
from email.message import EmailMessage
from email.utils import make_msgid, formatdate

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, HERE)
from radar import db  # noqa: E402


def main():
    con = db.connect()
    T = con.execute("SELECT max(date) FROM trading_days WHERE twse=1 AND tpex=1").fetchone()[0]
    base = os.path.join(os.environ.get("RADAR_ALERTS_DIR") or os.path.join(HERE, "db", "alerts"), f"alert_{T.replace('-', '')}")
    if not os.path.exists(base + ".json"):
        print(f"send_alert: {T} 沒有警示檔 → 不寄"); return 0
    meta = json.load(open(base + ".json"))
    if not meta.get("would_send"):
        print(f"send_alert: {T} 沒有新內容（依設定不寄空摘要）"); return 0
    today = dt.datetime.now(dt.timezone(dt.timedelta(hours=8))).date()
    if (today - dt.date.fromisoformat(T)).days > 4:
        print(f"send_alert: 最新交易日 {T} 已超過 4 天，不補寄"); return 0
    if con.execute("SELECT 1 FROM alert_log WHERE trade_date=? AND status='sent' LIMIT 1", (T,)).fetchone() or meta.get("sent"):
        print(f"send_alert: {T} 已寄過 → 不重寄"); return 0
    user, pw = os.environ.get("SMTP_USER", "").strip(), os.environ.get("SMTP_PASS", "").strip()
    to = [x.strip() for x in os.environ.get("ALERT_TO", "").split(",") if x.strip()]
    if not (user and pw and to):
        print("send_alert: 略過 — repo 的 Secrets 還沒設定 SMTP_USER / SMTP_PASS / ALERT_TO（只產生預覽，不寄）"); return 0
    txt = open(base + ".txt", encoding="utf-8").read()
    body = txt.split("\n\n", 1)[1] if "\n\n" in txt else txt   # drop the To:/Subject: preview header
    msg = EmailMessage()
    msg["Subject"] = meta["subject"]; msg["From"] = f"型態雷達 <{user}>"; msg["To"] = ", ".join(to)
    msg["Date"] = formatdate(localtime=False); mid = make_msgid(domain="pattern-radar"); msg["Message-ID"] = mid
    msg.set_content(body)
    if os.path.exists(base + ".html"):
        msg.add_alternative(open(base + ".html", encoding="utf-8").read(), subtype="html")
    host = os.environ.get("SMTP_HOST", "").strip() or "smtp.gmail.com"
    port = int(os.environ.get("SMTP_PORT", "").strip() or 465)
    try:
        if port == 465:
            with smtplib.SMTP_SSL(host, port, context=ssl.create_default_context(), timeout=60) as s:
                s.login(user, pw); s.send_message(msg)
        else:
            with smtplib.SMTP(host, port, timeout=60) as s:
                s.starttls(context=ssl.create_default_context()); s.login(user, pw); s.send_message(msg)
    except Exception as e:  # never print credentials; the exception text from smtplib does not contain them
        print(f"send_alert: 寄送失敗：{type(e).__name__}: {str(e)[:200]}"); return 2
    now = dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
    con.execute("UPDATE alert_log SET status='sent', sent_at=?, message_id=?, updated_at=?, updated_by_device='github-actions' "
                "WHERE trade_date=? AND status='dry_run'", (now, mid, now, T))
    con.commit()
    meta.update(sent=True, mode="sent", sent_at=now, note="已由 GitHub Actions 寄出。")
    json.dump(meta, open(base + ".json", "w"), ensure_ascii=False, indent=1)
    print(f"send_alert: 已寄出 {T}｜{meta['subject']}｜收件人 {len(to)} 位")
    return 0


if __name__ == "__main__":
    sys.exit(main())
